﻿# game/script.rpy:461
translate italian start_228acfba:

    # "Hi! I'm Vulpx, the person who translated this novel. I hope you enjoy the experience."
    "Ciao! Sono Vulpx, la persona che ha tradotto questo romanzo. Spero che la lettura ti piaccia."

# game/script.rpy:462
translate italian start_f4a59e50:

    # "If you want to know more about my work, you can follow me on {a=https://x.com/VulpxVenandi25}{color=#00acee}Twitter{/color}{/a} or visit my {a=https://vulpxvenandi25.github.io/}{color=#004030}Website{/color}{/a}."
    "Se vuoi saperne di più sul mio lavoro, puoi seguirmi su {a=https://x.com/VulpxVenandi25}{color=#00acee}Twitter{/color}{/a} o visitare il mio {a=https://vulpxvenandi25.github.io/}{color=#004030}Sito Web{/color}{/a}."

# game/script.rpy:463
translate italian start_e5949be7:

    # "You can also support me with a donation at my {a=https://ko-fi.com/vulpxvenandi25}{color=#FF5E5B}Ko-fi{/color}{/a}."
    "Puoi anche supportarmi con una donazione sul mio {a=https://ko-fi.com/vulpxvenandi25}{color=#FF5E5B}Ko-fi{/color}{/a}."

# game/script.rpy:464
translate italian start_f1450563:

    # "And without further ado, I leave you with this novel called \"[config.name]\"."
    "E senza ulteriori indugi, vi lascio con questo romanzo intitolato \"[config.name]\"."
