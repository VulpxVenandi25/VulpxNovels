﻿# game/act1.rpy:5
translate italian act1_92fdd6e9:

    # centered "{i}Why…?"
    centered "{i}Perché…?"

# game/act1.rpy:8
translate italian act1_830ead0c:

    # "Within the city limits of Sonora, the people who reside here live and die by its motto: ‘Turn a penny into a million!’."
    "All'interno dei confini della città di Sonora, gli abitanti vivono e muoiono secondo il motto: \"Trasforma un centesimo in un milione!\"."

# game/act1.rpy:9
translate italian act1_ed108da8:

    # "That’s right – even I started to foolishly believe it. That everyone within these lines was intellectual equals, and that all it took to become someone grand and elite was a little perseverance, a bit of skill… and a lot of luck."
    "Esatto, persino io ho iniziato a crederci ingenuamente. Che tutti all'interno di queste righe fossero intellettualmente uguali e che per diventare qualcuno di importante e di alto livello bastassero un po' di perseveranza, un po' di abilità... e tanta fortuna."

# game/act1.rpy:10
translate italian act1_b97ff407:

    # "That, in the ocean of lights, in the sea of people, I could escape the bounds of being nothing more than a minnow, pulled by the current and helplessly toyed with by the sharks of this world."
    "Che, nell'oceano di luci, nel mare di persone, potessi sfuggire ai limiti dell'essere nient'altro che un pesciolino, trascinato dalla corrente e in balia degli squali di questo mondo."

# game/act1.rpy:11
translate italian act1_941dd8a9:

    # "But, just like sharks, the elites of this city can’t stop moving, even for a second. Those who do meet the same fate as their aquatic counterparts."
    "Ma, proprio come gli squali, le élite di questa città non riescono a fermarsi, nemmeno per un secondo. Chi lo fa, subisce la stessa sorte delle loro controparti acquatiche."

# game/act1.rpy:12
translate italian act1_df641876:

    # "And that meant the most dangerous enemy to a shark, who cannot sleep… is the foolish minnow who dares to dream."
    "E questo significava che il nemico più pericoloso per uno squalo, che non può dormire... è il piccolo pesce sciocco che osa sognare."

# game/act1.rpy:14
translate italian act1_5cbebd49:

    # centered "{i}So, why…?"
    centered "{i}Allora, perché...?"

# game/act1.rpy:16
translate italian act1_ce1d5703:

    # tr_text "Well, then. That’s… how much? Oh, right…"
    tr_text "Bene, allora. Quanto costa? Oh, giusto…"

# game/act1.rpy:19
translate italian act1_cb241121:

    # tr_text2 "Twelve-thousand dollars. You have the money, don’t you?"
    tr_text2 "Dodicimila dollari. Hai i soldi, vero?"

# game/act1.rpy:20
translate italian act1_44d3afcd:

    # tr_text3 "Aw, don't look so distraught. \nSorry to clip your wings, Valentine."
    tr_text3 "Oh, non fare quella faccia sconvolta. Mi dispiace di averti tarpato le ali, Valentine."

# game/act1.rpy:21
translate italian act1_a9ed576d:

    # tr_text "But you really should’ve known better~"
    tr_text "Ma avresti dovuto pensarci meglio~"

# game/act1.rpy:26
translate italian act1_ef767577:

    # "…or so I thought."
    "…o almeno così credevo."

# game/act1.rpy:27
translate italian act1_6ca22e14:

    # "But sometimes, a fool isn’t a visionary, a secret genius whose ways of thinking defy the norm and set you free."
    "Ma a volte, uno sciocco non è un visionario, un genio segreto il cui modo di pensare sfida la norma e ti libera."

# game/act1.rpy:29
translate italian act1_f105c54a:

    # centered "Why… was I so stupid?!"
    centered "Perché... sono stato così stupido?!"

# game/act1.rpy:32
translate italian act1_fbd7b7f9:

    # "Sometimes… {w}a fool is just a fool."
    "A volte… {w}uno sciocco è solo uno sciocco."

# game/act1.rpy:35
translate italian act1_6962edba:

    # centered "24 hours earlier.{w}\nHanasaka Bar & Inn"
    centered "24 ore prima.{w}\nHanasaka Bar & Inn"

# game/act1.rpy:39
translate italian act1_a2abb429:

    # "Light reflects from the rain-soaked asphalt like a hazy mirror, rippling on occasion from the droplets still falling to the ground."
    "La luce si riflette sull'asfalto inzuppato di pioggia come uno specchio appannato, creando a tratti delle increspature dovute alle gocce che ancora cadono a terra."

# game/act1.rpy:40
translate italian act1_e814e384:

    # "The signs hanging overhead are a bright, deep red, making my fur shine pink in its neon glow. I bathe in it, lingering for just a second longer than I know I should."
    "Le insegne appese sopra di me sono di un rosso acceso e intenso, che fa brillare la mia pelliccia di rosa nel suo bagliore al neon. Mi ci immergo, indugiando un secondo in più di quanto so che dovrei."

# game/act1.rpy:41
translate italian act1_48f93f51:

    # "Maybe it suits me. At least, more than white does... God knows I don’t match the purity my snow-colored fur exudes."
    "Forse mi dona. Almeno, più del bianco... Dio solo sa quanto io non sia all'altezza della purezza che emana la mia pelliccia color neve."

# game/act1.rpy:43
translate italian act1_b8f76885:

    # "I’m stalling."
    "Sto prendendo tempo."

# game/act1.rpy:44
translate italian act1_6523784f:

    # "I know I am, but even so, I let myself stay still for a few seconds longer, steeling myself for the exchange that’s to come."
    "So di esserlo, ma nonostante ciò, mi concedo di rimanere immobile per qualche secondo in più, preparandomi allo scambio che sta per avvenire."

# game/act1.rpy:45
translate italian act1_92e359d9:

    # "I should be used to it by now. Interviewing is my least favorite part of my job, but it’s also the most important. So, I do what I always do: I swallow down my own desires and focus on what needs to be done."
    "Ormai dovrei esserci abituata. I colloqui sono la parte del mio lavoro che meno mi piace, ma è anche la più importante. Quindi, faccio quello che faccio sempre: metto da parte i miei desideri e mi concentro su ciò che deve essere fatto."

# game/act1.rpy:46
translate italian act1_2cb4dfb8:

    # "With one last exhale, I put my best poker face on and enter the bar."
    "Con un ultimo sospiro, indosso la mia migliore espressione impassibile ed entro nel bar."

# game/act1.rpy:51
translate italian act1_6fe08d8f:

    # "It’s cold inside, contrasting the humid post-rain air of the city streets. Someone plays a piano quietly across the bar, and idle chatter resonates throughout the room."
    "Dentro fa freddo, in netto contrasto con l'aria umida e piovosa delle strade cittadine. Qualcuno suona piano il pianoforte dall'altra parte del bancone e un mormorio sommesso si diffonde nella stanza."

# game/act1.rpy:52
translate italian act1_fd201b63:

    # "It’s fancier than the bars I’m accustomed to, but I relax my shoulders, casually scanning the room while I pretend to fit right in with these higher-class people."
    "È più elegante dei bar a cui sono abituata, ma rilasso le spalle, scrutando distrattamente la sala mentre fingo di trovarmi perfettamente a mio agio tra questa gente di classe superiore."

# game/act1.rpy:53
translate italian act1_baf2c34d:

    # "It doesn’t take long to find him. Sitting alone in a corner booth, drinking what appears to be whiskey, Mr. Yoshida stares out the rain-splattered window, deep in thought. I quietly walk towards him, and without a word, slip into the booth in front of him."
    "Non ci vuole molto per trovarlo. Seduto da solo in un angolo, con in mano quello che sembra whisky, il signor Yoshida fissa il vuoto fuori dalla finestra bagnata dalla pioggia, assorto nei suoi pensieri. Mi avvicino silenziosamente e, senza dire una parola, mi siedo nel tavolo di fronte a lui."

# game/act1.rpy:55
translate italian act1_9c3bb6cd:

    # a uniform stan "…"
    a uniform stan "…"

# game/act1.rpy:57
translate italian act1_8670a23c:

    # "Although I’m certain he knows I’m here, he doesn’t turn to face me, his eyes fixed outside in a trance-like state. I clear my throat to get his attention. If he’s dragging this out on purpose, I want none of it."
    "Sebbene sia certa che sappia che sono qui, non si volta a guardarmi, con lo sguardo fisso fuori, come in trance. Mi schiarisco la gola per attirare la sua attenzione. Se sta prolungando la situazione di proposito, non ne voglio sapere."

# game/act1.rpy:58
translate italian act1_27bbfe2c:

    # "He finally turns to look at me, a far-off look in his eyes as he measures me up, his gaze locked on me."
    "Finalmente si volta a guardarmi, con uno sguardo perso nel vuoto mentre mi scruta, il suo sguardo fisso su di me."

# game/act1.rpy:60
translate italian act1_ee4a9501:

    # y "Ah… good evening, Valentine. A pleasure to finally meet you."
    y "Ah… buonasera, Valentine. È un piacere conoscerti finalmente."

# game/act1.rpy:61
translate italian act1_d91e2571:

    # a "{i}Yoroshiku onegai shimasu, Mr. Yoshida."
    a "{i}Yoroshiku onegai shimasu, signor Yoshida."

# game/act1.rpy:63
translate italian act1_86388077:

    # "He smiles, genuinely, and chuckles as he brings the glass to his maw."
    "Sorride, sinceramente, e ridacchia mentre porta il bicchiere alla bocca."

# game/act1.rpy:65
translate italian act1_7ab080c1:

    # y "{i}Kochira koso… Yoru ga ii janai ka?"
    y "{i}Kochira koso… Yoru ga ii janai ka?"

# game/act1.rpy:68
translate italian act1_77f14b59:

    # a bashful "U-um… sorry. ‘Nice to meet you’ and ‘Where’s the bathroom?’ are kind of the extent of my Japanese."
    a bashful "U-um… scusi. 'Piacere di conoscerla' e 'Dov'è il bagno?' sono praticamente tutto quello che so di giapponese."

# game/act1.rpy:69
translate italian act1_8a625145:

    # y cocky "Hah! Of course. My apologies. I simply said that tonight’s a nice night, isn’t it?"
    y cocky "Ah! Certo. Chiedo scusa. Volevo solo dire che stasera è una bella serata, no?"

# game/act1.rpy:71
translate italian act1_f51c1138:

    # "I glance out the window. Steam rises from the ground as the cold rain meets the hot asphalt, and a small stream of dirt-colored water flows down the sidewalk."
    "Guardo fuori dalla finestra. Il vapore sale dal terreno mentre la pioggia fredda incontra l'asfalto rovente, e un piccolo rivolo d'acqua color terra scorre lungo il marciapiede."

# game/act1.rpy:73
translate italian act1_dfa3e98f:

    # a stan "…if you think so."
    a stan "…se la pensi così."

# game/act1.rpy:74
translate italian act1_827b836d:

    # y hm "You don’t?"
    y hm "Tu no?"

# game/act1.rpy:75
translate italian act1_7da94968:

    # a frown "I’m not a fan of the rain."
    a frown "Non mi piace la pioggia."

# game/act1.rpy:76
translate italian act1_b43f824b:

    # y smile "Hm~ I welcome it. It almost feels like someone up above is trying to wash this city free of sin."
    y smile "Mmm~ Lo accolgo con favore. È quasi come se qualcuno lassù stesse cercando di purificare questa città dal peccato."

# game/act1.rpy:77
translate italian act1_b6875aae:

    # y "Though, it may need to rain much longer for that to happen."
    y "Tuttavia, potrebbe essere necessario che piova molto più a lungo perché ciò accada."

# game/act1.rpy:78
translate italian act1_a7d70aab:

    # a stan "Hm."
    a stan "Hmm."

# game/act1.rpy:80
translate italian act1_41e5754b:

    # "He gives me a knowing smile, dripping with fake nicety."
    "Mi rivolge un sorriso complice, intriso di finta gentilezza."

# game/act1.rpy:82
translate italian act1_6d8c5401:

    # y smile "Of course. You Valentines are all the same. All business, no pleasure."
    y smile "Certo. Voi innamorati siete tutti uguali. Solo affari, niente piacere."

# game/act1.rpy:84
translate italian act1_c86ca835:

    # "He leisurely takes out a cigar from his coat pocket, taking his time lighting it and sucking in a few puffs, his glassy eyes locked on me the whole time as he exhales the smoke against the window."
    "Con calma estrae un sigaro dalla tasca del cappotto, lo accende con pazienza e aspira qualche boccata, tenendo gli occhi vitrei fissi su di me per tutto il tempo mentre espira il fumo contro la finestra."

# game/act1.rpy:86
translate italian act1_33c1a6a5:

    # y "Well, then."
    y "Bene, allora."

# game/act1.rpy:88
translate italian act1_fed5782d:

    # y stan "Talk."
    y stan "Parlare."

# game/act1.rpy:89
translate italian act1_4d8672f4:

    # a "…{w}right."
    a "…{w}destra."

# game/act1.rpy:91
translate italian act1_464483f8:

    # "I slide my voice recorder and notebook onto the table, pen in hand, mirroring his stare."
    "Appoggio sul tavolo il registratore vocale e il taccuino, con la penna in mano, ricambiando il suo sguardo."

# game/act1.rpy:93
translate italian act1_8879b358:

    # "He blinks.{w} I blink back."
    "Lui sbatte le palpebre.{w} Ricambio lo sguardo."

# game/act1.rpy:95
translate italian act1_453bb462:

    # a frown "Megumi Yoshida went missing on March 21st of this year, approximately three months ago. Her last whereabouts are unknown, and the cause of her disappearance has also been questioned."
    a frown "Megumi Yoshida è scomparsa il 21 marzo di quest'anno, circa tre mesi fa. Non si hanno sue notizie e anche le cause della sua scomparsa sono state oggetto di indagine."

# game/act1.rpy:97
translate italian act1_c17d2bbe:

    # y frown "Yes. I’m quite aware of all this, Valentine."
    y frown "Sì. Sono perfettamente al corrente di tutto questo, Valentine."

# game/act1.rpy:99
translate italian act1_e999472e:

    # "He almost hisses this out, the pleasantness he once evoked now nowhere to be seen behind his glare."
    "Lo dice quasi sibilando, la cordialità che un tempo suscitava ora è scomparsa dietro il suo sguardo torvo."

# game/act1.rpy:100
translate italian act1_61821a83:

    # "I swallow hard.{w} I was never any good at stating the facts."
    "Deglutisco a fatica.{w} Non sono mai stato bravo a esporre i fatti."

# game/act1.rpy:102
translate italian act1_33e16fde:

    # a worried "Right… of course. Moving on…"
    a worried "Bene… certo. Andiamo avanti…"

# game/act1.rpy:103
translate italian act1_b764639b:

    # a concern "The police reports I’ve been granted are full of confidential information. That is to say, I haven’t gotten very far with them."
    a concern "I rapporti della polizia che mi sono stati forniti sono pieni di informazioni riservate. In altre parole, non sono andato molto avanti con essi."

# game/act1.rpy:104
translate italian act1_0e189f54:

    # a frown "I have little information about her disappearance, and even less about her life before that. Considering you’re the only family member listed on her records, I was hoping you could shed some light on who she was."
    a frown "Ho poche informazioni sulla sua scomparsa e ancor meno sulla sua vita prima di allora. Dato che lei è l'unico membro della famiglia menzionato nei suoi documenti, speravo che potesse fornirmi qualche informazione in più su chi fosse."

# game/act1.rpy:105
translate italian act1_02d38658:

    # a worried "Perhaps it could help us find her."
    a worried "Forse potrebbe aiutarci a trovarla."

# game/act1.rpy:106
translate italian act1_c046734e:

    # y stan "…"
    y stan "…"

# game/act1.rpy:108
translate italian act1_1d5f96ff:

    # "He lets out another puff of smoke, tapping the table with one finger, staring at my hand holding the pen. I try to hide my shakiness, but something tells me he’s caught onto it."
    "Emette un'altra boccata di fumo, tamburellando sul tavolo con un dito e fissando la mia mano che impugna la penna. Cerco di nascondere il mio tremore, ma qualcosa mi dice che se n'è accorto."

# game/act1.rpy:110
translate italian act1_0e153d47:

    # y frown "Don’t hide your questioning behind a façade of kindness, Valentine. It doesn’t suit your kind."
    y frown "Non nascondere i tuoi dubbi dietro una facciata di gentilezza, Valentine. Non si addice alla tua specie."

# game/act1.rpy:111
translate italian act1_14e13729:

    # a frown "…I assure you, that’s not what I’m doing."
    a frown "…Vi assicuro che non è quello che sto facendo."

# game/act1.rpy:112
translate italian act1_43ac0ca6:

    # y smile "Heh. Of course."
    y smile "Eh. Certo."

# game/act1.rpy:115
translate italian act1_57cd2c5e:

    # y "Megumi was-{w} is… my niece."
    y "Megumi era-{w} è… mia nipote."

# game/act1.rpy:116
translate italian act1_abb8b7aa:

    # y ponder "My brother’s daughter. After his passing, he entrusted her and her brother to me. In a lot of ways, I’m more like her father than her uncle. But that’s a position I could never take."
    y ponder "La figlia di mio fratello. Dopo la sua morte, mi ha affidato lei e suo fratello. Per molti aspetti, sono più simile a suo padre che a suo zio. Ma è un ruolo che non potrei mai ricoprire."

# game/act1.rpy:118
translate italian act1_25404381:

    # "His gaze returns to the outside, and I take the opportunity to jot some things down. To say I’m surprised he’s opening up to me so easily is an understatement, but I make sure to not let it show on my face."
    "Il suo sguardo torna a posarsi sull'esterno e io ne approfitto per annotare qualcosa. Dire che sono sorpresa che si stia aprendo con me così facilmente è un eufemismo, ma mi assicuro di non darlo a vedere sul mio viso."

# game/act1.rpy:119
translate italian act1_d5949f6d:

    # "He continues."
    "Continua."

# game/act1.rpy:121
translate italian act1_a88bfeab:

    # y "She was always a troublesome kid. Mixing with the bad crowds, no matter how many times I scolded her. She never learned… or perhaps she simply chose not to listen."
    y "È sempre stata una bambina problematica. Frequentava cattive compagnie, non importa quante volte la rimproverassi. Non ha mai imparato la lezione... o forse semplicemente ha scelto di non ascoltare."

# game/act1.rpy:122
translate italian act1_3e8c9b08:

    # a surprised "What kind of bad crowds?"
    a surprised "Che tipo di folla pericolosa?"

# game/act1.rpy:123
translate italian act1_a506e366:

    # y "…"
    y "…"

# game/act1.rpy:124
translate italian act1_2b3a4ab7:

    # y frown "She loved to roughhouse with boys. Pull pranks on teachers. It started off innocent in that way."
    y frown "Le piaceva giocare in modo un po' rude con i ragazzi. Fare scherzi agli insegnanti. Tutto era iniziato in modo innocente, in quel senso."

# game/act1.rpy:125
translate italian act1_d1198d7a:

    # y "But then she grew up."
    y "Ma poi è cresciuta."

# game/act1.rpy:128
translate italian act1_71dffd1c:

    # y stan "It was one vice after the other. First it was smoking, which I’m sure she caught from me. Then, it was liquor."
    y stan "È stato un vizio dopo l'altro. Prima il fumo, che sono sicuro abbia preso da me. Poi, l'alcol."

# game/act1.rpy:130
translate italian act1_639dd4a5:

    # y frown "And then…{w} it was gambling."
    y frown "E poi…{w} è stato il gioco d'azzardo."

# game/act1.rpy:132
translate italian act1_87c584fc:

    # "My fur stands on end."
    "Mi si rizza il pelo."

# game/act1.rpy:133
translate italian act1_03e5d30d:

    # a concern "…gambling?"
    a concern "…gioco d'azzardo?"

# game/act1.rpy:134
translate italian act1_29f07dd0:

    # y ponder "Yes. Gambling."
    y ponder "Sì. Il gioco d'azzardo."

# game/act1.rpy:135
translate italian act1_f4c8dbb2:

    # y stan "You’re aware, aren’t you, Valentine? The heart of this city is gambling. The casinos are the veins, and money, the blood."
    y stan "Lo sai, vero, Valentine? Il cuore di questa città è il gioco d'azzardo. I casinò sono le vene e il denaro il sangue."

# game/act1.rpy:136
translate italian act1_b0bb5786:

    # y "I figured that since she never knew poverty, never went hungry, she wouldn’t be interested in such an activity as foolish as that."
    y "Ho pensato che, non avendo mai conosciuto la povertà e non avendo mai sofferto la fame, non sarebbe stata interessata a un'attività così sciocca."

# game/act1.rpy:138
translate italian act1_d9518279:

    # y frown "How wrong I was.{w} It's the rich who crave to use their money in such ways, not the poor. I see that now..."
    y frown "Quanto mi sbagliavo.{w} Sono i ricchi che desiderano usare i loro soldi in questo modo, non i poveri. Ora lo capisco..."

# game/act1.rpy:139
translate italian act1_835ac230:

    # y "Megumi lived to gamble. It was casino after casino… each one that kicked her out, she’d just find a new one, and if there weren’t any left, she’d find a more illegal way of doing it."
    y "Megumi viveva per il gioco d'azzardo. Un casinò dopo l'altro... ogni volta che veniva cacciata, ne trovava semplicemente un altro, e se non ce n'erano più, escogitava un modo ancora più illegale per farlo."

# game/act1.rpy:140
translate italian act1_6cce9cd9:

    # y surprised "It was her drug, her breathing. The money we had saved for her to study… was gone in a matter of months."
    y surprised "Era la sua droga, il suo respiro. I soldi che avevamo risparmiato per i suoi studi... sono spariti nel giro di pochi mesi."

# game/act1.rpy:141
translate italian act1_131acb26:

    # y frown "It’s one thing to be a gambler. It’s another thing to be a {i}terrible{/i} gambler."
    y frown "Una cosa è essere un giocatore d'azzardo. Un'altra cosa è essere un giocatore d'azzardo {i}terribile{/i}."

# game/act1.rpy:143
translate italian act1_f220c059:

    # "He lets his cigar keep burning out, unable to put it back onto his lips."
    "Lascia che il sigaro si consumi completamente, incapace di rimetterlo alle labbra."

# game/act1.rpy:145
translate italian act1_3440713f:

    # y ponder "That…"
    y ponder "Quello…"

# game/act1.rpy:147
translate italian act1_cec72d90:

    # y stan "Is all I feel like sharing with you today, Valentine."
    y stan "È tutto ciò che mi sento di condividere con te oggi, Valentine."

# game/act1.rpy:148
translate italian act1_1e9598f8:

    # a worried "…"
    a worried "…"

# game/act1.rpy:149
translate italian act1_96a00ba1:

    # a "Could you please just tell me… where you last saw her?"
    a "Potresti dirmi, per favore, dove l'hai vista l'ultima volta?"

# game/act1.rpy:150
translate italian act1_a506e366_1:

    # y "…"
    y "…"

# game/act1.rpy:152
translate italian act1_4b9d0a7f:

    # y frown "In my house.{w} Two years ago."
    y frown "A casa mia.{w} Due anni fa."

# game/act1.rpy:153
translate italian act1_1f805e02:

    # y stan "She moved out. And I never saw her again."
    y stan "Lei se n'è andata. E non l'ho mai più vista."

# game/act1.rpy:154
translate italian act1_923fbe92:

    # y ponder "Until her picture showed up on the news."
    y ponder "Fino a quando la sua foto non è apparsa al telegiornale."

# game/act1.rpy:157
translate italian act1_1b640637:

    # a "I’m… terribly sorry, Mr. Yoshida."
    a "Mi dispiace moltissimo, signor Yoshida."

# game/act1.rpy:158
translate italian act1_4714fc24:

    # y ponder "Don’t be."
    y ponder "Non esserlo."

# game/act1.rpy:159
translate italian act1_e9736e8e:

    # y frown "If she chose to be insolent and reckless, then whatever fate she met was what she deserved."
    y frown "Se avesse scelto di essere insolente e sconsiderata, qualsiasi destino le sarebbe toccato sarebbe stato quello che si sarebbe meritata."

# game/act1.rpy:161
translate italian act1_e9137f27:

    # "His voice doesn’t waver when he says this. Yet, somehow, I don’t believe he truly means it."
    "La sua voce non trema quando lo dice. Eppure, in qualche modo, non credo che lo pensi davvero."

# game/act1.rpy:163
translate italian act1_e09f4140:

    # "I close my notebook, sighing quietly through my nose. Although there’s still a lot I’d like to ask, I decide not to push my luck. Any information is good information, and I’ll just have to make do with what I have."
    "Chiudo il quaderno, sospirando piano. Anche se ci sono ancora molte cose che vorrei chiedere, decido di non tentare la fortuna. Qualsiasi informazione è utile, e dovrò accontentarmi di quello che ho."

# game/act1.rpy:165
translate italian act1_36fe7ade:

    # a frown "Well, I appreciate you giving me your time, Mr. Yoshida. I promise you; I’m doing what I can to try and bring this story to light."
    a frown "Bene, la ringrazio per il tempo che mi ha dedicato, signor Yoshida. Le assicuro che farò tutto il possibile per cercare di portare alla luce questa storia."

# game/act1.rpy:167
translate italian act1_be487d7f:

    # "He sneers at me, a cynical air to his grin."
    "Mi guarda con disprezzo, un'aria cinica nel suo sorriso."

# game/act1.rpy:169
translate italian act1_02544cc6:

    # y "I don’t doubt that. I’m sure this ‘story’ is of utmost importance to you."
    y "Non ne dubito. Sono certo che questa \"storia\" sia di fondamentale importanza per te."

# game/act1.rpy:170
translate italian act1_66a5e221:

    # y "After all, you get a nice reward if you solve it, don’t you?"
    y "Dopotutto, se lo risolvi, ricevi una bella ricompensa, no?"

# game/act1.rpy:171
translate italian act1_2a4ff97c:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:172
translate italian act1_9ac41913:

    # a worried "Like I said, Mr. Yoshida, that has nothing to do with my desire to find Ms. Megumi."
    a worried "Come ho già detto, signor Yoshida, questo non ha nulla a che vedere con il mio desiderio di trovare la signorina Megumi."

# game/act1.rpy:174
translate italian act1_7c4aef21:

    # y smile "Lying doesn’t suit you, Valentine. Perhaps it’s a good thing you, of all people, don’t gamble."
    y smile "Mentire non ti si addice, Valentine. Forse è un bene che tu, tra tutti, non ti dedichi al gioco d'azzardo."

# game/act1.rpy:176
translate italian act1_3a71e83c:

    # "I inhale sharply, feeling flustered. Just who does this old man think he is, anyway? And more importantly, what makes him think he knows me so well?"
    "Trattengo il respiro, sentendomi agitata. Ma chi si crede di essere questo vecchio? E soprattutto, cosa gli fa pensare di conoscermi così bene?"

# game/act1.rpy:178
translate italian act1_2ceac7a3:

    # "I get up, tucking my things into my bag and giving him a halfhearted bow."
    "Mi alzo, infilo le mie cose nella borsa e gli faccio un inchino poco convinto."

# game/act1.rpy:180
translate italian act1_062cf843:

    # a frown "Have a good rest of your evening, Mr. Yoshida."
    a frown "Le auguro una buona continuazione di serata, signor Yoshida."

# game/act1.rpy:182
translate italian act1_c47fd351:

    # "I start to head towards the doorway, but as I pass his side of the booth, his hand latches onto my wrist, making me freeze in place. He looks at me through the corner of his eyes, dark and elusive, and panic starts to form in my stomach."
    "Mi dirigo verso la porta, ma appena supero il suo lato del tavolo, la sua mano mi afferra il polso, facendomi immobilizzare. Mi guarda con la coda dell'occhio, scuro e sfuggente, e il panico comincia a farsi strada nel mio stomaco."

# game/act1.rpy:184
translate italian act1_4fbd7740:

    # y "I don’t believe you expected this chat without any sort of incentive for me… did you, Valentine?"
    y "Non credo che ti aspettassi questa chiacchierata senza alcun incentivo da parte mia... vero, Valentine?"

# game/act1.rpy:185
translate italian act1_38956b2c:

    # a concern "Incentive?"
    a concern "Incentivo?"

# game/act1.rpy:186
translate italian act1_0f32b27b:

    # y "I’m a very busy man, as I’m sure you’re aware of. I don’t just organize meetings without some sort of gain on my end."
    y "Sono un uomo molto impegnato, come sicuramente saprete. Non organizzo riunioni senza un qualche tornaconto personale."

# game/act1.rpy:188
translate italian act1_c2f8d11d:

    # "His grip on my wrist relaxes in an instant, his fingers starting to delicately trace the inside of my palm in an almost… {i}seductive{/i} way."
    "La sua presa sul mio polso si allenta in un istante, le sue dita iniziano a tracciare delicatamente l'interno del mio palmo in un modo quasi... {i}seducente{/i}."

# game/act1.rpy:190
translate italian act1_ac389fe8:

    # y "Tell me… how do you plan on repaying my time?"
    y "Dimmi… come pensi di ripagare il tempo che ti ho dedicato?"

# game/act1.rpy:191
translate italian act1_620b4cf8:

    # a flustered "…"
    a flustered "…"

# game/act1.rpy:192
translate italian act1_9cd0c3c7:

    # a "I-"
    a "IO-"

# game/act1.rpy:194
translate italian act1_96ceb886:

    # "I’m about to come up with some excuse when a heavy hand falls on my shoulder, and a familiar body presses against me."
    "Sto per inventare una scusa quando una mano pesante mi si posa sulla spalla e un corpo familiare si stringe a me."

# game/act1.rpy:196
translate italian act1_ceb80cb2:

    # e "Mr. Yoshida. Fancy running into you here."
    e "Signor Yoshida, che sorpresa incontrarla qui."

# game/act1.rpy:199
translate italian act1_40d0b271:

    # "Ethan’s voice comes from behind me, his voice full of that authoritarian tone he reserves for everyone but me.{w} His grip on me tightens somewhat."
    "La voce di Ethan proviene da dietro di me, una voce piena di quel tono autoritario che riserva a tutti tranne che a me.{w} La sua presa su di me si stringe un po'."

# game/act1.rpy:202
translate italian act1_af97d8ff:

    # y smile "Officer Hutcherson. I’m surprised you’re still working this late."
    y smile "Agente Hutcherson, mi sorprende che stia ancora lavorando a quest'ora."

# game/act1.rpy:203
translate italian act1_ccc2f37b:

    # e smile "Just had some business with… this Valentine here."
    e smile "Ho appena avuto degli affari con... questo Valentino qui."

# game/act1.rpy:204
translate italian act1_0f76b66b:

    # "My eye twitches."
    "Il mio occhio si contrae."

# game/act1.rpy:205
translate italian act1_6820a2eb:

    # e "I’ll be heading home soon."
    e "Tra poco tornerò a casa."

# game/act1.rpy:207
translate italian act1_fc0fccec:

    # e stan "Maybe you should, too. This side of the neighborhood isn’t very safe at night."
    e stan "Forse dovresti farlo anche tu. Questa parte del quartiere non è molto sicura di notte."

# game/act1.rpy:208
translate italian act1_2939b09d:

    # y "I’m well aware."
    y "Ne sono perfettamente consapevole."

# game/act1.rpy:210
translate italian act1_bebc79d8:

    # "Mr. Yoshida turns his attention to me now, that same sneer on his face."
    "Il signor Yoshida ora rivolge la sua attenzione a me, con quello stesso ghigno stampato in faccia."

# game/act1.rpy:212
translate italian act1_123b4330:

    # y "You poor thing. They have such a short leash on you. I didn’t know Valentines had a curfew."
    y "Poverina. Ti tengono così corta al guinzaglio. Non sapevo che San Valentino avesse un coprifuoco."

# game/act1.rpy:213
translate italian act1_8ef2c679:

    # a frown "…"
    a frown "…"

# game/act1.rpy:214
translate italian act1_fc6a906c:

    # y smile "Oh, well. Figures as much."
    y smile "Oh, beh. Era prevedibile."

# game/act1.rpy:216
translate italian act1_b3dd97c3:

    # "He finally lets go of my hand, grabbing his glass again."
    "Alla fine mi lascia la mano e riprende il suo bicchiere."

# game/act1.rpy:218
translate italian act1_92298cdc:

    # y "All business, no pleasure."
    y "Solo lavoro, niente piacere."

# game/act1.rpy:220
translate italian act1_1d50824a:

    # e "You have a nice rest of your evening, Mr. Yoshida."
    e "Le auguro una buona continuazione di serata, signor Yoshida."

# game/act1.rpy:221
translate italian act1_e03a1446:

    # "Without another word, Ethan ushers me towards the exit, leaving Mr. Yoshida alone in the dim bar."
    "Senza dire una parola, Ethan mi accompagna verso l'uscita, lasciando il signor Yoshida da solo nel bar in penombra."

# game/act1.rpy:229
translate italian act1_f0322940:

    # "In the passenger seat of Ethan’s car, I watch as the city lights blur and blend into one another, and from the corner of my eye, his stoic stare focuses on the road. Anger flushes against my face, in a slow, uncomfortable way."
    "Seduta sul sedile del passeggero dell'auto di Ethan, osservo le luci della città che si confondono e si mescolano l'una all'altra, e con la coda dell'occhio il suo sguardo impassibile si fissa sulla strada. La rabbia mi sale al viso, lentamente e in modo sgradevole."

# game/act1.rpy:231
translate italian act1_074cd341:

    # a frown "I didn’t need you to come pick me up."
    a frown "Non avevo bisogno che venissi a prendermi."

# game/act1.rpy:233
translate italian act1_baa8824d:

    # a "I could’ve handled it."
    a "Avrei potuto gestirlo."

# game/act1.rpy:234
translate italian act1_87a176c7:

    # e "Sure you could’ve."
    e "Certo che avresti potuto."

# game/act1.rpy:235
translate italian act1_ab534df3:

    # a angry "I’m serious."
    a angry "Dico sul serio."

# game/act1.rpy:236
translate italian act1_ac38fc99:

    # "I practically hiss this."
    "Praticamente mi viene da sibilare questa cosa."

# game/act1.rpy:237
translate italian act1_e178313d:

    # a "Why do you feel the need to babysit me? Maybe I should just stop telling you where I’m gonna be."
    a "Perché senti il ​​bisogno di farmi da babysitter? Forse dovrei smettere di dirti dove vado."

# game/act1.rpy:238
translate italian act1_9dc4202d:

    # e "You know I’d still be able to find you."
    e "Sai che sarei comunque in grado di trovarti."

# game/act1.rpy:239
translate italian act1_49b2380f:

    # "I scoff at him."
    "Lo derido."

# game/act1.rpy:240
translate italian act1_e19984e5:

    # a "Are you that desperate to control me?"
    a "Sei così disperato da volermi controllare?"

# game/act1.rpy:241
translate italian act1_ccf3a0d7:

    # e "You know that’s not what I’m doing."
    e "Sai benissimo che non è quello che sto facendo."

# game/act1.rpy:242
translate italian act1_3c2b6593:

    # a "That’s exactly what it feels like to me."
    a "È esattamente la stessa sensazione che provo io."

# game/act1.rpy:244
translate italian act1_6318d271:

    # "He lets out a heavy sigh, clearly exhausted, but I don’t let him off the hook so easily."
    "Emette un profondo sospiro, chiaramente esausto, ma non lo lascio andare così facilmente."

# game/act1.rpy:245
translate italian act1_b23cd9bb:

    # a hm "{i}It’s about the principle. I didn’t ask for his help."
    a hm "{i}È una questione di principio. Non gli ho chiesto aiuto."

# game/act1.rpy:246
translate italian act1_1f24a5a1:

    # a pout "{i}…even if I might have needed it…"
    a pout "{i}…anche se forse ne avrei avuto bisogno…"

# game/act1.rpy:249
translate italian act1_12f0418f:

    # "The car comes to a stop, right in front of Ethan’s apartment complex. I shoot him a nasty look, and he puts his hands up, feigning innocence."
    "L'auto si ferma proprio davanti al condominio di Ethan. Gli lancio un'occhiataccia e lui alza le mani, fingendo innocenza."

# game/act1.rpy:251
translate italian act1_ffc463ca:

    # e "Just come inside for a minute. I promise I’ll take you home after."
    e "Entra un attimo. Ti prometto che dopo ti accompagno a casa."

# game/act1.rpy:252
translate italian act1_4a530c3d:

    # a hm "…"
    a hm "…"

# game/act1.rpy:254
translate italian act1_ab5d56fe:

    # a hmph "Fine. But you’re ordering takeout."
    a hmph "Va bene. Ma ordinerai cibo da asporto."

# game/act1.rpy:256
translate italian act1_ded5af8c:

    # "He finally cracks a smile, realizing I’m not as mad as he thinks I was, and drops his hands back to his lap."
    "Alla fine accenna un sorriso, rendendosi conto che non sono così arrabbiata come pensava, e riabbassa le mani sulle ginocchia."

# game/act1.rpy:258
translate italian act1_288bf64c:

    # e "Deal."
    e "Affare."

# game/act1.rpy:261
translate italian act1_5c76d7d2:

    # "There’s a certain vibe to Ethan’s apartment that I haven’t been able to pinpoint for as long as I’ve been here."
    "Nell'appartamento di Ethan c'è un'atmosfera particolare che non sono riuscito a definire con precisione, nonostante sia qui da molto tempo."

# game/act1.rpy:262
translate italian act1_391dad16:

    # "On one hand, it’s pretty sad; it’s your stereotypical bachelor pad. Posters of TV shows I’ve never had the time to watch, empty bottles of beer and soda on his coffee table, that damn prehistoric radio that never wants to turn on."
    "Da un lato, è piuttosto triste; è il classico appartamento da scapolo. Poster di programmi TV che non ho mai avuto il tempo di guardare, bottiglie vuote di birra e bibite sul tavolino, quella dannata radio preistorica che non si accende mai."

# game/act1.rpy:263
translate italian act1_82626eaf:

    # "But, on the other hand… it’s cozy. It’s familiar, and the area has a distinct smell of something foreign, but nice. It’s the kind of place I’d like to stay in more often… and call home."
    "Ma, d'altra parte... è accogliente. È familiare, e la zona ha un odore particolare di qualcosa di straniero, ma piacevole. È il tipo di posto in cui mi piacerebbe soggiornare più spesso... e che vorrei chiamare casa."

# game/act1.rpy:264
translate italian act1_bffd7ef2:

    # "Unfortunately, that kind of wishful thinking never does me any good. I shake the thought away, walking deeper into the apartment, my hands tracing the radio as Ethan takes off his vest."
    "Purtroppo, questo genere di illusioni non mi porta mai bene. Scaccio via il pensiero, addentrandomi nell'appartamento, le mani che accarezzano la radio mentre Ethan si toglie il gilet."

# game/act1.rpy:265
translate italian act1_4ded9b34:

    # "I push the button to turn it on… to no response."
    "Premo il pulsante per accenderlo... ma non succede nulla."

# game/act1.rpy:267
translate italian act1_101c45ee:

    # a bored "Of course."
    a bored "Ovviamente."

# game/act1.rpy:268
translate italian act1_7e5be565:

    # e "What?"
    e "Che cosa?"

# game/act1.rpy:269
translate italian act1_20d5e264:

    # a hm "Your radio doesn’t work. I keep telling you to throw the damn thing out."
    a hm "La tua radio non funziona. Continuo a dirti di buttarla via."

# game/act1.rpy:270
translate italian act1_85413874:

    # e "What’re you talking about? It works fine."
    e "Di cosa stai parlando? Funziona benissimo."

# game/act1.rpy:271
translate italian act1_c7ed074f:

    # "He comes over and presses the button again, to the same response."
    "Si avvicina e preme di nuovo il pulsante, ottenendo la stessa risposta."

# game/act1.rpy:275
translate italian act1_f213923e:

    # "He then gives the top of the radio a fierce {i}SMACK{/i} that makes even me jump, and suddenly, the radio sputters its first words, full of static."
    "Poi dà un forte {i}SCHIAFFO{/i} alla parte superiore della radio che fa sobbalzare persino me, e all'improvviso la radio balbetta le sue prime parole, piene di fruscio."

# game/act1.rpy:277
translate italian act1_9096d56f:

    # e cocky "Ehh?~"
    e cocky "Ehh?~"

# game/act1.rpy:278
translate italian act1_e951962d:

    # a bashful "R-right… I’d rather not have to beat up my appliances every time I want to use them."
    a bashful "G-giusto… preferirei non dover maltrattare i miei elettrodomestici ogni volta che voglio usarli."

# game/act1.rpy:279
translate italian act1_19bf5813:

    # e "See, that's the difference between you and me. You're just too much of a softy."
    e "Ecco, questa è la differenza tra te e me. Tu sei troppo sensibile."

# game/act1.rpy:280
translate italian act1_aa157141:

    # a "If that’s what you wanna call it."
    a "Se è così che vuoi chiamarlo."

# game/act1.rpy:282
translate italian act1_2ae003f8:

    # "I sit on his couch with a sigh, crossing my arms and eyeing him as he steps in front of me, hands on his hips."
    "Mi siedo sul suo divano con un sospiro, incrocio le braccia e lo osservo mentre si mette di fronte a me, con le mani sui fianchi."

# game/act1.rpy:284
translate italian act1_230841a8:

    # a pout "…"
    a pout "…"

# game/act1.rpy:285
translate italian act1_e13efb7e:

    # e hm "…"
    e hm "…"

# game/act1.rpy:286
translate italian act1_23693c98:

    # a hmph "Hmph."
    a hmph "Hmph."

# game/act1.rpy:287
translate italian act1_3dc4eb12:

    # e uh "Don’t give me that."
    e uh "Non dirmi questo."

# game/act1.rpy:288
translate italian act1_19f52485:

    # a superhmph "Hmmmmph."
    a superhmph "Hmmmmph."

# game/act1.rpy:289
translate italian act1_63b27157:

    # e hm "Fine. Pout all you want. I’m not apologizing."
    e hm "Va bene. Fai pure il broncio quanto vuoi. Non ho intenzione di scusarmi."

# game/act1.rpy:290
translate italian act1_2f2e1132:

    # e surprised "And I guess you don’t want to see what’s inside my bag tonight…"
    e surprised "E immagino che non vogliate vedere cosa c'è nella mia borsa stasera..."

# game/act1.rpy:291
translate italian act1_2a4ff97c_1:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:292
translate italian act1_184afd34:

    # a excited "Is it a present?"
    a excited "È un regalo?"

# game/act1.rpy:293
translate italian act1_4e08234b:

    # e smile "Of sorts."
    e smile "In un certo senso."

# game/act1.rpy:295
translate italian act1_8784ee50:

    # "He carefully takes out a stack of folders that I recognize to be straight from the police station, and my eyes light up at the sight of them."
    "Con cura estrae una pila di cartelle che riconosco come provenienti direttamente dalla stazione di polizia, e i miei occhi si illuminano alla loro vista."

# game/act1.rpy:297
translate italian act1_31de4269:

    # a surprised "That’s not-?"
    a surprised "Non è questo-?"

# game/act1.rpy:298
translate italian act1_b57b3c9e:

    # e "It might be."
    e "Potrebbe essere."

# game/act1.rpy:299
translate italian act1_53bfa339:

    # a "How did you get those?"
    a "Come hai fatto ad ottenerli?"

# game/act1.rpy:300
translate italian act1_fcfc991f:

    # e "I pulled a few strings… called in a favor. It wasn’t that hard. I’ll put it back first thing tomorrow, no one will know."
    e "Ho mosso qualche filo... ho chiesto un favore. Non è stato poi così difficile. Lo rimetterò a posto domani mattina, nessuno se ne accorgerà."

# game/act1.rpy:302
translate italian act1_208c2e5a:

    # "He tucks them back inside, sighing dramatically."
    "Li rimette dentro, sospirando in modo teatrale."

# game/act1.rpy:304
translate italian act1_f21315e3:

    # e pout "Oh, but you’re too upset to even think about reading all of this. Much less accept it from me, who you so obviously hate now…"
    e pout "Oh, ma sei troppo sconvolto anche solo per pensare di leggere tutto questo. Tanto meno per accettarlo da me, che ora odi così palesemente..."

# game/act1.rpy:306
translate italian act1_ecb100ef:

    # a flustered "I don’t hate you! I, uh, love you! So~ much…!"
    a flustered "Non ti odio! Io, uh, ti amo! Tantissimo...!"

# game/act1.rpy:307
translate italian act1_cf2eda62:

    # e "Uhuh."
    e "Uhuh."

# game/act1.rpy:308
translate italian act1_2132660d:

    # a excited "Come on~ I swear I’m not even mad anymore. Just gimme the files!"
    a excited "Dai~ Giuro che non sono più arrabbiato. Dammi solo i file!"

# game/act1.rpy:309
translate italian act1_69d9592c:

    # e frown "Say thank you first."
    e frown "Ringrazia prima di tutto."

# game/act1.rpy:310
translate italian act1_a4ca8edd:

    # a concern "For what?!"
    a concern "Per quello?!"

# game/act1.rpy:311
translate italian act1_a94a8060:

    # e hm "The files. AND saving you."
    e hm "I file. E salvarti."

# game/act1.rpy:312
translate italian act1_1ab72481:

    # a concern "…"
    a concern "…"

# game/act1.rpy:313
translate italian act1_45946726:

    # a pout "Thank you for saving me and getting me the files…{w} {size=*0.5}hoe."
    a pout "Grazie per avermi salvato e per avermi procurato i file...{w} {size=*0.5}hoe."

# game/act1.rpy:314
translate italian act1_df86bc02:

    # e frown "What was that?"
    e frown "Che cos 'era questo?"

# game/act1.rpy:315
translate italian act1_0d3e5c0b:

    # a eyeroll "I said ‘bro’. Geez."
    a eyeroll "Ho detto \"fratello\". Cavolo."

# game/act1.rpy:317
translate italian act1_641bfd01:

    # e hm "Fine. Here."
    e hm "Va bene. Ecco."

# game/act1.rpy:319
translate italian act1_b597a80c:

    # "He finally hands me the files, and a quick flip to the first page tells me this is the jackpot:{w} {i}{b}Megumi Yoshida – Missing Person Case."
    "Finalmente mi consegna i fascicoli e una rapida occhiata alla prima pagina mi dice che è il colpo grosso: {w} {i}{b}Megumi Yoshida – Caso di persona scomparsa."

# game/act1.rpy:321
translate italian act1_c94832f4:

    # e "Knock yourself out. I’ll order the food. Is Chinese okay?"
    e "Fai pure quello che vuoi. Ordino io da mangiare. Va bene anche il cinese?"

# game/act1.rpy:322
translate italian act1_bde3eb7f:

    # a excited "Yeah yeah, fine…"
    a excited "Sì, sì, va bene…"

# game/act1.rpy:324
translate italian act1_d1a1e3e8:

    # "He chuckles, shaking his head and disappearing into the kitchen."
    "Lui ridacchia, scuote la testa e scompare in cucina."

# game/act1.rpy:326
translate italian act1_2a4ff97c_2:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:329
translate italian act1_5a43a784:

    # "I take a deep breath, excitement coursing through my fingertips as I rub the sheets of paper in my hands. Any information is good information, and this seems like it’ll be {b}very{/b} good."
    "Prendo un respiro profondo, l'eccitazione mi scorre nelle dita mentre strofino i fogli di carta tra le mani. Qualsiasi informazione è una buona informazione, e questa sembra essere {b}molto{/b} buona."

# game/act1.rpy:331
translate italian act1_5c8a29df:

    # "The first page reveals Megumi’s personal case file. It’s nothing I hadn’t seen before, but this seems to be the original copy without all of the redacted information."
    "La prima pagina rivela il fascicolo personale di Megumi. Non c'è niente di nuovo, ma sembra essere la copia originale, senza tutte le informazioni censurate."

# game/act1.rpy:332
translate italian act1_17a17669:

    # "Extra notes have been added to the bottom of the page, detailing the exact time and area she was last seen on a security camera.{w} But why would it be redacted on my copy?"
    "Sono state aggiunte delle note extra in fondo alla pagina, che specificano l'ora e il luogo esatti in cui è stata vista l'ultima volta da una telecamera di sicurezza.{w} Ma perché sono state oscurate nella mia copia?"

# game/act1.rpy:334
translate italian act1_286f0a41:

    # a hm "{i}'Footage courtesy of C.C.’ Who is that?"
    a hm "{i}Filmato per gentile concessione di CC</z1> Chi è?"

# game/act1.rpy:336
translate italian act1_118b9452:

    # "The next page holds Megumi’s criminal record. Petty theft, assault charges, D.U.I.’s. Minor offenses in the grand scheme of things."
    "Nella pagina successiva si trova la fedina penale di Megumi. Furto di lieve entità, accuse di aggressione, guida in stato di ebbrezza. Reati minori, tutto sommato."

# game/act1.rpy:337
translate italian act1_81046e04:

    # "Unfortunately, there aren’t many details of these charges, and it seems like she only served minor jail time. Looks like she was bailed out every time."
    "Purtroppo non ci sono molti dettagli su queste accuse e sembra che abbia scontato solo una breve pena detentiva. A quanto pare è sempre stata rilasciata su cauzione."

# game/act1.rpy:339
translate italian act1_829ed93e:

    # a hm "{i}Must be nice having a rich family. All those mistakes, and never any responsibility for the consequences."
    a hm "{i}Dev'essere bello avere una famiglia ricca. Tutti quegli errori, e mai alcuna responsabilità per le conseguenze."

# game/act1.rpy:341
translate italian act1_65c0cc13:

    # "I flip over to the next page…"
    "Giro pagina…"

# game/act1.rpy:343
translate italian act1_b33ac013:

    # "…and my heart skips a beat."
    "…e il mio cuore perde un battito."

# game/act1.rpy:345
translate italian act1_c4a143d0:

    # a concern "{i}Corona’s…"
    a concern "{i}Corona…"

# game/act1.rpy:347
translate italian act1_5feac77d:

    # "Photos of her walking out of Corona’s Casino on the last day she was seen litter the page, and I now realize why they redacted that little detail out."
    "La pagina è piena di foto che la ritraggono mentre esce dal Corona's Casino l'ultimo giorno in cui è stata vista, e ora capisco perché hanno omesso quel piccolo dettaglio."

# game/act1.rpy:348
translate italian act1_cbf467cd:

    # "Valentines aren’t allowed to enter casinos, full stop. And that’s especially true for Corona’s."
    "Ai festeggiamenti di San Valentino non è consentito entrare nei casinò, punto e basta. E questo vale soprattutto per il Corona's."

# game/act1.rpy:350
translate italian act1_9915c9c6:

    # "That being said… this is big. Very big. Is the S.P.D. hiding this from every major news outlet?"
    "Detto questo... è una cosa seria. Molto seria. La polizia di Seattle sta forse nascondendo tutto ai principali organi di informazione?"

# game/act1.rpy:352
translate italian act1_20af90f5:

    # "I flip the page over, revealing a complete stranger’s personal file. ‘James Smith’."
    "Giro pagina e trovo il fascicolo personale di un perfetto sconosciuto. \"James Smith\"."

# game/act1.rpy:354
translate italian act1_e0f2493b:

    # a eyeroll "{i}Bleh. Might as well be called ‘John Doe’."
    a eyeroll "{i}Bleah. Potrebbe benissimo chiamarsi 'John Doe'."

# game/act1.rpy:356
translate italian act1_b4b79627:

    # "I’m confused as to why it’s here, until I reach the bottom of the page; {i}’Gone missing. Last seen September 24th at 8:16 p.m.{w} Images courtesy of C.C.'"
    "Sono confuso sul perché sia ​​qui, finché non arrivo in fondo alla pagina; {i}'Scomparso. Ultimo avvistamento il 24 settembre alle 20:16{w}Immagini per gentile concessione di CC'"

# game/act1.rpy:358
translate italian act1_64539f81:

    # a angry "…what the hell?"
    a angry "…che diavolo?"

# game/act1.rpy:360
translate italian act1_86e4d42a:

    # "A missing person case six months prior to this one that I had zero knowledge about, and they’re both last seen in the same location? That can’t be coincidence, can it?"
    "Un caso di persona scomparsa sei mesi prima di questo, di cui non sapevo assolutamente nulla, ed entrambi sono stati visti l'ultima volta nello stesso luogo? Non può essere una coincidenza, vero?"

# game/act1.rpy:361
translate italian act1_31114165:

    # "I take a look at the files attached to it, and the similarities are uncanny: A criminal record of small crimes, followed by pictures of his last sighting in the casino."
    "Ho dato un'occhiata ai documenti allegati e le somiglianze sono impressionanti: una fedina penale per piccoli reati, seguita dalle foto del suo ultimo avvistamento nel casinò."

# game/act1.rpy:362
translate italian act1_5e53f370:

    # "A knot starts to form in my stomach."
    "Mi si forma un nodo allo stomaco."

# game/act1.rpy:364
translate italian act1_0ac9d95b:

    # a concern "{i}What am I going to do…?"
    a concern "{i}Cosa farò...?"

# game/act1.rpy:370
translate italian act1_98b77848:

    # "I find Ethan slumped over his kitchen table, a frown on his face as he mulls over a set of files of his own, drumming his fingers against the wooden surface over and over again."
    "Trovo Ethan accasciato sul tavolo della cucina, con un'espressione corrucciata, intento a esaminare una serie di documenti, tamburellando ripetutamente con le dita sulla superficie di legno."

# game/act1.rpy:371
translate italian act1_6b225464:

    # "I place a hand on his shoulder, and it only seems to tense up even more."
    "Gli appoggio una mano sulla spalla, e sembra che si irrigidisca ancora di più."

# game/act1.rpy:373
translate italian act1_95d6c9b2:

    # a worried "Hey."
    a worried "EHI."

# game/act1.rpy:374
translate italian act1_ca95b42c:

    # e "Hey."
    e "EHI."

# game/act1.rpy:375
translate italian act1_47b79484:

    # a hm "What’s that?"
    a hm "Che cos'è?"

# game/act1.rpy:377
translate italian act1_47aa9d3a:

    # "A quick glance tells me it’s a long-written report on some suspect. Nothing of my concern."
    "A prima vista mi basta dare un'occhiata per capire che si tratta di un lungo rapporto su un sospettato. Niente che mi riguardi."

# game/act1.rpy:379
translate italian act1_f0b58833:

    # e uh "Just some shit I’ve had to deal with for a while. Some guy who’s running around, entering bars and clubs with several fake I.D.’s and somehow getting away with it."
    e uh "È una situazione spiacevole con cui ho a che fare da un po' di tempo. C'è un tipo che va in giro, entra in bar e discoteche con diversi documenti falsi e in qualche modo riesce a farla franca."

# game/act1.rpy:381
translate italian act1_5a00c89c:

    # "He sighs and rubs his temples, which prompts me to start rubbing his shoulders to ease him a bit."
    "Sospira e si massaggia le tempie, il che mi spinge a iniziare a massaggiargli le spalle per tranquillizzarlo un po'."

# game/act1.rpy:383
translate italian act1_894b5508:

    # a flattered "Hey, it’ll be fine. Entering a club with a fake I.D. is like, a rite of passage for the average citizen, right?"
    a flattered "Ehi, non preoccuparti, andrà tutto bene. Entrare in un locale con un documento falso è una specie di rito di passaggio per il cittadino medio, no?"

# game/act1.rpy:384
translate italian act1_5950a915:

    # e "Yeah, but this guy’s… different. Somehow."
    e "Sì, ma questo ragazzo è... diverso. In qualche modo."

# game/act1.rpy:385
translate italian act1_a3aff8ca:

    # a "Well, it’s nothing you can’t leave for tomorrow."
    a "Beh, non è niente che non si possa rimandare a domani."

# game/act1.rpy:386
translate italian act1_91f04cf7:

    # e uh "…maybe you’re right."
    e uh "…forse hai ragione."

# game/act1.rpy:388
translate italian act1_7052ee72:

    # "He finally relaxes a bit, but the firmness of his shoulders remains the same under the pressure of my fingers."
    "Alla fine si rilassa un po', ma la rigidità delle sue spalle rimane invariata sotto la pressione delle mie dita."

# game/act1.rpy:390
translate italian act1_cb0fdbbe:

    # e flattered "Were the files any good?"
    e flattered "I file erano di buona qualità?"

# game/act1.rpy:392
translate italian act1_1eda7aba:

    # a bashful "They, uh… were. Yeah."
    a bashful "Loro, ehm... erano. Sì."

# game/act1.rpy:393
translate italian act1_085d506b:

    # e "That’s not convincing."
    e "Non è convincente."

# game/act1.rpy:394
translate italian act1_e78f53d0:

    # a "It’s a little complicated."
    a "È un po' complicato."

# game/act1.rpy:395
translate italian act1_1043f72d:

    # e "How so?"
    e "Come mai?"

# game/act1.rpy:398
translate italian act1_a98c2ef8:

    # a worried "Corona’s is involved."
    a worried "Il coronavirus è coinvolto."

# game/act1.rpy:400
translate italian act1_f899c20d:

    # e "Oh."
    e "OH."

# game/act1.rpy:402
translate italian act1_0a644488:

    # e hm "Well, shit."
    e hm "Beh, merda."

# game/act1.rpy:403
translate italian act1_2c754e57:

    # a flattered "Yeah. Exactly."
    a flattered "Sì. Esattamente."

# game/act1.rpy:404
translate italian act1_d3b26f53:

    # e worried "What are you gonna do?"
    e worried "Che cosa hai intenzione di fare?"

# game/act1.rpy:405
translate italian act1_b3ab9e35:

    # a worried "I’m not sure… maybe ask the staff when they have days off? I’ll have to find their schedules… which could be tedious. But, doable, I guess."
    a worried "Non ne sono sicuro… forse potrei chiedere al personale quando hanno giorni liberi? Dovrò trovare i loro orari… il che potrebbe essere un lavoro noioso. Ma, fattibile, immagino."

# game/act1.rpy:406
translate italian act1_ed4b0783:

    # e hm "And you think that’ll help?"
    e hm "E pensi che questo possa essere d'aiuto?"

# game/act1.rpy:407
translate italian act1_45dcd46e:

    # a surprised "Maybe."
    a surprised "Forse."

# game/act1.rpy:409
translate italian act1_7a39d65b:

    # "The lie comes out quick, hoping he’d somehow believe me. The truth is, I don’t believe for a second that’ll work, but I don’t have many other options, do I?"
    "La bugia mi esce di bocca in fretta, sperando che in qualche modo mi creda. La verità è che non credo nemmeno per un secondo che funzionerà, ma non ho molte altre opzioni, vero?"

# game/act1.rpy:411
translate italian act1_ea311f7b:

    # e "And if it doesn’t?"
    e "E se non funziona?"

# game/act1.rpy:413
translate italian act1_52864ca0:

    # a cocky "Then… I’ll sneak my way inside and get some intel. Super-Secret-Spy style."
    a cocky "Poi… mi intrufolerò dentro e raccoglierò informazioni. In perfetto stile super spia."

# game/act1.rpy:414
translate italian act1_d02d54c4:

    # e "…"
    e "…"

# game/act1.rpy:415
translate italian act1_893a58fc:

    # a bored "That was a joke. Laugh."
    a bored "Era uno scherzo. Ridete."

# game/act1.rpy:416
translate italian act1_248f51c0:

    # e frown "I don’t find that funny."
    e frown "Non lo trovo divertente."

# game/act1.rpy:417
translate italian act1_fa06ffe6:

    # a eyeroll "Ugh. You’re such a buzzkill. I was kidding."
    a eyeroll "Uff. Sei proprio una guastafeste. Stavo scherzando."

# game/act1.rpy:418
translate italian act1_c02f591c:

    # e "Not completely."
    e "Non completamente."

# game/act1.rpy:419
translate italian act1_230841a8_1:

    # a pout "…"
    a pout "…"

# game/act1.rpy:420
translate italian act1_ab174506:

    # a concern "Yeah, well, this is a really important story. People are going missing, Ethan. It’s not something I can just sweep under the rug."
    a concern "Sì, beh, questa è una storia davvero importante. Ci sono persone che scompaiono, Ethan. Non è una cosa che posso semplicemente insabbiare."

# game/act1.rpy:422
translate italian act1_0524686a:

    # a surprised "And besides… do you have any idea the commission I’ll make if we can actually track down Megumi?"
    a surprised "E poi... hai idea di quanto potrei guadagnare se riuscissimo davvero a rintracciare Megumi?"

# game/act1.rpy:423
translate italian act1_21e9effd:

    # a excited "That would be enough to go to Vienna for a full week at a {i}fancy{/i} hotel. Imagine!"
    a excited "Sarebbe sufficiente per andare a Vienna per un'intera settimana in un hotel di lusso. Immagina!"

# game/act1.rpy:424
translate italian act1_cfbb29ef:

    # e "I know you want to go visit your mom, but the casino doesn’t play those kinds of games, Angel. If they find out you’re sneaking inside, snooping around, they’re gonna screw your ass."
    e "So che vuoi andare a trovare tua madre, ma al casinò non si fanno questi giochetti, Angel. Se scoprono che ti intrufoli di nascosto, che curiosa in giro, ti fregheranno."

# game/act1.rpy:426
translate italian act1_505ab5a3:

    # a silly "My ass has been needing a good screwing, anyway."
    a silly "Il mio culo aveva proprio bisogno di una bella scopata, comunque."

# game/act1.rpy:427
translate italian act1_1154ebd9:

    # e frown "Angel."
    e frown "Angelo."

# game/act1.rpy:428
translate italian act1_08f782e8:

    # a smile "All I’m saying is it’s not anything I can’t handle."
    a smile "Quello che sto dicendo è che non è niente che non possa gestire."

# game/act1.rpy:429
translate italian act1_512f4327:

    # e "It’s a bad idea."
    e "È una cattiva idea."

# game/act1.rpy:430
translate italian act1_57880eae:

    # a excited "I’ll be super careful. I’ll check out the area, talk to a few people, and then-"
    a excited "Starò molto attento. Controllerò la zona, parlerò con un paio di persone e poi..."

# game/act1.rpy:432
translate italian act1_036da1a0:

    # e angry "Why can’t you just take the shit that I tell you seriously for once?!"
    e angry "Perché non riesci a prendere sul serio, almeno per una volta, le stronzate che ti dico?!"

# game/act1.rpy:434
translate italian act1_2a4ff97c_3:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:435
translate italian act1_2da57d79:

    # e concern "…"
    e concern "…"

# game/act1.rpy:436
translate italian act1_4b6e6cdc:

    # a dejected "…"
    a dejected "…"

# game/act1.rpy:439
translate italian act1_dc0fa98c:

    # "I mumble an apology, shame bubbling inside me as I start to back away, when his hands quickly grab onto my waist, pulling me over to him."
    "Borbotto delle scuse, la vergogna che mi ribolle dentro mentre inizio ad allontanarmi, quando le sue mani mi afferrano rapidamente la vita, tirandomi verso di lui."

# game/act1.rpy:441
translate italian act1_ecfea7cf:

    # e "Hey, no. I’m sorry. Don’t go."
    e "Ehi, no. Mi dispiace. Non andare."

# game/act1.rpy:445
translate italian act1_d5f7df22:

    # "He envelops me in his arms, hugging me against him and burying his face against my stomach, squeezing me in one of his tight embraces."
    "Mi avvolge tra le sue braccia, stringendomi forte a sé e affondando il viso nel mio stomaco, stringendomi in uno dei suoi abbracci decisi."

# game/act1.rpy:447
translate italian act1_5b820f3b:

    # e worried "I’m sorry… I didn’t mean to yell."
    e worried "Mi dispiace… non volevo urlare."

# game/act1.rpy:449
translate italian act1_4a03fc76:

    # a worried "I… I-It’s okay…"
    a worried "Io… V-Va bene…"

# game/act1.rpy:450
translate italian act1_2f0745f0:

    # e sigh "I’m tired, a-and stressed, and-"
    e sigh "Sono stanco, e stressato, e-"

# game/act1.rpy:452
translate italian act1_536a847c:

    # a "It’s okay, Ethan. Seriously."
    a "Va tutto bene, Ethan. Davvero."

# game/act1.rpy:454
translate italian act1_01eee57d:

    # e concern "It’s just…{w} you’re one of the few things I care about in this city. If something happened to you… if I somehow lost you…"
    e concern "È solo che... {w} sei una delle poche cose a cui tengo in questa città. Se ti succedesse qualcosa... se in qualche modo ti perdessi..."

# game/act1.rpy:455
translate italian act1_49c77f63:

    # e "I don’t know what I’d do."
    e "Non so cosa farei."

# game/act1.rpy:456
translate italian act1_2a4ff97c_4:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:458
translate italian act1_3dbb158c:

    # "The silent rage boiling inside me quickly dissipates into nothing, and I hold Ethan closer to my body, cradling his giant head in my arms."
    "La rabbia silenziosa che ribolliva dentro di me si dissolve rapidamente nel nulla, e stringo Ethan più forte a me, cullando la sua testa enorme tra le mie braccia."

# game/act1.rpy:460
translate italian act1_b78aecce:

    # a sad "I know. I’m sorry."
    a sad "Lo so. Mi dispiace."

# game/act1.rpy:461
translate italian act1_d02d54c4_1:

    # e "…"
    e "…"

# game/act1.rpy:462
translate italian act1_a17dae96:

    # e "Just… be careful, Angel. Nothing good can come of you messing with that side of this city."
    e "Stai attenta, Angel. Non può venir fuori niente di buono se ti metti contro quella parte della città."

# game/act1.rpy:464
translate italian act1_7ad10a14:

    # a flattered "Yeah. I promise... I’ll be careful."
    a flattered "Sì. Lo prometto... starò attento."

# game/act1.rpy:466
translate italian act1_e2b98bc6:

    # "He looks up at me, and when our eyes lock, something inside me stirs. Something familiar."
    "Lui alza lo sguardo verso di me e, quando i nostri occhi si incrociano, qualcosa dentro di me si agita. Qualcosa di familiare."

# game/act1.rpy:468
translate italian act1_feb7a7f0:

    # "We stay that way, staring into each other, neither one of us moving an inch, daring to breathe or even blink."
    "Restiamo immobili, a fissarci l'un l'altro, nessuno dei due si muove di un millimetro, nessuno osa respirare o persino battere le palpebre."

# game/act1.rpy:471
translate italian act1_745e1205:

    # e "That’s… probably the delivery."
    e "Quella è… probabilmente la consegna."

# game/act1.rpy:472
translate italian act1_1b9077e0:

    # a surprised "Right. No, yeah, um…"
    a surprised "Giusto. No, sì, ehm…"

# game/act1.rpy:476
translate italian act1_d9070db7:

    # "He lets me go as I bashfully step aside, smoothing out my clothes as he gets up to answer the door."
    "Mi lascia andare mentre io, timidamente, mi faccio da parte, lisciandomi i vestiti mentre lui si alza per aprire la porta."

# game/act1.rpy:478
translate italian act1_3bea2f9e:

    # "I sigh out a long breath. It wouldn’t be the first time we’ve had one of these kinds of moments. I guess I’ll rest assured it won’t be the last, either."
    "Sospiro profondamente. Non sarebbe la prima volta che ci capita un momento del genere. Immagino che non sarà nemmeno l'ultima."

# game/act1.rpy:480
translate italian act1_d6c86588:

    # "Dinner was eaten mostly in silence, only interrupted by the occasional chit-chat of our day and how work is going. Seems like neither of us have any energy to hold a conversation tonight."
    "La cena si è svolta perlopiù in silenzio, interrotta solo da qualche chiacchiera sulla giornata e su come procede il lavoro. Sembra che nessuno dei due abbia le energie per sostenere una conversazione stasera."

# game/act1.rpy:484
translate italian act1_ec2164fb:

    # e "Hey. Stay the night. I know I said I’d drive you home, but I’m seriously drained..."
    e "Ehi. Resta a dormire. So che ti avevo detto che ti avrei riaccompagnato a casa, ma sono davvero esausto..."

# game/act1.rpy:485
translate italian act1_9c0c0bb8:

    # a surprised "Are you sure? I mean, I don’t mind… I’ll take the couch, if you want your space."
    a surprised "Sei sicuro? Cioè, non mi dispiace... prendo il divano, se vuoi un po' di spazio."

# game/act1.rpy:486
translate italian act1_f217d170:

    # e smile "Nah. Come."
    e smile "No. Vieni."

# game/act1.rpy:493
translate italian act1_3d246a96:

    # "He takes me by the hand into his bedroom, and although the situation makes my blood start pumping – especially in certain areas – it’s clear that nothing will happen tonight."
    "Mi prende per mano e mi conduce nella sua camera da letto, e sebbene la situazione mi faccia ribollire il sangue – soprattutto in certe zone – è chiaro che stasera non succederà nulla."

# game/act1.rpy:495
translate italian act1_57000b47:

    # "So when he starts to undress in front of me, I have to pretend I don’t care about how good his body looks underneath that uniform, or that there may or may not be a slight tent in his boxers as he climbs into bed."
    "Quindi, quando inizia a spogliarsi davanti a me, devo fingere di non curarmi di quanto sia attraente il suo corpo sotto quella divisa, o del fatto che possa esserci o meno una leggera protuberanza nei suoi boxer mentre si infila a letto."

# game/act1.rpy:499
translate italian act1_c311d6e3:

    # "Once I’m undressed too, I slide under his covers, stiffly lying beside him as we lock eyes."
    "Una volta spogliata anch'io, scivolo sotto le sue coperte, rimanendo rigidamente sdraiata accanto a lui mentre i nostri sguardi si incrociano."

# game/act1.rpy:501
translate italian act1_c286388c:

    # "He’s lying on his stomach, blinking slowly, and the uncontrollable urge to brush his hair surges through my whole body. He suddenly chuckles, and it makes me crack a smile."
    "È sdraiato a pancia in giù, sbatte lentamente le palpebre e un'irrefrenabile voglia di spazzolargli i capelli mi pervade tutto il corpo. All'improvviso ridacchia e questo mi fa spuntare un sorriso."

# game/act1.rpy:503
translate italian act1_4a55fc80:

    # a -uniform cocky "What?"
    a -uniform cocky "Che cosa?"

# game/act1.rpy:504
translate italian act1_c8310393:

    # e cocky "Nothing. You just have a stupid look on your face."
    e cocky "Niente. Hai solo un'espressione stupida in faccia."

# game/act1.rpy:505
translate italian act1_5379f623:

    # "His voice is somewhat muffled, since his cheek is firmly pressed against the mattress, making him involuntarily pout his lips a little."
    "La sua voce è un po' ovattata, poiché la guancia è premuta con forza contro il materasso, il che lo porta involontariamente a mettere un po' il broncio."

# game/act1.rpy:506
translate italian act1_5920e065:

    # a flirty "Uhuh. Go to sleep, fatty."
    a flirty "Uhuh. Vai a dormire, ciccione."

# game/act1.rpy:508
translate italian act1_77db2ff9:

    # "He frowns, but that smile never leaves his face."
    "Aggrotta la fronte, ma quel sorriso non abbandona mai il suo volto."

# game/act1.rpy:510
translate italian act1_8f212335:

    # e "Fatty? Who you callin’ fatty?"
    e "Ciccione? Chi chiami ciccione?"

# game/act1.rpy:511
translate italian act1_0a9570b7:

    # a cocky "The only fatty that’s taking up more than half the bed."
    a cocky "L'unico ciccione che occupa più di metà del letto."

# game/act1.rpy:512
translate italian act1_22cac25e:

    # e pout "It’s me-sized. Not you-sized."
    e pout "È della mia misura. Non della tua."

# game/act1.rpy:514
translate italian act1_21d5baa0:

    # a "So it’s fatty-sized."
    a "Quindi è di dimensioni cicciottelle."

# game/act1.rpy:515
translate italian act1_19a5483d:

    # e flirty "Shut up."
    e flirty "Stai zitto."

# game/act1.rpy:518
translate italian act1_1d1a5dc9:

    # e flattered "Hey. Angel."
    e flattered "Ehi, Angel."

# game/act1.rpy:519
translate italian act1_85a989be:

    # a smile "Yeah?"
    a smile "Sì?"

# game/act1.rpy:520
translate italian act1_f46504e3:

    # e "You know, you could stay over more often. I don’t mind."
    e "Sai, potresti fermarti più spesso. Non mi dispiacerebbe."

# game/act1.rpy:521
translate italian act1_2a4ff97c_5:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:523
translate italian act1_4768e1c9:

    # "It feels like a drunken confession with the way he says it, and it might as well be, considering how woozy the sleepiness is making him. I smile warmly, but by now, his eyes are fully closed."
    "Sembra una confessione fatta da ubriaco, per come la pronuncia, e in effetti potrebbe esserlo, considerando quanto è intontito dalla sonnolenza. Sorrido calorosamente, ma ormai ha gli occhi completamente chiusi."

# game/act1.rpy:525
translate italian act1_08be709d:

    # a blush "Okay."
    a blush "Va bene."

# game/act1.rpy:526
translate italian act1_e64396b1:

    # e "Hrmph. ‘Okay’ shut-up-you’re-so-annoying, or ‘Okay’ okay?"
    e "Hrmph. 'Okay' stai zitto, sei così fastidioso, oppure 'Okay' okay?"

# game/act1.rpy:527
translate italian act1_076d405c:

    # a eyeroll "’Okay’ okay, you moron. I…"
    a eyeroll "'Okay' okay, idiota. Io…"

# game/act1.rpy:528
translate italian act1_3652a158:

    # a blush "I like being here, too. Your bed’s a lot comfier than mine."
    a blush "Anche a me piace stare qui. Il tuo letto è molto più comodo del mio."

# game/act1.rpy:529
translate italian act1_4dd70457:

    # a bashful "Well… the third of your bed that I can fit into, anyway."
    a bashful "Beh... almeno nel terzo del tuo letto in cui riesco a entrare."

# game/act1.rpy:531
translate italian act1_05bf1520:

    # "He smiles. I watch him in silence for about a minute, seeing how it fades in real time, and about thirty seconds after that, he’s already snoring."
    "Lui sorride. Lo osservo in silenzio per circa un minuto, vedendo come il sorriso svanisce in tempo reale, e circa trenta secondi dopo, sta già russando."

# game/act1.rpy:533
translate italian act1_06f39335:

    # a stan "…"
    a stan "…"

# game/act1.rpy:535
translate italian act1_bb59f8ed:

    # "It’s moments like these that make me forget about my silent promise of not daydreaming about him. About us."
    "Sono momenti come questi che mi fanno dimenticare la mia tacita promessa di non fantasticare su di lui. Su di noi."

# game/act1.rpy:536
translate italian act1_9204291d:

    # "I let my own thoughts run wild, telling myself that I’ll allow it for a minute. Just one minute."
    "Ho lasciato che i miei pensieri vagassero liberamente, dicendomi che me lo sarei concesso solo per un minuto. Un solo minuto."

# game/act1.rpy:537
translate italian act1_38038703:

    # "And in that minute, I see him closing the distance between us in this bed, his large arms wrapping around me, his warm breath against my ears. I feel the heat of his crotch pressing against me, how it would throb in rhythm to my own."
    "E in quell'istante, lo vedo annullare la distanza tra noi in questo letto, le sue grandi braccia che mi avvolgono, il suo respiro caldo contro le mie orecchie. Sento il calore del suo inguine premere contro di me, come pulsasse a ritmo con il mio."

# game/act1.rpy:538
translate italian act1_1a7a9a84:

    # "He’d whisper something sweet into my ear – something romantic, because he’d allow himself to do that. To be completely himself."
    "Mi sussurrava qualcosa di dolce all'orecchio, qualcosa di romantico, perché si permetteva di farlo. Di essere completamente se stesso."

# game/act1.rpy:539
translate italian act1_d54e4d7d:

    # "He’d tell me he wants me, but that he’s too tired right now. He promises to make it up to me in the morning, and I’d laugh against his chest, buzzing with excitement for tomorrow to come."
    "Mi direbbe che mi desidera, ma che in quel momento è troppo stanco. Prometterebbe di farsi perdonare la mattina dopo, e io riderei appoggiata al suo petto, fremente di eccitazione per il giorno seguente."

# game/act1.rpy:540
translate italian act1_6fe29ed2:

    # "He would hold me, and I would touch him. And we’d both drift off to sleep together."
    "Lui mi abbracciava e io lo toccavo. E ci addormentavamo entrambi insieme."

# game/act1.rpy:542
translate italian act1_82213f1f:

    # "And then the vision fades.{w} My minute is up."
    "E poi la visione svanisce.{w} Il mio minuto è scaduto."

# game/act1.rpy:543
translate italian act1_d1519caf:

    # "But the yearning persists, as it always does after a daydream. That’s why it’s so dangerous to do it. If a minute can make me feel this way, I can’t imagine how I’d feel if I had no restraint on these fantasies."
    "Ma il desiderio persiste, come sempre accade dopo un sogno ad occhi aperti. Ecco perché è così pericoloso farlo. Se un solo minuto può farmi sentire così, non riesco a immaginare come mi sentirei se non avessi alcun freno a queste fantasie."

# game/act1.rpy:547
translate italian act1_2702b521:

    # a closedworry "{i}I would surely go insane."
    a closedworry "Diventerei sicuramente pazzo."

# game/act1.rpy:549
translate italian act1_e1fc0a36:

    # a "{i}That kind of freedom… is nothing but torture."
    a "{i}Quel tipo di libertà... non è altro che tortura."

# game/act1.rpy:553
translate italian act1_3d40c031:

    # e "Angel…"
    e "Angelo…"

# game/act1.rpy:554
translate italian act1_6a8757a7:

    # a1 "Mm?"
    a1 "Mm?"

# game/act1.rpy:555
translate italian act1_ee0ba040:

    # e "Pick up your fucking phone."
    e "Prendi quel cazzo di telefono."

# game/act1.rpy:556
translate italian act1_83d9daad:

    # a1 "Mm…"
    a1 "Mm…"

# game/act1.rpy:559
translate italian act1_89463b25:

    # "I stir awake, blinking back a deep grogginess as I reach for my pant leg and grab my phone, flipping it open and pressing it into my ear."
    "Mi sveglio di soprassalto, sbattendo le palpebre per scacciare un profondo torpore, mentre allungo la mano verso la gamba dei pantaloni, afferro il telefono, lo apro e me lo metto all'orecchio."

# game/act1.rpy:561
translate italian act1_06af801e:

    # a -uniform hm "Hello?"
    a -uniform hm "Ciao?"

# game/act1.rpy:562
translate italian act1_dfc3e367:

    # anon "How kind of you to finally pick up the phone, Angel."
    anon "Che gentile da parte tua, Angel, rispondere finalmente al telefono."

# game/act1.rpy:564
translate italian act1_45263d9d:

    # "And just like that, my grogginess disappears in an instant."
    "E così, all'improvviso, la mia sonnolenza scompare."

# game/act1.rpy:566
translate italian act1_f48354de:

    # a flustered "M-Mr. Valentine…"
    a flustered "Signor Valentine…"

# game/act1.rpy:567
translate italian act1_1211f1f2:

    # v "Did I wake you?"
    v "Ti ho svegliato?"

# game/act1.rpy:569
translate italian act1_7642fec8:

    # "His voice drips with snarkiness, no trace of an apologetic tone in his sentence. I swallow hard, rubbing my eyes of the drowsiness that I want to so desperately stay in."
    "La sua voce trasuda sarcasmo, nessuna traccia di pentimento nella sua frase. Deglutisco a fatica, strofinandomi gli occhi per scacciare la sonnolenza in cui vorrei disperatamente rimanere."

# game/act1.rpy:571
translate italian act1_8b849210:

    # a bashful "N-no, of course not. I was just about to head into the office."
    a bashful "N-no, certo che no. Stavo proprio per andare in ufficio."

# game/act1.rpy:572
translate italian act1_dcb6ffb3:

    # v "At five a.m.? How diligent. If only we all had your work ethic."
    v "Alle cinque del mattino? Che diligenza! Magari avessimo tutti la tua etica del lavoro."

# game/act1.rpy:574
translate italian act1_461e7036:

    # "Is it really that early? No wonder I’m so tired."
    "È davvero così presto? Non c'è da stupirsi che io sia così stanco."

# game/act1.rpy:575
translate italian act1_795d48a4:

    # "But even in my half-lucid state, I know how painfully obvious it is that Mr. Valentine is just fucking with me. Plain and simple."
    "Ma anche nel mio stato di semi-lucidità, so quanto sia dolorosamente ovvio che il signor Valentine mi sta solo prendendo in giro. Punto e basta."

# game/act1.rpy:577
translate italian act1_85383b07:

    # a "Ahaha… how can I help you, sir?"
    a "Ahaha… come posso aiutarla, signore?"

# game/act1.rpy:578
translate italian act1_31da0ee5:

    # v "Well, as luck would have it, I’m heading back to the office myself. Santa Blanca was quite the... {i}skid row{/i}, to put it lightly."
    v "Beh, guarda caso, sto tornando anch'io in ufficio. Santa Blanca era proprio un... {i}quartiere malfamato{/i}, per usare un eufemismo."

# game/act1.rpy:579
translate italian act1_2e694926:

    # v "I’d absolutely love a box of donuts from Big Joe’s. Oh, and a dark roast from Nova. You can do that for me, can’t you?"
    v "Mi piacerebbe tantissimo una scatola di ciambelle di Big Joe's. Oh, e anche un caffè tostato scuro di Nova. Puoi farmeli, vero?"

# game/act1.rpy:580
translate italian act1_6f9e2919:

    # a flustered "Um… y-yes sir."
    a flustered "Ehm... s-sì signore."

# game/act1.rpy:581
translate italian act1_900ad62f:

    # v "Good. I’ll be at the office in about half an hour. Please do have them there by then."
    v "Bene. Sarò in ufficio tra circa mezz'ora. Per favore, fate in modo che siano lì per quell'ora."

# game/act1.rpy:582
translate italian act1_0057f2f7:

    # a concern "Wha… but Big Joe’s and Nova Café are twenty minutes away from each other."
    a concern "Cosa... ma Big Joe's e Nova Café distano venti minuti l'uno dall'altro."

# game/act1.rpy:583
translate italian act1_acf9cfd4:

    # v "I thought you were already heading out? That should be plenty of time, is it not?"
    v "Pensavo che fossi già uscito? Dovresti avere tutto il tempo necessario, no?"

# game/act1.rpy:584
translate italian act1_d4d38d3e:

    # v "Or perhaps I should ask someone more qualified… and hand them over your story, while I’m at it."
    v "O forse dovrei chiedere a qualcuno più qualificato... e, già che ci sono, raccontargli anche la tua storia."

# game/act1.rpy:585
translate italian act1_ba173338:

    # a flustered "Ah- N-no! No, no, I’m on it, sir!"
    a flustered "Ah- N-no! No, no, ci penso io, signore!"

# game/act1.rpy:586
translate italian act1_adcb6d1a:

    # v "Good."
    v "Bene."

# game/act1.rpy:588
translate italian act1_dc96d132:

    # "And he just hangs up, without another word."
    "E riattacca, senza dire una parola."

# game/act1.rpy:590
translate italian act1_0b54fa84:

    # e "You're leaving already?"
    e "Te ne vai già?"

# game/act1.rpy:592
translate italian act1_d2d5b675:

    # "I turn to see Ethan lying next to me, half asleep, one eye peeping up to look at me."
    "Mi volto e vedo Ethan sdraiato accanto a me, mezzo addormentato, con un occhio che sbircia verso l'alto per guardarmi."

# game/act1.rpy:594
translate italian act1_0a9109cc:

    # a worried "Yeah. I’m sorry."
    a worried "Sì. Mi dispiace."

# game/act1.rpy:596
translate italian act1_975093ce:

    # "He groans, then turns to his side and lets out a big huff, clearly a little annoyed."
    "Geme, poi si gira su un fianco e sbuffa sonoramente, chiaramente un po' infastidito."

# game/act1.rpy:598
translate italian act1_0e42454f:

    # e "Your boss is Satan..."
    e "Il tuo capo è Satana..."

# game/act1.rpy:599
translate italian act1_56f6c8cb:

    # a hm "Don't say that. He's really not that bad..."
    a hm "Non dire così. Non è poi così male..."

# game/act1.rpy:600
translate italian act1_a0dc2ed0:

    # e "Ugh. He is and you know it."
    e "Uff. Lo è, e tu lo sai."

# game/act1.rpy:601
translate italian act1_1e9598f8_1:

    # a worried "…"
    a worried "…"

# game/act1.rpy:602
translate italian act1_51d0a6b6:

    # e "Let’s…"
    e "Andiamo…"

# game/act1.rpy:604
translate italian act1_5e1df7d5:

    # "He yawns mid-sentence, loud and for a solid ten seconds."
    "Sbadiglia a metà frase, rumorosamente e per ben dieci secondi."

# game/act1.rpy:606
translate italian act1_6bdb8c36:

    # e "Let’s have lunch together, then."
    e "Allora pranziamo insieme."

# game/act1.rpy:607
translate italian act1_7800fb0f:

    # a flattered "…"
    a flattered "…"

# game/act1.rpy:608
translate italian act1_57ab5745:

    # a "Okay. I really gotta go now."
    a "Okay. Ora devo proprio andare."

# game/act1.rpy:609
translate italian act1_dab4fa57:

    # e "Yeah… okay…"
    e "Sì... okay..."

# game/act1.rpy:611
translate italian act1_c94a258d:

    # "He drifts back to sleep, and a part of me wants to just curl back up and sleep with him, possibly forever."
    "Si riaddormenta e una parte di me vorrebbe semplicemente accoccolarsi di nuovo accanto a lui e dormire, magari per sempre."

# game/act1.rpy:612
translate italian act1_5551840a:

    # "{i}If only{/i}, is the last thought I have as I jump out of bed and start to get dressed."
    "{i}Se solo{/i}, è l'ultimo pensiero che mi attraversa la mente mentre salto giù dal letto e inizio a vestirmi."

# game/act1.rpy:617
translate italian act1_3442efd0:

    # "The cold morning air bites my ears as I step out into the sidewalk. The usually buzzing city of Sonora is half-asleep, and only a few cars and taxis drive past the mostly empty roads."
    "L'aria fredda del mattino mi pizzica le orecchie mentre esco sul marciapiede. La città di Sonora, solitamente brulicante di vita, è mezza addormentata e solo poche auto e taxi percorrono le strade quasi deserte."

# game/act1.rpy:618
translate italian act1_c7e8b0c1:

    # "In the distance, like a centerpiece, glowing lights illuminate a building so grandiose and luxurious, anyone who doesn’t live here would be attracted to it. Like a moth to a flame...{w} Corona's Casino."
    "In lontananza, come un elemento centrale, luci scintillanti illuminano un edificio così grandioso e lussuoso che chiunque non ci abiti ne sarebbe attratto. Come una falena attratta dalla fiamma... {w}Il Casinò di Corona."

# game/act1.rpy:619
translate italian act1_39ff3fca:

    # "Money, spectacle, risk… an entire life blooms behind those enormous red doors, a life that couldn’t be more different than mine."
    "Denaro, spettacolo, rischio… un’intera vita sboccia dietro quelle enormi porte rosse, una vita che non potrebbe essere più diversa dalla mia."

# game/act1.rpy:620
translate italian act1_8bab13ee:

    # "And yet, just like everyone else in this city, I can’t help but wonder…{w} what if?"
    "Eppure, proprio come tutti gli altri in questa città, non posso fare a meno di chiedermi... e se?"

# game/act1.rpy:621
translate italian act1_b76f8c18:

    # "What if I played a game – just one game – where I bet my entire life on the line? What if losing meant dying, and winning meant riches beyond my wildest dreams?"
    "E se giocassi a un gioco – un solo gioco – in cui scommettessi tutta la mia vita? E se perdere significasse morire e vincere significasse ricchezze inimmaginabili?"

# game/act1.rpy:623
translate italian act1_15596431:

    # "Wouldn’t I be free either way?"
    "Non sarei libero in entrambi i casi?"

# game/act1.rpy:625
translate italian act1_383e3b17:

    # a uniform frown "…"
    a uniform frown "…"

# game/act1.rpy:626
translate italian act1_d9b977f3:

    # "How idiotic. It’s thoughts like these that make me positive that my own imagination would get me killed, if I let it run this wild."
    "Che idiota. Sono pensieri come questi che mi convincono che la mia immaginazione, se la lasciassi libera di scatenarsi, finirebbe per uccidermi."

# game/act1.rpy:627
translate italian act1_fe347ebb:

    # "I don’t have time for stupidity.{w} I raise my paw and hail a cab."
    "Non ho tempo per le stupidaggini.{w} Alzo la zampa e chiamo un taxi."

# game/act1.rpy:631
translate italian act1_ea1cd4a1:

    # "Forty minutes later and I’m rushing through the doors of the Valentine Report, donut box in one hand and coffee cup in the other."
    "Quaranta minuti dopo, mi ritrovo a varcare la soglia del Valentine Report, con la scatola di ciambelle in una mano e la tazza di caffè nell'altra."

# game/act1.rpy:632
translate italian act1_e75b5ea7:

    # "I dash into Mr. Valentine’s office, praying to God that he somehow got delayed, that he got caught in traffic – or better yet, in a minor car accident, even!"
    "Mi precipito nell'ufficio del signor Valentine, pregando Dio che in qualche modo abbia subito un ritardo, che sia rimasto bloccato nel traffico – o meglio ancora, che sia stato coinvolto in un piccolo incidente stradale!"

# game/act1.rpy:633
translate italian act1_2e2b67e5:

    # "Unfortunately, I’m not so lucky."
    "Purtroppo io non sono così fortunato."

# game/act1.rpy:636
translate italian act1_878552ca:

    # v "You’re late."
    v "Sei in ritardo."

# game/act1.rpy:637
translate italian act1_28ba70bf:

    # a flustered "I’m sorry, I-"
    a flustered "Mi dispiace, io-"

# game/act1.rpy:638
translate italian act1_d83113a5:

    # v hm "Bore someone else with your excuses. Hand me my coffee."
    v hm "Annoia qualcun altro con le tue scuse. Passami il caffè."

# game/act1.rpy:640
translate italian act1_218759ec:

    # "I slide everything onto his desk, and he lets out a long, drawn-out sigh."
    "Faccio scivolare tutto sulla sua scrivania, e lui emette un lungo, prolungato sospiro."

# game/act1.rpy:642
translate italian act1_cdd82002:

    # v hm "Is everyone in the world incompetent?"
    v hm "Sono tutti incompetenti al mondo?"

# game/act1.rpy:643
translate italian act1_1e9598f8_2:

    # a worried "…"
    a worried "…"

# game/act1.rpy:644
translate italian act1_d7c8aceb:

    # v frown "That wasn’t rhetorical. I’d like an answer."
    v frown "Non era una domanda retorica. Vorrei una risposta."

# game/act1.rpy:645
translate italian act1_12397fa4:

    # a flustered "Huh? Uh…{w} no?"
    a flustered "Eh? Uh…{w} no?"

# game/act1.rpy:647
translate italian act1_3b69ecde:

    # "He rubs his temple, taking a sip of his coffee. Thankfully, no complaints there…"
    "Si massaggia le tempie, sorseggiando il caffè. Per fortuna, nessuna lamentela..."

# game/act1.rpy:649
translate italian act1_76f895d8:

    # v hm "Well, that certainly seems to be the case..."
    v hm "Beh, sembra proprio di sì..."

# game/act1.rpy:651
translate italian act1_effb38fa:

    # "Mr. Valentine has been running the corporation ever since I even started training to become a Valentine myself. In all the years that I’ve known him, he’s been more or less the same; a stoic, cold-mannered man with little regard for other’s feelings."
    "Il signor Valentine dirige l'azienda da quando ho iniziato l'addestramento per diventare io stesso un Valentine. In tutti questi anni in cui lo conosco, è sempre stato più o meno lo stesso: un uomo stoico, dai modi freddi e con poca considerazione per i sentimenti altrui."

# game/act1.rpy:652
translate italian act1_f3366767:

    # "I sometimes wonder if he’s even mortal. I’ve never once heard him complain about being tired, overworked, hungry, sad... you know, basic emotions we all have?"
    "A volte mi chiedo se sia davvero mortale. Non l'ho mai sentito lamentarsi di essere stanco, oberato di lavoro, affamato, triste... insomma, le emozioni basilari che proviamo tutti."

# game/act1.rpy:653
translate italian act1_38770b13:

    # "I have a few theories that include sociopathy and/or vampirism, but I think the most likely reason is he’s just an asshole."
    "Ho alcune teorie che includono la sociopatia e/o il vampirismo, ma penso che la ragione più probabile sia semplicemente che è uno stronzo."

# game/act1.rpy:655
translate italian act1_f80bbf20:

    # a yeesh "{i}Sometimes, the answer is the most obvious explanation."
    a yeesh "A volte, la risposta è la spiegazione più ovvia."

# game/act1.rpy:657
translate italian act1_94817ef0:

    # "Still, to say I hate him wouldn't be the whole truth. My feelings for Mr. Valentine are as complex as the tasks he so wilfully makes me do..."
    "Tuttavia, dire che lo odio non sarebbe del tutto vero. I miei sentimenti per il signor Valentine sono complessi quanto i compiti che mi costringe ostinatamente a svolgere..."

# game/act1.rpy:659
translate italian act1_3e32c7a1:

    # v hm "So, Angel. Do tell… what advancements have you made on the missing person’s story? I haven’t gotten a single report from you all week."
    v hm "Allora, Angel, dimmi... che progressi hai fatto nella vicenda della persona scomparsa? Non ho ricevuto nessun aggiornamento da te per tutta la settimana."

# game/act1.rpy:660
translate italian act1_2c55d2a5:

    # a bashful "Ah, y-yes, sorry… I was actually planning on writing one today. I’ll go do that now, if you’ll excuse me…"
    a bashful "Ah, s-sì, scusa… In realtà avevo intenzione di scriverne uno oggi. Vado a farlo subito, se mi permetti…"

# game/act1.rpy:661
translate italian act1_28402040:

    # v stan "No need. I’m right here, after all."
    v stan "Non ce n'è bisogno. Dopotutto, sono proprio qui."

# game/act1.rpy:662
translate italian act1_7bebfa4a:

    # v "Talk to me."
    v "Parla con me."

# game/act1.rpy:663
translate italian act1_620b4cf8_1:

    # a flustered "…"
    a flustered "…"

# game/act1.rpy:664
translate italian act1_48ba359a:

    # a bashful "Yes… well, I have made a few advancements…"
    a bashful "Sì… beh, ho fatto qualche progresso…"

# game/act1.rpy:665
translate italian act1_79ae6925:

    # v hm "Such as?"
    v hm "Ad esempio?"

# game/act1.rpy:666
translate italian act1_836c9b1f:

    # a flustered "Um…"
    a flustered "Ehm…"

# game/act1.rpy:667
translate italian act1_508a4113:

    # v glare "Hm? Spit it out."
    v glare "Mh? Sputa il rospo."

# game/act1.rpy:668
translate italian act1_a80539b9:

    # v "What have you figured out, my Valentine?"
    v "Cos'hai scoperto, mio ​​Valentino?"

# game/act1.rpy:669
translate italian act1_2a4ff97c_6:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:671
translate italian act1_800c8b73:

    # "He knows I know something. Of course he does. A flick of the ear, a twitch of the eye, a single spasm in your finger, and Mr. Valentine can read your mind. Just like that."
    "Lui sa che so qualcosa. Certo che lo sa. Un movimento dell'orecchio, un tic all'occhio, un singolo spasmo al dito, e il signor Valentine può leggerti nel pensiero. Così, in un attimo."

# game/act1.rpy:673
translate italian act1_06f39335_1:

    # a stan "…"
    a stan "…"

# game/act1.rpy:675
translate italian act1_e1c5830c:

    # a frown "I believe Corona’s is somehow involved, sir."
    a frown "Credo che il coronavirus sia in qualche modo coinvolto, signore."

# game/act1.rpy:676
translate italian act1_bed3fbbc:

    # v "…"
    v "…"

# game/act1.rpy:679
translate italian act1_09e2ee76:

    # v "Is that so…?"
    v "È così…?"

# game/act1.rpy:681
translate italian act1_73172134:

    # "He says that more to himself than to me, and I have a feeling he already knew. However, his face still seems a bit surprised by this."
    "Lo dice più a se stesso che a me, e ho la sensazione che lo sapesse già. Tuttavia, la sua espressione sembra ancora un po' sorpresa."

# game/act1.rpy:683
translate italian act1_942a14b9:

    # v hm "What are your sources?"
    v hm "Quali sono le tue fonti?"

# game/act1.rpy:684
translate italian act1_c0f17b45:

    # a surprised "Oh. Um…"
    a surprised "Oh. Ehm…"

# game/act1.rpy:685
translate italian act1_08c74c0f:

    # v "I’m guessing your partner had something to do with it?"
    v "Immagino che il tuo partner c'entri qualcosa, vero?"

# game/act1.rpy:686
translate italian act1_8e5db748:

    # a flustered "My partner?"
    a flustered "Il mio partner?"

# game/act1.rpy:687
translate italian act1_d4199ab5:

    # v "Your police escort? Hutcherson, was it?"
    v "La sua scorta della polizia? Si chiamava Hutcherson, giusto?"

# game/act1.rpy:688
translate italian act1_33d2e68f:

    # a surprised "Oh! Yes, forgive me. Hutcherson wasn’t, um, involved, so-"
    a surprised "Oh! Sì, perdonatemi. Hutcherson non era, ehm, coinvolto, quindi-"

# game/act1.rpy:689
translate italian act1_93056945:

    # v frown "Oh please. I won’t get your little boyfriend in trouble. If he’s giving you valuable information, all the better."
    v frown "Oh, per favore. Non metterò nei guai il tuo fidanzatino. Se ti sta dando informazioni preziose, tanto meglio."

# game/act1.rpy:690
translate italian act1_06c2a380:

    # a "He’s not my-"
    a "Lui non è il mio-"

# game/act1.rpy:691
translate italian act1_7423d5ad:

    # v glare "In any case, your next step is clear, isn’t it?"
    v glare "In ogni caso, il tuo prossimo passo è chiaro, no?"

# game/act1.rpy:692
translate italian act1_ebab04de:

    # a flustered "Huh? Um…"
    a flustered "Eh? Ehm…"

# game/act1.rpy:693
translate italian act1_158912f3:

    # v hm "Isn’t it? Or do you want me to pass this story to someone more… capable?"
    v hm "Non è così? O preferisci che passi questa storia a qualcuno più... capace?"

# game/act1.rpy:695
translate italian act1_6af7789b:

    # a surprised "Of course not!"
    a surprised "Ovviamente no!"

# game/act1.rpy:698
translate italian act1_4a036494:

    # a concern "…sir."
    a concern "…Signore."

# game/act1.rpy:700
translate italian act1_4665d401:

    # v frown "Listen. Angel. I gave you this case because I have faith in your abilities. I always have."
    v frown "Ascolta, Angel. Ti ho affidato questo caso perché ho fiducia nelle tue capacità. L'ho sempre avuta."

# game/act1.rpy:701
translate italian act1_5d9c1143:

    # v hm "Despite what you may think of yourself, you’re one of the few Valentines with decent people's skills. I believe when it comes to these more… sensitive stories, the Valentines don’t have such a great reputation."
    v hm "Nonostante quello che pensi di te stesso, sei uno dei pochi Valentine con delle buone capacità relazionali. Credo che quando si tratta di queste storie più... delicate, i Valentine non godano di un'ottima reputazione."

# game/act1.rpy:702
translate italian act1_9fc54b64:

    # v frown "We’re seen as cold, calculated… unfeeling."
    v frown "Veniamo visti come freddi, calcolatori... insensibili."

# game/act1.rpy:703
translate italian act1_35889f11:

    # a yeesh "{i}I wonder why…"
    a yeesh "{i}Mi chiedo perché…"

# game/act1.rpy:704
translate italian act1_5f66f15e:

    # v stan "But you seem to have a more empathetic air to you. People open up to you. They want to tell you things because they believe you want to help them."
    v stan "Ma tu sembri avere un'aria più empatica. Le persone si aprono con te. Vogliono raccontarti le cose perché credono che tu voglia aiutarle."

# game/act1.rpy:705
translate italian act1_e952fc8f:

    # a concern "…I do want to help them."
    a concern "…Voglio aiutarli."

# game/act1.rpy:707
translate italian act1_6558c85a:

    # v frown "Then do it."
    v frown "Allora fallo."

# game/act1.rpy:708
translate italian act1_9ad414a4:

    # v glare "But don’t forget who comes first."
    v glare "Ma non dimenticate chi viene prima."

# game/act1.rpy:709
translate italian act1_bcae0112:

    # v frown "Now get out of my office. I’ve wasted enough time on this conversation."
    v frown "Ora esci dal mio ufficio. Ho già perso abbastanza tempo con questa conversazione."

# game/act1.rpy:710
translate italian act1_24c25ff2:

    # v hm "And take these donuts with you. This coffee is sweet enough as it is."
    v hm "E portatevi anche queste ciambelle. Questo caffè è già abbastanza dolce così com'è."

# game/act1.rpy:712
translate italian act1_e976ae02:

    # "And there’s the complaint."
    "Ed ecco la lamentela."

# game/act1.rpy:714
translate italian act1_76b307d7:

    # a sad "…{w}yes sir."
    a sad "…{w}sì signore."

# game/act1.rpy:716
translate italian act1_ab3b900c:

    # "I hang my head low as I grab the box of donuts from his desk, and I leave quietly, closing the door behind me."
    "Abbasso la testa mentre prendo la scatola di ciambelle dalla sua scrivania ed esco in silenzio, chiudendo la porta dietro di me."

# game/act1.rpy:722
translate italian act1_3735040f:

    # "I take the donuts to the breakroom, and I stuff one into my mouth as the conversation replays in my head."
    "Porto le ciambelle nella sala pausa e ne infilo una in bocca mentre la conversazione mi risuona nella testa."

# game/act1.rpy:723
translate italian act1_42c316c9:

    # "Does Mr. Valentine really believe in me? Does he think I have what it takes to solve this case? Or does he say that to everyone?"
    "Il signor Valentine crede davvero in me? Pensa che io abbia le capacità necessarie per risolvere questo caso? O lo dice a tutti?"

# game/act1.rpy:724
translate italian act1_dc8111a9:

    # "And he didn’t say anything about Corona’s involvement… what is he plotting?"
    "E non ha detto nulla sul coinvolgimento di Corona... cosa starà tramando?"

# game/act1.rpy:725
translate italian act1_cf2a8ab2:

    # "I don’t know what to think anymore {nw}"
    "Non so più cosa pensare {nw}"

# game/act1.rpy:729
translate italian act1_767f091f:

    # anon "BOO!"
    anon "BUH!"

# game/act1.rpy:731
translate italian act1_06f39335_2:

    # a stan "…"
    a stan "…"

# game/act1.rpy:732
translate italian act1_b77a292a:

    # c uh "…"
    c uh "…"

# game/act1.rpy:734
translate italian act1_7f94504a:

    # a smile "Morning."
    a smile "Mattina."

# game/act1.rpy:735
translate italian act1_86b37a63:

    # c disappointed "Aw, man…"
    c disappointed "Oh, cavolo…"

# game/act1.rpy:738
translate italian act1_113ad0c5:

    # c "You used to get so scared when I did that before. You’d be all like-"
    c "Prima ti spaventavi tantissimo quando lo facevo. Dicevi tipo-"

# game/act1.rpy:740
translate italian act1_48e3a9bb:

    # c "WAH!"
    c "WAH!"

# game/act1.rpy:741
translate italian act1_28ef1c35:

    # c disappointed "It was so cute… when did you grow out of it?"
    c disappointed "Era così carino... quando hai smesso di farlo?"

# game/act1.rpy:742
translate italian act1_89f3717b:

    # a cocky "Probably after the thousandth time you did it."
    a cocky "Probabilmente dopo averlo fatto per la millesima volta."

# game/act1.rpy:743
translate italian act1_78f9119a:

    # c pout "You’re no fun anymore."
    c pout "Non sei più divertente."

# game/act1.rpy:744
translate italian act1_d83d6c60:

    # c stan "Ooh, donuts."
    c stan "Oh, ciambelle."

# game/act1.rpy:746
translate italian act1_8220dd5a:

    # "Cameron, my coworker in the journalist unit of the corporation and annoying manchild, grabs two donuts from the dozen and eats them both at the same time, alternating bites between the two and chewing with his mouth open."
    "Cameron, il mio collega nella redazione giornalistica dell'azienda, un eterno Peter Pan insopportabile, prende due ciambelle dalla dozzina e le mangia entrambe contemporaneamente, alternando morsi e masticando a bocca aperta."

# game/act1.rpy:748
translate italian act1_8737e597:

    # a smile "What are you doing here so early, anyway?"
    a smile "Cosa ci fai qui così presto, comunque?"

# game/act1.rpy:750
translate italian act1_d0f31de8:

    # "Cameron leans coolly against the counter, rolling his eyes."
    "Cameron si appoggia con aria indifferente al bancone, alzando gli occhi al cielo."

# game/act1.rpy:752
translate italian act1_0fca3adb:

    # c "Valentine’s on my ass about punching in on time. When have we ever needed to punch in? This isn’t some office job."
    c "Valentine mi sta addosso perché timbro il cartellino in orario. Quando mai è stato necessario timbrare il cartellino? Non è un lavoro d'ufficio."

# game/act1.rpy:753
translate italian act1_afa6c99a:

    # c cocky "But he did assign me a very cool, very special story."
    c cocky "Ma mi ha affidato una storia davvero fantastica e speciale."

# game/act1.rpy:754
translate italian act1_3d4ea273:

    # a surprised "Really?"
    a surprised "Veramente?"

# game/act1.rpy:755
translate italian act1_cd2f9355:

    # c "Yup. I have the honor of writing an article for the grand opening of the second public library here in Sonora."
    c "Sì. Ho l'onore di scrivere un articolo per l'inaugurazione della seconda biblioteca pubblica qui a Sonora."

# game/act1.rpy:757
translate italian act1_ab391241:

    # a yeesh "Wow. Monumental…"
    a yeesh "Wow. Monumentale…"

# game/act1.rpy:758
translate italian act1_bb78aab7:

    # c "I know."
    c "Lo so."

# game/act1.rpy:760
translate italian act1_ed0b5f88:

    # "He takes another bite, chewing in pent up frustration."
    "Dà un altro morso, masticando per sfogare la frustrazione repressa."

# game/act1.rpy:762
translate italian act1_6118f869:

    # a bashful "Sorry you get the low hanging fruit."
    a bashful "Mi dispiace che tu abbia raccolto i frutti più facili."

# game/act1.rpy:763
translate italian act1_6d29e0ee:

    # c cocky "It’s fine. If Valentine wants to give {i}me{/i} these cheese-ass stories… then I’ll take my time with them. Treat it as a mini vacation."
    c cocky "Va bene. Se Valentine vuole raccontarmi queste storie sdolcinate... allora me le prenderò con calma. Considerala una mini vacanza."

# game/act1.rpy:767
translate italian act1_6129a2cf:

    # "He suddenly leans closer to me, invading my personal space and looking me right in the eyes with an odd, piercing glare."
    "All'improvviso si avvicina a me, invadendo il mio spazio personale e guardandomi dritto negli occhi con uno sguardo strano e penetrante."

# game/act1.rpy:769
translate italian act1_83425007:

    # c flirty "But you can’t say the same, can you? Little Angel got a big story, didn’t he?"
    c flirty "Ma non si può dire lo stesso, vero? Il piccolo Angel ha una storia fantastica da raccontare, no?"

# game/act1.rpy:770
translate italian act1_2a4ff97c_7:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:771
translate italian act1_06766ba4:

    # a flustered "I, uh… I guess so…"
    a flustered "Io, uh… credo di sì…"

# game/act1.rpy:773
translate italian act1_20634e04:

    # a bashful "Mr. Valentine said it’s because I have more ‘people’s skills’, if you can believe that."
    a bashful "Il signor Valentine ha detto che è perché ho più \"abilità relazionali\", se ci credete."

# game/act1.rpy:774
translate italian act1_121198f1:

    # c cocky "Hah!"
    c cocky "Ah!"

# game/act1.rpy:777
translate italian act1_07e37438:

    # "He backs off, the mood growing light again in an instant."
    "Si tira indietro, e l'atmosfera si fa di nuovo più leggera in un istante."

# game/act1.rpy:779
translate italian act1_1cf03f8b:

    # c "More than me? That’s hard to believe."
    c "Più di me? È difficile da credere."

# game/act1.rpy:781
translate italian act1_7e23a12a:

    # anon "Is it, though?"
    anon "Davvero?"

# game/act1.rpy:784
translate italian act1_e23fb6bd:

    # a smile "Oh, hi Mika."
    a smile "Oh, ciao Mika."

# game/act1.rpy:785
translate italian act1_4be652ed:

    # c hm "Here comes the fun police."
    c hm "Ecco che arriva la polizia del divertimento."

# game/act1.rpy:786
translate italian act1_c1168a2b:

    # mk stan "Don’t let him fool you, Angel. Cam is only somewhat capable in what he does."
    mk stan "Non lasciarti ingannare, Angel. Cam è solo parzialmente capace in quello che fa."

# game/act1.rpy:787
translate italian act1_e35e0d49:

    # c "I’ve been here longer than you."
    c "Sono qui da più tempo di te."

# game/act1.rpy:788
translate italian act1_1cdbd353:

    # mk hm "Doesn’t make you better."
    mk hm "Non ti rende migliore."

# game/act1.rpy:789
translate italian act1_f01800d0:

    # c "Uh, yeah, it does."
    c "Ehm, sì, lo fa."

# game/act1.rpy:791
translate italian act1_06c2f801:

    # "Mika is my only other coworker in the journalist unit, making three of us in total. I guess you can say we’re all friends… that never hang out outside of work. Probably because none of us actually want to be here."
    "Mika è la mia unica altra collega nella redazione giornalistica, quindi siamo in tre in totale. Direi che siamo tutti amici... che però non si vedono mai fuori dal lavoro. Probabilmente perché nessuno di noi vorrebbe davvero essere qui."

# game/act1.rpy:792
translate italian act1_42e5cb90:

    # "Mika is kind of Cameron’s opposite; quiet and very no nonsense. Despite this though, I find myself opening up to her more than anyone else in the corporation."
    "Mika è un po' l'opposto di Cameron: tranquilla e molto pragmatica. Nonostante ciò, mi ritrovo ad aprirmi con lei più che con chiunque altro in azienda."

# game/act1.rpy:793
translate italian act1_2a6f2ada:

    # "Compared to me, both of them have more experience in serious stories like this. So, maybe…"
    "Rispetto a me, entrambi hanno più esperienza in storie serie come questa. Quindi, forse…"

# game/act1.rpy:796
translate italian act1_0bb99e50:

    # a "Hey, you two… I have a bit of a weird question."
    a "Ehi, voi due… ho una domanda un po’ strana."

# game/act1.rpy:797
translate italian act1_074b93cc:

    # mk "Oh?"
    mk "OH?"

# game/act1.rpy:798
translate italian act1_8f1a8e41:

    # c hm "Is this about your cop boyfriend? I’m telling you, kid, never trust a narc."
    c hm "Si tratta del tuo ragazzo poliziotto? Te lo dico io, ragazzina, non fidarti mai di un agente della polizia."

# game/act1.rpy:801
translate italian act1_54923d8b:

    # a flustered "What? No! And he’s not my boyfriend!"
    a flustered "Cosa? No! E non è il mio ragazzo!"

# game/act1.rpy:802
translate italian act1_3ac9b187:

    # a worried "This is… about my story."
    a worried "Questa è… la mia storia."

# game/act1.rpy:806
translate italian act1_91731e29:

    # a "What would you guys do if… Corona was involved?"
    a "Cosa fareste se... ci fosse di mezzo il Coronavirus?"

# game/act1.rpy:808
translate italian act1_6fa85c4d:

    # a concern "What? What’s with the faces?"
    a concern "Cosa? Che cos'hanno in comune quelle facce?"

# game/act1.rpy:811
translate italian act1_c9be7db5:

    # mk worried "That’s just… a very heavy claim, Angel."
    mk worried "Questa è semplicemente... un'affermazione molto pesante, Angel."

# game/act1.rpy:812
translate italian act1_8de031a3:

    # c hm "Shit, Corona? Are you sure? There’s a lot of different casinos here. That’s like, the whole appeal of this city."
    c hm "Merda, Corona? Sei sicuro? Ci sono un sacco di casinò diversi qui. È proprio questo il bello di questa città."

# game/act1.rpy:813
translate italian act1_1099be1c:

    # a surprised "I know… but, I’m pretty sure Corona is at the center of this. I’ve got evidence pointing back to them, all of the missing person’s cases that involve high-class individuals falling into gambling addiction."
    a surprised "Lo so… ma sono abbastanza sicuro che Corona sia al centro di tutto questo. Ho delle prove che puntano verso di loro, tutti i casi di persone scomparse che coinvolgono individui di alto rango caduti nella dipendenza dal gioco d'azzardo."

# game/act1.rpy:814
translate italian act1_dcc7e2fd:

    # a frown "Isn’t it possible? I mean, if I could just… question the staff…"
    a frown "Non è possibile? Voglio dire, se solo potessi… interrogare il personale…"

# game/act1.rpy:817
translate italian act1_0e10e33f:

    # mk "You can’t!"
    mk "Non puoi!"

# game/act1.rpy:820
translate italian act1_d58a08c7:

    # mk worried "I mean… You shouldn’t…"
    mk worried "Voglio dire… Non dovresti…"

# game/act1.rpy:822
translate italian act1_16244947:

    # c "What Mika means is that Corona isn’t {i}just{/i} a casino."
    c "Ciò che Mika intende dire è che Corona non è {i}solo{/i} un casinò."

# game/act1.rpy:829
translate italian act1_a59ec0a7:

    # c "This city was built around it. Quite literally."
    c "Questa città è stata costruita attorno ad essa. Letteralmente."

# game/act1.rpy:830
translate italian act1_3c12c00a:

    # c "It’s not just some tourist attraction, or a fancy five-star hotel... Corona’s is everything that makes Sonora a powerhouse of a society."
    c "Non si tratta di una semplice attrazione turistica o di un lussuoso hotel a cinque stelle... Corona's rappresenta tutto ciò che rende Sonora una società dinamica e all'avanguardia."

# game/act1.rpy:831
translate italian act1_fc24abd3:

    # c "The hold it has on the economy, on the minds of the people, on the elites of this world… it’s on a whole other level. They're basically the government here. You {i}cannot{/i} mess with them without consequence."
    c "Il controllo che esercita sull'economia, sulle menti delle persone, sulle élite di questo mondo... è di un livello completamente diverso. Sono praticamente il governo qui. Non puoi metterti contro di loro senza subirne le conseguenze."

# game/act1.rpy:838
translate italian act1_4abec6a2:

    # c "They’re untouchable. The only way into their inner circle is either being a damn good gambler or being stupid rich. And a little reminder, kid, you’re neither of those things."
    c "Sono intoccabili. L'unico modo per entrare nella loro cerchia ristretta è essere un giocatore d'azzardo dannatamente bravo o essere incredibilmente ricco. E un piccolo promemoria, ragazzo, tu non sei nessuna delle due cose."

# game/act1.rpy:839
translate italian act1_9b6ef9d3:

    # mk "Mixing with Corona and getting too close is a bad idea, Angel."
    mk "Mescolarsi con Corona e avvicinarsi troppo è una pessima idea, Angel."

# game/act1.rpy:840
translate italian act1_1ab72481_1:

    # a concern "…"
    a concern "…"

# game/act1.rpy:842
translate italian act1_b08f0221:

    # a "But… we’re Valentines. Surely, we have some immunity, right? I mean, we’re not high-class elites, but we do have protection from the S.P.D., don’t we?"
    a "Ma... siamo dei Valentine. Sicuramente abbiamo una qualche immunità, no? Voglio dire, non siamo l'élite di alto rango, ma abbiamo la protezione dell'SPD, no?"

# game/act1.rpy:844
translate italian act1_9328924b:

    # c hm "Angel, if the Casino had to choose between facing the punishment of killing a Valentine, or protecting their own reputation… do you really think it’s a close call?"
    c hm "Angel, se il Casinò dovesse scegliere tra affrontare la punizione di aver ucciso un Valentine o proteggere la propria reputazione... credi davvero che la scelta sarebbe difficile?"

# game/act1.rpy:845
translate italian act1_72e94c19:

    # a "…"
    a "…"

# game/act1.rpy:848
translate italian act1_cef03c43:

    # a "Wh… why, then? Why did Mr. Valentine even give me a story like this in the first place?"
    a "Perché... perché, allora? Perché il signor Valentine mi ha raccontato una storia del genere?"

# game/act1.rpy:850
translate italian act1_e91e1474:

    # mk worried "Honestly?"
    mk worried "Onestamente?"

# game/act1.rpy:851
translate italian act1_4246521a:

    # mk "I think he expected you to fail."
    mk "Penso che si aspettasse che tu fallissi."

# game/act1.rpy:853
translate italian act1_7d5f8d55:

    # a sad "…"
    a sad "…"

# game/act1.rpy:854
translate italian act1_6218b584:

    # c "…"
    c "…"

# game/act1.rpy:856
translate italian act1_59d328cd:

    # c cocky "Hey, cheer up. Valentine’s a freak, anyway. You’re still practically a newbie at this. One failed assignment isn’t gonna stain your record. Maybe it’ll hurt your bonus, but, uh… what can you do, y’know…?"
    c cocky "Ehi, su con il morale. Valentine è una pazza, comunque. Sei ancora praticamente una principiante in questo campo. Un compito andato male non rovinerà la tua carriera. Magari ti danneggerà il bonus, ma, uh... che ci puoi fare, sai...?"

# game/act1.rpy:858
translate italian act1_9907a90e:

    # "He chuckles, trying to lighten the mood a bit, but it only makes this whole situation seem more like what it truly is: a big joke.{w} And I’m the punchline."
    "Lui ridacchia, cercando di sdrammatizzare un po', ma questo non fa altro che rendere l'intera situazione ancora più simile a quello che è realmente: un grande scherzo.{w} E io sono la battuta finale."

# game/act1.rpy:860
translate italian act1_1452821e:

    # mk worried "Listen, Angel. Corona’s influence in this city is so grand, that even if you’re outside of its walls, you’re {i}still{/i} gambling. Still risking your livelihood by even thinking about getting involved with it."
    mk worried "Ascolta, Angel. L'influenza del Coronavirus in questa città è così grande che, anche se sei fuori dalle sue mura, stai comunque rischiando. Stai ancora mettendo a repentaglio il tuo sostentamento anche solo pensando di esserne coinvolto."

# game/act1.rpy:861
translate italian act1_5d05f955:

    # mk "And as Valentines, we can’t take that risk."
    mk "E noi, in quanto innamorati, non possiamo correre questo rischio."

# game/act1.rpy:862
translate italian act1_ae62c068:

    # mk "Because we aren’t just risking our own lives."
    mk "Perché non stiamo rischiando solo la nostra vita."

# game/act1.rpy:866
translate italian act1_91db3ebe:

    # a "Mom…"
    a "Mamma…"

# game/act1.rpy:871
translate italian act1_c5d8b108:

    # c cocky "Well, that’s that, then! You just treat this like a vacation, too. Dick around, talk to people around the missing person’s inner circle, and tell Valentine he’s shit outta luck. You’re not messing with Corona."
    c cocky "Bene, allora è fatta! Considera anche questa come una vacanza. Gira per casa, parla con le persone vicine alla persona scomparsa e dì a Valentine che è proprio sfortunato. Non si scherza con Corona."

# game/act1.rpy:873
translate italian act1_b5ba8976:

    # "He slaps his paw on my shoulder, forcing a smile."
    "Mi dà una zampata sulla spalla, costringendomi a sorridere."

# game/act1.rpy:875
translate italian act1_44b405fd:

    # c cocky "And if you get bored, we can play chess in the breakroom when the boss ain’t around. I might even let you win next time."
    c cocky "E se ti annoi, possiamo giocare a scacchi nella sala relax quando il capo non c'è. Magari la prossima volta ti lascio anche vincere."

# game/act1.rpy:876
translate italian act1_2084c278:

    # a cocky "Tch. You’re on."
    a cocky "Tch. Tocca a te."

# game/act1.rpy:879
translate italian act1_b373285f:

    # "He gives me a hard squeeze, then turns around and heads out the door, sharing a glance with Mika as he exits the room."
    "Mi stringe forte, poi si gira ed esce dalla porta, scambiando un'occhiata con Mika mentre lascia la stanza."

# game/act1.rpy:883
translate italian act1_7d5f8d55_1:

    # a sad "…"
    a sad "…"

# game/act1.rpy:884
translate italian act1_4a7e75cf:

    # mk "I know you want to help her, Angel. But sometimes, the smartest move in a game is to not play at all."
    mk "So che vuoi aiutarla, Angel. Ma a volte, la mossa più saggia in un gioco è non giocare affatto."

# game/act1.rpy:885
translate italian act1_97005c09:

    # a bashful "…maybe you’re right."
    a bashful "…forse hai ragione."

# game/act1.rpy:887
translate italian act1_1ddc2c35:

    # a flattered "Thanks, Mika."
    a flattered "Grazie, Mika."

# game/act1.rpy:888
translate italian act1_e3530c2c:

    # mk "I’ll leave you to it, then."
    mk "Allora ti lascio fare."

# game/act1.rpy:892
translate italian act1_1ab72481_2:

    # a concern "…"
    a concern "…"

# game/act1.rpy:894
translate italian act1_cc2adb1b:

    # "Doubts fill my head, swirling around until it numbs the rest of my body."
    "I dubbi mi affollano la mente, turbinandomi intorno fino a intorpidirmi il resto del corpo."

# game/act1.rpy:895
translate italian act1_4a358500:

    # "Am I maybe just not good enough to solve this? Is Mr. Valentine just pulling a really big, elaborate ‘fuck you’ right in my face?"
    "Forse non sono abbastanza brava per risolvere questo problema? Il signor Valentine mi sta forse mandando a quel paese in modo plateale e plateale?"

# game/act1.rpy:896
translate italian act1_31e1bb4b:

    # "What is he expecting me to do? And, more importantly…"
    "Cosa si aspetta che io faccia? E, cosa ancora più importante…"

# game/act1.rpy:897
translate italian act1_548ef30c:

    # "What {i}am{/i} I going to do?"
    "Cosa {i}ho intenzione di{/i} fare?"

# game/act1.rpy:899
translate italian act1_2cfdf537:

    # "I think back to Mr. Yoshida, his strained expression as he spoke about his missing niece. I think about all the other missing people who came before Megumi, and how people seem to be going missing more and more frequently lately."
    "Ripenso al signor Yoshida, alla sua espressione tesa mentre parlava della nipote scomparsa. Penso a tutte le altre persone scomparse prima di Megumi, e a come ultimamente le sparizioni sembrino diventare sempre più frequenti."

# game/act1.rpy:900
translate italian act1_47304362:

    # "And I think of Mr. Valentine’s cold, knowing look, telling me exactly what I should do."
    "E ripenso allo sguardo freddo e sapiente del signor Valentine, che mi diceva esattamente cosa avrei dovuto fare."

# game/act1.rpy:902
translate italian act1_d4768e5a:

    # "My job."
    "Il mio lavoro."

# game/act1.rpy:906
translate italian act1_9e17a4d9:

    # "Fear bubbles in my chest as I look up to see the grand building before me."
    "La paura mi attanaglia il petto mentre alzo lo sguardo e vedo l'imponente edificio che si erge di fronte a me."

# game/act1.rpy:907
translate italian act1_9c3a1209:

    # "For being so off-limits, the casino is incredibly inviting; people pour inside despite it being relatively early, and there seems to be no one guarding the actual entrance."
    "Nonostante sia un luogo così inaccessibile, il casinò è incredibilmente invitante; la gente si riversa all'interno anche se è relativamente presto, e sembra non esserci nessuno a sorvegliare l'ingresso."

# game/act1.rpy:908
translate italian act1_52648680:

    # "I take small glances inside, the flickering of lights and the sounds of slot machines being audible even from all the way out here."
    "Do brevi occhiate all'interno, il luccichio delle luci e il rumore delle slot machine si sentono persino da quassù."

# game/act1.rpy:909
translate italian act1_330d49a5:

    # "It sounds… fun."
    "Sembra... divertente."

# game/act1.rpy:911
translate italian act1_2a4ff97c_8:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:912
translate italian act1_a5e10b62:

    # a flustered "{i}N-no way. There I go again, thinking stupid things. How can throwing money into a machine and hoping it matches three symbols in a row possibly be any fun at all?"
    a flustered "{i}N-no, non ci credo. Eccomi di nuovo a pensare a cose stupide. Come può essere divertente buttare soldi in una macchinetta e sperare che escano tre simboli di fila?"

# game/act1.rpy:914
translate italian act1_5cb2a6e0:

    # "That’s right. It’s just the allure of the casino. That’s what they’re designed to do."
    "Esatto. È proprio il fascino del casinò. È per questo che sono stati progettati."

# game/act1.rpy:916
translate italian act1_3094c3bf:

    # "I’m stalling. {w}Again."
    "Sto prendendo tempo. {w}Di nuovo."

# game/act1.rpy:917
translate italian act1_8a753b57:

    # "My heart’s hammering in my chest as I take yet another quick peek inside. I mean… there’s no {i}explicit{/i} rule a Valentine can’t just {i}enter{/i} a casino, right? Surely, Mr. Valentine would’ve stopped me had that been the case."
    "Il cuore mi batte forte nel petto mentre do un'altra rapida occhiata all'interno. Voglio dire... non c'è nessuna regola esplicita che impedisca a un innamorato di entrare in un casinò, giusto? Sicuramente, il signor Valentine mi avrebbe fermato se fosse stato così."

# game/act1.rpy:919
translate italian act1_06f39335_3:

    # a stan "…"
    a stan "…"

# game/act1.rpy:920
translate italian act1_8ef2c679_1:

    # a frown "…"
    a frown "…"

# game/act1.rpy:922
translate italian act1_d649132f:

    # "No. I can’t let my own fears and desires get in the way of my work. I’m a Valentine, not some amateur freelancer. This is what I was made to do."
    "No. Non posso permettere che le mie paure e i miei desideri si intromettano nel mio lavoro. Sono una Valentine, non una freelance dilettante. Questo è ciò per cui sono nata."

# game/act1.rpy:924
translate italian act1_16a9b7a9:

    # a "{i}That’s right. Unfeeling, calculated, and efficient. Get the job done."
    a "{i}Esatto. Insensibile, calcolatore ed efficiente. Porta a termine il lavoro."

# game/act1.rpy:925
translate italian act1_e6c9e262:

    # a "{i}Your livelihood isn’t the only thing on the line…"
    a "{i}Il tuo sostentamento non è l'unica cosa in gioco…"

# game/act1.rpy:927
translate italian act1_eefe62a7:

    # "I brush back my hair in a slow, soothing way… and take a step forward, entering the casino."
    "Mi pettino i capelli lentamente, con un gesto rilassante… e faccio un passo avanti, entrando nel casinò."

# game/act1.rpy:930
translate italian act1_c1c64b14:

    # "The lobby itself is a beautiful, spacious area, with a fountain at its center, filling the room with the sound of rushing water."
    "La hall è un ambiente splendido e spazioso, con una fontana al centro che riempie la stanza con il suono dell'acqua che scorre."

# game/act1.rpy:931
translate italian act1_3e987cfa:

    # "Prestigious looking people banter quietly around it, and further along this room is an entryway to where I’m positive the casino is. To my right, a hall leads towards the registration desk, and even further seems to be a restaurant."
    "Persone dall'aspetto prestigioso chiacchierano sottovoce intorno a questa stanza, e più avanti c'è un ingresso che, ne sono certo, conduce al casinò. Alla mia destra, un corridoio porta alla reception, e ancora più in là sembra esserci un ristorante."

# game/act1.rpy:932
translate italian act1_5b74122a:

    # "I can only guess that even deeper inside the building is the actual hotel lobby, where I’m sure leads to the many rooms available in this resort."
    "Posso solo immaginare che ancora più in profondità nell'edificio si trovi la vera e propria hall dell'hotel, da cui sicuramente si accede alle numerose camere disponibili in questo resort."

# game/act1.rpy:933
translate italian act1_38654dfb:

    # "Access is most likely only granted with a room keycard, and I wouldn’t be surprised if even the elevators won’t function if you don’t have one on you."
    "L'accesso è molto probabilmente consentito solo tramite la tessera magnetica della camera, e non mi sorprenderei se persino gli ascensori non funzionassero in assenza di tale tessera."

# game/act1.rpy:934
translate italian act1_435cd0bc:

    # "This place truly has it all…"
    "Questo posto ha davvero tutto..."

# game/act1.rpy:935
translate italian act1_9004a9c6:

    # "I walk aimlessly around the fountain, feigning interest… well, maybe not feigning it. I am quite interested, but not so much in the architecture of the place, as beautiful as it may be. There’s something else that caught my attention."
    "Giro senza meta intorno alla fontana, fingendo interesse… beh, forse non fingendo. Sono piuttosto interessato, ma non tanto all'architettura del luogo, per quanto bella possa essere. C'è qualcos'altro che ha catturato la mia attenzione."

# game/act1.rpy:936
translate italian act1_3d0008e5:

    # "This is the very last room Megumi was last seen in. I’m positive of it."
    "Questa è l'ultima stanza in cui Megumi è stata vista. Ne sono certo."

# game/act1.rpy:937
translate italian act1_098c2984:

    # "The patterns on the floor match exactly… but, how? Corona’s is in the middle of the city. Surely, some other camera must have picked up her trail…?"
    "I motivi sul pavimento corrispondono perfettamente... ma com'è possibile? Il locale di Corona si trova in centro città. Sicuramente qualche altra telecamera deve averla ripresa...?"

# game/act1.rpy:938
translate italian act1_b990767b:

    # "All the more reason to question the staff. And speaking of…"
    "Un motivo in più per mettere in discussione il personale. E a proposito di..."

# game/act1.rpy:939
translate italian act1_446f16d2:

    # a body2 uniform thinking "Hm…"
    a body2 uniform thinking "Hmm…"

# game/act1.rpy:941
translate italian act1_827db9a8:

    # "I walk up to the fountain, staring down at my distorted reflection in the ripples of the water. I do my best to appear unassuming, with my hands behind my back, looking at nothing in particular."
    "Mi avvicino alla fontana, fissando il mio riflesso distorto nelle increspature dell'acqua. Cerco di apparire modesto, con le mani dietro la schiena, senza guardare in particolare."

# game/act1.rpy:942
translate italian act1_1f1551c5:

    # "In reality, I’m gathering a ton of information."
    "In realtà, sto raccogliendo un'enorme quantità di informazioni."

# game/act1.rpy:943
translate italian act1_498205b5:

    # "In the entryway to the casino, just shy of my peripheral vision, stand two large men on either side. A polar bear to the right, a bull to the left. Stereotypical bouncers, but I suppose they can’t afford to have anything less than the biggest and strongest in a place like this."
    "All'ingresso del casinò, appena fuori dal mio campo visivo periferico, si stagliano due uomini imponenti ai lati. Un orso polare a destra, un toro a sinistra. I classici buttafuori, ma immagino che in un posto come questo non possano permettersi di avere niente di meno che i più grossi e forti."

# game/act1.rpy:944
translate italian act1_06ab6df9:

    # "I close my eyes, yawning without a sound as I try to pick up on anything they might be saying, the urge to flick my ears to their direction as strong as it ever is. Like an itch I’m not allowed to scratch."
    "Chiudo gli occhi, sbadiglio senza emettere alcun suono mentre cerco di cogliere qualcosa di quello che potrebbero dire, l'impulso di drizzare le orecchie nella loro direzione forte come sempre. Come un prurito che non mi è permesso grattarmi."

# game/act1.rpy:945
translate italian act1_6eca5595:

    # "I resist, of course… but unfortunately for me, the two men don’t make a sound."
    "Io resisto, naturalmente… ma sfortunatamente per me, i due uomini non emettono un suono."

# game/act1.rpy:947
translate italian act1_acd7ab5c:

    # a body2 frown2 "{i}This isn’t good. I’m not getting anything useful just standing here, and it’s not like I can just go up and talk to them…"
    a body2 frown2 "{i}Non va bene. Non ottengo niente di utile stando qui fermo, e non è che possa semplicemente avvicinarmi e parlare con loro..."

# game/act1.rpy:948
translate italian act1_98614485:

    # a body2 hm2 "{i}Well, it’s not the end of the world. I at least know what they look like. If I can talk to Ethan and ask him to get me information on every bull and polar bear in the city…"
    a body2 hm2 "{i}Beh, non è la fine del mondo. Almeno so che aspetto hanno. Se potessi parlare con Ethan e chiedergli di procurarmi informazioni su ogni toro e orso polare della città..."

# game/act1.rpy:949
translate italian act1_7a14a2f0:

    # a body concern "{i}But what good would that do for my story? Agh, that’s so needlessly complicated…! Why can’t I just go inside?!"
    a body concern "{i}Ma a cosa servirebbe alla mia storia? Ah, è così inutilmente complicato...! Perché non posso semplicemente entrare?!"

# game/act1.rpy:951
translate italian act1_8e0f8278:

    # "I guess technically I could… but I’m terrified of the consequences. I’d rather play it safe… like I always do."
    "Tecnicamente potrei, immagino... ma sono terrorizzato dalle conseguenze. Preferisco andare sul sicuro... come faccio sempre."

# game/act1.rpy:952
translate italian act1_ddb28b00:

    # "The casino itself might be off limits… but, maybe I could gather information at the registration? Even just going up to the hotel to snoop around would be wonderful."
    "Il casinò in sé potrebbe essere off limits... ma forse potrei raccogliere informazioni alla reception? Anche solo andare in hotel a curiosare sarebbe fantastico."

# game/act1.rpy:953
translate italian act1_28e0dea0:

    # "I’m just about to head towards the registration desk when something coming from the casino entryway catches my eye. Or rather-"
    "Sto per dirigermi verso il banco della registrazione quando qualcosa proveniente dall'ingresso del casinò attira la mia attenzione. O meglio..."

# game/act1.rpy:955
translate italian act1_631d3f96:

    # anon "Oh my… a Valentine in my casino? To what do I owe the pleasure?"
    anon "Oh mio Dio... un Valentino nel mio casinò? A cosa devo questo piacere?"

# game/act1.rpy:957
translate italian act1_3ef8f47e:

    # "…someone."
    "…qualcuno."

# game/act1.rpy:959
translate italian act1_a9737fa7:

    # "The man before me is none other than Leonidas Grey, the current owner of Corona's Casino. To say he’s rich and powerful would be downplaying his status – he’s one of the richest people in the entire country, probably top ten in the world."
    "L'uomo che ho di fronte non è altri che Leonidas Grey, l'attuale proprietario del Corona's Casino. Dire che è ricco e potente sarebbe riduttivo: è una delle persone più ricche di tutto il paese, probabilmente tra le prime dieci al mondo."

# game/act1.rpy:960
translate italian act1_e0c2f3dd:

    # "So, to see him in broad daylight, unprompted and with no security behind him is…"
    "Quindi, vederlo in pieno giorno, senza essere sollecitato e senza alcuna scorta alle spalle è…"

# game/act1.rpy:961
translate italian act1_d3e01b42:

    # "The large lion walks straight up to me, speaking in a sultry, sophisticated way that makes my skin crawl. My pulse quickens, and that feeling of fear comes right back, but I swallow it down, {i}hard."
    "Il grande leone mi si avvicina, parlando con un tono sensuale e sofisticato che mi fa venire i brividi. Il battito cardiaco accelera e quella sensazione di paura ritorna, ma la ingoio a fatica."

# game/act1.rpy:962
translate italian act1_f9fb622a:

    # "No one can see that I’m afraid. An emotion means death in this world."
    "Nessuno può vedere che ho paura. In questo mondo, un'emozione equivale alla morte."

# game/act1.rpy:963
translate italian act1_4ad61f65:

    # "I stand up straighter, putting one hand on my chest, the other behind my back. I bow, keeping my eyes locked on his, making sure he can’t read anything that might be written on my face."
    "Mi raddrizzo, portando una mano al petto e l'altra dietro la schiena. Mi inchino, tenendo gli occhi fissi nei suoi, assicurandomi che non possa leggere nulla di ciò che potrebbe essere scritto sul mio viso."

# game/act1.rpy:965
translate italian act1_8d760f82:

    # a stan "Excuse my intrusion, sir. Angel Valentine, of the Valentine Report. The pleasure is all mine."
    a stan "Mi scusi per l'intrusione, signore. Sono Angel Valentine, del Valentine Report. Il piacere è tutto mio."

# game/act1.rpy:967
translate italian act1_5b7685b5:

    # "He smiles, a low purr rumbling in the back of his throat as he does.{w} I don’t smile back."
    "Sorride, un basso ronronio che gli rimbomba in fondo alla gola mentre lo fa.{w} Io non ricambio il sorriso."

# game/act1.rpy:969
translate italian act1_a6800a27:

    # l "What a rare sight. The last time we had a Valentine enter these premises… oh, far too long."
    l "Che spettacolo raro. L'ultima volta che un Valentino è entrato in questi locali... oh, è passato davvero troppo tempo."

# game/act1.rpy:970
translate italian act1_1153e934:

    # a frown "Forgive my audacity, sir. I was simply…"
    a frown "Mi perdoni la mia audacia, signore. Ero semplicemente…"

# game/act1.rpy:972
translate italian act1_58790042:

    # "I freeze. I can’t think of a single excuse, and the fear of what this man might do to me is getting to my head."
    "Rimango paralizzata. Non riesco a trovare una sola scusa, e la paura di ciò che quest'uomo potrebbe farmi mi sta dando alla testa."

# game/act1.rpy:974
translate italian act1_2534a904:

    # a concern "I… was simply waiting for a client who requested we meet-"
    a concern "Io... stavo semplicemente aspettando un cliente che aveva richiesto un incontro."

# game/act1.rpy:975
translate italian act1_8e15d252:

    # l stan "I have no interest in fictional stories, Valentine. You of all people must understand that, as a seeker of truth."
    l stan "Non mi interessano le storie di fantasia, Valentine. Tu, che cerchi la verità, dovresti capirlo più di chiunque altro."

# game/act1.rpy:976
translate italian act1_497e7220:

    # "He purrs when he speaks, that English accent of his making every word that comes out of his mouth sound like something important."
    "Quando parla, fa le fusa, e quel suo accento inglese fa sì che ogni parola che esce dalla sua bocca suoni importante."

# game/act1.rpy:978
translate italian act1_72e94c19_1:

    # a "…"
    a "…"

# game/act1.rpy:979
translate italian act1_bdb7e440:

    # l ponder "As a matter of fact… I believe you have some business with me, do you not?"
    l ponder "In realtà… credo che tu abbia degli affari da sbrigare con me, non è così?"

# game/act1.rpy:980
translate italian act1_afa540c7:

    # a surprised "Business? No, I-"
    a surprised "Affari? No, io-"

# game/act1.rpy:981
translate italian act1_8c2ea5f9:

    # l surprised "No? There isn’t anything that you’d like to talk about with me?"
    l surprised "No? Non c'è niente di cui vorresti parlare con me?"

# game/act1.rpy:982
translate italian act1_9e0a61a1:

    # l peek "Is the reason you’re here… none of my concern?"
    l peek "Il motivo per cui sei qui... non mi riguarda affatto?"

# game/act1.rpy:985
translate italian act1_f3e195f2:

    # "The gross, icky feeling of being wrapped around someone else’s finger seeps into me, his eyes drilling into mine, not even blinking once."
    "La sensazione disgustosa e ripugnante di essere completamente in balia di qualcun altro mi pervade, i suoi occhi mi trafiggono senza battere ciglio."

# game/act1.rpy:986
translate italian act1_fba30e4e:

    # "It’s the same feeling I had with Mr. Yoshida, Mr. Valentine… and now, Mr. Grey. That’s my place in this city: nothing more than a pawn in the bigger game of chess these men play with each other."
    "È la stessa sensazione che provavo con il signor Yoshida, il signor Valentine... e ora, il signor Grey. Questo è il mio posto in questa città: niente più che una pedina nella grande partita a scacchi che questi uomini giocano tra di loro."

# game/act1.rpy:988
translate italian act1_1ab72481_3:

    # a concern "…"
    a concern "…"

# game/act1.rpy:989
translate italian act1_dd558478:

    # a "I do have some business with you, sir."
    a "Ho delle questioni da risolvere con lei, signore."

# game/act1.rpy:990
translate italian act1_f5891c95:

    # l ponder "That’s what I thought. Come then, Valentine."
    l ponder "Ecco cosa pensavo. Avanti, Valentine."

# game/act1.rpy:992
translate italian act1_f42dbed1:

    # "He turns and heads deeper into the building, not checking to see if I follow him; he knows I will. With a racing pulse, I lift my chin up and walk a few feet behind him, silently wondering if I’ll make it out of here alive."
    "Si volta e si addentra ulteriormente nell'edificio, senza nemmeno controllare se lo seguo; sa che lo farò. Con il cuore che mi batte all'impazzata, alzo il mento e cammino qualche passo dietro di lui, chiedendomi in silenzio se riuscirò a uscire viva da qui."

# game/act1.rpy:995
translate italian act1_b287243b:

    # "Walking straight past the reception desk, we enter the main lobby of the building: a beautiful, vast room with large staircases leading up to the rooms of the many elites who will no doubt enjoy their time here."
    "Proseguendo oltre la reception, entriamo nella hall principale dell'edificio: una sala ampia e splendida, con grandi scalinate che conducono alle stanze dei numerosi ospiti d'élite che senza dubbio apprezzeranno il loro soggiorno qui."

# game/act1.rpy:997
translate italian act1_b038933a:

    # a yeesh "{i}And spend a ton of cash in the process."
    a yeesh "E spendere un sacco di soldi nel frattempo."

# game/act1.rpy:999
translate italian act1_e84a32a7:

    # "I’m in awe at such a luxurious place. Even in my wildest dreams, I don’t dream something this big."
    "Sono sbalordita da un posto così lussuoso. Nemmeno nei miei sogni più sfrenati riuscirei a immaginare qualcosa di così grandioso."

# game/act1.rpy:1000
translate italian act1_664d556c:

    # "Mr. Grey keeps his stride as we walk up the steps, and to my surprise, strikes up a friendly conversation with me."
    "Il signor Grey mantiene il suo passo mentre saliamo le scale e, con mia sorpresa, inizia una conversazione amichevole con me."

# game/act1.rpy:1002
translate italian act1_d31e48d4:

    # l "Is this your first time inside?"
    l "È la prima volta che entri?"

# game/act1.rpy:1003
translate italian act1_b3754221:

    # a flustered "Yes, sir."
    a flustered "Sì, signore."

# game/act1.rpy:1004
translate italian act1_0612a485:

    # l "Marvelous, isn’t it? Its brilliance doesn’t get any easier to get used to, I’ve come to experience."
    l "Meraviglioso, vero? La sua genialità non diventa più facile da sopportare, l'ho imparato a mie spese."

# game/act1.rpy:1005
translate italian act1_06f39335_4:

    # a stan "…"
    a stan "…"

# game/act1.rpy:1007
translate italian act1_0b995d43:

    # "That’s right… If I remember correctly, Mr. Grey isn’t actually a descendant of the original owners of this place. The details of how he came to be are muddled, and kept under wraps. Even the Valentine Report doesn’t have any files on it."
    "Esatto… Se non ricordo male, il signor Grey non è un discendente dei proprietari originali di questo posto. I dettagli su come sia entrato in possesso di questa proprietà sono confusi e tenuti segreti. Persino il Rapporto Valentine non contiene alcun documento al riguardo."

# game/act1.rpy:1008
translate italian act1_df242a5b:

    # "All the more reason to be guarded. This man must be as dangerous as he is enigmatic."
    "Tanto più motivo di stare in guardia. Quest'uomo dev'essere tanto pericoloso quanto enigmatico."

# game/act1.rpy:1011
translate italian act1_6b7f354c:

    # "We reach a hallway that leads down an elevator, and with the push of a button, it opens for him instantly."
    "Raggiungiamo un corridoio che conduce a un ascensore e, premendo un pulsante, le porte si aprono all'istante."

# game/act1.rpy:1013
translate italian act1_464520cd:

    # l "After you."
    l "Dopo di te."

# game/act1.rpy:1015
translate italian act1_3e3d84fa:

    # "We both get inside of it. He presses his fingers on some sort of fingerprint scanner, making the elevator shoot up with surprising speed."
    "Entriamo entrambi. Lui preme le dita su una specie di scanner per impronte digitali, facendo schizzare l'ascensore verso l'alto con una velocità sorprendente."

# game/act1.rpy:1016
translate italian act1_1b226aed:

    # "I fiddle with my bangs, taking in my surroundings. A high-tech elevator going at max speed, a camera on the upper right corner with a glowing red dot, mirrors on every wall. It’s an assault on the senses, to say the least."
    "Mi sistemo la frangia, osservando ciò che mi circonda. Un ascensore super tecnologico che viaggia alla massima velocità, una telecamera nell'angolo in alto a destra con un puntino rosso luminoso, specchi su ogni parete. È un vero e proprio assalto ai sensi, a dir poco."

# game/act1.rpy:1017
translate italian act1_74406a91:

    # "Finally, we reach an undefined number of floors up, and the doors open again. Mr. Grey gestures for me to walk out first, and I think to myself how if I’m going to be killed here, it’s nice he’s being a gentleman about it."
    "Finalmente raggiungiamo un numero imprecisato di piani e le porte si riaprono. Il signor Grey mi fa cenno di uscire per primo e penso tra me e me che, se proprio devo morire qui, è un bene che si stia comportando da gentiluomo."

# game/act1.rpy:1018
translate italian act1_ddfb6ff3:

    # "After another short walk down a hallway, we reach a door he opens with zero hesitation, leading to what I can only assume is his office."
    "Dopo un altro breve tratto lungo un corridoio, raggiungiamo una porta che lui apre senza esitazione, che conduce a quello che presumo sia il suo ufficio."

# game/act1.rpy:1023
translate italian act1_7b073ca2:

    # l "Have a seat, Valentine. Would you like a drink?"
    l "Siediti, Valentine. Vuoi qualcosa da bere?"

# game/act1.rpy:1025
translate italian act1_7dec20c7:

    # "I subtly look around as I do what I’m told, sitting down as he pours himself a glass of what is most likely whiskey."
    "Mi guardo intorno con discrezione mentre faccio quello che mi è stato detto, sedendomi mentre lui si versa un bicchiere di quello che con ogni probabilità è whisky."

# game/act1.rpy:1027
translate italian act1_677dd66f:

    # a "No, thank you."
    a "No, grazie."

# game/act1.rpy:1029
translate italian act1_e850918b:

    # "He drapes his coat on his large chair and sits down in front of me with a sigh, leaning back on his chair in a cool, collected manner. He looks at me… {i}really{/i} looks at me, eyeing me up and down and taking everything in.{w} It makes me feel naked."
    "Appoggia il cappotto sulla sua grande poltrona e si siede di fronte a me con un sospiro, reclinandosi allo schienale con aria calma e composta. Mi guarda... {i}davvero{/i}mi guarda, scrutandomi da capo a piedi e cogliendo ogni dettaglio.{w} Mi fa sentire nuda."

# game/act1.rpy:1032
translate italian act1_74d66e96:

    # l ponder "Before we discuss anything, I’d like to make one simple condition."
    l ponder "Prima di discutere di qualsiasi altra cosa, vorrei porre una semplice condizione."

# game/act1.rpy:1034
translate italian act1_9af356c8:

    # a concern "And… that is?"
    a concern "E… cioè?"

# game/act1.rpy:1036
translate italian act1_7ec6b243:

    # l serious "No lies."
    l serious "Niente bugie."

# game/act1.rpy:1038
translate italian act1_8225f837:

    # l stan "You’ve come here for the truth, yes? Then, I’ll give it to you. I only ask for the same treatment in return."
    l stan "Sei venuto qui per la verità, vero? Bene, te la darò. Chiedo solo lo stesso trattamento in cambio."

# game/act1.rpy:1039
translate italian act1_e482e608:

    # l surprised "Do we have a deal, Valentine?"
    l surprised "Affare fatto, Valentine?"

# game/act1.rpy:1042
translate italian act1_71ad9d89:

    # a "Yes, sir."
    a "Sì, signore."

# game/act1.rpy:1044
translate italian act1_86a916a1:

    # l peek "Good.{w} I hope you mean it. I’m quite good at calling someone’s bluff."
    l peek "Bene.{w} Spero che tu dica sul serio. Sono piuttosto bravo a smascherare i bluff."

# game/act1.rpy:1045
translate italian act1_89086a83:

    # a hm "{i}I’m sure you are…"
    a hm "{i}Sono sicuro che lo sei…"

# game/act1.rpy:1046
translate italian act1_44691850:

    # l stan "Very well, Valentine. Please, do tell what business it is you have with me."
    l stan "Va benissimo, Valentine. Per favore, dimmi cosa vuoi da me."

# game/act1.rpy:1049
translate italian act1_47aa83e4:

    # "I swallow hard. Do I really just… lay it out honestly to him? It’s what he asked for, but…"
    "Deglutisco a fatica. Devo davvero… dirglielo onestamente? È quello che mi ha chiesto, ma…"

# game/act1.rpy:1052
translate italian act1_4c145d88:

    # "Something tells me he won’t appreciate anything but the cold, hard truth."
    "Qualcosa mi dice che non apprezzerà altro che la cruda e dura verità."

# game/act1.rpy:1054
translate italian act1_1ab72481_4:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1055
translate italian act1_ac50d5dc:

    # a frown "{i}Fine. Have it your way."
    a frown "{i}Bene. Come vuoi."

# game/act1.rpy:1057
translate italian act1_ddbc6019:

    # a bashful "You won’t mind if I record this, would you, Mr. Grey?"
    a bashful "Signor Grey, non le dispiacerà se registro questa conversazione, vero?"

# game/act1.rpy:1058
translate italian act1_e616ed6c:

    # l ponder "Certainly not. By all means."
    l ponder "Certamente no. Assolutamente sì."

# game/act1.rpy:1060
translate italian act1_8f2ca2b0:

    # "I lay my recorder on his desk, pressing the button to start it up, and lean back on my seat, mirroring his gaze."
    "Appoggio il registratore sulla sua scrivania, premo il pulsante per accenderlo e mi appoggio allo schienale della sedia, ricambiando il suo sguardo."

# game/act1.rpy:1062
translate italian act1_6208a9ee:

    # a stan "Ms. Megumi Yoshida has been missing for the past three months. She was last seen here, in your casino. Several reports indicate that she isn’t the only missing person in the last twelve months that was last seen in this location."
    a stan "La signora Megumi Yoshida è scomparsa da tre mesi. È stata vista l'ultima volta qui, nel vostro casinò. Diverse segnalazioni indicano che non è l'unica persona scomparsa negli ultimi dodici mesi ad essere stata vista per l'ultima volta in questo luogo."

# game/act1.rpy:1064
translate italian act1_91055c0c:

    # a frown "Every other press has been silent; the police have also made little attempts to actually search for these individuals… which is why their families have come to us: The Valentine Report."
    a frown "Tutti gli altri organi di stampa hanno taciuto; anche la polizia ha fatto ben poco per cercare concretamente queste persone... ed è per questo che le loro famiglie si sono rivolte a noi: The Valentine Report."

# game/act1.rpy:1065
translate italian act1_877caacc:

    # a "Do you have any explanations for this… Mr. Grey?"
    a "Signor Grey, ha qualche spiegazione in merito?"

# game/act1.rpy:1068
translate italian act1_96aec05d:

    # "He grins, a somewhat satisfied look on his face. Whatever I did right, it must have pleased him.{w} Not that I could care in the slightest."
    "Sorride, con un'espressione alquanto soddisfatta sul volto. Qualunque cosa io abbia fatto di giusto, deve avergli fatto piacere.{w} Non che mi importi minimamente."

# game/act1.rpy:1070
translate italian act1_7b7a8542:

    # l surprised "This is all very true, Valentine. People have been going missing for quite some time now in Sonora. The number seems to pile up every day."
    l surprised "È tutto vero, Valentine. In Sonora le persone scompaiono da parecchio tempo. Il numero sembra aumentare ogni giorno."

# game/act1.rpy:1071
translate italian act1_67e3cebf:

    # l shocked "As for explanations…{w} I’m afraid I have none."
    l shocked "Quanto alle spiegazioni...{w} temo di non averne."

# game/act1.rpy:1073
translate italian act1_9b636321:

    # a concern "Pardon?"
    a concern "Perdono?"

# game/act1.rpy:1074
translate italian act1_62cdc8a8:

    # l "It’s true. I’m as dumbfounded as you are, love. I have no involvement in any of these disappearances, and my staff has been closely monitored to ensure no one is up to anything nefarious behind my back."
    l "È vero. Sono sbalordita quanto te, tesoro. Non ho alcun coinvolgimento in queste sparizioni e il mio staff è stato attentamente monitorato per garantire che nessuno stia tramando qualcosa di losco alle mie spalle."

# game/act1.rpy:1075
translate italian act1_10c63832:

    # l serious "It’s a pity and a shame what happened to those people… but unfortunately for you, Valentine, my hands are clean."
    l serious "È un peccato e una vergogna quello che è successo a quelle persone... ma sfortunatamente per te, Valentine, le mie mani sono pulite."

# game/act1.rpy:1076
translate italian act1_8ef2c679_2:

    # a frown "…"
    a frown "…"

# game/act1.rpy:1078
translate italian act1_a7f95762:

    # "Bullshit. There’s no way one of the most powerful men on this earth doesn’t know what’s going on at every given moment."
    "Sciocchezze. È impossibile che uno degli uomini più potenti del mondo non sappia cosa sta succedendo in ogni singolo istante."

# game/act1.rpy:1079
translate italian act1_f6e35ec2:

    # "He’s lying to me. He has to be…"
    "Mi sta mentendo. Deve essere..."

# game/act1.rpy:1081
translate italian act1_9fdce16c:

    # l hm "Tell me, Valentine… why would I stain my own reputation, and my casino’s reputation for that matter, by committing such an atrocity right here in this very building? What would the people say about me? What must they be saying now?"
    l hm "Dimmi, Valentine… perché mai dovrei macchiare la mia reputazione, e quella del mio casinò, commettendo un'atrocità simile proprio qui, in questo edificio? Cosa direbbe la gente di me? Cosa staranno dicendo adesso?"

# game/act1.rpy:1082
translate italian act1_fcc463d7:

    # l serious "I have no desire to enact violence. No need to resort to crimes to exact justice. I am just as you see me: a businessman."
    l serious "Non ho alcun desiderio di ricorrere alla violenza. Non c'è bisogno di commettere crimini per ottenere giustizia. Sono esattamente come mi vedete: un uomo d'affari."

# game/act1.rpy:1083
translate italian act1_cc4fa49c:

    # l shocked "Ms. Yoshida did frequent our casino, but she did so of her own volition. She never owed us any money, as Corona never loans to anyone."
    l shocked "La signora Yoshida frequentava il nostro casinò, ma lo faceva di sua spontanea volontà. Non ci doveva mai denaro, poiché Corona non concede mai prestiti a nessuno."

# game/act1.rpy:1084
translate italian act1_d6131dcd:

    # l ponder "Now what reason would I possibly have to harm a young woman who gives me business?"
    l ponder "Quale motivo avrei mai per fare del male a una giovane donna che mi procura degli affari?"

# game/act1.rpy:1087
translate italian act1_1ab72481_5:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1089
translate italian act1_f33cee1c:

    # "As much as I hate to admit it, he might have a point. Megumi wasn’t exactly indebted to the casino… and having so many disappearances all center Corona’s... someone like Mr. Grey couldn’t possibly be dumb enough to overlook that."
    "Per quanto mi dispiaccia ammetterlo, potrebbe avere ragione. Megumi non era esattamente indebitata con il casinò... e con così tante sparizioni tutte legate al Corona's... uno come il signor Grey non potrebbe essere così stupido da non notarlo."

# game/act1.rpy:1091
translate italian act1_889601ec:

    # a "So, then… if not you, it must be someone from your staff. Someone with access to the video footage of the casino? Someone trying to harm your reputation?"
    a "Quindi, se non sei tu, dev'essere qualcuno del tuo staff. Qualcuno con accesso alle riprese video del casinò? Qualcuno che cerca di danneggiare la tua reputazione?"

# game/act1.rpy:1092
translate italian act1_7ce92d85:

    # l ponder "Rest assured, these are all scenarios I’ve accounted for. My staff is under my watchful eye. None of them are involved. The full, unedited tape was willfully given to the police department. And as for someone trying to harm my image…"
    l ponder "State tranquilli, ho preso in considerazione tutti questi scenari. Il mio staff è sotto la mia attenta supervisione. Nessuno di loro è coinvolto. La registrazione integrale e non modificata è stata consegnata volontariamente al dipartimento di polizia. E per quanto riguarda qualcuno che cerca di danneggiare la mia immagine..."

# game/act1.rpy:1093
translate italian act1_1e57f20e:

    # l serious "Perhaps that may be the case. But it is no one I personally know, or anyone under me."
    l serious "Forse è così. Ma non si tratta di nessuno che io conosca personalmente, né di qualcuno che lavora sotto di me."

# game/act1.rpy:1096
translate italian act1_60fe82d1:

    # a frown "Why should I just take your word for it?"
    a frown "Perché dovrei semplicemente fidarmi della tua parola?"

# game/act1.rpy:1098
translate italian act1_f11dcd81:

    # l ponder "Oh, Valentine… did we not have an agreement? My word is good."
    l ponder "Oh, Valentine… non avevamo forse un accordo? La mia parola è buona."

# game/act1.rpy:1099
translate italian act1_c2267708:

    # l peek "And I think, deep down, you know that."
    l peek "E penso che, in fondo, tu lo sappia."

# game/act1.rpy:1101
translate italian act1_c44d2f4a:

    # l "Don’t you, Angel?"
    l "Non è vero, Angel?"

# game/act1.rpy:1103
translate italian act1_6c249d5a:

    # "My stomach drops."
    "Mi si stringe lo stomaco."

# game/act1.rpy:1104
translate italian act1_c4312f07:

    # a scared "H… How do you…?"
    a scared "C… Come fai…?"

# game/act1.rpy:1105
translate italian act1_130ddcba:

    # l "You see, I’ve done my homework."
    l "Vedete, ho fatto i compiti."

# game/act1.rpy:1107
translate italian act1_9752d698:

    # "He grabs a folder that had been sitting on his desk, flipping it open as a cold feeling trickles down my spine."
    "Afferra una cartella che era rimasta sulla sua scrivania e la apre, mentre un brivido gelido mi percorre la schiena."

# game/act1.rpy:1109
translate italian act1_b320a40d:

    # l peek "Mr. Angel Valentine. Unlike many of your peers, you began training to become a Valentine at a remarkably young age, and graduated with flying colors. At just twenty-three, you now have a high-profile case in your hands at the investigation unit of the company."
    l peek "Signor Angel Valentine. A differenza di molti suoi colleghi, lei ha iniziato l'addestramento per diventare un Valentine in giovanissima età, diplomandosi con il massimo dei voti. A soli ventitré anni, ora si trova a gestire un caso di alto profilo presso l'unità investigativa dell'azienda."

# game/act1.rpy:1110
translate italian act1_52556f33:

    # l surprised "Most Valentines don’t even get to be in the ‘Journalist’ unit, much less receive important cases such as these… one has to wonder, how did you do it?"
    l surprised "La maggior parte dei Valentine non riesce nemmeno ad entrare nella redazione \"Giornalisti\", figuriamoci a ricevere casi importanti come questi... viene da chiedersi, come hai fatto?"

# game/act1.rpy:1111
translate italian act1_50806284:

    # a nngh "…"
    a nngh "…"

# game/act1.rpy:1112
translate italian act1_3b153748:

    # l peek "Hm… perhaps because you’ve had to work twice as hard for it? I mean, if your debt is anything to base my assumptions on."
    l peek "Mmm... forse perché hai dovuto lavorare il doppio per ottenerlo? Voglio dire, se i miei sospetti si basano sul tuo debito."

# game/act1.rpy:1113
translate italian act1_60a29c2f:

    # l shocked "50,000 dollars, Angel. How does a teenager garner that much debt?"
    l shocked "50.000 dollari, Angel. Come fa un'adolescente ad accumulare un debito così ingente?"

# game/act1.rpy:1116
translate italian act1_7c65ec3e:

    # a "That… doesn’t concern you, Mr. Grey."
    a "Questo… non la riguarda, signor Grey."

# game/act1.rpy:1117
translate italian act1_89451eb4:

    # l ponder "Oh? Perhaps you’re right."
    l ponder "Oh? Forse hai ragione."

# game/act1.rpy:1118
translate italian act1_5838cd4b:

    # l peek "It doesn’t concern me… this is between you and your mother, isn’t it?"
    l peek "Non mi riguarda... questa è una questione tra te e tua madre, no?"

# game/act1.rpy:1119
translate italian act1_07ceb950:

    # a scared "…!"
    a scared "…!"

# game/act1.rpy:1120
translate italian act1_af4a0232:

    # l hm "This must be {i}her{/i} debt… how cruel. Pushing it onto her thirteen-year-old son, giving him no choice but to work it off for her. Tell me, Angel… when do you estimate you’ll pay this off?"
    l hm "Questo dev'essere il suo debito... che crudeltà. Scaricarlo sul figlio tredicenne, non lasciandogli altra scelta che lavorare per ripagarlo. Dimmi, Angel... quando pensi di riuscire a saldarlo?"

# game/act1.rpy:1121
translate italian act1_90b79f9a:

    # a nngh "Please…"
    a nngh "Per favore…"

# game/act1.rpy:1122
translate italian act1_f22f1395:

    # l shocked "If my calculations are correct - and rest assured, they are - you’ve paid off less than ten percent of your total debt. Have you done the math, love?"
    l shocked "Se i miei calcoli sono corretti - e ti assicuro che lo sono - hai saldato meno del dieci percento del tuo debito totale. Hai fatto due conti, tesoro?"

# game/act1.rpy:1123
translate italian act1_bacbc201:

    # l serious "It’ll take more than forty years for your debt to be finalized."
    l serious "Ci vorranno più di quarant'anni prima che il tuo debito venga estinto."

# game/act1.rpy:1124
translate italian act1_d8eb5386:

    # a scared "…"
    a scared "…"

# game/act1.rpy:1125
translate italian act1_01658988:

    # l ponder "Of course, I’m not counting bonuses. That must shave off a few months or two in the equation, correct? Now, why don’t we-?"
    l ponder "Certo, non sto considerando i bonus. Questo dovrebbe far risparmiare un paio di mesi, giusto? Ora, perché non...?"

# game/act1.rpy:1129
translate italian act1_48ca1703:

    # a scared "Please, stop!!"
    a scared "Per favore, fermati!!"

# game/act1.rpy:1131
translate italian act1_9fa7f313:

    # a "Please… why are you doing this...?"
    a "Per favore... perché lo stai facendo...?"

# game/act1.rpy:1134
translate italian act1_d66ee287:

    # l "My apologies, Angel. I did not mean to upset you."
    l "Mi dispiace, Angel. Non volevo turbarti."

# game/act1.rpy:1135
translate italian act1_f07a8d7f:

    # l ponder "You see… I just find you…{w} fascinating."
    l ponder "Vedi… ti trovo semplicemente…{w} affascinante."

# game/act1.rpy:1137
translate italian act1_fc143fa3:

    # a concern "…what?"
    a concern "…Che cosa?"

# game/act1.rpy:1139
translate italian act1_95fe2f03:

    # l stan "Indeed. Someone who wasn’t given a choice as to what their life may look like, how their story will play out. It’s exceptionally cruel… so much potential, so much intelligence… but has anyone ever asked you…"
    l stan "Certo. Qualcuno a cui non è stata data la possibilità di scegliere come sarebbe stata la sua vita, come si sarebbe svolta la sua storia. È incredibilmente crudele... tanto potenziale, tanta intelligenza... ma qualcuno te l'ha mai chiesto..."

# game/act1.rpy:1140
translate italian act1_a7c3abd5:

    # l peek "What it is that {i}you{/i} want to do with your life, Angel? When you fall asleep at night, do you allow yourself to dream? Or is the very notion utterly ridiculous?"
    l peek "Che cosa vuoi fare della tua vita, Angelo? Quando ti addormenti la notte, ti permetti di sognare? O l'idea stessa ti sembra assolutamente ridicola?"

# game/act1.rpy:1143
translate italian act1_acee1a87:

    # "I just stare at him, that cold feeling still permeating throughout my body, flowing through my bloodstream right up to my fingertips."
    "Lo fisso, quella sensazione di freddo che ancora mi pervade il corpo, scorrendo nel mio sangue fino alla punta delle dita."

# game/act1.rpy:1144
translate italian act1_9b097c91:

    # "Just who is this man…?"
    "Chi è quest'uomo...?"

# game/act1.rpy:1147
translate italian act1_25fb7bdb:

    # l ponder "It fascinates me…{w} so I’d like to play a game with you."
    l ponder "Mi affascina…{w} quindi mi piacerebbe giocare con te."

# game/act1.rpy:1150
translate italian act1_659527a9:

    # a "A… game?"
    a "Un… gioco?"

# game/act1.rpy:1151
translate italian act1_2b01422b:

    # l "Precisely. As you might already know, this casino wasn’t mine to begin with, and I have no familial ties to its original owners."
    l "Esattamente. Come forse già saprai, questo casinò non era mio fin dall'inizio e non ho alcun legame familiare con i suoi proprietari originali."

# game/act1.rpy:1152
translate italian act1_f145c840:

    # l ponder "To make a very long story short… I won it. In a gamble."
    l ponder "Per farla breve… l'ho vinto. Al gioco."

# game/act1.rpy:1153
translate italian act1_1ab72481_6:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1154
translate italian act1_42e9e275:

    # l "It was a surprisingly ordinary game of poker… but oh, how wonderful it was. It still stays in my memory as one of the most thrilling experiences of my life."
    l "È stata una partita a poker sorprendentemente ordinaria... ma oh, quanto è stata meravigliosa. Rimane impressa nella mia memoria come una delle esperienze più emozionanti della mia vita."

# game/act1.rpy:1155
translate italian act1_fd8d5b35:

    # l surprised "Baring it all on the line, your entire life… for the chance of success. {i}That{/i} is what I believe divides the strong from the weak."
    l surprised "Mettere tutto in gioco, tutta la propria vita... per la possibilità di successo. {i}Questo{/i}è ciò che credo distingua i forti dai deboli."

# game/act1.rpy:1156
translate italian act1_4fa8003e:

    # l ponder "How much are we willing to risk for the greatest return…?"
    l ponder "Quanto siamo disposti a rischiare per ottenere il massimo profitto...?"

# game/act1.rpy:1158
translate italian act1_32098d40:

    # "He opens a drawer on his desk, and slowly, carefully, places a gold coin in the middle of the surface, the weight of it making a deep sounding {i}clink{/i} against the smooth wood. It has a crown engraved on one side, a jester's hat on the other."
    "Apre un cassetto della sua scrivania e, lentamente e con attenzione, vi deposita una moneta d'oro al centro, il cui peso produce un profondo tintinnio contro il legno liscio. Su un lato è incisa una corona, sull'altro un cappello da giullare."

# game/act1.rpy:1160
translate italian act1_090b14d8:

    # l ponder "It’s a simple coin flip. A fifty-fifty chance."
    l ponder "È un semplice lancio di moneta. Una probabilità del cinquanta per cento."

# game/act1.rpy:1161
translate italian act1_fcd43039:

    # l stan "If you win…{w} I’ll give you my casino."
    l stan "Se vinci...{w} ti darò il mio casinò."

# game/act1.rpy:1163
translate italian act1_d8eb5386_1:

    # a scared "…"
    a scared "…"

# game/act1.rpy:1165
translate italian act1_e5aedeb0:

    # a "That’s… it…?"
    a "Questo è tutto…?"

# game/act1.rpy:1167
translate italian act1_f595ad40:

    # "He lifts his brows in genuine amusement."
    "Alza le sopracciglia con aria genuinamente divertita."

# game/act1.rpy:1169
translate italian act1_4134af49:

    # l surprised "Oh? Would you like something more?"
    l surprised "Oh? Desideri qualcos'altro?"

# game/act1.rpy:1170
translate italian act1_ed0591ac:

    # a concern "N-No no! I mean… Just like that?! What… Why would you do that?!"
    a concern "N-No no! Cioè... Proprio così?! Cosa... Perché l'hai fatto?!"

# game/act1.rpy:1171
translate italian act1_f12140c4:

    # l cocky "Why? Well…"
    l cocky "Perché? Beh…"

# game/act1.rpy:1172
translate italian act1_2de68f0f:

    # l ponder "Because if you lose…"
    l ponder "Perché se perdi…"

# game/act1.rpy:1173
translate italian act1_755a6a34:

    # l peek "I want you to work as my personal assistant.{w} For the rest of your days."
    l peek "Voglio che tu lavori come mio assistente personale.{w} Per il resto dei tuoi giorni."

# game/act1.rpy:1174
translate italian act1_19e37536:

    # l ponder "All of the knowledge that the Valentine Academy has taught you, all of your experiences in the agency… someone like you, working in {i}my{/i} casino…"
    l ponder "Tutte le conoscenze che la Valentine Academy ti ha trasmesso, tutte le tue esperienze in agenzia... qualcuno come te, che lavora nel {i}mio{/i}casinò..."

# game/act1.rpy:1175
translate italian act1_a0ba2d50:

    # l peek "Better still, under my watchful gaze… {w}and under my complete mercy..."
    l peek "Meglio ancora, sotto il mio sguardo vigile… {w}e sotto la mia completa misericordia..."

# game/act1.rpy:1176
translate italian act1_94184006:

    # l grin "Oh, I’d wager much more than my casino for a chance to have that."
    l grin "Oh, scommetterei molto di più del mio casinò per avere la possibilità di averlo."

# game/act1.rpy:1179
translate italian act1_9169c6d7:

    # a scared "You’re… insane… That’s just crazy! Why would you make such a gamble?!"
    a scared "Sei… pazzo… È una follia! Perché mai dovresti fare una scommessa del genere?!"

# game/act1.rpy:1181
translate italian act1_0e96fe73:

    # l surprised "Isn’t it fair? In the world of gambling, it doesn’t matter what your status is, who you are, what you’ve done… all that matters is what you put on the line, and who will emerge victorious."
    l surprised "Non è giusto? Nel mondo del gioco d'azzardo non importa quale sia il tuo status, chi sei, cosa hai fatto... tutto ciò che conta è cosa metti in gioco e chi ne uscirà vincitore."

# game/act1.rpy:1182
translate italian act1_89dbef3e:

    # l ponder "We decide our fates. We choose to put our livelihoods on the line. What greater act of rebellion against the world exists? To decide to risk your life, and leave it up to fate?"
    l ponder "Siamo noi a decidere il nostro destino. Scegliamo di mettere a repentaglio la nostra stessa vita. Quale atto di ribellione più grande contro il mondo esiste? Decidere di rischiare la propria vita e affidarsi al destino?"

# game/act1.rpy:1183
translate italian act1_b8ae10f7:

    # l grin "I truly believe… that the risk makes the man. How can you live in a world where you’re afraid of its natural state – of loss? Of change?"
    l grin "Credo fermamente che il rischio forgi l'uomo. Come si può vivere in un mondo in cui si ha paura del suo stato naturale, della perdita? Del cambiamento?"

# game/act1.rpy:1184
translate italian act1_1ab72481_7:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1185
translate italian act1_5d6cf7e9:

    # l ponder "So, tell me, Angel… right here, right now, you and I are equals. We can both lose our livelihoods in the blink of an eye… or, we can gain something truly remarkable… and truly lifechanging."
    l ponder "Allora dimmi, Angel... proprio qui e ora, io e te siamo uguali. Entrambi possiamo perdere il nostro sostentamento in un batter d'occhio... oppure possiamo guadagnare qualcosa di veramente straordinario... e che ci cambierà la vita."

# game/act1.rpy:1186
translate italian act1_3efc1ae2:

    # l grin "You can be free… and I’ll have the most fascinating thing my eyes have ever laid upon, right on the palm of my paw."
    l grin "Tu puoi essere libero... e io avrò la cosa più affascinante che i miei occhi abbiano mai visto, proprio sul palmo della mia zampa."

# game/act1.rpy:1187
translate italian act1_2e13a4b5:

    # l "The choice is now fully yours."
    l "Ora la scelta è interamente vostra."

# game/act1.rpy:1189
translate italian act1_d8eb5386_2:

    # a scared "…"
    a scared "…"

# game/act1.rpy:1191
translate italian act1_8b788452:

    # "I stare at the coin, one simple gold coin that probably isn’t worth much… holding so much power inside of it, so much potential."
    "Fisso la moneta, una semplice moneta d'oro che probabilmente non vale molto... eppure racchiude al suo interno così tanto potere, così tanto potenziale."

# game/act1.rpy:1192
translate italian act1_aa149f53:

    # "When have I ever been given the chance to decide on… anything, really? Mr. Grey is right. My life was carefully laid out for me from the moment I was forced to join the Valentine Agency."
    "Quando mai mi è stata data la possibilità di decidere su... qualsiasi cosa, davvero? Il signor Grey ha ragione. La mia vita è stata pianificata nei minimi dettagli fin dal momento in cui sono stato costretto a entrare nell'Agenzia Valentine."

# game/act1.rpy:1193
translate italian act1_7fa7d4b8:

    # "But now… I’ve been given a choice. A ‘What if?’ scenario."
    "Ma ora… mi è stata data una scelta. Uno scenario del tipo \"E se?\"."

# game/act1.rpy:1194
translate italian act1_235129c4:

    # "What if…{w} I accept?"
    "E se…{w} accettassi?"

# game/act1.rpy:1195
translate italian act1_3e5ca1a8:

    # "I could win. The odds aren’t that bad… I could own Corona, pay off my debt in an instant, do whatever I wanted for the rest of my life…!"
    "Potrei vincere. Le probabilità non sono poi così male... Potrei possedere la Corona, saldare i miei debiti in un istante, fare tutto ciò che voglio per il resto della mia vita...!"

# game/act1.rpy:1196
translate italian act1_2455f43b:

    # "Or… I could lose. I could live the rest of my life by this lunatic’s side, doing God knows what with him, probably still trying to pay off my debt until I’m sixty…"
    "Oppure… potrei perdere. Potrei vivere il resto della mia vita al fianco di questo pazzo, facendo chissà cosa con lui, probabilmente cercando ancora di ripagare i miei debiti fino a sessant'anni…"

# game/act1.rpy:1197
translate italian act1_fea24e1f:

    # "With no hope in sight."
    "Senza alcuna speranza all'orizzonte."

# game/act1.rpy:1198
translate italian act1_af7b4225:

    # "Is that really a risk… I’m capable of taking?{w} Allowed to take?"
    "È davvero un rischio che posso correre?{w} Posso correre?"

# game/act1.rpy:1203
translate italian act1_384472ec:

    # a sad "No."
    a sad "NO."

# game/act1.rpy:1205
translate italian act1_b4150a31:

    # l serious "No…"
    l serious "NO…"

# game/act1.rpy:1207
translate italian act1_88279e59:

    # "Mr. Grey lets out a long sigh, deflating against his sturdy chair, the glimmer that was once in his eyes fizzling out in a heartbeat."
    "Il signor Grey emette un lungo sospiro, lasciandosi cadere sulla sua robusta sedia, il luccichio che un tempo brillava nei suoi occhi che si spegne in un istante."

# game/act1.rpy:1209
translate italian act1_804b02be:

    # l "Of course, the answer is no."
    l "Ovviamente la risposta è no."

# game/act1.rpy:1210
translate italian act1_dbd3547a:

    # l serious "As always, those who are afraid to lose will never play any kind of game."
    l serious "Come sempre, chi ha paura di perdere non giocherà mai a nessun tipo di gioco."

# game/act1.rpy:1211
translate italian act1_4e9b20ee:

    # a concern "I’m sorry… but I’m not just gambling my own life… I have someone who depends on me…"
    a concern "Mi dispiace… ma non sto mettendo a repentaglio la mia vita… ho qualcuno che dipende da me…"

# game/act1.rpy:1212
translate italian act1_f05c3207:

    # a frown "And Valentines don’t gamble."
    a frown "E a San Valentino non si gioca d'azzardo."

# game/act1.rpy:1214
translate italian act1_05affc4a:

    # l disappointed "I suppose you’re right. You have a life you simply can’t afford to lose, it seems."
    l disappointed "Credo tu abbia ragione. A quanto pare, hai una vita che non puoi assolutamente permetterti di perdere."

# game/act1.rpy:1215
translate italian act1_35921a3f:

    # l serious "Very well."
    l serious "Ottimo."

# game/act1.rpy:1217
translate italian act1_996e4abc:

    # "He grabs the coin and haphazardly throws it back in his cabinet, leaning back in his chair."
    "Afferra la moneta e la getta distrattamente nell'armadietto, appoggiandosi allo schienale della sedia."

# game/act1.rpy:1219
translate italian act1_739187a5:

    # l "Then I believe you no longer have any business with me."
    l "Allora credo che tu non abbia più alcun rapporto con me."

# game/act1.rpy:1220
translate italian act1_8072122c:

    # l disappointed "Please, see yourself out of the building."
    l disappointed "Per favore, uscite dall'edificio."

# game/act1.rpy:1223
translate italian act1_5ef3f08e:

    # l angry "Immediately."
    l angry "Immediatamente."

# game/act1.rpy:1224
translate italian act1_49b2f98d:

    # a scared "I-I… yes, sir…"
    a scared "II… sì, signore…"

# game/act1.rpy:1226
translate italian act1_ecdc46e4:

    # "Holding back my emotions, I quickly stand up and grab my things as I give him one last bow before exiting the room, a shiver running down my spine. I feel his cold eyes watch me the whole way out the door until I shut it firmly behind me."
    "Reprimendo le mie emozioni, mi alzo in fretta, prendo le mie cose e gli faccio un ultimo inchino prima di uscire dalla stanza, con un brivido che mi percorre la schiena. Sento i suoi occhi freddi fissarmi per tutto il tragitto fino a quando non chiudo la porta con forza dietro di me."

# game/act1.rpy:1231
translate italian act1_0d141f5c:

    # "By the time I’m out of the building, my breathing has gotten heavy, and hot tears threaten to leak out of my eyes as I stare at the spinning floor beneath my feet. ‘Humiliated’ doesn’t even begin to cover how I feel."
    "Quando finalmente esco dall'edificio, il respiro si fa affannoso e lacrime calde minacciano di sgorgare dai miei occhi mentre fisso il pavimento che gira sotto i miei piedi. \"Umiliata\" non rende minimamente l'idea di come mi sento."

# game/act1.rpy:1232
translate italian act1_0d9ea18d:

    # "He knew {i}everything{/i} about me, and I was powerless to it. He tried to play me, tried to make me one of his pawns…{w} didn’t he?"
    "Lui sapeva {i}tutto{/i} di me, e io ero impotente. Ha cercato di manipolarmi, ha cercato di farmi diventare una delle sue pedine...{w} vero?"

# game/act1.rpy:1233
translate italian act1_fccdb881:

    # "Yes, he did. There’s no doubt. That cheeky look in his eyes, that faux kindness… it was all a lie. Offering me the casino? How ridiculous…!"
    "Sì, l'ha fatto. Non c'è dubbio. Quello sguardo sfacciato, quella finta gentilezza... era tutta una bugia. Offrirmi il casinò? Che assurdità...!"

# game/act1.rpy:1234
translate italian act1_50806284_1:

    # a nngh "…"
    a nngh "…"

# game/act1.rpy:1236
translate italian act1_9eb08190:

    # "I feel like I’m about to throw up on the side of the road when my phone begins to ring."
    "Mi sento come se stessi per vomitare sul ciglio della strada quando il mio telefono inizia a squillare."

# game/act1.rpy:1238
translate italian act1_c79bdf45:

    # "I take a deep breath, brush my hair out of my eyes, and answer it, doing my best to sound calm and collected."
    "Faccio un respiro profondo, mi scosto i capelli dagli occhi e rispondo, cercando di sembrare calma e composta."

# game/act1.rpy:1240
translate italian act1_ae7b809f:

    # a concern "Hello?"
    a concern "Ciao?"

# game/act1.rpy:1241
translate italian act1_3246f219:

    # e "Hey, Angie. We still on for lunch?"
    e "Ciao Angie, siamo ancora d'accordo per pranzo?"

# game/act1.rpy:1243
translate italian act1_27639df5:

    # a nngh "Uh… yeah, sure."
    a nngh "Ehm... sì, certo."

# game/act1.rpy:1244
translate italian act1_ee509009:

    # e "…you okay?"
    e "...stai bene?"

# game/act1.rpy:1246
translate italian act1_4d350d10:

    # a concern "Yeah… yeah, I’m…"
    a concern "Sì… sì, io sono…"

# game/act1.rpy:1248
translate italian act1_f5c6d13a:

    # a bashful "Corona’s ended up being a bust. I’m just disappointed."
    a bashful "Corona si è rivelato un fallimento. Sono solo deluso."

# game/act1.rpy:1249
translate italian act1_95760b1e:

    # e "Aw. Yeah, I get it. Don’t beat yourself up about it. Let’s go to Shogey’s, maybe you’ll cheer up."
    e "Oh. Sì, ho capito. Non prendertela troppo. Andiamo da Shogey, magari ti tirerai su il morale."

# game/act1.rpy:1250
translate italian act1_a2c51ab7:

    # a hm "Shogey’s? The sports bar?"
    a hm "Da Shogey? Il bar sportivo?"

# game/act1.rpy:1251
translate italian act1_e659f609:

    # e "Yeah. I like their wings. Plus… they have beer."
    e "Sì. Mi piacciono le loro alette di pollo. E poi... hanno la birra."

# game/act1.rpy:1252
translate italian act1_2a4ff97c_9:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:1253
translate italian act1_609dce30:

    # a stan "I’ll be there."
    a stan "Io ci sarò."

# game/act1.rpy:1257
translate italian act1_831eafea:

    # "Fifteen minutes later, I’m sitting at the bar in the brightly lit room, hearing men talk loudly as they stare at whatever sports game is on the screen on the TV while I wait for Ethan to show up."
    "Quindici minuti dopo, sono seduto al bancone del bar nella sala illuminata a giorno, e sento gli uomini parlare ad alta voce mentre fissano la partita sportiva in onda in TV, in attesa che arrivi Ethan."

# game/act1.rpy:1258
translate italian act1_76a49148:

    # "I order a beer, and the waiter asks me if Babylon is okay. I tell him no – Babylon is the expensive kind – that a Tonio would be good."
    "Ordino una birra e il cameriere mi chiede se la Babylon va bene. Gli rispondo di no – la Babylon è una marca costosa – che una Tonio sarebbe perfetta."

# game/act1.rpy:1259
translate italian act1_565bfea5:

    # "If I could, I would have ordered a Babylon. I remember the first time I tried one – on my twenty-first birthday at some dive bar near Ethan’s apartment. He had bought me both, as a birthday present, and asked me if I could taste the difference."
    "Se avessi potuto, avrei ordinato un Babylon. Ricordo la prima volta che ne ho assaggiato uno: il giorno del mio ventunesimo compleanno, in un bar malfamato vicino all'appartamento di Ethan. Me li aveva regalati entrambi per il mio compleanno e mi aveva chiesto se riuscivo a sentire la differenza."

# game/act1.rpy:1260
translate italian act1_f5250fe9:

    # "At the time, they both tasted equally as bad. Now that I’ve acquired a bit of a taste for them, however, I can tell that Babylon is the superior brand. But, alas, it’s about the price of two and a half Tonios, so it’s unfortunately not worth the extra money."
    "All'epoca, entrambe avevano un sapore ugualmente pessimo. Ora che mi ci sono un po' abituato, però, posso dire che Babylon è la marca migliore. Ma, ahimè, costa circa quanto due Tonios e mezzo, quindi purtroppo non vale la pena spendere di più."

# game/act1.rpy:1261
translate italian act1_2ad00b84:

    # "The bartender comes back with two beers, a Babylon and a Tonio. He slides my drink in front of me, and the other to the guy to my left, who I somehow failed to notice was even there. He takes it, downing about half the bottle in one big gulp."
    "Il barista torna con due birre, una Babylon e una Tonio. Mi porge il mio drink e l'altro al ragazzo alla mia sinistra, che in qualche modo non avevo nemmeno notato. Lui lo prende e ne beve circa metà in un solo sorso."

# game/act1.rpy:1262
translate italian act1_b031c24e:

    # "Envy boils inside me as I watch him from the corner of my eye. How does someone as disheveled looking as him have the money to afford expensive beers like that? Has he had to work as hard as I do? Will he ever have to?"
    "L'invidia mi ribolle dentro mentre lo osservo con la coda dell'occhio. Come fa uno con un aspetto così trasandato ad avere i soldi per permettersi birre così costose? Ha dovuto lavorare tanto quanto me? Dovrà mai farlo?"

# game/act1.rpy:1263
translate italian act1_2a7cb2ab:

    # "I think back to my conversation with Mr. Grey. How stupid it is to think that he and I could ever be equals. Gambling isn’t going to fix anything. He’s just an insane man who happened to get lucky."
    "Ripenso alla mia conversazione con il signor Grey. Quanto è stupido pensare che io e lui possiamo mai essere uguali. Il gioco d'azzardo non risolverà nulla. È solo un pazzo che ha avuto fortuna."

# game/act1.rpy:1266
translate italian act1_4ee9dd05:

    # a worried "{i}Well… isn’t that the whole point? Getting lucky?"
    a worried "Beh... non è proprio questo il punto? Avere fortuna?"

# game/act1.rpy:1267
translate italian act1_592eefeb:

    # a "{i}What if I could have gotten lucky, too?"
    a "E se anch'io avessi avuto fortuna?"

# game/act1.rpy:1271
translate italian act1_dc2083a4:

    # "I shake my head. When have the odds {i}ever{/i} been in my favor? That coin would have sealed my fate into his hands, no question about it."
    "Scuoto la testa. Quando mai le probabilità sono state a mio favore? Quella moneta avrebbe sigillato il mio destino nelle sue mani, senza ombra di dubbio."

# game/act1.rpy:1272
translate italian act1_a153919c:

    # "I seethe internally as I’m about to bring the bottle to my lips, when the stranger next to me slides his bottle to my side. I look over at him completely now, raising an eyebrow."
    "Dentro di me ribolle la rabbia mentre sto per portare la bottiglia alle labbra, quando lo sconosciuto accanto a me fa scivolare la sua bottiglia di lato. Lo guardo completamente, alzando un sopracciglio."

# game/act1.rpy:1274
translate italian act1_2c856a94:

    # anon "Oh, sorry… You seemed to be eyeing my drink. I thought maybe you wanted to have some."
    anon "Oh, scusa… Sembrava che stessi guardando il mio drink. Ho pensato che magari volessi berne un po'."

# game/act1.rpy:1275
translate italian act1_4a530c3d_1:

    # a hm "…"
    a hm "…"

# game/act1.rpy:1278
translate italian act1_e8ee194c:

    # "This… man… speaks in a low, almost hushed voice, a serious look on his face that I can’t tell whether it's because of me, or if that’s just how he always looks."
    "Quest'uomo parla a bassa voce, quasi sussurrando, con un'espressione seria sul volto che non riesco a capire se sia per via mia o se sia semplicemente il suo aspetto abituale."

# game/act1.rpy:1279
translate italian act1_425ea68f:

    # "He has a bit of an accent, as if English isn’t his first language, but I can’t quite discern where it’s from. The ‘disheveled’ look I assessed earlier may not have been completely true; he seems more rugged, like he’s not trying hard to look good."
    "Ha un leggero accento, come se l'inglese non fosse la sua lingua madre, ma non riesco a capire bene da dove provenga. L'aspetto \"trasandato\" che gli avevo descritto prima potrebbe non essere del tutto veritiero; sembra più trasandato, come se non si sforzasse di apparire al meglio."

# game/act1.rpy:1280
translate italian act1_6f72a3d8:

    # "He doesn’t have to, though. He’s naturally handsome, with dark fur and piercing eyes to match. He’s unlike anyone I’ve ever seen before, at least in person. He could fit right into a movie with that face."
    "Non ne ha bisogno, però. È naturalmente bello, con una pelliccia scura e occhi penetranti. Non assomiglia a nessuno che io abbia mai visto prima, almeno di persona. Con quel viso, potrebbe benissimo recitare in un film."

# game/act1.rpy:1281
translate italian act1_b3293698:

    # "I laugh off his statement, shaking my head."
    "Rido alla sua affermazione, scuotendo la testa."

# game/act1.rpy:1283
translate italian act1_0f98a810:

    # a bashful "N-nah, sorry… I’m good with mine. Thanks."
    a bashful "N-no, scusa… io sto bene così. Grazie."

# game/act1.rpy:1285
translate italian act1_8ac3f09b:

    # "He nods, offering me a sheepish smile and grabbing his bottle to clink it against mine."
    "Annuisce con la testa, rivolgendomi un sorriso timido e afferrando la sua bottiglia per farla tintinnare contro la mia."

# game/act1.rpy:1287
translate italian act1_03a2da55:

    # anon "{i}Salud, pues."
    anon "{i}Salud, pues."

# game/act1.rpy:1289
translate italian act1_25e8efdc:

    # "I stare at him as he practically finishes the bottle in one gulp. So, he’s a Spanish speaker. From where in the world, I couldn’t tell off his accent alone. The last time I met someone who spoke Spanish was... back in the Academy."
    "Lo fisso mentre finisce praticamente la bottiglia in un sorso. Quindi, parla spagnolo. Da dove diavolo, non avrei mai potuto capirlo solo dal suo accento. L'ultima volta che ho incontrato qualcuno che parlava spagnolo è stato... all'Accademia."

# game/act1.rpy:1291
translate italian act1_af12e8a5:

    # anon "You waiting for someone, {i}chele?"
    anon "Stai aspettando qualcuno, {i}chele?"

# game/act1.rpy:1292
translate italian act1_1a47636f:

    # a flattered "Uh…{w} yes?"
    a flattered "Ehm…{w} sì?"

# game/act1.rpy:1293
translate italian act1_45edd81e:

    # anon "You don’t sound so sure."
    anon "Non sembri molto sicuro."

# game/act1.rpy:1294
translate italian act1_40d0a660:

    # a bashful "I’m sure. I just don’t know what {i}chele{/i} means… it’s nothing bad, is it?"
    a bashful "Ne sono sicuro. Solo che non so cosa significhi {i}chele{/i}… non è niente di male, vero?"

# game/act1.rpy:1296
translate italian act1_deb7c2e9:

    # "He laughs a full, hearty laugh, leaning his body a bit closer to mine. My instincts tell me to back away. {w}I don’t, though."
    "Ride di gusto, una risata piena e fragorosa, avvicinando un po' di più il suo corpo al mio. Il mio istinto mi dice di allontanarmi. {w}Non lo faccio, però."

# game/act1.rpy:1298
translate italian act1_9420b883:

    # anon "{i}Chele{/i} just means you have light-colored fur. It’s not offensive."
    anon "{i}Chele{/i} significa semplicemente che hai la pelliccia di colore chiaro. Non è offensivo."

# game/act1.rpy:1300
translate italian act1_b79c8c67:

    # a surprised "Oh. Well… how do I know you’re telling the truth?"
    a surprised "Oh. Beh... come faccio a sapere che stai dicendo la verità?"

# game/act1.rpy:1301
translate italian act1_d8d612b6:

    # anon "…"
    anon "…"

# game/act1.rpy:1303
translate italian act1_da715c31:

    # anon "You don’t. You’re just gonna have to take my word for it."
    anon "Non puoi. Devi solo fidarti della mia parola."

# game/act1.rpy:1305
translate italian act1_156cb837:

    # "He practically whispers this, looking me right in the eyes as he does."
    "Lo dice praticamente sottovoce, guardandomi dritto negli occhi."

# game/act1.rpy:1307
translate italian act1_8f248a44:

    # a cocky "…"
    a cocky "…"

# game/act1.rpy:1309
translate italian act1_8526af50:

    # a "Well, just in case you {i}are{/i} calling me something bad, I’d rather you call me by my name."
    a "Beh, nel caso in cui tu mi stia chiamando con un nome offensivo, preferirei che mi chiamassi per nome."

# game/act1.rpy:1310
translate italian act1_f176356c:

    # a smile "I’m Angel. I don’t think I’ve ever seen you around Sonora."
    a smile "Sono Angel. Non credo di averti mai visto in giro per Sonora."

# game/act1.rpy:1311
translate italian act1_64b7ac9c:

    # s "Nice to meet you, {i}Ángel{/i}. I’m Sebas."
    s "Piacere di conoscerti, {i}Ángel{/i}. Sono Sebas."

# game/act1.rpy:1312
translate italian act1_12adba69:

    # a surprised "Sebas? I've never heard that name before."
    a surprised "Sebas? Non ho mai sentito questo nome prima d'ora."

# game/act1.rpy:1313
translate italian act1_be2de156:

    # s cocky "It’s short for {i}Sebastián{/i}, if you must know. I just like it better this way."
    s cocky "È l'abbreviazione di {i}Sebastián{/i}, se proprio vuoi saperlo. Mi piace di più così."

# game/act1.rpy:1315
translate italian act1_4c01482c:

    # "His accent comes out strong here, and I realize he must have trouble pronouncing his r’s, practically rolling them when he tries to say them. He says my name differently in his accent, {i}Ahn-hel.{/i} It sounds… nice."
    "Il suo accento è molto marcato qui, e mi rendo conto che deve avere difficoltà a pronunciare le \"r\", quasi le arrotola quando cerca di dirle. Pronuncia il mio nome in modo diverso con il suo accento, {i}Ahn-hel.{/i} Suona... bene."

# game/act1.rpy:1316
translate italian act1_c5d52ac1:

    # "He also pronounces his own name completely different than you would in English, his vowels and consonants sounding almost… harsher? {i}Seh-bas-tyan{/i}, with more emphasis in the last syllable."
    "Inoltre, pronuncia il suo nome in modo completamente diverso da come lo pronuncereste voi in inglese, le sue vocali e consonanti suonano quasi... più aspre? {i}Seh-bas-tyan{/i}, con maggiore enfasi sull'ultima sillaba."

# game/act1.rpy:1318
translate italian act1_4038d4af:

    # s "So, {i}Ángel{/i}… is this mystery person coming any time soon, or should I keep you company?"
    s "Allora, {i}Ángel{/i}… questa persona misteriosa arriverà presto, o dovrei tenerti compagnia?"

# game/act1.rpy:1320
translate italian act1_45895f19:

    # a smile "He’s being held up at his job. But I wouldn’t mind your company until he gets here."
    a smile "È trattenuto al lavoro. Ma non mi dispiacerebbe la tua compagnia finché non arriva."

# game/act1.rpy:1321
translate italian act1_8cacac30:

    # s amused "Is that right…?"
    s amused "È corretto...?"

# game/act1.rpy:1323
translate italian act1_ca293780:

    # "He finishes his drink, licking his muzzle slowly as he stares down the counter."
    "Finisce il suo drink, leccandosi lentamente il muso mentre fissa il bancone."

# game/act1.rpy:1325
translate italian act1_748f9a5a:

    # s hm "I’m surprised to see someone like you here at this hour."
    s hm "Sono sorpreso di vedere una persona come te qui a quest'ora."

# game/act1.rpy:1326
translate italian act1_0490af36:

    # a hm "Someone like me?"
    a hm "Qualcuno come me?"

# game/act1.rpy:1327
translate italian act1_03a32570:

    # s "You are a Valentine, yeah? I hear it’s quite the demanding job."
    s "Tu sei un Valentine, giusto? Ho sentito dire che è un lavoro piuttosto impegnativo."

# game/act1.rpy:1330
translate italian act1_dce97470:

    # a bashful "That’s right. Never a dull moment… I’m just stopping by for lunch."
    a bashful "Esatto. Non ci si annoia mai... Mi fermo solo per pranzo."

# game/act1.rpy:1331
translate italian act1_2f156776:

    # s smile "I see. It must be interesting though, being a journalist. You get to talk to so many different people, go to different places."
    s smile "Capisco. Dev'essere interessante, però, fare il giornalista. Si ha l'opportunità di parlare con tantissime persone diverse, di visitare posti diversi."

# game/act1.rpy:1333
translate italian act1_e8ff743c:

    # a flattered "Hah. No, not really. The Valentine Report only covers stories inside of Sonora, and talking to people isn’t exactly a fun part of the job. Most here don’t really like Valentines."
    a flattered "Ah. No, non proprio. Il Valentine Report si occupa solo di notizie che accadono a Sonora, e parlare con la gente non è esattamente la parte divertente del lavoro. Alla maggior parte delle persone qui non piacciono i biglietti di San Valentino."

# game/act1.rpy:1334
translate italian act1_f0a46da3:

    # s lookaway "So I’ve come to notice."
    s lookaway "Quindi me ne sono accorto."

# game/act1.rpy:1337
translate italian act1_d69e8620:

    # a surprised "Where are you from, actually?"
    a surprised "Di dove sei, in realtà?"

# game/act1.rpy:1339
translate italian act1_a0a82255:

    # s smile "Michigan."
    s smile "Michigan."

# game/act1.rpy:1341
translate italian act1_c8d5007a:

    # a concern "Oh."
    a concern "OH."

# game/act1.rpy:1343
translate italian act1_4448f1a3:

    # s "What? Could it be... you wanted to know where I'm {i}really{/i} from?"
    s "Cosa? Potrebbe essere... volevi sapere da dove vengo {i}veramente{/i}?"

# game/act1.rpy:1345
translate italian act1_2e2a7cc9:

    # "My cheeks grow hot. Now he's gonna think I'm some racist."
    "Mi si scaldano le guance. Ora penserà che sono razzista."

# game/act1.rpy:1347
translate italian act1_735768f4:

    # a flustered "N-No no, I was just-!"
    a flustered "N-No no, stavo solo-!"

# game/act1.rpy:1349
translate italian act1_31159a0d:

    # s "Heh. {i}Tranquilo.{/i} I'm messing with you."
    s "Heh. {i}Tranquillo.{/i} Ti sto prendendo in giro."

# game/act1.rpy:1350
translate italian act1_9d5527ba:

    # s smile "I'm Colombian. But I do live in Michigan."
    s smile "Sono colombiana, ma vivo in Michigan."

# game/act1.rpy:1351
translate italian act1_bc28083b:

    # a "I see... good to know."
    a "Capisco... bene a sapersi."

# game/act1.rpy:1352
translate italian act1_23d6c3d3:

    # s amused "I take it you don't see many foreigners around here?"
    s amused "Immagino che da queste parti non si vedano molti stranieri, vero?"

# game/act1.rpy:1353
translate italian act1_a334f6f2:

    # a bashful "Well… there are lots of people from all around the world living here, actually. I’ve just never had a proper conversation with anyone who speaks Spanish."
    a bashful "Beh… in realtà qui vivono molte persone provenienti da tutto il mondo. Solo che non ho mai avuto una vera conversazione con nessuno che parlasse spagnolo."

# game/act1.rpy:1354
translate italian act1_d61f74db:

    # s smile "Maybe I can teach you a thing or two… when you’re not so busy."
    s smile "Magari posso insegnarti un paio di cose... quando non sarai così impegnato."

# game/act1.rpy:1356
translate italian act1_5b0f6ff7:

    # a blush "I’d like that."
    a blush "Mi piacerebbe."

# game/act1.rpy:1358
translate italian act1_45b8e009:

    # a smile "So what brings you to Sonora, anyway?"
    a smile "Allora, cosa ti porta esattamente a Sonora?"

# game/act1.rpy:1363
translate italian act1_e19df76a:

    # "He leans in even closer, as if he’s about to tell me a secret. I get closer too, so close I can smell the beer on his breath. It makes my face burn red."
    "Si sporge ancora di più, come se stesse per confidarmi un segreto. Mi avvicino anch'io, così tanto da sentire l'odore di birra sul suo alito. Mi fa diventare la faccia rossa."

# game/act1.rpy:1365
translate italian act1_eed73d59:

    # s "I’m here on business... But, that’s not the main reason I came to this city."
    s "Sono qui per lavoro... Ma non è questo il motivo principale per cui sono venuto in questa città."

# game/act1.rpy:1366
translate italian act1_e09541fe:

    # s cocky "To tell you the truth, {i}chelito…{/i}{w} I came here to gamble."
    s cocky "A dire la verità, {i}chelito…{/i}{w} sono venuto qui per giocare d'azzardo."

# game/act1.rpy:1369
translate italian act1_0db9357b:

    # a surprised "Did you, now?"
    a surprised "Davvero?"

# game/act1.rpy:1370
translate italian act1_db7b1833:

    # s amused "That’s right. I was wondering, actually… if you happened to know of any good places for that."
    s amused "Esatto. Mi chiedevo, in effetti… se per caso conoscessi qualche buon posto per quello."

# game/act1.rpy:1375
translate italian act1_33a52ec1:

    # "I lean back in my own space, sighing."
    "Mi appoggio allo schienale della sedia, sospirando."

# game/act1.rpy:1377
translate italian act1_1496192a:

    # a hm "Unfortunately not. Valentines can’t gamble."
    a hm "Purtroppo no. A San Valentino non si può giocare d'azzardo."

# game/act1.rpy:1378
translate italian act1_2611337c:

    # s hm "’Can’t’ or ‘don’t’?"
    s hm "'Non posso' o 'non voglio'?"

# game/act1.rpy:1379
translate italian act1_73910e7a:

    # a hm "That’s… the same thing."
    a hm "È… la stessa cosa."

# game/act1.rpy:1380
translate italian act1_d30b3a39:

    # s stan "I don’t think it is."
    s stan "Non credo lo sia."

# game/act1.rpy:1382
translate italian act1_f98db646:

    # a worried "In any case… the only place I know of is Corona’s, and let’s just say, I don’t recommend it. I’m actually writing a story about the missing person case that happened there not too long ago."
    a worried "In ogni caso… l'unico posto che conosco è Corona's, e diciamo solo che non lo consiglio. In realtà sto scrivendo un articolo sul caso di persona scomparsa avvenuto lì non molto tempo fa."

# game/act1.rpy:1383
translate italian act1_08f0a55d:

    # s lookaway "I’ve heard about that, too."
    s lookaway "Anch'io ne ho sentito parlare."

# game/act1.rpy:1385
translate italian act1_e86985fa:

    # "His casual demeanor falters somewhat, a darkness clouding his already pitch-black eyes."
    "Il suo atteggiamento disinvolto vacilla leggermente, un'ombra oscura offusca i suoi occhi già neri come la pece."

# game/act1.rpy:1387
translate italian act1_97001861:

    # s hm "Well, doesn’t matter. There’s plenty of other places to go, I’m sure."
    s hm "Beh, non importa. Ci sono un sacco di altri posti dove andare, ne sono sicuro."

# game/act1.rpy:1388
translate italian act1_63c059ba:

    # s smile "In fact, I’ve heard talk around the town that there’s an underground ring somewhere in Sonora. Maybe I’ll check that out instead."
    s smile "In effetti, ho sentito dire in giro che c'è una rete clandestina da qualche parte a Sonora. Forse potrei andare a dare un'occhiata lì."

# game/act1.rpy:1389
translate italian act1_05ed241b:

    # a hm "Underground? Where did you hear this?"
    a hm "Sottoterra? Dove l'hai sentito?"

# game/act1.rpy:1391
translate italian act1_9fd1a17b:

    # "He tilts his now empty bottle side to side, toying with it as he thinks."
    "Inclina la bottiglia ormai vuota da un lato all'altro, giocherellando con essa mentre pensa."

# game/act1.rpy:1393
translate italian act1_841194e4:

    # s "Where I heard this…? I can’t remember anymore. I get around a lot. But I did remember where it was. Some bar called The Albatross."
    s "Dove l'ho sentito...? Non me lo ricordo più. Viaggio molto. Ma ricordo dove l'ho sentito. In un bar chiamato The Albatross."

# game/act1.rpy:1394
translate italian act1_1ab72481_8:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1396
translate italian act1_0324b1fb:

    # "That’s… the dive bar near Ethan’s apartment."
    "Quello è… il bar malfamato vicino all'appartamento di Ethan."

# game/act1.rpy:1398
translate italian act1_88c4eae3:

    # a body2 thinking "I see…"
    a body2 thinking "Vedo…"

# game/act1.rpy:1400
translate italian act1_b7c2169f:

    # s smile "You know, {i}chele{/i}, I think you should check it out. Those kinds of people are always in the know-how, and if you gamble with them, they might tell you a thing or two. Could help you out with your story."
    s smile "Sai, {i}chele{/i}, penso che dovresti dare un'occhiata. Quel tipo di persone sono sempre ben informate e, se giochi d'azzardo con loro, potrebbero dirti un paio di cose. Potrebbero aiutarti con la tua storia."

# game/act1.rpy:1402
translate italian act1_b9dd7fa6:

    # a body cocky "Hah. Fat chance. Even if I wanted to gamble, which I don’t… I don’t even have the money to do it."
    a body cocky "Ah. Impossibile. Anche se volessi scommettere, cosa che non voglio... non ho nemmeno i soldi per farlo."

# game/act1.rpy:1403
translate italian act1_7c08430d:

    # s hm "Who said anything about money? You have something much more valuable."
    s hm "Chi ha parlato di soldi? Tu hai qualcosa di molto più prezioso."

# game/act1.rpy:1404
translate italian act1_a15d76ee:

    # a hm "And that is…?"
    a hm "E cioè...?"

# game/act1.rpy:1407
translate italian act1_9c8bec2b:

    # s "Information."
    s "Informazioni."

# game/act1.rpy:1409
translate italian act1_1237e421:

    # s "Sure, you might have to pay your first time around, but… unlike a casino, money isn’t the only thing you can put on the table in these places."
    s "Certo, la prima volta potresti dover pagare, ma... a differenza di un casinò, in questi posti il ​​denaro non è l'unica cosa che puoi mettere sul tavolo."

# game/act1.rpy:1410
translate italian act1_e1d567d1:

    # s hm2 "Properties, possessions… and yeah, even something as abstract as information. It’s all fair game, as long as both parties agree. And trust me, these people have a lot of information to share as well."
    s hm2 "Proprietà, beni… e sì, persino qualcosa di astratto come le informazioni. Tutto è lecito, purché entrambe le parti siano d'accordo. E credetemi, anche queste persone hanno molte informazioni da condividere."

# game/act1.rpy:1412
translate italian act1_9f9d836b:

    # s "You’d be surprised how interconnected this world is. Someone knows a guy who knows a guy, who knows a guy…"
    s "Rimarreste sorpresi da quanto sia interconnesso questo mondo. Qualcuno conosce qualcuno che conosce qualcuno, che conosce qualcun altro…"

# game/act1.rpy:1413
translate italian act1_04d77b3e:

    # s cocky "And pretty soon, you know every guy. And the person with the most knowledge has the most power."
    s cocky "E ben presto, conosci tutti. E chi ha più conoscenze ha più potere."

# game/act1.rpy:1414
translate italian act1_a5587c65:

    # s amused "And isn’t that what you’re after, {i}Ángel{/i}?"
    s amused "E non è forse questo che desideri, {i}Ángel{/i}?"

# game/act1.rpy:1416
translate italian act1_1ab72481_9:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1418
translate italian act1_1c90cd1f:

    # "Does he mean information…{w} or power?"
    "Intende forse l'informazione…{w} o il potere?"

# game/act1.rpy:1420
translate italian act1_59b80d18:

    # a "I, um…"
    a "Io, ehm…"

# game/act1.rpy:1422
translate italian act1_7d58c590:

    # e "Angel."
    e "Angelo."

# game/act1.rpy:1426
translate italian act1_a2795d4e:

    # "I flinch, quickly turning around to see Ethan standing right behind me, with a look that tells me I’ve done something wrong."
    "Sussulto, mi giro di scatto e vedo Ethan in piedi proprio dietro di me, con un'espressione che mi dice che ho fatto qualcosa di sbagliato."

# game/act1.rpy:1428
translate italian act1_b6fddf70:

    # a bashful "Ethan… there you are. What took you so long?"
    a bashful "Ethan... eccoti. Perché ci hai messo tanto?"

# game/act1.rpy:1429
translate italian act1_a667392f:

    # e hm "Got held up at work. Who’s your friend?"
    e hm "Sono rimasto bloccato al lavoro. Chi è il tuo amico?"

# game/act1.rpy:1431
translate italian act1_13bd0050:

    # "He nods towards Sebas, who, despite being put on the spot, doesn’t seemed phased by Ethan’s pointedness in the slightest."
    "Fa un cenno con la testa verso Sebas, il quale, pur essendo messo alle strette, non sembra minimamente turbato dalla schiettezza di Ethan."

# game/act1.rpy:1433
translate italian act1_c319ca04:

    # a "Um… Ethan, this is-"
    a "Ehm... Ethan, questo è-"

# game/act1.rpy:1435
translate italian act1_b10fd209:

    # s "I’m just a stranger making conversation. But unfortunately, I’ve got places to be now."
    s "Sono solo uno sconosciuto che cerca di conversare. Ma purtroppo ora ho degli impegni."

# game/act1.rpy:1438
translate italian act1_88e0f826:

    # "He gets up, opening his wallet to leave a bill on the bar, and very smoothly leans close to me as he’s turning to leave, speaking in a hushed voice that I’m sure Ethan couldn’t hear - maybe intentionally so."
    "Si alza, apre il portafoglio per lasciare una banconota sul bancone e, con molta disinvoltura, si china verso di me mentre si volta per andarsene, parlando a bassa voce, in un modo che sono sicuro Ethan non abbia potuto sentire, forse di proposito."

# game/act1.rpy:1440
translate italian act1_c16ecddd:

    # s smile "I’ll see you around, {i}Ángel{/i}."
    s smile "Ci vediamo in giro, {i}Ángel{/i}."

# game/act1.rpy:1442
translate italian act1_ff2008fc:

    # "I shudder, resisting the urge to turn and watch him leave. Ethan slides into the stool that Sebas was on, giving me a puzzled look."
    "Rabbrividisco, resistendo all'impulso di voltarmi e guardarlo andarsene. Ethan si siede sullo sgabello dove era seduto Sebas, lanciandomi un'occhiata perplessa."

# game/act1.rpy:1444
translate italian act1_f684ca3c:

    # e "Do you know that guy?"
    e "Conosci quel tipo?"

# game/act1.rpy:1446
translate italian act1_6ff83036:

    # a surprised "Never met him before."
    a surprised "Non l'avevo mai incontrato prima."

# game/act1.rpy:1447
translate italian act1_2b8e7590:

    # e "Yeah, well let’s hope we don’t run into him again. He gives me the creeps."
    e "Sì, beh, speriamo di non incontrarlo di nuovo. Mi mette i brividi."

# game/act1.rpy:1448
translate italian act1_bfcb83b8:

    # a bashful "Yeah… me too."
    a bashful "Sì... anch'io."

# game/act1.rpy:1450
translate italian act1_4ac584c9:

    # "Or so I say. And, although he does kind of give me the creeps, too… I secretly hope that it won’t be the last time I run into him."
    "O almeno così dico io. E, anche se in effetti mette un po' i brividi anche a me... spero segretamente che non sia l'ultima volta che lo incontro."

# game/act1.rpy:1452
translate italian act1_0a6ed9bb:

    # e uh "Stop talking to strangers, too. You're gonna get yourself into trouble."
    e uh "Smetti anche di parlare con gli sconosciuti. Ti metterai nei guai."

# game/act1.rpy:1453
translate italian act1_7197ccdf:

    # a eyeroll "Yes, Dad."
    a eyeroll "Sì, papà."

# game/act1.rpy:1454
translate italian act1_7cb4947d:

    # e sigh "Ugh. Whatever. I need a drink."
    e sigh "Uff. Vabbè. Ho bisogno di bere qualcosa."

# game/act1.rpy:1456
translate italian act1_56e11dcf:

    # "He waves over the bartender and orders - what else - a Tonio. I prop my chin on my hand, resting my elbows on the bar’s countertop as I watch him take three big, manly gulps of his beer."
    "Fa un cenno al barista e ordina – indovinate un po'? – una Tonio. Appoggio il mento sulla mano, poggiando i gomiti sul bancone del bar, mentre lo guardo bere tre grossi sorsi virili di birra."

# game/act1.rpy:1458
translate italian act1_e3fea642:

    # a worried "Rough day?"
    a worried "Giornata difficile?"

# game/act1.rpy:1460
translate italian act1_1b49255d:

    # "Ethan sighs as he sets the glass down, licking his muzzle clean."
    "Ethan sospira mentre appoggia il bicchiere, leccandosi il muso per pulirlo."

# game/act1.rpy:1462
translate italian act1_968f0ed6:

    # e hm "Sort of. The police station is a bit of a mess right now. I don’t want to get too into it, though. I don’t even fully know what’s going on."
    e hm "Più o meno. La stazione di polizia è un po' un caos in questo momento. Non voglio entrare troppo nei dettagli, però. Non so nemmeno bene cosa stia succedendo."

# game/act1.rpy:1463
translate italian act1_74afa0b7:

    # a "Hm… that does sound tiring…"
    a "Mh... sembra davvero faticoso..."

# game/act1.rpy:1464
translate italian act1_e2530fe9:

    # e "Yeah… though, I’ve never seen it this… hectic."
    e "Sì... anche se non l'ho mai visto così... frenetico."

# game/act1.rpy:1466
translate italian act1_6f1b178c:

    # a surprised "Wasn’t it like that when you were younger?"
    a surprised "Non era così anche quando eri più giovane?"

# game/act1.rpy:1467
translate italian act1_84e307a6:

    # e "You mean when my dad was in office?"
    e "Intendi quando mio padre era in carica?"

# game/act1.rpy:1468
translate italian act1_d925f1ea:

    # a cocky "Kind of, yeah. Or when you first started off. You know… {i}way{/i} back then."
    a cocky "In un certo senso, sì. O quando hai iniziato. Sai... {i}tanto{/i} tanto tempo fa."

# game/act1.rpy:1469
translate italian act1_caa46594:

    # e hm "Haha. Well, no. Not when I was starting off."
    e hm "Ahah. Beh, no. Non quando ho iniziato."

# game/act1.rpy:1470
translate italian act1_c0550d5e:

    # e surprised "But my dad would work late nights. Mainly because he worked the graveyard shift. I just thought that was how it always was, though. I guess you don’t really catch onto things when you’re a kid."
    e surprised "Mio padre lavorava fino a tardi la sera. Principalmente perché faceva il turno di notte. Io però pensavo che fosse sempre stato così. Immagino che da bambini non si capiscano certe cose."

# game/act1.rpy:1471
translate italian act1_556f4b80:

    # a surprised "Hm."
    a surprised "Hmm."

# game/act1.rpy:1472
translate italian act1_1141060d:

    # e frown "Enough about me, though. What about you? What did {i}Mr. Valentine{/i} want?"
    e frown "Ma basta parlare di me. E tu? Cosa voleva il signor Valentine?"

# game/act1.rpy:1474
translate italian act1_e2886545:

    # "Ethan says his name like it has a taste to it, and not a very good one at that. I just smile, rolling my eyes."
    "Ethan pronuncia il suo nome come se avesse un sapore particolare, e per giunta non molto gradevole. Io mi limito a sorridere, alzando gli occhi al cielo."

# game/act1.rpy:1476
translate italian act1_02a70138:

    # a cocky "Oh, you know, just to partake in his favorite pastime in the whole wide world… tormenting me for fun. I had to go on a fetch quest for donuts that he didn’t end up eating."
    a cocky "Oh, sai, giusto per dedicarsi al suo passatempo preferito in assoluto... tormentarmi per divertimento. Ho dovuto andare a recuperare delle ciambelle che alla fine non ha mangiato."

# game/act1.rpy:1477
translate italian act1_99e258fb:

    # e uh "Seriously? That guy’s a lunatic."
    e uh "Davvero? Quel tipo è un pazzo."

# game/act1.rpy:1478
translate italian act1_4aa82261:

    # a bashful "Hah, yeah… but whatever."
    a bashful "Ah, sì... ma vabbè."

# game/act1.rpy:1479
translate italian act1_005c29c6:

    # e flattered "Yeah. What can you do, am I right?"
    e flattered "Sì. Che ci si può fare, giusto?"

# game/act1.rpy:1481
translate italian act1_d7e01f39:

    # "I hum like I agree with him… but, in my head, I can’t help but think about my conversation with Mr. Grey, as much as I’d like to pretend our whole interaction was just some nightmarish dream."
    "Canticchio come per dire che sono d'accordo con lui... ma, nella mia testa, non posso fare a meno di pensare alla mia conversazione con il signor Grey, per quanto vorrei fingere che tutta la nostra interazione sia stata solo un incubo."

# game/act1.rpy:1483
translate italian act1_b3efd907:

    # "Despite what I said, Mr. Grey {i}did{/i} give me an option. Just the very thought is crazy to me, and I still haven’t been able to fully process it."
    "Nonostante quello che ho detto, il signor Grey {i}mi ha{/i} offerto un'opzione. Il solo pensiero mi sembra assurdo e non sono ancora riuscito a elaborarlo completamente."

# game/act1.rpy:1484
translate italian act1_499f5003:

    # "I had an {i}option.{/i} I had an out, albeit an extremely risky out, to this life that I’m trapped in, for the first time ever. So, when I hear Ethan say the words ‘What can you do?’… I realize that there {i}is{/i} something I could’ve done."
    "Avevo un'opzione. Avevo una via d'uscita, seppur estremamente rischiosa, da questa vita in cui sono intrappolato, per la prima volta in assoluto. Quindi, quando sento Ethan dire le parole \"Cosa puoi fare?\"... mi rendo conto che c'è qualcosa che avrei potuto fare."

# game/act1.rpy:1486
translate italian act1_872a7f7a:

    # "Maybe something I {i}should’ve{/i} done…"
    "Forse qualcosa che avrei dovuto fare..."

# game/act1.rpy:1488
translate italian act1_517f8b9c:

    # e worried "In any case, what happened in Corona’s?"
    e worried "In ogni caso, cosa è successo a Corona?"

# game/act1.rpy:1490
translate italian act1_1376d153:

    # "Ethan’s voice snaps me out of my worrying thoughts, only for his sentence to bring another layer of anxiety to them. No way in hell am I telling him what happened in there."
    "La voce di Ethan mi distoglie dai miei pensieri angoscianti, solo per poi aggiungere un ulteriore livello di ansia alla mia mente. Non ho la minima intenzione di dirgli cosa è successo lì dentro."

# game/act1.rpy:1492
translate italian act1_12ef6bd2:

    # a flustered "Huh? Oh, um… it was just… useless."
    a flustered "Eh? Oh, ehm... era semplicemente... inutile."

# game/act1.rpy:1493
translate italian act1_9be96621:

    # e "Seriously? How come?"
    e "Davvero? Come mai?"

# game/act1.rpy:1494
translate italian act1_5ede1711:

    # a flattered "Well… I did try and talk to the staff, but…"
    a flattered "Beh… ho provato a parlare con il personale, ma…"

# game/act1.rpy:1495
translate italian act1_d4d0c6a1:

    # e "But?"
    e "Ma?"

# game/act1.rpy:1497
translate italian act1_015eaa14:

    # a bashful "But nothing worthwhile was said."
    a bashful "Ma non è stato detto nulla di utile."

# game/act1.rpy:1499
translate italian act1_1c9fca34:

    # e worried "Aw. I see."
    e worried "Oh, capisco."

# game/act1.rpy:1501
translate italian act1_cbbbf41b:

    # "He seems somewhat let down by this, but mostly relieved, taking much smaller sips of his beer as he looks at nothing in particular. Did he really wanna know about Corona’s?"
    "Sembra un po' deluso, ma soprattutto sollevato, e beve a piccoli sorsi la sua birra mentre guarda nel vuoto. Voleva davvero sapere qualcosa su Corona?"

# game/act1.rpy:1502
translate italian act1_5f7e3912:

    # "More importantly, apart from my very strange interaction with Mr. Grey, did I really not learn anything useful today? He claims he has nothing to do with the disappearances, and his staff are all under a watchful eye."
    "Ancora più importante, a parte la mia stranissima interazione con il signor Grey, non ho davvero imparato nulla di utile oggi? Lui afferma di non avere nulla a che fare con le sparizioni e che tutto il suo staff è sotto stretta sorveglianza."

# game/act1.rpy:1503
translate italian act1_d03749f0:

    # "Doesn’t that put me back at square one?"
    "Questo non mi riporta al punto di partenza?"

# game/act1.rpy:1504
translate italian act1_04e207b7:

    # "Unless…"
    "Salvo che…"

# game/act1.rpy:1505
translate italian act1_9587a2fa:

    # "My conversation with Sebas replays in my head… but, was he telling me the truth? Or just planting seeds in my mind?"
    "La mia conversazione con Sebas continua a ripresentarsi nella mia mente… ma mi diceva la verità? O stava solo seminando dubbi nella mia testa?"

# game/act1.rpy:1506
translate italian act1_7659baf8:

    # "Either way, I can find out if I play my cards right."
    "In entrambi i casi, potrò scoprire se ho giocato bene le mie carte."

# game/act1.rpy:1508
translate italian act1_cad7c531:

    # a surprised "Well… there was {i}one{/i} thing I found out about."
    a surprised "Beh… c’è una cosa che ho scoperto."

# game/act1.rpy:1510
translate italian act1_6059195a:

    # "Ethan perks up again, listening attentively."
    "Ethan si rianima e inizia ad ascoltare con attenzione."

# game/act1.rpy:1512
translate italian act1_6bafbff3:

    # a hm "I was talking to a staff member-"
    a hm "Stavo parlando con un membro dello staff-"

# game/act1.rpy:1513
translate italian act1_d257c14b:

    # e hm "Which one?"
    e hm "Quale?"

# game/act1.rpy:1514
translate italian act1_1465dab9:

    # a surprised "Uh… I don’t know, they were just walking by in uniform. Maybe a receptionist?"
    a surprised "Ehm... non lo so, stavano passando in uniforme. Forse una receptionist?"

# game/act1.rpy:1516
translate italian act1_66dfc06b:

    # "He nods, urging me to go on."
    "Lui annuisce, incoraggiandomi a proseguire."

# game/act1.rpy:1517
translate italian act1_2300f589:

    # "He bought it. Nice."
    "L'ha comprato. Bene."

# game/act1.rpy:1519
translate italian act1_a6d0c2ec:

    # a frown "Anyway, they told me something about their boss keeping them under strict surveillance, and that they doubt it was anyone from the staff. But… they also told me to ask around a certain underground ring."
    a frown "Comunque, mi hanno detto qualcosa sul fatto che il loro capo li teneva sotto stretta sorveglianza e che sospettavano che fosse stato qualcuno dello staff. Però... mi hanno anche detto di chiedere in giro in una certa rete clandestina."

# game/act1.rpy:1520
translate italian act1_739597c0:

    # a hm "The Albatross seems to have some gambling going on underneath the bar. Have you… heard about that?"
    a hm "Sembra che all'Albatross si svolgano delle scommesse clandestine sotto il bancone. Ne hai... sentito parlare?"

# game/act1.rpy:1524
translate italian act1_30370f1a:

    # "Ethan doesn’t look too surprised by this, which just confirms my suspicions before he even opens his mouth again."
    "Ethan non sembra affatto sorpreso, il che non fa altro che confermare i miei sospetti ancor prima che apra bocca."

# game/act1.rpy:1526
translate italian act1_18f0101e:

    # e sigh "There have been reports about underground rings forming in the city in the past couple of months. The Albatross {i}is{/i} a suspect… but we have nothing concrete yet."
    e sigh "Negli ultimi due mesi sono giunte segnalazioni di anelli sotterranei che si sarebbero formati in città. L'Albatross {i}è{/i} un sospettato... ma non abbiamo ancora nulla di concreto."

# game/act1.rpy:1528
translate italian act1_783737a0:

    # a hm "Why haven’t you guys investigated it? If it’s something the S.P.D. suspect is happening."
    a hm "Perché non avete indagato? Se è qualcosa che sospetta la polizia di Seattle sta accadendo."

# game/act1.rpy:1529
translate italian act1_d9e63a93:

    # e hm "It’s not that simple. There are ways of going about these things. You think they’ll just let a cop in the ring, no questions asked?"
    e hm "Non è così semplice. Ci sono modi diversi di affrontare queste situazioni. Credi davvero che lasceranno entrare un poliziotto sul ring senza fare domande?"

# game/act1.rpy:1530
translate italian act1_77f545e4:

    # e frown "It’s underground for a reason, Angie. It’s supposed to be a secret, and even if there are rumors going around, without solid proof, we can’t do anything."
    e frown "È sotterraneo per un motivo, Angie. Dovrebbe rimanere un segreto, e anche se circolano voci, senza prove concrete non possiamo fare nulla."

# game/act1.rpy:1531
translate italian act1_67a18015:

    # e hm "Besides… private gambling isn’t {i}technically{/i} illegal in Sonora. There are just certain rules you have to follow. If it’s just a couple of guys playing poker, we can’t really shut that down."
    e hm "Inoltre... il gioco d'azzardo privato non è tecnicamente illegale in Sonora. Ci sono solo alcune regole da seguire. Se si tratta solo di un paio di ragazzi che giocano a poker, non possiamo certo impedirlo."

# game/act1.rpy:1532
translate italian act1_f5b14976:

    # e uh "But if they start sending out invitations, well… then it becomes a problem."
    e uh "Ma se iniziano a inviare inviti, beh… allora diventa un problema."

# game/act1.rpy:1533
translate italian act1_1ab72481_10:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1535
translate italian act1_f19967e4:

    # a "But then… what would be the issue? If anyone can just gamble with whoever they want, why does it matter if there are rings?"
    a "Ma allora… qual è il problema? Se chiunque può scommettere con chi vuole, perché dovrebbe importare se ci sono degli anelli?"

# game/act1.rpy:1537
translate italian act1_8d15e008:

    # e "Because there’s no regulation. Unlike casinos, the house can accept anything as payment, not just money, and that becomes a problem. People lose their homes, their possessions… some people gamble their family members away."
    e "Perché non c'è regolamentazione. A differenza dei casinò, la casa da gioco può accettare qualsiasi cosa come pagamento, non solo denaro, e questo diventa un problema. Le persone perdono la casa, i loro beni... alcune persone mandano al gioco anche i propri familiari."

# game/act1.rpy:1538
translate italian act1_21260edc:

    # e frown "That’s why, when you’re out of physical money, but still think you can turn your luck around somehow…"
    e frown "Ecco perché, quando sei senza soldi veri, ma pensi ancora di poter in qualche modo ribaltare la situazione…"

# game/act1.rpy:1539
translate italian act1_1f0992e1:

    # a surprised "You go to a ring."
    a surprised "Vai verso un anello."

# game/act1.rpy:1540
translate italian act1_3b6e13c9:

    # e sigh "Exactly."
    e sigh "Esattamente."

# game/act1.rpy:1542
translate italian act1_2d311620:

    # "So, Sebas was telling the truth after all.{w} What else was he right about?"
    "Quindi, Sebas diceva la verità, dopotutto.{w} Su cos'altro aveva ragione?"

# game/act1.rpy:1544
translate italian act1_25bd8fed:

    # a body2 thinking "{i}I guess this is my only real lead right now… that doesn’t give me many options. I might have to end up going to The Albatross… How would I even go about doing it?"
    a body2 thinking "{i}Credo che questa sia la mia unica vera pista al momento... il che non mi lascia molte opzioni. Potrei dover andare all'Albatross... Come potrei fare?"

# game/act1.rpy:1545
translate italian act1_848bcf35:

    # a frown2 "{i}Maybe a disguise? I don’t have many clothes, though…"
    a frown2 "{i}Forse un travestimento? Non ho molti vestiti, però…"

# game/act1.rpy:1547
translate italian act1_42884d1f:

    # e frown "Don’t even think about it."
    e frown "Non pensarci nemmeno."

# game/act1.rpy:1548
translate italian act1_d0c2f276:

    # a body surprised "Huh?"
    a body surprised "Eh?"

# game/act1.rpy:1549
translate italian act1_ee21b85d:

    # e "I know what you’re thinking. You’re not going there."
    e "So cosa stai pensando. Non ci andrai."

# game/act1.rpy:1550
translate italian act1_596e1ed8:

    # a frown "What? Why not?"
    a frown "Cosa? Perché no?"

# game/act1.rpy:1551
translate italian act1_570aff14:

    # e "If people have gone missing right on the doorsteps of the most famous casino in the city, imagine what would happen to you at some dingy dive bar."
    e "Se delle persone sono scomparse proprio davanti all'ingresso del casinò più famoso della città, immaginate cosa potrebbe succedere a voi in un bar squallido."

# game/act1.rpy:1552
translate italian act1_28c70d46:

    # a "I’m not going to get killed for just walking into a bar. This is part of my job, you know."
    a "Non ho intenzione di farmi ammazzare solo per essere entrato in un bar. Fa parte del mio lavoro, sai."

# game/act1.rpy:1553
translate italian act1_082d34e9:

    # e "No, your job is to write a story on the disappearance of that girl, not going around shady pubs and entering gambling rings."
    e "No, il tuo compito è scrivere un articolo sulla scomparsa di quella ragazza, non andare in giro per pub malfamati e intrufolarti in bische clandestine."

# game/act1.rpy:1554
translate italian act1_bc070f24:

    # a concern "That’s… sometimes part of it."
    a concern "Questo... a volte fa parte del problema."

# game/act1.rpy:1555
translate italian act1_7c1ce8a2:

    # e uh "Don’t start right now. I don’t need to hear how you think you have everything under control, and you don’t care what happens to you."
    e uh "Non cominciare adesso. Non ho bisogno di sentire che pensi di avere tutto sotto controllo e che non ti importa di quello che ti succede."

# game/act1.rpy:1556
translate italian act1_c918a3a1:

    # a worried "I do care what happens to me. But if I don’t at least try-"
    a worried "Mi interessa quello che mi succede. Ma se non ci provo almeno..."

# game/act1.rpy:1557
translate italian act1_c31f17e1:

    # e angry "Why don’t you try listening to someone who clearly knows more about this than you and just do what you’re supposed to do for once?"
    e angry "Perché non provi ad ascoltare qualcuno che ne sa chiaramente più di te e a fare semplicemente quello che dovresti fare, per una volta?"

# game/act1.rpy:1560
translate italian act1_1ab72481_11:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1562
translate italian act1_b0987038:

    # "My cheeks flush, at first in shame, but it quickly morphs into something different. Something stronger."
    "Le mie guance si arrossano, inizialmente per la vergogna, ma ben presto la sensazione si trasforma in qualcosa di diverso. Qualcosa di più intenso."

# game/act1.rpy:1564
translate italian act1_ad68a591:

    # a angry "So, what? I’m just some idiot who doesn’t know what they’re doing?"
    a angry "E allora? Sono solo un idiota che non sa cosa sta facendo?"

# game/act1.rpy:1566
translate italian act1_dd80b533:

    # e uh "That’s not what I meant. You just..."
    e uh "Non è questo che intendevo. Tu semplicemente..."

# game/act1.rpy:1569
translate italian act1_ba87f978:

    # a "That's exactly what you meant."
    a "È esattamente quello che intendevi."

# game/act1.rpy:1570
translate italian act1_0c57f51c:

    # e uh "Well, can you blame me? You never take my advice."
    e uh "Beh, puoi biasimarmi? Non ascolti mai i miei consigli."

# game/act1.rpy:1571
translate italian act1_8e0225a5:

    # a "Your 'advice' is to just shut up and do as I'm told."
    a "Il tuo \"consiglio\" è semplicemente quello di stare zitto e fare quello che mi viene detto."

# game/act1.rpy:1572
translate italian act1_8504393e:

    # e hm "If that'll keep you safe, then just do it. Better to bite your tongue than the dust."
    e hm "Se questo ti terrà al sicuro, allora fallo e basta. Meglio mordersi la lingua che la polvere."

# game/act1.rpy:1574
translate italian act1_2f8b1e00:

    # a dejected "Yeah, because I'm too stupid to know better, so you have to tell me what to do so I can stay safe? I think I get it now."
    a dejected "Certo, perché sono troppo stupido per capirlo, quindi devi dirmi tu cosa devo fare per stare al sicuro? Credo di aver capito ora."

# game/act1.rpy:1576
translate italian act1_ef7c6d9b:

    # "I scoff, getting up to head towards the bathroom when Ethan grabs my arm, starting to protest."
    "Sbuffo, alzandomi per dirigermi verso il bagno, quando Ethan mi afferra il braccio, iniziando a protestare."

# game/act1.rpy:1578
translate italian act1_783995ab:

    # e "Hey, calm down. I didn’t mean it like that. You {i}know{/i} I didn’t mean it like that."
    e "Ehi, calmati. Non intendevo dire questo. Lo sai che non intendevo dire questo."

# game/act1.rpy:1579
translate italian act1_45e2de1b:

    # e sigh "Just sit back down, and we’ll{nw}"
    e sigh "Siediti di nuovo e noi{nw}"

# game/act1.rpy:1583
translate italian act1_2b27af46:

    # a nngh "Stop {i}fucking{/i} telling me what to do, Ethan!"
    a nngh "Smettila di dirmi cosa devo, Ethan!"

# game/act1.rpy:1585
translate italian act1_188851da:

    # "I yank my arm away, something snapping in my mind that makes me start seeing red."
    "Ritraggo bruscamente il braccio, qualcosa scatta nella mia mente e inizio a vedere rosso."

# game/act1.rpy:1587
translate italian act1_06907826:

    # a concern "What is wrong with you? Who do you take me for? Why do you feel the need to watch over me like I’m some idiot who can’t take care of himself?"
    a concern "Che ti prende? Chi credi che io sia? Perché senti il ​​bisogno di sorvegliarmi come se fossi un idiota incapace di badare a se stesso?"

# game/act1.rpy:1588
translate italian act1_8fac8f53:

    # a angry "I’m not your child, or {i}whatever{/i} you think I am that gives you the authority to keep telling me what I can or can’t do! I’m so fucking sick of it!"
    a angry "Non sono tuo figlio, o qualsiasi altra cosa tu creda che io sia, che ti dà l'autorità di continuare a dirmi cosa posso o non posso fare! Ne ho fottutamente abbastanza!"

# game/act1.rpy:1590
translate italian act1_b4679918:

    # "All the pent-up frustrations from today stumble out of me all at once, and I couldn’t care less in this moment if I’m making a scene, if I hurt Ethan’s feelings. {w}I just want to go home."
    "Tutte le frustrazioni accumulate oggi esplodono in un colpo solo, e in questo momento non mi importa minimamente se sto facendo una scenata, se ferisco i sentimenti di Ethan. {w}Voglio solo tornare a casa."

# game/act1.rpy:1592
translate italian act1_ec0fcc5f:

    # a sad "You really think I don’t have enough of that already?"
    a sad "Credi davvero che io non ne abbia già abbastanza?"

# game/act1.rpy:1593
translate italian act1_655f7994:

    # a "You’re the one person I thought I could get away from all of this, and just be myself around… I guess I can’t even do that."
    a "Sei l'unica persona con cui pensavo di potermi allontanare da tutto questo ed essere semplicemente me stessa... Immagino di non poter fare nemmeno questo."

# game/act1.rpy:1595
translate italian act1_4f94e27b:

    # "I slam a crumpled-up bill on the counter of the bar, giving Ethan one last look of disdain before turning around and exiting the bar."
    "Sbatto una banconota stropicciata sul bancone del bar, lanciando a Ethan un ultimo sguardo di disprezzo prima di voltarmi e uscire dal locale."

# game/act1.rpy:1600
translate italian act1_7e8c5916:

    # "Home."
    "Casa."

# game/act1.rpy:1601
translate italian act1_b597a209:

    # "Or, at least, the only place in the city that comes to close to it."
    "O, perlomeno, l'unico posto in città che gli si avvicina."

# game/act1.rpy:1603
translate italian act1_12487595:

    # "It feels like forever since I’ve last step foot in my own apartment, even though it’s only been about a day or two. Life in Sonora can feel endless in that way."
    "Mi sembra un'eternità dall'ultima volta che ho messo piede nel mio appartamento, anche se in realtà sono passati solo un paio di giorni. La vita a Sonora può sembrare infinita, in questo senso."

# game/act1.rpy:1604
translate italian act1_ba463265:

    # "It wouldn’t matter much, anyway. This space isn’t particularly pretty or cozy – that’s why I spend so much time over at Ethan’s – but it’s the one place in the city where I can be completely, fully alone… which can be both a good and bad thing."
    "Non importerebbe granché, comunque. Questo posto non è particolarmente bello o accogliente – ecco perché passo così tanto tempo da Ethan – ma è l'unico posto in città dove posso stare completamente, totalmente da sola… il che può essere sia un bene che un male."

# game/act1.rpy:1605
translate italian act1_d06b3471:

    # "I feel my entire body slump from exhaustion as I close the door behind me, and I start to slowly undress from head to toe, trudging towards the bathroom as I peel off each article of clothing from my fur."
    "Sento tutto il corpo cedere per la stanchezza mentre chiudo la porta alle mie spalle e inizio a spogliarmi lentamente dalla testa ai piedi, trascinandomi verso il bagno mentre mi tolgo ogni indumento dalla pelliccia."

# game/act1.rpy:1606
translate italian act1_7d2a83a2:

    # "The feeling of wanting to burst into tears overtakes my sense, but, just as always, I push it down. Crying wins me nothing. It’s just a waste of time."
    "La voglia di scoppiare in lacrime mi assale, ma, come sempre, la reprimo. Piangere non mi porta a nulla. È solo una perdita di tempo."

# game/act1.rpy:1609
translate italian act1_8943ecb2:

    # "I turn on the faucet to my bathtub, setting my bare ass on the edge of its porcelain body as I watch the warm water fill up.{w} I think of nothing.{w} I feel nothing. "
    "Apro il rubinetto della vasca da bagno, appoggiando il mio sedere nudo sul bordo della sua superficie di porcellana mentre guardo l'acqua calda che si riempie.{w} Non penso a niente.{w} Non sento niente."

# game/act1.rpy:1610
translate italian act1_a1c95695:

    # "I can’t. I don’t allow myself to. The moment I let my reasoning slip, I know I’ll fall into a sadness so deep, not even I could pull myself out of. If I allow myself to daydream of better times, of a softer, simple life… it would drive me to the brink of madness."
    "Non posso. Non me lo permetto. So che nel momento in cui lascio andare la razionalità, sprofonderò in una tristezza così profonda che nemmeno io riuscirei a uscirne. Se mi lasciassi andare a sogni ad occhi aperti di tempi migliori, di una vita più serena e semplice... finirei sull'orlo della follia."

# game/act1.rpy:1611
translate italian act1_7fadadf2:

    # "Because it’s impossible. Because I know I’ll sob my eyes out, stomp and throw a tantrum like a child, scream out ferociously how it’s not fair, it’s not fair, not fair…!"
    "Perché è impossibile. Perché so che scoppierò a piangere, batterò i piedi e farò i capricci come una bambina, urlerò ferocemente che non è giusto, non è giusto, non è giusto...!"

# game/act1.rpy:1612
translate italian act1_12410810:

    # "And when I’ve finally settled down… nothing will have changed. I am still a Valentine. I am still in Sonora. I am still all on my own, with no one to come home to, no chance of living a normal life."
    "E quando finalmente mi sarò sistemata… non sarà cambiato nulla. Sarò ancora una Valentine. Sarò ancora a Sonora. Sarò ancora completamente sola, senza nessuno ad aspettarmi a casa, senza alcuna possibilità di vivere una vita normale."

# game/act1.rpy:1613
translate italian act1_2daddbf6:

    # "So…{w} I don’t cry. I don’t feel. I simply exist in the life that was laid out for me."
    "Quindi...{w} Non piango. Non provo emozioni. Semplicemente esisto nella vita che mi è stata assegnata."

# game/act1.rpy:1616
translate italian act1_46a88f9b:

    # "The water is warm, hot even. It stings as I slip inside, making my muscles tense up when I submerge myself completely. Eventually, though, my body adjusts to the temperature, and my sense of touch goes numb from the heat."
    "L'acqua è calda, persino bollente. Brucia appena ci entro, e i miei muscoli si irrigidiscono quando mi immergo completamente. Alla fine, però, il mio corpo si abitua alla temperatura e il calore mi intorpidisce il tatto."

# game/act1.rpy:1617
translate italian act1_06d768da:

    # "But I can’t relax. The rage I feel for the way Ethan spoke to me starts to spread to the way Mr. Gray looked at me, like I was a toy he really wanted to play with. Then it goes to Mr. Valentine, how he, too, toys with my head any chance he gets."
    "Ma non riesco a rilassarmi. La rabbia che provo per il modo in cui Ethan mi ha parlato inizia a diffondersi al modo in cui il signor Gray mi guarda, come se fossi un giocattolo con cui vuole davvero giocare. Poi si estende al signor Valentine, a come anche lui si diverte a prendermi in giro ogni volta che ne ha l'occasione."

# game/act1.rpy:1618
translate italian act1_8ee213d5:

    # "The cycle continues and repeats, until I’m not sure whether the heat I feel is from the bath water or the rage flushing against my cheeks."
    "Il ciclo continua e si ripete, finché non sono più sicuro se il calore che sento provenga dall'acqua del bagno o dalla rabbia che mi arrossisce le guance."

# game/act1.rpy:1622
translate italian act1_98d022c7:

    # "I grab my phone sitting on the sink, which I got into a habit of carrying everywhere nowadays. I never know when Mr. Valentine will call me for some other stupid, menial task."
    "Afferro il telefono che è appoggiato sul lavandino, cosa che ormai ho preso l'abitudine di portare sempre con me. Non so mai quando il signor Valentine mi chiamerà per qualche altra stupida e insignificante commissione."

# game/act1.rpy:1623
translate italian act1_956f67eb:

    # "I wonder to myself, is there someone who could talk me out of feeling this way? My mind immediately goes to Ethan. It was always him, in times like these. He would come over, or I would go to his apartment, and he’d show me some old movie I would never really be interested in."
    "Mi chiedo se ci sia qualcuno che possa convincermi a non sentirmi così. Il mio pensiero va subito a Ethan. Era sempre lui, in momenti come questi. Veniva a trovarmi, o andavo io al suo appartamento, e mi faceva vedere qualche vecchio film che non mi avrebbe mai interessato."

# game/act1.rpy:1624
translate italian act1_80ea8416:

    # "And yet, somehow, it made me feel better. To have someone in my life who wanted to share their time with me, not under any transaction, but just because they liked me. It made me feel… normal."
    "Eppure, in qualche modo, mi faceva sentire meglio. Avere qualcuno nella mia vita che voleva condividere il suo tempo con me, non per un tornaconto personale, ma semplicemente perché gli piacevo. Mi faceva sentire... normale."

# game/act1.rpy:1625
translate italian act1_d17ef062:

    # "But I don’t want to think about Ethan right now."
    "Ma adesso non voglio pensare a Ethan."

# game/act1.rpy:1627
translate italian act1_8ac8ffeb:

    # "Then, that leaves only one other person…"
    "Quindi, resta solo un'altra persona…"

# game/act1.rpy:1630
translate italian act1_018e60c7:

    # "With a shaky hand, I reach for my phone and dial the number I know by heart, pressing it up to my ear. I always get nervous when I call her, as if I’m intruding in her life, but I remind myself to not be ridiculous"
    "Con mano tremante, afferro il telefono e compongo il numero che conosco a memoria, portandolo all'orecchio. Mi innervosisco sempre quando la chiamo, come se stessi intromettendomi nella sua vita, ma mi ricordo di non essere ridicola."

# game/act1.rpy:1631
translate italian act1_cf8e66d3:

    # "She’s my mother. Moms want to hear from their kids, don’t they?"
    "Lei è mia madre. Le mamme vogliono sentire cosa dicono i loro figli, no?"

# game/act1.rpy:1633
translate italian act1_90fbe6ed:

    # "The phone rings. Once, then twice, three times…"
    "Il telefono squilla. Una volta, poi due volte, tre volte…"

# game/act1.rpy:1635
translate italian act1_fabc1d30:

    # mom "{i}Hello?"
    mom "{i}Pronto?"

# game/act1.rpy:1636
translate italian act1_7b14affb:

    # a -uniform surprised "Mom?"
    a -uniform surprised "Mamma?"

# game/act1.rpy:1638
translate italian act1_7964cf38:

    # "My voice comes out pleading, and tears fill my eyes as I hear her voice on the other end of the line. It’s amazing how quickly it soothes me."
    "La mia voce esce supplichevole e le lacrime mi riempiono gli occhi mentre sento la sua voce dall'altra parte del telefono. È incredibile quanto velocemente mi conforti."

# game/act1.rpy:1640
translate italian act1_a52c5483:

    # mom "{i}Angel?"
    mom "{i}Angelo?"

# game/act1.rpy:1641
translate italian act1_4a8112e3:

    # a bashful "Mom, hi… yeah, it’s Angel. How are you?"
    a bashful "Mamma, ciao… sì, sono Angel. Come stai?"

# game/act1.rpy:1642
translate italian act1_fda62b22:

    # a flattered "I-I’m sorry if I’m interrupting something, or if you're busy, I just… I wanted to talk to you."
    a flattered "Mi dispiace se interrompo qualcosa o se sei occupato, volevo solo... parlare con te."

# game/act1.rpy:1644
translate italian act1_332f1102:

    # mom "{i}Oh. Well, alright then… how are things going for you, Angel?"
    mom "Oh. Bene, d'accordo allora... come vanno le cose, Angel?"

# game/act1.rpy:1645
translate italian act1_ce32ebbf:

    # a worried "…things are…"
    a worried "…le cose sono…"

# game/act1.rpy:1647
translate italian act1_7d5f8d55_2:

    # a sad "…"
    a sad "…"

# game/act1.rpy:1648
translate italian act1_a2d994ac:

    # a bashful "Things are fine. I’m just a little tired lately."
    a bashful "Va tutto bene. Sono solo un po' stanco ultimamente."

# game/act1.rpy:1649
translate italian act1_d16aee84:

    # mom "I understand. I’m sorry, honey… Don’t get bummed out about it, okay? You’re doing a good job, and I’m very grateful for everything you do for me."
    mom "Capisco. Mi dispiace, tesoro… Non scoraggiarti, okay? Stai facendo un ottimo lavoro e ti sono molto grata per tutto quello che fai per me."

# game/act1.rpy:1650
translate italian act1_1ab72481_12:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1652
translate italian act1_b9827c55:

    # "How many times have I heard her say those words to me? They always used to fill me with hope, always made my heart feel warm and proud. So… why do these words feel hollow to me now?"
    "Quante volte l'ho sentita dirmi quelle parole? Mi riempivano sempre di speranza, mi scaldavano il cuore e mi facevano sentire orgogliosa. Allora... perché ora queste parole mi sembrano vuote?"

# game/act1.rpy:1654
translate italian act1_7a3299cb:

    # a flattered "I know, Mom. I was just thinking that maybe… I could come visit soon? I got a new story, and if everything goes well, I think I’ll get a bonus, which would be enough to…"
    a flattered "Lo so, mamma. Stavo solo pensando che forse… potrei venire a trovarti presto? Ho una nuova storia, e se tutto va bene, penso che riceverò un bonus, che sarebbe sufficiente per…"

# game/act1.rpy:1656
translate italian act1_da6716a9:

    # mom "Oh honey… I don’t know. Are you sure you can afford it? Everything is so expensive in Sonora."
    mom "Oh tesoro… non lo so. Sei sicura di potertelo permettere? A Sonora è tutto così caro."

# game/act1.rpy:1658
translate italian act1_381d122a:

    # "She speaks in that soft, slow manner she always does with me, ever since I was little. Today, for some reason, it only annoys me."
    "Parla con quel tono dolce e lento che ha sempre usato con me, fin da quando ero piccola. Oggi, per qualche ragione, mi dà solo fastidio."

# game/act1.rpy:1660
translate italian act1_5454bb4e:

    # a bashful "It’s fine, Mom. I have a bit saved up already. This would just be the last push I need to make it come true. Besides, I think I need a little break, hehe…"
    a bashful "Va bene, mamma. Ho già messo da parte un po' di soldi. Questa sarebbe solo la spinta finale che mi serve per realizzare il mio sogno. Inoltre, credo di aver bisogno di una piccola pausa, hehe…"

# game/act1.rpy:1662
translate italian act1_24a5165b:

    # mom "Oh, I know honey. You work very hard. But…"
    mom "Oh, lo so tesoro. Lavori molto duramente. Ma…"

# game/act1.rpy:1663
translate italian act1_dc0b48da:

    # mom "Things are just… not very good here on my end, Angel. I got a new job, so I won’t be able to take days off whenever it is that you come to visit. It’s just not good timing, hun."
    mom "Le cose non vanno molto bene da parte mia, Angel. Ho trovato un nuovo lavoro, quindi non potrò prendermi dei giorni di ferie quando verrai a trovarmi. Non è proprio il momento giusto, tesoro."

# game/act1.rpy:1665
translate italian act1_d8eb5386_3:

    # a scared "…"
    a scared "…"

# game/act1.rpy:1666
translate italian act1_edd6952c:

    # a "Oh… Okay…"
    a "Oh… Okay…"

# game/act1.rpy:1667
translate italian act1_77d0f8f4:

    # a bashful "No, yeah, that’s fine, um…{w} that’s okay!{w} You just never mentioned a new job, so… I mean, of course you didn’t, haha!"
    a bashful "No, sì, va bene, ehm... {w} va bene! {w} Non hai mai accennato a un nuovo lavoro, quindi... Voglio dire, certo che no, ahah!"

# game/act1.rpy:1668
translate italian act1_14190633:

    # a "When was the last time we called? Last month? Or, the one before that? It’s been a while."
    a "Quand'è stata l'ultima volta che ci siamo sentiti? Il mese scorso? O quello prima? È passato un po' di tempo."

# game/act1.rpy:1669
translate italian act1_33849264:

    # mom "Yeah… yeah, it has. I’m sorry, sweetie…"
    mom "Sì… sì, è successo. Mi dispiace, tesoro…"

# game/act1.rpy:1670
translate italian act1_e29620df:

    # a flattered "It’s okay! I know you’re busy… um…"
    a flattered "Va bene! So che sei impegnato… ehm…"

# game/act1.rpy:1672
translate italian act1_0d9e6113:

    # "I’m trying to keep my composure, trying to not cry as I feel my one beacon of hope slowly die out in front of. I tilt my head up, looking at my monochrome popcorn ceiling, my breathing ragged and heavy as I try to blink away the tears."
    "Cerco di mantenere la calma, di non piangere mentre sento la mia unica speranza spegnersi lentamente davanti ai miei occhi. Alzo la testa, guardando il soffitto monocromatico a effetto popcorn, il respiro affannoso e pesante mentre cerco di trattenere le lacrime."

# game/act1.rpy:1674
translate italian act1_bfe32573:

    # a bashful "I’ll just… save that money. For next year, when you’re more acclimated to your job."
    a bashful "Metterò da parte quei soldi. Per l'anno prossimo, quando ti sarai ambientato meglio al lavoro."

# game/act1.rpy:1675
translate italian act1_59d4ca8c:

    # mom "Okay sweetie. Whatever it is you decide."
    mom "Va bene tesoro. Decidi tu."

# game/act1.rpy:1677
translate italian act1_7c16802d:

    # "I wait for her to tell me more, to try and reassure me we’ll be reunited again soon. Static is all that comes from the other end of the line."
    "Aspetto che mi racconti di più, che cerchi di rassicurarmi sul fatto che presto ci rivedremo. Dall'altro capo del telefono sento solo fruscii."

# game/act1.rpy:1679
translate italian act1_306f02a4:

    # a sad "I… I love you…"
    a sad "Io… ti amo…"

# game/act1.rpy:1681
translate italian act1_7a1574c5:

    # mom "I love you too, Angel."
    mom "Anch'io ti amo, angelo."

# game/act1.rpy:1683
translate italian act1_72e94c19_2:

    # a "…"
    a "…"

# game/act1.rpy:1684
translate italian act1_da86492f:

    # a "Bye…"
    a "Ciao…"

# game/act1.rpy:1685
translate italian act1_42ec471b:

    # mom "Goodbye, honey."
    mom "Addio, tesoro."

# game/act1.rpy:1689
translate italian act1_f30b931d:

    # "She hangs up the call, and I dig my claws into my arm, willing myself not to do it. Don’t cry. Even if my own mother – the person who I’ve been fighting for my whole life – doesn’t want to take time to see me…{w} just don’t cry."
    "Lei riattacca e io mi stringo gli artigli nel braccio, imponendomi di non farlo. Non piangere. Anche se mia madre – la persona per cui ho lottato per tutta la vita – non vuole trovare il tempo di vedermi… non piangere e basta."

# game/act1.rpy:1692
translate italian act1_3a16345d:

    # "But it’s no use. I’m not made of stone, as much as I wish I was, and after seeking solace in the only family I have to turn to and being met with nothing but indifference…{w} I break down."
    "Ma è inutile. Non sono fatta di pietra, per quanto lo desideri, e dopo aver cercato conforto nell'unica famiglia a cui posso rivolgermi e aver trovato solo indifferenza...{w} crollo."

# game/act1.rpy:1693
translate italian act1_12b2340b:

    # "I sob. I cry and scream in my tiny, colorless bathroom, my wails echoing against the walls."
    "Scoppio in lacrime. Piango e urlo nel mio minuscolo bagno incolore, i miei lamenti che riecheggiano contro le pareti."

# game/act1.rpy:1695
translate italian act1_da1cf445:

    # a1 "It’s not fair…"
    a1 "Non è giusto…"

# game/act1.rpy:1697
translate italian act1_2a55eda3:

    # "The words I didn’t dare even utter now come out in pained cries as my teardrops plop loudly into the water. I was right, though; it fixes nothing. I am still a Valentine, no matter how hard I scream… but it feels good, somehow. To let everything I had inside come out."
    "Le parole che non osavo nemmeno pronunciare ora escono in grida di dolore mentre le mie lacrime cadono rumorosamente nell'acqua. Avevo ragione, però; non risolve nulla. Sono ancora una Valentine, non importa quanto forte urli... ma in qualche modo mi fa stare bene. Lasciar uscire tutto ciò che avevo dentro."

# game/act1.rpy:1699
translate italian act1_0f42e80c:

    # "By the time I finish crying, my fur is soaked and matted, my bones aching from sitting in the tub for too long. I get up, my throat sore and my eyes red and burning. I meticulously dry myself in front of my mirror, staring hard into my reflection."
    "Quando finisco di piangere, il mio pelo è fradicio e arruffato, e le ossa mi fanno male per essere rimasta troppo a lungo nella vasca. Mi alzo, con la gola irritata e gli occhi rossi e brucianti. Mi asciugo meticolosamente davanti allo specchio, fissando intensamente il mio riflesso."

# game/act1.rpy:1700
translate italian act1_c558194c:

    # "It’s just the me that I’ve always seen, if not a little dazed and distressed. I look angry, sad, and deranged… which I guess I am. But I hate to see myself this way. So weak, so pathetic."
    "Sono semplicemente la me che ho sempre visto, anche se un po' stordita e angosciata. Sembro arrabbiata, triste e squilibrata... il che, suppongo, mi si addica. Ma odio vedermi così. Così debole, così patetica."

# game/act1.rpy:1701
translate italian act1_4f56cfce:

    # "I won’t even be able to be used as a pawn like this. No one wants to play with such a fragile toy."
    "Non potrò nemmeno essere usato come pedina in questo modo. Nessuno vuole giocare con un giocattolo così fragile."

# game/act1.rpy:1703
translate italian act1_c3c63ad1:

    # a1 "…"
    a1 "…"

# game/act1.rpy:1705
translate italian act1_69ba9a2a:

    # "But no. I’m nowhere near broken. I’m exactly as I was yesterday, and the day before. Nothing in my life has changed."
    "Ma no. Non sono affatto a pezzi. Sono esattamente come ero ieri e l'altro ieri. Nulla nella mia vita è cambiato."

# game/act1.rpy:1706
translate italian act1_7f1c32e1:

    # "Nothing… except for the dark realization that, in the end, I am truly and completely on my own in in this city."
    "Niente... tranne la cupa consapevolezza che, alla fine, sono davvero e completamente solo in questa città."

# game/act1.rpy:1708
translate italian act1_1274d778:

    # "I was never just fighting for my mother… there’s one thing that mattered far more to me than her, as selfish as it is to admit. And that’s my freedom."
    "Non ho mai combattuto solo per mia madre… c’è una cosa che contava molto più di lei per me, per quanto egoistico possa sembrare ammetterlo. Ed è la mia libertà."

# game/act1.rpy:1710
translate italian act1_7fb96abc:

    # "I drop my towel on the floor and walk out of my bathroom, naked, cold, and alone… but now filled with something stronger than just pure determination."
    "Lascio cadere l'asciugamano sul pavimento ed esco dal bagno, nuda, infreddolita e sola... ma ora pervasa da qualcosa di più forte della semplice determinazione."

# game/act1.rpy:1712
translate italian act1_ac4c7fc8:

    # "After all, I still have a job to do."
    "Dopotutto, ho ancora un lavoro da fare."

# game/act1.rpy:1716
translate italian act1_5f3c12b3:

    # "The Albatross is a stuffy, dingy place. The smell of smoke lingers in the air, and the regulars talk loudly amongst themselves, drowning out the sound of the jukebox with their laughter. It’s cheap and dirty, but somehow finds a way to be cozy."
    "L'Albatross è un locale soffocante e squallido. Nell'aria aleggia odore di fumo e gli avventori abituali chiacchierano ad alta voce tra di loro, sovrastando il suono del jukebox con le loro risate. È un posto economico e sporco, ma in qualche modo riesce a essere accogliente."

# game/act1.rpy:1717
translate italian act1_e1c6b5ab:

    # "Basically, it’s for people like me."
    "In pratica, è pensato per persone come me."

# game/act1.rpy:1719
translate italian act1_f7e4691b:

    # a uniform hm "{i}So how is there an underground ring here?"
    a uniform hm "Com'è possibile che qui ci sia un anello sotterraneo?"

# game/act1.rpy:1721
translate italian act1_a7e4008d:

    # "It doesn’t make sense. I don’t see anyone suspicious, or people walking into the same room. In fact, I don’t see very many rooms in this place at all, minus the kitchen in the back, where they make the soggiest nachos known to mankind."
    "Non ha senso. Non vedo nessuno di sospetto, né persone che entrano nella stessa stanza. Anzi, a dire il vero non vedo molte stanze in questo posto, a parte la cucina sul retro, dove preparano i nachos più mollicci che si conoscano."

# game/act1.rpy:1722
translate italian act1_c242e7cd:

    # "I think they dip them in water or something. Anyway…"
    "Credo che li immergano nell'acqua o qualcosa del genere. Comunque…"

# game/act1.rpy:1723
translate italian act1_038a945b:

    # "I slip a peanut into my mouth, scanning the room, listening in on anything out of the ordinary… but I’m coming up short. Are they being extra careful because I’m here?"
    "Mi metto un'arachide in bocca, scrutando la stanza, cercando di cogliere qualsiasi rumore insolito... ma non trovo nulla. Stanno forse prestando più attenzione perché ci sono io?"

# game/act1.rpy:1724
translate italian act1_f32f8db6:

    # "I ended up coming in my uniform, but I’m technically off the clock right now. I guess that wouldn’t matter to anyone, though. Valentines aren’t to be trusted…"
    "Alla fine sono venuto in uniforme, ma tecnicamente ora non sono più in servizio. Immagino che a nessuno importi, comunque. Non ci si può fidare di San Valentino…"

# game/act1.rpy:1725
translate italian act1_9b688d6c:

    # "I sigh. I may have let the idea of getting more information get to my head. Maybe Ethan was right. Maybe I bit off more than I can-"
    "Sospiro. Forse mi sono lasciata prendere la mano dall'idea di ottenere più informazioni. Forse Ethan aveva ragione. Forse ho fatto il passo più lungo della gamba..."

# game/act1.rpy:1727
translate italian act1_992cfc69:

    # anon "{i}Chelito~"
    anon "{i}Chelito~"

# game/act1.rpy:1729
translate italian act1_35f11f7d:

    # "I feel a hot whisper against my ear and a large hand grab my waist, so sudden that it catches me off guard, shuddering a full body chill."
    "Sento un sussurro caldo contro il mio orecchio e una mano grande afferrarmi la vita, così all'improvviso da cogliermi di sorpresa, facendomi rabbrividire per tutto il corpo."

# game/act1.rpy:1731
translate italian act1_120103f9:

    # a flustered "S-Sebas…"
    a flustered "S-Sebas…"

# game/act1.rpy:1732
translate italian act1_1a38621c:

    # s "{i}Dichoso los ojos.{/i} I didn’t expect to actually see you here tonight."
    s "{i}Dicoso los ojos.{/i} Non mi aspettavo di vederti qui stasera."

# game/act1.rpy:1734
translate italian act1_62c3f639:

    # "He sits down on the stool next to me, and I take the opportunity to compose myself. How did I not notice him walk in? He didn’t even make a sound."
    "Si siede sullo sgabello accanto a me e io ne approfitto per ricompormi. Come ho fatto a non accorgermi che era entrato? Non ha emesso un suono."

# game/act1.rpy:1736
translate italian act1_c7bf3780:

    # a cocky "Well, I’m full of surprises. Seems like you are, too."
    a cocky "Beh, sono pieno di sorprese. A quanto pare anche tu."

# game/act1.rpy:1738
translate italian act1_095606c5:

    # s amused "You could say that."
    s amused "Si potrebbe dire così."

# game/act1.rpy:1739
translate italian act1_5d9e8d12:

    # s cocky "You want a drink? You look like you could use one."
    s cocky "Vuoi un drink? Hai proprio l'aria di averne bisogno."

# game/act1.rpy:1740
translate italian act1_eca1388d:

    # a hm "Why do you say that?"
    a hm "Perché dici questo?"

# game/act1.rpy:1741
translate italian act1_16509f2b:

    # s amused "You just seem... tense. Some alcohol will help with that, I'm sure."
    s amused "Sembri... teso. Un po' di alcol ti aiuterà di sicuro."

# game/act1.rpy:1742
translate italian act1_f0c9ee04:

    # a bashful "Hah. You might be right, but I think I'll pass on the drink."
    a bashful "Ah. Potresti avere ragione, ma credo che rinuncerò al drink."

# game/act1.rpy:1743
translate italian act1_d6cfc10e:

    # s cocky "Oh? Well, if there's something else that could help you ease up, let me know. I'm full of ideas."
    s cocky "Oh? Beh, se c'è qualcos'altro che potrebbe aiutarti a rilassarti, fammelo sapere. Ho un sacco di idee."

# game/act1.rpy:1745
translate italian act1_c251e7fe:

    # "I roll my eyes, but a smile is still on my face. This guy’s clearly full of shit."
    "Alzo gli occhi al cielo, ma un sorriso mi rimane stampato in faccia. Questo tipo è chiaramente pieno di frottole."

# game/act1.rpy:1747
translate italian act1_68aeab4c:

    # a cocky "{i}But even if you’re hot, I won’t let my guard down for someone like you."
    a cocky "Ma anche se sei attraente, non abbasserò la guardia per una come te."

# game/act1.rpy:1749
translate italian act1_f12264ef:

    # a flattered "I’m okay."
    a flattered "Sto bene."

# game/act1.rpy:1750
translate italian act1_1d6dd05a:

    # s "Are you, now? What a shame."
    s "Lo sei davvero adesso? Che peccato."

# game/act1.rpy:1752
translate italian act1_e9f64793:

    # "He orders a drink, and I sneak glances at him while he’s distracted with the bartender."
    "Ordina da bere e io gli lancio delle occhiate furtive mentre è distratto dal barista."

# game/act1.rpy:1753
translate italian act1_f0191cdf:

    # "Yeah, this guy’s eye-candy for sure. His arms are huge, his hair soft and flowy when he moves… but those eyes are what really capture me."
    "Sì, questo ragazzo è davvero uno spettacolo per gli occhi. Ha braccia enormi, capelli morbidi e fluenti quando si muove... ma sono soprattutto i suoi occhi a conquistarmi."

# game/act1.rpy:1754
translate italian act1_6a26abc2:

    # "Tired, and with dark circles under them, but with an intrigue and allure that I can’t help but want to stare into. What secrets lie behind them, I wonder…?"
    "Stanchi e con delle occhiaie profonde, ma con un fascino e un'aura di mistero che mi spingono a perdermi in quello sguardo. Chissà quali segreti si celano dietro quegli occhi...?"

# game/act1.rpy:1756
translate italian act1_fb10136e:

    # "He suddenly turns to me, and I quickly glance away, pretending to be very immersed in the pattern of the wooden countertop."
    "All'improvviso si gira verso di me e io distolgo rapidamente lo sguardo, fingendo di essere completamente assorta nell'osservazione del disegno del piano di lavoro in legno."

# game/act1.rpy:1758
translate italian act1_0739775b:

    # s amused "So, {i}Ángel{/i}… tell me. Are you here because of me?"
    s amused "Allora, {i}Ángel{/i}… dimmi. Sei qui per colpa mia?"

# game/act1.rpy:1759
translate italian act1_b434f98f:

    # a surprised "What…?"
    a surprised "Che cosa…?"

# game/act1.rpy:1760
translate italian act1_62560213:

    # s "Because I told you about {i}that?"
    s "Perché te l'ho detto {i}quello?"

# game/act1.rpy:1762
translate italian act1_7fa9e587:

    # "He’s speaking in code now?"
    "Sta parlando in codice adesso?"

# game/act1.rpy:1764
translate italian act1_2c941e91:

    # a bashful "…maybe."
    a bashful "…Forse."

# game/act1.rpy:1766
translate italian act1_48c51842:

    # "Sebas smiles."
    "Sebas sorride."

# game/act1.rpy:1768
translate italian act1_c08d9d08:

    # s "Well, good thing I’m here then. You would’ve been lost without me."
    s "Beh, meno male che ci sono io allora. Senza di me ti saresti perso."

# game/act1.rpy:1769
translate italian act1_1fb89e7e:

    # a hm "Oh? I think I was doing just fine."
    a hm "Oh? Credo che me la stessi cavando benissimo."

# game/act1.rpy:1770
translate italian act1_0f127e90:

    # s cocky "Yeah? How were you gonna get in?"
    s cocky "Sì? Come pensavi di entrare?"

# game/act1.rpy:1771
translate italian act1_2a4ff97c_10:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:1772
translate italian act1_e0e66212:

    # a flustered "That’s… a work in progress."
    a flustered "È... un lavoro in corso."

# game/act1.rpy:1773
translate italian act1_aaea323d:

    # s flirty "Do you even know where you’re supposed to enter from?"
    s flirty "Sai almeno da dove dovresti entrare?"

# game/act1.rpy:1774
translate italian act1_72e94c19_3:

    # a "…"
    a "…"

# game/act1.rpy:1775
translate italian act1_ddfe0f38:

    # a "The… back… door…"
    a "La… porta… posteriore…"

# game/act1.rpy:1776
translate italian act1_c6b91f77:

    # s amused "{i}Ajá.{/i} It’s fine to admit it, you know. You can ask for help."
    s amused "{i}Ajá.{/i} Va bene ammetterlo, sai. Puoi chiedere aiuto."

# game/act1.rpy:1778
translate italian act1_807244a7:

    # a frown "I don’t {i}need{/i} help."
    a frown "Non ho bisogno di aiuto."

# game/act1.rpy:1781
translate italian act1_c5491485:

    # "He shrugs, grabbing a peanut and popping it in his maw like a pill."
    "Lui alza le spalle, afferra un'arachide e se la mette in bocca come una pillola."

# game/act1.rpy:1783
translate italian act1_e19daa53:

    # s smile "Whatever you say, {i}chelito."
    s smile "Qualunque cosa tu dica, {i}chelito."

# game/act1.rpy:1786
translate italian act1_fff9cb32:

    # a hm "If, say, I {i}did{/i} need help… what would you tell me?"
    a hm "Se, per esempio, io {i}avessi{/i} bisogno di aiuto… cosa mi diresti?"

# game/act1.rpy:1788
translate italian act1_068315e5:

    # s flirty "Well… first, I’d bring you a bit closer…"
    s flirty "Beh… prima di tutto, vorrei avvicinarmi un po’…"

# game/act1.rpy:1792
translate italian act1_e71f38df:

    # "He grabs the edge of my stool and effortlessly pulls it right next to his, bringing us shoulder to shoulder."
    "Afferra il bordo del mio sgabello e, senza alcuno sforzo, lo avvicina al suo, facendoci arrivare spalla a spalla."

# game/act1.rpy:1794
translate italian act1_e474a194:

    # s "…to prevent any listening ears."
    s "…per impedire che qualcuno origliasse."

# game/act1.rpy:1796
translate italian act1_241be771:

    # "I can smell the peanut on his breath, his muzzle closing in on my ear again. I blush, completely unaccustomed to this level of closeness with another guy that isn’t Ethan."
    "Sento l'odore di arachidi sul suo alito, il suo muso si avvicina di nuovo al mio orecchio. Arrossisco, completamente impreparata a questo livello di intimità con un altro ragazzo che non sia Ethan."

# game/act1.rpy:1797
translate italian act1_b2d774e5:

    # "Not even he puts his face this close to mine…"
    "Nemmeno lui avvicina il viso così tanto al mio…"

# game/act1.rpy:1799
translate italian act1_95f513c3:

    # s amused "And I’d tell you to order a Death in the Gulf Stream… and tap your fingers-"
    s amused "E io ti direi di ordinare un Death in the Gulf Stream... e di tamburellare con le dita."

# game/act1.rpy:1801
translate italian act1_f6e01fbc:

    # "He taps his claw on the countertop thrice as he enunciates his next words."
    "Mentre pronuncia le parole successive, batte tre volte l'artiglio sul piano di lavoro."

# game/act1.rpy:1803
translate italian act1_8110a229:

    # s "Just.{w} Like.{w} This."
    s "Proprio.{w} Come.{w} Questo."

# game/act1.rpy:1808
translate italian act1_d2e63892:

    # "I pull away to look at him."
    "Mi allontano un po' per guardarlo."

# game/act1.rpy:1810
translate italian act1_39746212:

    # a concern "How do you know all of this?"
    a concern "Come fai a sapere tutte queste cose?"

# game/act1.rpy:1812
translate italian act1_e4a0e38c:

    # s cocky "Do you think journalists are the only ones with connections?"
    s cocky "Credi che solo i giornalisti abbiano delle conoscenze?"

# game/act1.rpy:1814
translate italian act1_140f84be:

    # "He downs his drink – a rum and coke, I think – in three big gulps and sighs, slipping out of his stool to stand behind me."
    "Beve il suo drink – un rum e cola, credo – in tre grossi sorsi e sospira, poi si alza dallo sgabello e si mette in piedi dietro di me."

# game/act1.rpy:1816
translate italian act1_59cea1f1:

    # s "And speaking of, I’m actually here on business myself, so I’ll have to cut our conversation a little short tonight."
    s "A proposito, anch'io sono qui per lavoro, quindi stasera dovrò abbreviare un po' la nostra conversazione."

# game/act1.rpy:1818
translate italian act1_fd49e2ef:

    # "He slips something into my back pocket, his hands lingering there for a moment too long, and I whip around to frown at him."
    "Mi infila qualcosa nella tasca posteriore, le sue mani indugiano lì per un istante di troppo, e io mi giro di scatto per guardarlo con aria corrucciata."

# game/act1.rpy:1820
translate italian act1_361caf04:

    # s "Just my personal number. I wanna hear all about your escapades tonight."
    s "Solo il mio numero personale. Voglio sentire tutti i dettagli delle tue avventure di stasera."

# game/act1.rpy:1821
translate italian act1_4a530c3d_2:

    # a hm "…"
    a hm "…"

# game/act1.rpy:1822
translate italian act1_b0cd670a:

    # s smile "I’ll see you around… {i}Ángel{/i}."
    s smile "Ci vediamo in giro… {i}Ángel{/i}."

# game/act1.rpy:1824
translate italian act1_1ab72481_13:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1825
translate italian act1_ab4a2c78:

    # a "{i}What a freak. Stupidly hot… but a freak nonetheless."
    a "Che tipo strano. Stupidamente sexy... ma pur sempre strano."

# game/act1.rpy:1827
translate italian act1_c36be69c:

    # "I know exactly what he’s doing. Flirting with me, closing the distance between us (literally) to make me open up to him. I bet he just wants information out of me, too."
    "So esattamente cosa sta facendo. Flirta con me, riduce la distanza tra noi (letteralmente) per farmi aprire con lui. Scommetto che vuole solo estorcermi delle informazioni."

# game/act1.rpy:1828
translate italian act1_02ac015c:

    # "Sebas… Something is off about that man. So very, very off, and yet…"
    "Sebas… C’è qualcosa di strano in quell’uomo. Qualcosa di veramente, veramente strano, eppure…"

# game/act1.rpy:1829
translate italian act1_c21a708e:

    # "I don’t think I’ll be able to resist him, even if I tried."
    "Non credo che riuscirei a resistergli, nemmeno se ci provassi."

# game/act1.rpy:1831
translate italian act1_6f3e5935:

    # a body2 hm2 "{i}…well, whatever. He did give me some pretty useful information… if it turns out to be true, that is."
    a body2 hm2 "{i}… beh, comunque. Mi ha dato delle informazioni piuttosto utili… se si riveleranno vere, ovviamente."

# game/act1.rpy:1832
translate italian act1_6e53bf92:

    # "But nerves start to rattle me again. There’s no going back after this, no feigning ignorance; If I’m caught inside a hidden gambling ring, there’s no saving me from the consequences that may come."
    "Ma i nervi ricominciano a tormentarmi. Non si può tornare indietro, non si può fingere di non sapere nulla; se vengo scoperto all'interno di un giro di scommesse clandestine, non c'è modo di salvarmi dalle conseguenze che ne potrebbero derivare."

# game/act1.rpy:1833
translate italian act1_66587f2e:

    # "My instincts tell me to just go home – play it safe, do as I’m told… but the anger and refusal that comes from thinking that way overpowers my fears."
    "Il mio istinto mi dice di tornare a casa, di andare sul sicuro, di fare come mi viene detto... ma la rabbia e il rifiuto che derivano da questo modo di pensare hanno la meglio sulle mie paure."

# game/act1.rpy:1834
translate italian act1_dccf32eb:

    # "I don’t want to be a pawn anymore."
    "Non voglio più essere una pedina."

# game/act1.rpy:1836
translate italian act1_6b24d3e6:

    # a body frown "Excuse me…!"
    a body frown "Mi scusi…!"

# game/act1.rpy:1838
translate italian act1_9391ffbf:

    # "I call the bartender over, my heart pounding in my ears. He nonchalantly stands in front of me, a bored look on his face."
    "Chiamo il barista, con il cuore che mi batte forte nelle orecchie. Lui se ne sta in piedi di fronte a me con aria indifferente, con un'espressione annoiata sul volto."

# game/act1.rpy:1840
translate italian act1_1ab72481_14:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1841
translate italian act1_af67d12a:

    # a "Gimmie a Death in the Gulf Stream."
    a "Datemi una morte nella Corrente del Golfo."

# game/act1.rpy:1843
translate italian act1_60bc6f72:

    # "{i}Tap. Tap. Tap."
    "{i}Tocca. Tocca. Tocca."

# game/act1.rpy:1845
translate italian act1_c7fc7fd4:

    # ba "…"
    ba "…"

# game/act1.rpy:1847
translate italian act1_82c5671c:

    # ba "We don’t have that in stock."
    ba "Non lo abbiamo in magazzino."

# game/act1.rpy:1849
translate italian act1_7fefe483:

    # a surprised "O… Oh…"
    a surprised "O… Oh…"

# game/act1.rpy:1851
translate italian act1_2fb8fd03:

    # "My ears burn as I look down, my face hot in raw embarrassment. Was I really played for a fool by Sebas? When I see that motherfucker again, I swear, I’ll-"
    "Le mie orecchie bruciano mentre abbasso lo sguardo, la faccia calda per l'imbarazzo. Sono stato davvero preso in giro da Sebas? Quando rivedrò quel figlio di puttana, giuro, io-"

# game/act1.rpy:1853
translate italian act1_ace49fc3:

    # ba "But there’s some in the supply closet. In the bathroom."
    ba "Ma ce n'è un po' nel ripostiglio. In bagno."

# game/act1.rpy:1855
translate italian act1_09db9eaf:

    # a "Huh?"
    a "Eh?"

# game/act1.rpy:1857
translate italian act1_0897c2f6:

    # "The bartender jerks his head towards the bathroom, that same bored look on his face."
    "Il barista indica di scatto il bagno con la testa, con la stessa espressione annoiata sul volto."

# game/act1.rpy:1859
translate italian act1_603e722b:

    # ba "Check in there."
    ba "Fai il check-in lì."

# game/act1.rpy:1861
translate italian act1_e49b2507:

    # ba "Now."
    ba "Ora."

# game/act1.rpy:1862
translate italian act1_1693a0f6:

    # a flustered "Eh? Uh! Right…! Thank you…?"
    a flustered "Eh? Uh! Giusto…! Grazie…?"

# game/act1.rpy:1864
translate italian act1_b9f3af82:

    # "I hop off my stool and hurry over to the bathroom, my head spinning in different directions as I open the door."
    "Salto giù dallo sgabello e corro in bagno, con la testa che mi gira in tutte le direzioni mentre apro la porta."

# game/act1.rpy:1868
translate italian act1_ace22fb9:

    # a yeesh "Ugh…"
    a yeesh "Uff…"

# game/act1.rpy:1870
translate italian act1_4f71162a:

    # "It smells like piss and cigarettes. Do guys not aim for the urinal when they pee?"
    "Puzza di urina e sigarette. Ma gli uomini non mirano all'orinatoio quando fanno pipì?"

# game/act1.rpy:1871
translate italian act1_a375e90d:

    # "It’s quiet, other than the hum of a ventilation fan somewhere in the room. On the other end of the room is the supply closet door, and I slowly approach it, as if I’m some protagonist in those old horror movies Ethan loves so much."
    "C'è silenzio, a parte il ronzio di una ventola di aerazione da qualche parte nella stanza. Dall'altra parte della stanza c'è la porta del ripostiglio, e mi avvicino lentamente, come se fossi il protagonista di uno di quei vecchi film horror che Ethan ama tanto."

# game/act1.rpy:1872
translate italian act1_24260409:

    # "I place a sweaty paw on the handle, and taking a deep breath, I turn it-"
    "Appoggio una mano sudata sul manico e, facendo un respiro profondo, lo giro-"

# game/act1.rpy:1874
translate italian act1_6bd7b91c:

    # "It’s locked."
    "È chiuso a chiave."

# game/act1.rpy:1876
translate italian act1_2f86b996:

    # "I turn around, getting more agitated. What, is there a key? Or is everyone in the world pulling some elaborate prank on me?"
    "Mi volto, sempre più agitato. Cosa, c'è una chiave? O forse tutti al mondo mi stanno facendo uno scherzo elaborato?"

# game/act1.rpy:1877
translate italian act1_0c1e0bfb:

    # "This is getting so-!"
    "Sta diventando così-!"

# game/act1.rpy:1882
translate italian act1_bde5f0ad:

    # "The door suddenly swings open behind me, and before I have time to react, a pair of large hands grab onto me and pull me to the other side."
    "La porta si spalanca improvvisamente alle mie spalle e, prima che io possa reagire, un paio di mani grosse mi afferrano e mi tirano dall'altra parte."

# game/act1.rpy:1884
translate italian act1_1158132d:

    # "I’m thrown onto the ground, disoriented by the sudden change of lighting, and when I open my eyes…"
    "Vengo scaraventato a terra, disorientato dal repentino cambio di luce, e quando apro gli occhi…"

# game/act1.rpy:1886
translate italian act1_6d416a7a:

    # "I see someplace that doesn’t look like a gambling ring to me."
    "Vedo un posto che non mi sembra affatto un giro di scommesse clandestine."

# game/act1.rpy:1887
translate italian act1_b39d87c7:

    # "I expected a rundown, rustic place that would mirror the bar outside. The room I’m in now looks sleek, modern, brand new, even. It’s…{w} kind of beautiful."
    "Mi aspettavo un posto fatiscente e rustico che rispecchiasse il bar fuori. La stanza in cui mi trovo ora sembra elegante, moderna, persino nuova di zecca. È...{w} in un certo senso bellissima."

# game/act1.rpy:1889
translate italian act1_3fac4603:

    # "But I don’t have much time to admire my surroundings. Someone that seems almost twice my size steps in front of me, and I look up to see what I can only assume to be a pro wrestler with how well built they are."
    "Ma non ho molto tempo per ammirare ciò che mi circonda. Qualcuno che sembra quasi il doppio di me mi si para davanti, e alzo lo sguardo per vedere quello che, a giudicare dalla sua corporatura, presumo sia un wrestler professionista."

# game/act1.rpy:1890
translate italian act1_3fc8f2dd:

    # "He sneers down at me, obviously trying to intimidate me. I steel my nerves, doing my best to not let it show in my face that he’s unfortunately doing a good job of it."
    "Mi guarda con disprezzo, cercando chiaramente di intimidirmi. Mi faccio forza, sforzandomi di non mostrare sul viso che, purtroppo, ci sta riuscendo piuttosto bene."

# game/act1.rpy:1892
translate italian act1_699cc9e1:

    # guard "Well, lookie what we caught here…"
    guard "Ebbene, guardate cosa abbiamo pescato qui…"

# game/act1.rpy:1894
translate italian act1_e78a19c6:

    # "Someone else steps into my view, a woman this time, but surprisingly, she looks just as strong as the alligator."
    "Un'altra persona entra nel mio campo visivo, questa volta una donna, ma sorprendentemente, sembra forte quanto l'alligatore."

# game/act1.rpy:1896
translate italian act1_35df2c99:

    # guard2 "A Valentine? What’s he doing here?"
    guard2 "Un San Valentino? Cosa ci fa qui?"

# game/act1.rpy:1897
translate italian act1_30b32e56:

    # guard "Maybe he’s gone rogue. Or he’s just plain ol’ stupid."
    guard "Forse è impazzito. O forse è semplicemente stupido."

# game/act1.rpy:1899
translate italian act1_646c681a:

    # "I frown at him, and that makes his grin grow wider."
    "Lo guardo accigliato, e questo fa sì che il suo sorriso si allarghi ulteriormente."

# game/act1.rpy:1901
translate italian act1_5001f9aa:

    # guard "Or…"
    guard "O…"

# game/act1.rpy:1903
translate italian act1_9d79b084:

    # "He kneels down and grabs me by the arm again, lifting me to my knees with a grip so tight, I’m scared it’ll bruise."
    "Si inginocchia e mi afferra di nuovo per un braccio, sollevandomi in ginocchio con una presa così forte che ho paura che mi venga un livido."

# game/act1.rpy:1905
translate italian act1_f3320fb7:

    # a nngh "H-hey! Let me go!"
    a nngh "Ehi! Lasciami andare!"

# game/act1.rpy:1907
translate italian act1_8fddf079:

    # guard "Or maybe, he’s sticking his little nose where it doesn’t belong."
    guard "O forse sta ficcando il naso dove non dovrebbe."

# game/act1.rpy:1908
translate italian act1_07ceb950_1:

    # a scared "…!"
    a scared "…!"

# game/act1.rpy:1909
translate italian act1_88bfd07e:

    # anon "Come on now, Darwin… is that really any way to treat a guest?"
    anon "Suvvia, Darwin... è davvero questo il modo di trattare un ospite?"

# game/act1.rpy:1911
translate italian act1_fd780de8:

    # "’Darwin’ and I both turn our heads to look up at my savior, and my eyes widen the moment I see who it is."
    "Io e 'Darwin' giriamo entrambi la testa per guardare il mio salvatore, e i miei occhi si spalancano nell'istante in cui vedo chi è."

# game/act1.rpy:1914
translate italian act1_4df5c473:

    # "Matteo Milan... superstar actor and Sonora's golden boy."
    "Matteo Milan... attore superstar e ragazzo d'oro di Sonora."

# game/act1.rpy:1915
translate italian act1_907d36bf:

    # "He's a celebrity in every sense of the word. Movies, TV shows, magazines... hell, I think he has his own fragrance line."
    "È una celebrità in ogni senso della parola. Film, programmi televisivi, riviste... diavolo, credo che abbia persino una sua linea di profumi."

# game/act1.rpy:1916
translate italian act1_d2a05db2:

    # "From what I can remember, his father owns one of the largest banks in the country, and even his mother is in the entertainment industry...{w}so basically, he's a nepo baby."
    "Da quello che ricordo, suo padre possiede una delle più grandi banche del paese, e persino sua madre lavora nel settore dell'intrattenimento... quindi, in pratica, è un figlio di papà."

# game/act1.rpy:1917
translate italian act1_87cec0ec:

    # "But I've seen some of his movies, and even I have to admit, he is quite talented. So..."
    "Ma ho visto alcuni dei suoi film, e devo ammettere che è davvero talentuoso. Quindi..."

# game/act1.rpy:1918
translate italian act1_16702a35:

    # "What the hell is he doing in a gambling ring on the shittiest side of Sonora?"
    "Che diavolo ci fa in un giro di scommesse clandestine nella zona più squallida di Sonora?"

# game/act1.rpy:1920
translate italian act1_151ea6c9:

    # m cocky "But I’ll admit, a Valentine does me make even me feel a bit uneasy."
    m cocky "Devo ammettere, però, che un biglietto di San Valentino mette un po' a disagio persino me."

# game/act1.rpy:1922
translate italian act1_247ff2b5:

    # "He kneels down to look at me, with piercing mismatched colored eyes that make me wonder if they’re even real. I can smell his cologne from how close he is, and I silently wonder if it's his own brand."
    "Si inginocchia per guardarmi, con occhi penetranti di colore diverso che mi fanno dubitare della loro effettiva veridicità. Riesco a sentire il profumo del suo dopobarba da quanto è vicino, e mi chiedo in silenzio se sia della sua marca personale."

# game/act1.rpy:1924
translate italian act1_f5ac109a:

    # m serious "Why don’t you tell me why you’re really here?"
    m serious "Perché non mi dici perché sei davvero qui?"

# game/act1.rpy:1925
translate italian act1_2a4ff97c_11:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:1927
translate italian act1_bcd77f52:

    # a frown "Why does anyone come down here?"
    a frown "Perché qualcuno viene fin quassù?"

# game/act1.rpy:1928
translate italian act1_65b68bfb:

    # a angry "…I’m here to gamble."
    a angry "…Sono qui per giocare d'azzardo."

# game/act1.rpy:1931
translate italian act1_c639e33d:

    # "Matteo smiles;{w} I answered correctly, it seems."
    "Matteo sorride;{w} A quanto pare ho risposto correttamente."

# game/act1.rpy:1933
translate italian act1_56549518:

    # m sweet "I bet you are."
    m sweet "Scommetto di sì."

# game/act1.rpy:1935
translate italian act1_91ff5b12:

    # "He stands up, addressing Darwin now."
    "Si alza in piedi e si rivolge a Darwin."

# game/act1.rpy:1937
translate italian act1_ffd30e6b:

    # m serious "Let him go."
    m serious "Lascialo andare."

# game/act1.rpy:1939
translate italian act1_3c6eff57:

    # "Darwin hesitates for a moment, then does as he’s told with a grunt. I guess even the strongest yield to the richest."
    "Darwin esita per un attimo, poi fa come gli viene detto con un grugnito. Immagino che anche i più forti cedano al più ricco."

# game/act1.rpy:1940
translate italian act1_8c93a97a:

    # "Matteo waves a hand at both of his guards, and they wordlessly slip away, manning the door and looking inside with stoic expressions. He offers me his paw, and after a beat, I take it, letting him pull me to my feet."
    "Matteo fa un cenno con la mano a entrambe le guardie, che si allontanano senza dire una parola, posizionandosi sulla porta e guardando dentro con espressioni impassibili. Mi porge la zampa e, dopo un attimo, la afferro, lasciandomi tirare su in piedi."

# game/act1.rpy:1942
translate italian act1_bfca4648:

    # m apologetic "Sorry about that. We can never be too careful down here, and you’re not exactly a friendly face."
    m apologetic "Mi dispiace. Qui non si è mai troppo prudenti, e tu non hai esattamente un aspetto amichevole."

# game/act1.rpy:1944
translate italian act1_b1878180:

    # "There’s an odd kindness to him, a smile on his face that I can’t quite tell if it’s fake or not. For the sake of my own safety, I’ll assume the worst... but even I have to admit, I'm a little starstruck."
    "C'è una strana gentilezza in lui, un sorriso sul suo volto che non riesco a capire se sia vero o falso. Per la mia sicurezza, presumerò il peggio... ma devo ammettere che sono un po' emozionata."

# game/act1.rpy:1945
translate italian act1_715ac276:

    # "I'm not exactly a 'fan', but to see a celebrity so up close and looking right at me... it does things to my heart that I can't quite control. It helps he's very easy on the eyes, too."
    "Non sono esattamente una \"fan\", ma vedere una celebrità così da vicino e che mi guarda dritto negli occhi... mi fa provare delle emozioni che non riesco a controllare. E poi, è anche molto attraente."

# game/act1.rpy:1947
translate italian act1_651b1d7c:

    # a bashful "I-It’s fine. I guess I can’t blame you for that."
    a bashful "Va bene. Immagino di non poterti biasimare per questo."

# game/act1.rpy:1948
translate italian act1_d044ace3:

    # m sweet "I’m glad we’re on the same page, then."
    m sweet "Sono contento che siamo d'accordo, allora."

# game/act1.rpy:1949
translate italian act1_8d551c42:

    # m stan "I’m Matteo. Welcome to my little… establishment."
    m stan "Mi chiamo Matteo. Benvenuti nel mio piccolo… locale."

# game/act1.rpy:1951
translate italian act1_1c27d2cd:

    # a flattered "I know who you are..."
    a flattered "So chi sei..."

# game/act1.rpy:1952
translate italian act1_18eae385:

    # m "Oh? I'm surprised a Valentine knows about pop culture."
    m "Oh? Mi sorprende che una persona che si identifica con Valentine conosca la cultura pop."

# game/act1.rpy:1954
translate italian act1_0866ac8b:

    # a bashful "Kind of hard to miss when your face is on billboards."
    a bashful "È piuttosto difficile non notarlo quando la tua faccia è sui cartelloni pubblicitari."

# game/act1.rpy:1955
translate italian act1_6926f79c:

    # m apologetic "Well, you have a point there."
    m apologetic "Beh, hai ragione."

# game/act1.rpy:1956
translate italian act1_668a4abf:

    # m stan "Is this your first time gambling?"
    m stan "È la prima volta che giochi d'azzardo?"

# game/act1.rpy:1958
translate italian act1_0665e59c:

    # "Saying ‘yes’ might make me look too naïve… but saying ‘no’ means I won’t get any explanations about how to play."
    "Dire \"sì\" potrebbe farmi sembrare troppo ingenuo... ma dire \"no\" significa che non riceverò alcuna spiegazione su come giocare."

# game/act1.rpy:1959
translate italian act1_96d8ef11:

    # "Well, whatever. I’d rather know the rules of whatever game we play in exchange for looking like I’m a dumb amateur."
    "Beh, non importa. Preferisco conoscere le regole di qualsiasi gioco facciamo piuttosto che sembrare un dilettante imbranato."

# game/act1.rpy:1961
translate italian act1_f2548162:

    # a flattered "Yeah, it is. Would you mind walking me through it?"
    a flattered "Sì, lo è. Potresti spiegarmelo nel dettaglio?"

# game/act1.rpy:1962
translate italian act1_188012cf:

    # m sweet "It’d be an honor."
    m sweet "Sarebbe un onore."

# game/act1.rpy:1963
translate italian act1_f1a5bcfd:

    # m cocky "What’s your pleasure? Cards? Slots? Roulette?"
    m cocky "Cosa preferisci? Carte? Slot machine? Roulette?"

# game/act1.rpy:1965
translate italian act1_9c88fa3a:

    # "I definitely don’t want to play a game that leaves {i}everything{/i} up to luck. I need to have some kind of control."
    "Non voglio assolutamente giocare a un gioco che lascia {i}tutto{/i} alla fortuna. Ho bisogno di avere un qualche tipo di controllo."

# game/act1.rpy:1967
translate italian act1_35fdbc41:

    # a surprised "Do you guys have poker?"
    a surprised "Avete del poker?"

# game/act1.rpy:1968
translate italian act1_25729f79:

    # m cocky "Do we have poker? Do kitchens have forks?"
    m cocky "Abbiamo il poker? In cucina ci sono le forchette?"

# game/act1.rpy:1969
translate italian act1_980d7afc:

    # a bashful "Right. Stupid question."
    a bashful "Giusto. Domanda stupida."

# game/act1.rpy:1971
translate italian act1_7f0defe2:

    # "He leads me towards a table, and to my surprise, sits directly in front of me. Someone who doesn’t seem to be a guard approaches us, standing to our left."
    "Mi conduce verso un tavolo e, con mia sorpresa, si siede proprio di fronte a me. Una persona che non sembra essere una guardia si avvicina a noi, posizionandosi alla nostra sinistra."

# game/act1.rpy:1973
translate italian act1_b9d29f39:

    # a hm "What’s this?"
    a hm "Che cos'è questo?"

# game/act1.rpy:1974
translate italian act1_f69b9377:

    # m sweet "We have a different style of poker around here. Our own little creation, to make us stand out. You’ll actually be playing against me."
    m sweet "Qui abbiamo uno stile di poker diverso. Una nostra piccola invenzione, per distinguerci dagli altri. In realtà giocherai contro di me."

# game/act1.rpy:1976
translate italian act1_5fc2ecf6:

    # a "What? You guys don’t have the regular kind?"
    a "Cosa? Voi non avete la versione normale?"

# game/act1.rpy:1977
translate italian act1_edd0ffb3:

    # m cocky "If you wanted to play regular poker, you should’ve gone to a casino, Valentine."
    m cocky "Se volevi giocare a poker normalmente, avresti dovuto andare in un casinò, Valentine."

# game/act1.rpy:1978
translate italian act1_1ab72481_15:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1979
translate italian act1_0ce4550e:

    # m sweet "I’ll simply be acting as the house for this game. If you don’t like it, you’re welcome to walk out at any time."
    m sweet "In questo gioco farò semplicemente da \"casa\". Se non vi va bene, potete andarvene quando volete."

# game/act1.rpy:1982
translate italian act1_16469495:

    # a eyeroll "{i}Ugh. Talk about avant-garde bullshit."
    a eyeroll "{i}Ugh. Parliamo di stronzate d'avanguardia."

# game/act1.rpy:1983
translate italian act1_18847f8f:

    # a hm "Fine. I’ll play. What’re the rules?"
    a hm "Va bene. Ci sto. Quali sono le regole?"

# game/act1.rpy:1985
translate italian act1_ec383832:

    # m sweet "The rules are simple."
    m sweet "Le regole sono semplici."

# game/act1.rpy:1991
translate italian act1_cb3bab6b:

    # m "We'll be using a standard 52 deck of cards, plus both joker cards, for a total of 54."
    m "Useremo un mazzo standard di 52 carte, più entrambe le carte jolly, per un totale di 54."

# game/act1.rpy:1993
translate italian act1_2ea0f800:

    # m "The deck gets split in two, and our dealer places both halves on either side of our card shuffler here."
    m "Il mazzo viene diviso in due e il nostro mazziere posiziona entrambe le metà ai lati del mescolatore di carte."

# game/act1.rpy:1996
translate italian act1_cd065e9a:

    # m "Then, we both get 4 cards each, instead of the standard 5. No exchanges can be made once the cards are dealt."
    m "Dopodiché, ognuno di noi riceve 4 carte, invece delle solite 5. Una volta distribuite le carte, non è possibile effettuare scambi."

# game/act1.rpy:1997
translate italian act1_30952b57:

    # m "The hands are all the same, minus one card, so there's a greater chance you'll get a good hand. However..."
    m "Le mani sono tutte uguali, tranne una carta, quindi ci sono maggiori probabilità di ottenere una buona mano. Tuttavia..."

# game/act1.rpy:1998
translate italian act1_30bd91f0:

    # m "That's where the jokers come in."
    m "È qui che entrano in gioco i jolly."

# game/act1.rpy:2002
translate italian act1_12e71a12:

    # m "The gray joker card is also a 'wild card', but not in the same way. Instead, a random card will be drawn from the deck, and that'll be your joker's value."
    m "Anche il jolly grigio è una \"carta jolly\", ma non nello stesso modo. Invece, verrà pescata una carta a caso dal mazzo, e quella carta rappresenterà il valore del tuo jolly."

# game/act1.rpy:2003
translate italian act1_20b201b0:

    # m "It leaves your hand up to fate. You might not want this card, Valentine."
    m "Ti affidi al destino. Forse non vorrai questo biglietto, San Valentino."

# game/act1.rpy:2006
translate italian act1_f0fccda4:

    # m "The colored joker is the good one. It's a wild card, and can be used to make any hand a little better. It'll represent any suit or rank once we move on to the showdown phase."
    m "Il jolly colorato è quello buono. È una carta jolly e può essere usato per migliorare qualsiasi mano. Rappresenterà qualsiasi seme o valore una volta passati alla fase di showdown."

# game/act1.rpy:2007
translate italian act1_1575ab1a:

    # m "So, a three of a kind can become a four of a kind. That can be the difference between a win and a loss... so you're gonna want this joker."
    m "Quindi, un tris può diventare un poker. Questa può essere la differenza tra una vittoria e una sconfitta... quindi vorrai sicuramente questo jolly."

# game/act1.rpy:2016
translate italian act1_ee7a4570:

    # m "We each pay a blind to start the game, one small and one big. Since you're new, I'll start off with the big blind and let you play first. So, if you fold, you lose the least amount."
    m "Ognuno di noi paga una puntata iniziale, una piccola e una grande. Dato che sei nuovo, inizierò io con la puntata più alta e ti lascerò giocare per primo. Così, se passi, perderai il meno possibile."

# game/act1.rpy:2017
translate italian act1_f4aecb5c:

    # m stan "Considering this is your first time gambling... let's start with 15 chips. Small blind is one, big blind, two."
    m stan "Visto che è la prima volta che giochi d'azzardo... iniziamo con 15 fiches. Il piccolo buio è uno, il grande buio è due."

# game/act1.rpy:2018
translate italian act1_67860d75:

    # a hm "How much is each chip worth?"
    a hm "Quanto vale ogni chip?"

# game/act1.rpy:2019
translate italian act1_6f6984ee:

    # m sweet "Let's not worry about that right now. This'll be a practice round. If you win, you keep whatever you make. If you lose, I won't charge you a penny. If you like the game, we'll keep playing."
    m sweet "Non preoccupiamoci di questo adesso. Questa sarà solo una prova. Se vinci, tieni tutto quello che guadagni. Se perdi, non ti chiederò un centesimo. Se il gioco ti piace, continueremo a giocare."

# game/act1.rpy:2020
translate italian act1_2b93c220:

    # m stan "How's that sound?"
    m stan "Che ne dici?"

# game/act1.rpy:2021
translate italian act1_5cd59426:

    # a frown "..."
    a frown "..."

# game/act1.rpy:2023
translate italian act1_aaa409c0:

    # "It doesn't sound {i}too{/i} bad, I guess. Although I may not know much about gambling, this game doesn't seem too unfair to me. A little more 'luck-of-the-draw' than I was hoping for, but I can make it work."
    "Non sembra poi così male, suppongo. Anche se non so molto di giochi d'azzardo, questo gioco non mi sembra troppo ingiusto. Un po' più di \"fortuna\" di quanto sperassi, ma posso farcela."

# game/act1.rpy:2024
translate italian act1_857a5814:

    # "I have to make it work."
    "Devo far funzionare le cose."

# game/act1.rpy:2026
translate italian act1_97e19bc4:

    # a stan "Sounds good to me."
    a stan "Mi sembra un'ottima idea."

# game/act1.rpy:2029
translate italian act1_59b5234d:

    # m sweet "Perfect. Let's start then, shall we?"
    m sweet "Perfetto. Iniziamo, allora, che ne dici?"

# game/act1.rpy:2033
translate italian act1_e375a5a9:

    # "My heart is pounding in my ears as I watch our dealer, a tall, quiet capybara, rips open a fresh pack of cards and splits the deck in half, slipping them into the machine as if he's done it a million times before."
    "Il cuore mi batte forte nelle orecchie mentre guardo il nostro croupier, un capibara alto e silenzioso, aprire un mazzo di carte nuovo di zecca e dividerlo a metà, infilandolo nella macchina come se l'avesse già fatto un milione di volte."

# game/act1.rpy:2035
translate italian act1_48a1db47:

    # "Matteo smiles warmly at me, as if sensing my nerves, but I don't return it. Any sign of weakness, and he'll latch onto it until it becomes the death of me. I won't let him do that."
    "Matteo mi sorride calorosamente, come se percepisse il mio nervosismo, ma io non ricambio. Qualsiasi segno di debolezza, e lui se ne aggrapperà fino a distruggermi. Non glielo permetterò."

# game/act1.rpy:2037
translate italian act1_d825fb98:

    # "Four cards are passed out to each of us, as well as three stacks of five chips. Matteo grabs two and throws them into the middle with a satisfying clinking sound, and he looks at me, quietly telling me to do the same."
    "Ci vengono distribuite quattro carte a testa, insieme a tre mazzi da cinque fiches. Matteo ne prende due e le lancia al centro con un soddisfacente tintinnio, poi mi guarda e mi dice sottovoce di fare lo stesso."

# game/act1.rpy:2038
translate italian act1_92c9aeef:

    # "I grab one from my stack and slide it into our pile, hoping he doesn’t see just how shaky my hands are."
    "Ne prendo uno dalla mia pila e lo faccio scivolare nella nostra, sperando che non si accorga di quanto mi tremano le mani."

# game/act1.rpy:2040
translate italian act1_a5fcf8a5:

    # a flustered "{i}Am I really doing this? Think about how much trouble I could get myself into if I get found out. I could spend the rest of my life as a Valentine, or worse… in prison."
    a flustered "{i}Lo sto facendo davvero? Pensa a quanti guai potrei cacciarmi se mi scoprissero. Potrei passare il resto della mia vita come Valentine, o peggio... in prigione."

# game/act1.rpy:2041
translate italian act1_e38efd9d:

    # a sad "{i}But… is my situation right now… really any better?"
    a sad "Ma... la mia situazione attuale è davvero migliore?"

# game/act1.rpy:2044
translate italian act1_46909a98:

    # "Mr. Grey’s voice echoes in the back of my mind."
    "La voce del signor Grey mi risuona ancora nella mente."

# game/act1.rpy:2045
translate italian act1_2dc7abb5:

    # l "{i}If my calculations are correct - and rest assured, they are - you’ve paid off less than ten percent of your total debt. Have you done the math, love? It’ll take more than forty years for your debt to be finalized."
    l "Se i miei calcoli sono corretti - e ti assicuro che lo sono - hai saldato meno del dieci percento del tuo debito totale. Hai fatto due conti, tesoro? Ci vorranno più di quarant'anni prima che il tuo debito sia estinto."

# game/act1.rpy:2046
translate italian act1_72e94c19_4:

    # a "…"
    a "…"

# game/act1.rpy:2047
translate italian act1_99170d3a:

    # a "{i}That’s basically my entire life. At this rate, whether I do something bad or not doesn’t really matter anymore."
    a "{i}Praticamente tutta la mia vita. Di questo passo, che io faccia qualcosa di male o meno non ha più molta importanza."

# game/act1.rpy:2048
translate italian act1_3aa2ecb4:

    # a frown "{i}Because…"
    a frown "{i}Perché…"

# game/act1.rpy:2049
translate italian act1_6e05d908:

    # a angry "{i}I want to start living... {w}right now!"
    a angry "{i}Voglio iniziare a vivere... {w}subito!"

# game/act1.rpy:2051
translate italian act1_b425ce55:

    # "I grab my cards and look at them, Matteo following suit.{w} The game has begun."
    "Prendo le mie carte e le guardo, Matteo fa lo stesso.{w} La partita è iniziata."

# game/act1.rpy:2053
translate italian act1_9f6e9266:

    # "A pair of sixes, a four and a jack. No joker."
    "Una coppia di sei, un quattro e un jack. Nessun jolly."

# game/act1.rpy:2054
translate italian act1_cf25c946:

    # a hm "{i}This… is a pretty shitty hand."
    a hm "{i}Questa… è una mano piuttosto scadente."

# game/act1.rpy:2055
translate italian act1_76b664b0:

    # a frown "{i}But the odds of Matteo having an equally shitty hand is pretty high, too. Considering we can’t even change our hands, the most we can hope for is pairs, or straights if we’re lucky enough."
    a frown "Ma anche le probabilità che Matteo abbia una mano altrettanto pessima sono piuttosto alte. Considerando che non possiamo nemmeno cambiare le nostre mani, il massimo che possiamo sperare è una coppia, o una scala se siamo abbastanza fortunati."

# game/act1.rpy:2056
translate italian act1_7ec3e551:

    # a yeesh "{i}That’s where the joker would come into play… if I HAD one. Anyways…"
    a yeesh "{i}È qui che entrerebbe in gioco il jolly... se ne avessi uno. Comunque..."

# game/act1.rpy:2057
translate italian act1_01d54544:

    # a hm "{i}Seems like I should fold. The only way I’d win is if he has a total pig."
    a hm "{i}Sembra che dovrei arrendermi. L'unico modo in cui potrei vincere è se lui avesse una mano pessima."

# game/act1.rpy:2059
translate italian act1_2c043118:

    # "Matteo looks up at me, a coy smile on his face. That’s right… a big part of poker is bluffing, isn’t it? As long as your opponent {i}thinks{/i} you have a good hand, then you can win, even with a pig."
    "Matteo mi guarda con un sorriso malizioso. Esatto... una parte importante del poker è bluffare, no? Finché il tuo avversario {i}pensa{/i} che tu abbia una buona mano, puoi vincere, anche con una mano pessima."

# game/act1.rpy:2061
translate italian act1_4c4a65af:

    # "But it’s a risk… if they match you, you can lose, big time."
    "Ma è un rischio... se ti eguagliano, puoi perdere, e alla grande."

# game/act1.rpy:2062
translate italian act1_92db9dda:

    # "I guess that’s the whole point of gambling, in the end…"
    "Credo che, in fin dei conti, questo sia il senso del gioco d'azzardo..."

# game/act1.rpy:2064
translate italian act1_8ef2c679_3:

    # a frown "…"
    a frown "…"

# game/act1.rpy:2065
translate italian act1_89a9ae70:

    # a "{i}I’m done with taking the safe route. If I can’t take a risk on a practice game of poker, with nothing to lose… then I’m not cut out to be in Sonora."
    a "Ho smesso di prendere la strada più sicura. Se non posso rischiare in una partita di poker di prova, senza niente da perdere... allora non sono fatto per stare a Sonora."

# game/act1.rpy:2066
translate italian act1_08b7e6a5:

    # a angry "{i}’The risk makes the man’, huh, Mr. Grey? I’ll show you…"
    a angry "{i}\"Il rischio fa l'uomo\", eh, signor Grey? Le dimostrerò..."

# game/act1.rpy:2068
translate italian act1_c3dbae8d:

    # "Our dealer places one card from the deck face down, then spreads his hands palms-up to us. I guess that means the betting phase starts now."
    "Il nostro croupier mette una carta dal mazzo a faccia in giù, poi allarga le mani con i palmi rivolti verso di noi. Immagino che questo significhi che la fase delle puntate inizia ora."

# game/act1.rpy:2070
translate italian act1_48f75b7c:

    # m cocky "Your move, Valentine."
    m cocky "Ora tocca a te, Valentine."

# game/act1.rpy:2071
translate italian act1_8ef2c679_4:

    # a frown "…"
    a frown "…"

# game/act1.rpy:2074
translate italian act1_5cb9c09a:

    # "I place two chips in the center of our pile, putting up a confident front."
    "Metto due fiches al centro del nostro mucchio, ostentando sicurezza."

# game/act1.rpy:2076
translate italian act1_c7236708:

    # a stan "Two chips."
    a stan "Due chip."

# game/act1.rpy:2078
translate italian act1_b00bdf74:

    # m amused "Ballsy. I like it."
    m amused "Coraggioso. Mi piace."

# game/act1.rpy:2079
translate italian act1_549c91ec:

    # m wink "Then, I’ll raise you by one chip."
    m wink "Allora, ti rilancio di una fiche."

# game/act1.rpy:2081
translate italian act1_e53fb254:

    # "He throws in three chips of his own, smiling that same kind smile. My eye twitches."
    "Aggiunge tre delle sue patatine, sfoggiando quel suo solito sorriso gentile. Il mio occhio si contrae."

# game/act1.rpy:2082
translate italian act1_2098eda2:

    # "So he has a good hand? Is that it? Or is he bluffing? God, I can’t tell at all…"
    "Quindi ha una buona mano? È così? O sta bluffando? Oddio, non riesco proprio a capirlo..."

# game/act1.rpy:2084
translate italian act1_6af51e81:

    # a frown "{i}Fuck it. It’s a practice round. I can afford to lose a chip or two."
    a frown "{i}Al diavolo. È solo un giro di prova. Posso permettermi di perdere una o due fiches."

# game/act1.rpy:2085
translate italian act1_2bee9c6b:

    # a surprised "I’ll match your bet."
    a surprised "Accetto la tua scommessa."

# game/act1.rpy:2086
translate italian act1_acf7debb:

    # m cocky "We call that a ‘call’, Valentine."
    m cocky "Noi la chiamiamo una \"chiamata\", Valentine."

# game/act1.rpy:2088
translate italian act1_b31acd52:

    # a flustered "Uh- r-right… I call."
    a flustered "Uh- r-giusto… chiamo."

# game/act1.rpy:2090
translate italian act1_95a3bd26:

    # "I slide another chip to the center pile, making 6 chips in total."
    "Faccio scivolare un'altra fiche sul mucchietto centrale, arrivando a un totale di 6 fiches."

# game/act1.rpy:2092
translate italian act1_bbcc30c9:

    # dealer "You may now reveal your cards."
    dealer "Ora potete rivelare le vostre carte."

# game/act1.rpy:2093
translate italian act1_65d756d7:

    # m sweet "You wanna do the honors?"
    m sweet "Vuoi fare gli onori di casa?"

# game/act1.rpy:2094
translate italian act1_1ab72481_16:

    # a concern "…"
    a concern "…"

# game/act1.rpy:2096
translate italian act1_6da85dc9:

    # "With a pounding heart, I flip my cards on the table, showing them off."
    "Con il cuore che mi batteva forte, rigiro le carte sul tavolo, mostrandole a tutti."

# game/act1.rpy:2098
translate italian act1_be052b6f:

    # a surprised "A pair of sixes."
    a surprised "Una coppia di sei."

# game/act1.rpy:2100
translate italian act1_eba4e660:

    # m apologetic "Agh, darn."
    m apologetic "Ah, dannazione."

# game/act1.rpy:2102
translate italian act1_ecec95ad:

    # "Matteo flips his, showing…"
    "Matteo capovolge la sua, mostrando…"

# game/act1.rpy:2104
translate italian act1_7550c10c:

    # m "Queen high-card. A pig."
    m "Regina come carta più alta. Un maiale."

# game/act1.rpy:2105
translate italian act1_72e94c19_5:

    # a "…"
    a "…"

# game/act1.rpy:2106
translate italian act1_1539fbdb:

    # m wink "Congrats, Valentine. You won~"
    m wink "Congratulazioni, Valentine. Hai vinto~"

# game/act1.rpy:2107
translate italian act1_4c4ae253:

    # a "I…"
    a "IO…"

# game/act1.rpy:2109
translate italian act1_856c7772:

    # a blush "{i}I did?"
    a blush "{i}L'ho fatto?"

# game/act1.rpy:2110
translate italian act1_3670dea4:

    # a excited "{i}H-Hah! I did! I won!!!"
    a excited "{i}H-Ah! Ce l'ho fatta! Ho vinto!!!"

# game/act1.rpy:2112
translate italian act1_c65cb4ea:

    # "It’s impossible to hide my happiness, a giddy smile starting to creep into my face as my shaky hands fold together. I did it… I really did it!"
    "È impossibile nascondere la mia felicità, un sorriso euforico comincia a spuntare sul mio viso mentre le mie mani tremanti si stringono l'una all'altra. Ce l'ho fatta... ce l'ho fatta davvero!"

# game/act1.rpy:2114
translate italian act1_7f93398e:

    # "That wasn’t so bad…! Scary, sure, but it was almost… fun…"
    "Non è stato poi così male...! Spaventoso, certo, ma quasi... divertente..."

# game/act1.rpy:2115
translate italian act1_7800fb0f_1:

    # a flattered "…"
    a flattered "…"

# game/act1.rpy:2116
translate italian act1_297a7038:

    # m amused "So… did ya like it?"
    m amused "Allora… ti è piaciuto?"

# game/act1.rpy:2117
translate italian act1_d27f371a:

    # m cocky "Would you… like to keep playing?"
    m cocky "Vorresti… continuare a giocare?"

# game/act1.rpy:2120
translate italian act1_44577c64:

    # a confident "Let’s do it."
    a confident "Facciamolo."

# game/act1.rpy:2121
translate italian act1_f05f65d0:

    # m "…"
    m "…"

# game/act1.rpy:2122
translate italian act1_27205c47:

    # m amused "I knew you’d say that."
    m amused "Lo sapevo che avresti detto così."

# game/act1.rpy:2124
translate italian act1_22090c1d:

    # "The dealer starts shuffling the deck again, and I look over to Matteo."
    "Il mazziere ricomincia a mescolare le carte e io guardo Matteo."

# game/act1.rpy:2126
translate italian act1_bd707d0d:

    # a hm "Wait. How much will the chips be worth now?"
    a hm "Aspetta. Quanto varranno adesso le patatine?"

# game/act1.rpy:2127
translate italian act1_0ef1d36e:

    # m sweet "Hm? Oh, that. Well… let’s say, for this round… 50 dollars each. That sound good to you?"
    m sweet "Mh? Oh, quello. Bene… diciamo, per questo giro… 50 dollari a testa. Ti sembra un buon affare?"

# game/act1.rpy:2130
translate italian act1_6b0e3f4b:

    # "I bite my lip. 50 dollars is pretty generous, but even that much is a lot for me. That’s almost a week’s worth of food, if I stretch it right. Throwing that away in a gamble would be…"
    "Mi mordo il labbro. 50 dollari sono una cifra piuttosto generosa, ma anche quella è tanta per me. È quasi una settimana di cibo, se la faccio bastare. Buttarla via in una scommessa sarebbe..."

# game/act1.rpy:2132
translate italian act1_4e94752d:

    # "I shake my head. No, I can’t chicken out, not now that I’ve already gone all the way! Besides, I’ll make it back twofold if I win this one."
    "Scuoto la testa. No, non posso tirarmi indietro, non ora che sono già arrivato fino in fondo! Inoltre, se vinco, recupererò il doppio."

# game/act1.rpy:2134
translate italian act1_4ab8bbcc:

    # a bashful "Sounds good then."
    a bashful "Allora sembra un'ottima idea."

# game/act1.rpy:2135
translate italian act1_13e87235:

    # m sweet "Perfect."
    m sweet "Perfetto."

# game/act1.rpy:2146
translate italian act1_229e7d38:

    # a confident "A pair of nines."
    a confident "Una coppia di nove."

# game/act1.rpy:2147
translate italian act1_2a4937fd:

    # m apologetic "Another pig on my end. Damn. You’re gonna run me out of business, Valentine."
    m apologetic "Un altro maiale dalla mia parte. Dannazione. Mi farai fallire, Valentine."

# game/act1.rpy:2148
translate italian act1_0c51c9e3:

    # a silly "I guess I’m a natural~"
    a silly "Credo di avere un talento naturale~"

# game/act1.rpy:2150
translate italian act1_4711d7e7:

    # a blush "{i}Another win… this is exhilarating!"
    a blush "{i}Un'altra vittoria... è esaltante!"

# game/act1.rpy:2151
translate italian act1_af1e0449:

    # a bashful "{i}I shouldn’t get carried away… but, still…! I’m doing so well! I made 250 bucks from this game alone! If I could stay on a winning streak…"
    a bashful "{i}Non dovrei farmi prendere dall'entusiasmo... ma, comunque...! Sto andando così bene! Ho guadagnato 250 dollari solo con questo gioco! Se solo riuscissi a mantenere questa serie vincente..."

# game/act1.rpy:2152
translate italian act1_ca1ca69c:

    # a blush "{i}My debt could be paid off sooner than I thought!"
    a blush "{i}Il mio debito potrebbe essere saldato prima del previsto!"

# game/act1.rpy:2153
translate italian act1_591a6319:

    # m sweet "Another game?"
    m sweet "Un altro gioco?"

# game/act1.rpy:2154
translate italian act1_ef176421:

    # a confident "You’re on."
    a confident "Sei in diretta."

# game/act1.rpy:2156
translate italian act1_5f588122:

    # "I grab my cards and immediately try not to let it show on my face…"
    "Afferro le mie carte e cerco subito di non darlo a vedere sul mio viso…"

# game/act1.rpy:2157
translate italian act1_7da2e3de:

    # "…That I got the colored joker."
    "…Ho preso il jolly colorato."

# game/act1.rpy:2159
translate italian act1_2eb7991f:

    # a grin "{i}Yes!! Instant win! I just have to bluff my way into making him bet a lot."
    a grin "{i}Sì!! Vittoria immediata! Devo solo bluffare per convincerlo a scommettere un sacco di soldi."

# game/act1.rpy:2161
translate italian act1_b398cc83:

    # "A three-of-a-kind isn’t bad at all. It’s higher than a double pair, right?"
    "Un tris non è affatto male. È più alto di una doppia coppia, no?"

# game/act1.rpy:2163
translate italian act1_6e637585:

    # "I push two chips into the center, trying to play it nonchalant."
    "Inserisco due fiches al centro, cercando di sembrare disinvolto."

# game/act1.rpy:2165
translate italian act1_954e1892:

    # a smile "Two chips."
    a smile "Due chip."

# game/act1.rpy:2166
translate italian act1_90f4b9c1:

    # m cocky "You’re becoming a seasoned gambler, aye, Valentine? Well, I can’t stay behind anymore."
    m cocky "Stai diventando un giocatore esperto, eh, Valentine? Beh, io non posso più restare indietro."

# game/act1.rpy:2167
translate italian act1_5306ed51:

    # m stan "I’ll raise you one chip."
    m stan "Ti propongo una fiche."

# game/act1.rpy:2169
translate italian act1_dd3d9e3a:

    # "I smile. This {i}is{/i} fun."
    "Sorrido. Questo {i}è{/i}divertente."

# game/act1.rpy:2171
translate italian act1_b64e355a:

    # a cocky "Let’s see how high you’re willing to go, Milan. I’ll raise you by one myself."
    a cocky "Vediamo fin dove sei disposto ad arrivare, Milan. Io rilancio di uno."

# game/act1.rpy:2173
translate italian act1_098c1fc2:

    # m sweet "I’m pretty confident in my hand. I’ll raise you by two."
    m sweet "Sono abbastanza sicuro della mia mano. Ti rilancio di due."

# game/act1.rpy:2174
translate italian act1_2a4ff97c_12:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:2176
translate italian act1_c51f100d:

    # a concern "{i}There’s no way his hand is better than mine… right? Yeah, no way. What are the odds he gets a flush, or a straight?"
    a concern "{i}Non c'è modo che la sua mano sia migliore della mia... vero? Sì, impossibile. Quali sono le probabilità che faccia un colore o una scala?"

# game/act1.rpy:2177
translate italian act1_d74c75c8:

    # a frown "{i}He’s bluffing… I know he is. I just have to out-bluff him, and I’ll win the whole pot."
    a frown "{i}Sta bluffando... Lo so. Devo solo bluffare più forte di lui e vincerò tutto il piatto."

# game/act1.rpy:2178
translate italian act1_7ef4a284:

    # a stan "I raise your bet by one."
    a stan "Rilancio la tua puntata di uno."

# game/act1.rpy:2181
translate italian act1_193c518f:

    # m sweet "I’m all in."
    m sweet "Ci sto in pieno."

# game/act1.rpy:2183
translate italian act1_9e90b603:

    # "Matteo pushes all of his chips into the pile, a bead of sweat starting to form on my forehead as I watch him lean back confidently in his chair."
    "Matteo spinge tutte le sue patatine nel mucchio, e una goccia di sudore inizia a formarsi sulla mia fronte mentre lo guardo appoggiarsi con sicurezza allo schienale della sedia."

# game/act1.rpy:2186
translate italian act1_179ac558:

    # a scared "{i}Jesus… I… I can’t fold now. I’d lose, what, two-hundred? Three-hundred dollars? But if I match him, that’ll be six-hundred dollars…! Matteo can certainly afford to lose that, but can I?"
    a scared "{i}Gesù… io… non posso arrendermi ora. Perderei, che so, duecento? Trecento dollari? Ma se lo pareggio, saranno seicento dollari…! Matteo se lo può certamente permettere, ma io?"

# game/act1.rpy:2187
translate italian act1_60ee755b:

    # a concern "{i}In any case, the only way to not lose any money now would be to check him… and hope I win."
    a concern "{i}In ogni caso, l'unico modo per non perdere soldi ora sarebbe quello di controllarlo... e sperare di vincere."

# game/act1.rpy:2188
translate italian act1_8ef2c679_5:

    # a frown "…"
    a frown "…"

# game/act1.rpy:2189
translate italian act1_90099636:

    # a angry "{i}No. I WILL win. I alone have the colored joker. That makes my hand better than his automatically, doesn’t it?"
    a angry "{i}No. Vincerò io. Solo io ho il jolly colorato. Questo rende automaticamente la mia mano migliore della sua, no?"

# game/act1.rpy:2190
translate italian act1_bba9693b:

    # a "{i}No more stepping down. I’m doing this now!"
    a "{i}Basta fare un passo indietro. Lo faccio adesso!"

# game/act1.rpy:2192
translate italian act1_6d155545:

    # a frown "I’m all in, too!"
    a frown "Anch'io ci sto!"

# game/act1.rpy:2194
translate italian act1_1f285814:

    # "I push my chips to the center before I can regret it, my adrenaline spiking to levels I’ve never felt before. Matteo seems way too casual about this… but, maybe there’s a hint of nerves in his eyes?"
    "Spingo le patatine al centro prima di potermene pentire, l'adrenalina che mi sale a livelli mai provati prima. Matteo sembra fin troppo disinvolto... ma forse c'è un pizzico di nervosismo nei suoi occhi?"

# game/act1.rpy:2196
translate italian act1_48eb169e:

    # dealer "You may now show your cards."
    dealer "Ora potete mostrare le vostre carte."

# game/act1.rpy:2199
translate italian act1_cf50905c:

    # a surprised "…!"
    a surprised "…!"

# game/act1.rpy:2200
translate italian act1_9d5bc0ad:

    # a "M-mine’s a three-of-a-kind! That means I win, right!"
    a "M-io ho fatto un tris! Questo significa che ho vinto, giusto?"

# game/act1.rpy:2201
translate italian act1_3d0c4c32:

    # m cocky "Now, hold on… didn’t you notice?"
    m cocky "Aspetta un attimo… non te ne sei accorto?"

# game/act1.rpy:2202
translate italian act1_24fba808:

    # m sweet "I have a joker card of my own."
    m sweet "Anch'io ho una carta jolly tutta mia."

# game/act1.rpy:2203
translate italian act1_5f3979c1:

    # "I blink. He’s right… he has the gray joker. B-but there’s no way…"
    "Sbatto le palpebre. Ha ragione... ha il Joker grigio. M-ma non c'è modo..."

# game/act1.rpy:2204
translate italian act1_1effa9ce:

    # m cocky "Thomas?"
    m cocky "Tommaso?"

# game/act1.rpy:2206
translate italian act1_745e42ee:

    # "Our dealer – Thomas – draws a card from the deck, and it feels like he flips it in slow motion to reveal…"
    "Il nostro croupier, Thomas, estrae una carta dal mazzo e sembra che la giri al rallentatore per rivelare..."

# game/act1.rpy:2208
translate italian act1_c1ea52a2:

    # a scared "!!!"
    a scared "!!!"

# game/act1.rpy:2210
translate italian act1_38ccf612:

    # "My face turns to ice.{w} He drew a six."
    "Il mio viso si gela.{w} Ha pescato un sei."

# game/act1.rpy:2212
translate italian act1_a7edf123:

    # m sweet "Well, look at my luck! A flush on gray joker! I don’t think that’s {i}ever{/i} happened to me before."
    m sweet "Beh, guarda che fortuna! Un colore con il jolly grigio! Non credo che mi sia mai successo prima."

# game/act1.rpy:2214
translate italian act1_00502c9f:

    # "I shudder, feeling like I’m about to be sick. {i}Six-hundred dollars on a poker game…"
    "Rabbrividisco, mi sento come se stessi per vomitare. {i}Seicento dollari in una partita a poker…"

# game/act1.rpy:2216
translate italian act1_af16ec37:

    # "That’s almost half a month’s paycheck… what am I gonna tell Mom? What am I- "
    "È quasi mezzo stipendio mensile... cosa dirò alla mamma? Cosa farò-"

# game/act1.rpy:2218
translate italian act1_51b0a3da:

    # m cocky "Oh, shoot. We forgot to establish what the chips were worth this round, didn’t we?"
    m cocky "Oh, accidenti. Ci siamo dimenticati di stabilire il valore delle fiches in questo round, vero?"

# game/act1.rpy:2220
translate italian act1_0f65fcc3:

    # a "H… huh?"
    a "C… eh?"

# game/act1.rpy:2221
translate italian act1_086a5633:

    # a "N-no, we didn’t. You said 50 dollars…"
    a "N-no, non l'abbiamo fatto. Hai detto 50 dollari…"

# game/act1.rpy:2222
translate italian act1_5164fcfe:

    # m sweet "I said that last round, Valentine. Try and keep up, will ya?"
    m sweet "L'ho detto anche lo scorso round, Valentine. Cerca di starmi dietro, ok?"

# game/act1.rpy:2223
translate italian act1_bff02818:

    # m cocky "So, let’s see… how about…"
    m cocky "Allora, vediamo… che ne dici di…"

# game/act1.rpy:2224
translate italian act1_cd0fbc29:

    # m amused "A thousand dollars for each chip. That sounds good, right, Thomas?"
    m amused "Mille dollari per ogni chip. Sembra un buon affare, vero Thomas?"

# game/act1.rpy:2225
translate italian act1_bde74b23:

    # a nngh "What?!"
    a nngh "Che cosa?!"

# game/act1.rpy:2228
translate italian act1_dc2944f7:

    # "I stand up, slamming my hand on the table."
    "Mi alzo in piedi, sbattendo la mano sul tavolo."

# game/act1.rpy:2230
translate italian act1_ed4c7114:

    # a pissed "Don’t fuck with me! You can’t just put a price like that! Who do you think you are?!"
    a pissed "Non prendermi in giro! Non puoi semplicemente fissare un prezzo così! Chi credi di essere?!"

# game/act1.rpy:2233
translate italian act1_d8a0eebc:

    # m "I think the better question is… who do you think {i}you{/i} are?"
    m "Penso che la domanda migliore sia... chi credi di essere?"

# game/act1.rpy:2235
translate italian act1_301bd9fa:

    # "He stands up to meet my position, and those jewel-colored eyes turn icy in an instant, as if a switch was flipped in his head."
    "Si alza in piedi per andarmi incontro, e quegli occhi color gioiello si gelano in un istante, come se qualcosa si fosse spento nella sua testa."

# game/act1.rpy:2237
translate italian act1_7d205c1b:

    # m angry "This is my ring, Valentine. You think you have some authority here?"
    m angry "Questo è il mio anello, Valentine. Credi di avere qualche autorità qui?"

# game/act1.rpy:2238
translate italian act1_d8eb5386_4:

    # a scared "…"
    a scared "…"

# game/act1.rpy:2240
translate italian act1_ee984f78:

    # a "B-but we… we gambled, fair and square…"
    a "M-ma noi… noi abbiamo giocato, in modo onesto e leale…"

# game/act1.rpy:2242
translate italian act1_3d84049d:

    # m sweet "Yeah, sorry. Fair’s not really my thing."
    m sweet "Sì, mi dispiace. Le fiere non sono proprio il mio forte."

# game/act1.rpy:2244
translate italian act1_f81ee84d:

    # a pissed "You…! You can’t do this! You can’t-!"
    a pissed "Tu…! Non puoi farlo! Non puoi-!"

# game/act1.rpy:2245
translate italian act1_7ae2c0b4:

    # m angry "And who the fuck's gonna stop me?"
    m angry "E chi diavolo mi fermerà?"

# game/act1.rpy:2247
translate italian act1_834d052a:

    # m "Tell me, Valentine. What’re {i}you{/i} gonna do about it?"
    m "Dimmi, Valentine. Cosa {i}hai{/i} intenzione di fare al riguardo?"

# game/act1.rpy:2248
translate italian act1_67017425:

    # m cocky "Gonna tell the cops? Go right ahead. Tell them what you did."
    m cocky "Hai intenzione di dirlo alla polizia? Fallo pure. Racconta loro cosa hai fatto."

# game/act1.rpy:2249
translate italian act1_50806284_2:

    # a nngh "…"
    a nngh "…"

# game/act1.rpy:2251
translate italian act1_17c5e952:

    # "I collapse on my chair, head hung low facing the table, blinking tears onto its surface as Matteo chuckles above me."
    "Mi accascio sulla sedia, con la testa china sul tavolo, sbattendo le palpebre e lasciando cadere le lacrime sulla sua superficie, mentre Matteo ridacchia sopra di me."

# game/act1.rpy:2253
translate italian act1_1a4dfda4:

    # a sob "{i}Why…?"
    a sob "{i}Perché…?"

# game/act1.rpy:2259
translate italian act1_ce1d5703_1:

    # tr_text "Well, then. That’s… how much? Oh, right…"
    tr_text "Bene, allora. Quanto costa? Oh, giusto…"

# game/act1.rpy:2260
translate italian act1_cb241121_1:

    # tr_text2 "Twelve-thousand dollars. You have the money, don’t you?"
    tr_text2 "Dodicimila dollari. Hai i soldi, vero?"

# game/act1.rpy:2261
translate italian act1_90fdc461:

    # tr_text3 "Aw, don’t look so distraught.\nSorry to clip your wings, Valentine."
    tr_text3 "Oh, non fare quella faccia sconvolta.\nMi dispiace di averti tarpato le ali, Valentine."

# game/act1.rpy:2262
translate italian act1_a9ed576d_1:

    # tr_text "But you really should’ve known better~"
    tr_text "Ma avresti dovuto pensarci meglio~"

# game/act1.rpy:2264
translate italian act1_f947feb2:

    # a_text "{i}Why…{w} was I so stupid?!"
    a_text "{i}Perché…{w} sono stato così stupido?!"

# game/act1.rpy:2268
translate italian act1_f51fdf43:

    # anon "Sorry to interrupt your game, but… I couldn’t help myself from coming over."
    anon "Scusate se interrompo la vostra partita, ma… non ho potuto fare a meno di avvicinarmi."

# game/act1.rpy:2270
translate italian act1_a9b59ab7:

    # "A low, familiar voice makes my ears flick, and looking up through my tear-soaked eyes, I see…"
    "Una voce bassa e familiare mi fa fremere le orecchie e, alzando lo sguardo attraverso gli occhi pieni di lacrime, vedo…"

# game/act1.rpy:2272
translate italian act1_09e3fdde:

    # s "{i}¿Qué te pasó, angelito?{/i} I thought you said you had this under control?"
    s "{i}¿Qué te pasó, angelito?{/i} Pensavo avessi detto di avere la situazione sotto controllo?"

# game/act1.rpy:2274
translate italian act1_7c0933b0:

    # "I blink several times to clear my vision and see him properly, dumbfounded by his sudden appearance. What does he want…?"
    "Sbatto le palpebre più volte per schiarirmi la vista e vederlo bene, sbalordita dalla sua improvvisa apparizione. Cosa vuole...?"

# game/act1.rpy:2277
translate italian act1_661b3faa:

    # m "Can I help you?"
    m "Posso aiutarla?"

# game/act1.rpy:2280
translate italian act1_da7d049c:

    # "An annoyed Matteo does a once-over at Sebas, who just stands to my side, paws in his pockets, slightly hunched over without a care in the world."
    "Un Matteo irritato lancia un'occhiata a Sebas, che se ne sta in piedi al mio fianco, con le mani in tasca, leggermente curvo, come se non gli importasse di niente."

# game/act1.rpy:2282
translate italian act1_05d6cb08:

    # s hm "This is my friend here. I’m guessing he lost to you?"
    s hm "Questo è un mio amico. Immagino che abbia perso contro di te, vero?"

# game/act1.rpy:2283
translate italian act1_a63407a0:

    # m hm "He did. What’s it to you?"
    m hm "L'ha fatto. Che ti importa?"

# game/act1.rpy:2286
translate italian act1_41522b81:

    # s "I just hate seeing cute boys cry like that. Don’t you?"
    s "Detesto vedere i ragazzi carini piangere in quel modo. E tu?"

# game/act1.rpy:2288
translate italian act1_8fa0429a:

    # m angry "I honestly couldn’t care less. Darwin!"
    m angry "Sinceramente, non me ne potrebbe importare di meno. Darwin!"

# game/act1.rpy:2290
translate italian act1_d21fb988:

    # "Darwin starts marching over to us, and a whine escapes my throat, but Sebas stands his ground."
    "Darwin inizia ad avanzare verso di noi e un lamento mi sfugge dalle labbra, ma Sebas rimane fermo."

# game/act1.rpy:2292
translate italian act1_015e6191:

    # s cocky "I’m not looking for any trouble. Actually, I just wanted to gamble with you, too."
    s cocky "Non cerco guai. In realtà, volevo solo giocare d'azzardo anch'io con te."

# game/act1.rpy:2293
translate italian act1_f05f65d0_1:

    # m "…"
    m "…"

# game/act1.rpy:2295
translate italian act1_664f1d5d:

    # "Darwin just about puts his hands on Sebas when Matteo stops him, putting his own paw up in a ‘halt’ gesture."
    "Darwin sta per mettere le mani addosso a Sebas quando Matteo lo ferma, alzando la sua zampa in segno di \"alt\"."

# game/act1.rpy:2298
translate italian act1_1cfadca1:

    # m angry "What are you on about?"
    m angry "Di cosa stai parlando?"

# game/act1.rpy:2300
translate italian act1_d61ef346:

    # s amused "Is the saying ‘double or nothing’ a thing here?"
    s amused "Si usa qui il detto \"tutto o niente\"?"

# game/act1.rpy:2301
translate italian act1_f05f65d0_2:

    # m "…"
    m "…"

# game/act1.rpy:2303
translate italian act1_37cd1574:

    # m cocky "You wanna gamble for double his debt, huh?"
    m cocky "Vuoi scommettere il doppio del suo debito, eh?"

# game/act1.rpy:2304
translate italian act1_5965eed5:

    # s "That’s right. If you’d let me."
    s "Esatto. Se me lo permettessi."

# game/act1.rpy:2307
translate italian act1_b651aee8:

    # m arrogant "Hah!"
    m arrogant "Ah!"

# game/act1.rpy:2308
translate italian act1_e248c4a9:

    # m "Hahahaha!!"
    m "Ahahahaha!!"

# game/act1.rpy:2309
translate italian act1_f02cbf6f:

    # m angry "Who do you think you are?"
    m angry "Chi credi di essere?"

# game/act1.rpy:2310
translate italian act1_2d986cb6:

    # s "You can call me Sebas."
    s "Puoi chiamarmi Sebas."

# game/act1.rpy:2312
translate italian act1_e41bd4d8:

    # "He takes out his wallet and pulls out a shiny black card from inside, making everyone at the table gasp – except for me, who just sits there like an idiot that doesn’t know what he’s looking at."
    "Tira fuori il portafoglio ed estrae una carta nera e lucida, lasciando tutti al tavolo a bocca aperta, tranne me, che rimango seduto lì come un idiota che non capisce cosa sta guardando."

# game/act1.rpy:2314
translate italian act1_84390099:

    # s smile "And I believe this should show you I’m serious?"
    s smile "E credo che questo dovrebbe dimostrarti che faccio sul serio, vero?"

# game/act1.rpy:2317
translate italian act1_82a499c6:

    # "Matteo glances at the card, then at me, then Sebas… then the card again."
    "Matteo lancia un'occhiata alla carta, poi a me, poi a Sebas... poi di nuovo alla carta."

# game/act1.rpy:2319
translate italian act1_20cff6de:

    # m cocky "Heh. I don’t know who the hell you are, but if you’re willing to go double or nothing for this Valentine, then by all means. Be my guest."
    m cocky "Eh. Non so chi diavolo tu sia, ma se sei disposto a fare le cose in grande per questo San Valentino, allora fai pure. Accomodati."

# game/act1.rpy:2320
translate italian act1_e2082201:

    # m angry "But I’ve got my conditions. I want fifty thousand. I don’t care how you split it between the two of you."
    m angry "Ma ho le mie condizioni. Voglio cinquantamila. Non mi interessa come li dividete tra voi due."

# game/act1.rpy:2321
translate italian act1_67668bfb:

    # s "And If I win, you let Angel go, debt free."
    s "E se vinco, lascerai andare Angel, senza debiti."

# game/act1.rpy:2322
translate italian act1_162065f8:

    # m cocky "Fine. It’s a deal."
    m cocky "Va bene. Affare fatto."

# game/act1.rpy:2323
translate italian act1_fea2857d:

    # s smile "It’s settled, then."
    s smile "È deciso, dunque."

# game/act1.rpy:2327
translate italian act1_38e5cbc8:

    # a nngh "Wait, wait, WAIT!"
    a nngh "Aspetta, aspetta, ASPETTA!"

# game/act1.rpy:2332
translate italian act1_81dce528:

    # "I stand up and grab Sebas by the collar, pulling him lower to my eye level."
    "Mi alzo e afferro Sebas per il colletto, tirandolo più in basso fino al mio livello degli occhi."

# game/act1.rpy:2334
translate italian act1_2a07158d:

    # a nngh "Who the hell told you to make decisions for me?! You think I’m just going to let you rack up my debt if you lose?!"
    a nngh "Chi diavolo ti ha detto di prendere decisioni al posto mio?! Credi davvero che ti lascerò accumulare debiti se perdi?!"

# game/act1.rpy:2335
translate italian act1_2d4376b0:

    # s "…"
    s "…"

# game/act1.rpy:2336
translate italian act1_870f9c42:

    # s stan "I won’t lose, {i}Ángel{/i}."
    s stan "Non perderò, {i}Ángel{/i}."

# game/act1.rpy:2337
translate italian act1_2ed6667b:

    # s "It’s okay to ask for help sometimes."
    s "A volte è giusto chiedere aiuto."

# game/act1.rpy:2338
translate italian act1_07ceb950_2:

    # a scared "…!"
    a scared "…!"

# game/act1.rpy:2340
translate italian act1_be0ff9e2:

    # a concern "Just who the hell are you?"
    a concern "Ma chi diavolo sei?"

# game/act1.rpy:2342
translate italian act1_eb828f94:

    # s smile "I already told you. {w}A friend."
    s smile "Te l'ho già detto. {w}Un amico."

# game/act1.rpy:2345
translate italian act1_87ea51ac:

    # "I stare into those onyx eyes that are looking right back into my soul as we have one last silent conversation through our gazes alone."
    "Fisso quegli occhi d'onice che mi guardano dritto nell'anima mentre abbiamo un'ultima silenziosa conversazione, solo attraverso i nostri sguardi."

# game/act1.rpy:2347
translate italian act1_40f9a900:

    # a concern "{i}How do I know I can trust you…?"
    a concern "Come faccio a sapere di potermi fidare di te...?"

# game/act1.rpy:2349
translate italian act1_8c560d5d:

    # s hm "{i}You don’t.{w} You're just gonna have to take my word for it."
    s hm "{i}Non lo farai.{w} Dovrai semplicemente fidarti della mia parola."

# game/act1.rpy:2351
translate italian act1_2acfd085:

    # "Yet another wager."
    "Un'altra scommessa ancora."

# game/act1.rpy:2354
translate italian act1_2d5385e7:

    # a worried "Okay…"
    a worried "Va bene…"

# game/act1.rpy:2356
translate italian act1_25102470:

    # "I let go of him, and he stands up straight again, giving me a soft, assured smile."
    "Lo lascio andare e lui si raddrizza, rivolgendomi un sorriso dolce e sicuro."

# game/act1.rpy:2361
translate italian act1_ffdf7e95:

    # m "Are you two done? Can we get on with this?"
    m "Avete finito? Possiamo andare avanti?"

# game/act1.rpy:2362
translate italian act1_c6e90dec:

    # s smile "With pleasure."
    s smile "Con piacere."

# game/act1.rpy:2368
translate italian act1_1ba6cf5c:

    # "Sebas takes my seat at the table, and I’m forced to stand next to Thomas, unable to see either of their cards. This works out better for both of us. I don’t think I’d be able to hide the emotions on my face if I saw Sebas’ cards."
    "Sebas prende il mio posto al tavolo e io sono costretto a stare in piedi accanto a Thomas, senza poter vedere le carte di nessuno dei due. Meglio così per entrambi. Non credo che sarei riuscito a nascondere le emozioni sul mio viso se avessi visto le carte di Sebas."

# game/act1.rpy:2369
translate italian act1_e73e7260:

    # "I swallow hard, both men in front of me showing me nothing on either of their expressions. The once warm and kind façade from Matteo’s smile is nowhere to be seen, now replaced with a cold, calculating glare."
    "Deglutisco a fatica, entrambi gli uomini di fronte a me non mostrano alcuna emozione sul volto. La facciata di calore e gentilezza che un tempo caratterizzava il sorriso di Matteo è scomparsa, sostituita da uno sguardo freddo e calcolatore."

# game/act1.rpy:2370
translate italian act1_5b3bedd7:

    # "Sebas glances at me through the corner of his eyes as Matteo explains the rules to him. Am I supposed to help him out in any way? I’m so confused… and close to puking my guts out."
    "Sebas mi lancia un'occhiata di sottecchi mentre Matteo gli spiega le regole. Dovrei aiutarlo in qualche modo? Sono così confusa... e sto per vomitare tutto."

# game/act1.rpy:2375
translate italian act1_b504a48a:

    # m "You got all that?"
    m "Hai capito tutto?"

# game/act1.rpy:2376
translate italian act1_2d4376b0_1:

    # s "…"
    s "…"

# game/act1.rpy:2377
translate italian act1_9b99e06b:

    # m cocky "What? Getting cold feet?"
    m cocky "Cosa? Ti sei fatto prendere dal panico?"

# game/act1.rpy:2379
translate italian act1_e7c0b282:

    # s hm "No. I’m just curious why you use an automatic shuffler. Not even Corona’s uses one."
    s hm "No. Sono solo curioso di sapere perché usi un mescolatore automatico. Nemmeno il Corona's ne usa uno."

# game/act1.rpy:2381
translate italian act1_f76351e6:

    # "I frown. So he {i}did{/i} go to Corona’s?"
    "Aggrotto la fronte. Quindi lui {i}è{/i} andato da Corona?"

# game/act1.rpy:2383
translate italian act1_230b41b1:

    # m cocky "It’s just to ensure the shuffle is truly random. Nothing else to it."
    m cocky "Serve solo a garantire che la mescolatura sia veramente casuale. Nient'altro."

# game/act1.rpy:2384
translate italian act1_7e3ec1f8:

    # s stan "Is that right?"
    s stan "È corretto?"

# game/act1.rpy:2388
translate italian act1_9f054e46:

    # s "Would you care if we just let the dealer shuffle for us?"
    s "Vi dispiacerebbe se lasciassimo che fosse il mazziere a mescolare le carte per noi?"

# game/act1.rpy:2390
translate italian act1_77ad5c10:

    # m hm "Why, exactly?"
    m hm "Perché, esattamente?"

# game/act1.rpy:2392
translate italian act1_6c4bd225:

    # s "To make it fair, of course."
    s "Per garantire l'equità, ovviamente."

# game/act1.rpy:2393
translate italian act1_96bdcf02:

    # m angry "Are you insinuating I’m cheating?"
    m angry "Stai forse insinuando che ti sto tradendo?"

# game/act1.rpy:2394
translate italian act1_1bfae857:

    # s "No."
    s "NO."

# game/act1.rpy:2396
translate italian act1_52269187:

    # s "I’m… hm, what’s the word? ‘Stating’? Yes, I’m ‘stating’ that you’re cheating."
    s "Io... ehm, qual è la parola? 'Affermare'? Sì, sto 'affermando' che mi stai tradendo."

# game/act1.rpy:2397
translate italian act1_f05f65d0_3:

    # m "…"
    m "…"

# game/act1.rpy:2399
translate italian act1_1b80c301:

    # "Matteo looks into Sebas’ eyes with silent fury etched into them, clenching his jaw so tight I’m scared for his teeth."
    "Matteo guarda Sebas negli occhi con una furia silenziosa impressa, stringendo la mascella così forte che temo per i suoi denti."

# game/act1.rpy:2401
translate italian act1_0445ebdc:

    # m "That’s a {i}bold{/i} claim, whatever-your-name-was."
    m "Questa è un'affermazione {i}audace{/i}, qualunque-fossi-tuo-nome."

# game/act1.rpy:2402
translate italian act1_09bb2a0c:

    # s "It’s Sebas."
    s "È Sebas."

# game/act1.rpy:2404
translate italian act1_071db81b:

    # m "Whatever. I don’t have to sit here and take this slander from some punk who thinks he’s hot shit."
    m "Non importa. Non devo stare qui a subire queste calunnie da un ragazzino che si crede chissà chi."

# game/act1.rpy:2406
translate italian act1_5825b205:

    # s "Slander? I can prove it, if you’d like. I mean, even the fact that you’re getting so defensive about letting your dealer shuffle is telling in its own way."
    s "Calunnia? Posso provarlo, se vuoi. Voglio dire, anche il fatto che tu ti stia mettendo sulla difensiva per aver lasciato che il tuo mazziere mescolasse le carte è di per sé significativo."

# game/act1.rpy:2408
translate italian act1_84ec937e:

    # s "But I’ll admit, it’s a {i}very{/i} elaborate cheat. I bet no one’s ever noticed it before, have they?"
    s "Ma devo ammetterlo, è un trucco {i}molto{/i}elaborato. Scommetto che nessuno se n'è mai accorto prima, vero?"

# game/act1.rpy:2409
translate italian act1_63c5722b:

    # a concern "What… do you mean?"
    a concern "Cosa intendi?"

# game/act1.rpy:2411
translate italian act1_378b62a7:

    # "Sebas looks over to me, a smug grin on his face."
    "Sebas mi guarda con un sorriso compiaciuto stampato in faccia."

# game/act1.rpy:2413
translate italian act1_d84756f4:

    # s "I can’t blame you for not noticing, {i}chele{/i}. Unless you know cards well, you probably would’ve never caught it. Hell, even I had a hard time keeping up."
    s "Non posso biasimarti per non averlo notato, {i}chele{/i}. A meno che tu non conosca bene le carte, probabilmente non te ne saresti mai accorta. Cavolo, persino io ho fatto fatica a stargli dietro."

# game/act1.rpy:2414
translate italian act1_6f3ef5d9:

    # s "And obviously, the culprit is the machine."
    s "E ovviamente, il colpevole è la macchina."

# game/act1.rpy:2416
translate italian act1_2fddfe22:

    # s "It’s performing a perfect faro shuffle. The deck is split in half, and when they’re shuffled, each card gets interweaved through the other deck via the machine. That alone isn’t a cheat, though."
    s "Esegue una mescolatura Faro perfetta. Il mazzo è diviso a metà e, durante la mescolatura, ogni carta si intreccia con l'altra tramite la macchina. Questo, di per sé, non costituisce un imbroglio."

# game/act1.rpy:2419
translate italian act1_8027cac5:

    # s "The real trick comes from the deck itself. You weren’t shown the order before it was placed into the machine, right, Angel?"
    s "Il vero trucco sta nel mazzo stesso. Non ti è stato mostrato l'ordine prima che venisse inserito nella macchina, vero, Angel?"

# game/act1.rpy:2420
translate italian act1_5afab5e7:

    # a concern "No… but it was a brand-new deck. Aren’t they all the same order, anyway?"
    a concern "No… ma era un mazzo nuovo di zecca. Non sono tutti dello stesso ordine, comunque?"

# game/act1.rpy:2421
translate italian act1_b168d3c5:

    # s "Normally, yes. However, this one wasn’t."
    s "Normalmente sì. Tuttavia, questo non lo era."

# game/act1.rpy:2422
translate italian act1_f868463c:

    # s "It had a completely different order… a very specific one. Does the Joyal deck ring any bells, Matteo?"
    s "L'ordine era completamente diverso... molto specifico. Il mazzo Joyal ti dice qualcosa, Matteo?"

# game/act1.rpy:2423
translate italian act1_6d895f6f:

    # m "…!?"
    m "…!?"

# game/act1.rpy:2424
translate italian act1_ea3c9060:

    # a hm "Joyal?"
    a hm "Gioioso?"

# game/act1.rpy:2428
translate italian act1_3b7400d0:

    # s "It’s a specific pattern of a deck of cards used for different kinds of magic tricks. Matteo here must have them custom made, fresh in the pack."
    s "Si tratta di un particolare schema di un mazzo di carte utilizzato per diversi tipi di giochi di prestigio. Matteo se le deve fare su misura, fresche di zecca."

# game/act1.rpy:2429
translate italian act1_69246985:

    # s "In other words, the cards weren’t ever going to be randomized."
    s "In altre parole, le carte non sarebbero mai state randomizzate."

# game/act1.rpy:2430
translate italian act1_3afdad37:

    # s "Whether it was an out or in faro shuffle, each of your hands were predetermined from the very beginning. He must have memorized the outcome of each hand and betted accordingly."
    s "Che si trattasse di un Faro Shuffle in entrata o in uscita, l'esito di ciascuna delle vostre mani era predeterminato fin dall'inizio. Doveva aver memorizzato il risultato di ogni mano e aver puntato di conseguenza."

# game/act1.rpy:2435
translate italian act1_82399fc9:

    # s "What I don’t understand are the jokers… two extra cards messes with the order of the Joyal deck. My guess… a specific button that pushes them out, maybe?"
    s "Quello che non capisco sono i jolly... due carte extra scombussolano l'ordine del mazzo Joyal. La mia ipotesi... forse c'è un pulsante specifico che li fa uscire?"

# game/act1.rpy:2436
translate italian act1_f05f65d0_4:

    # m "…"
    m "…"

# game/act1.rpy:2437
translate italian act1_aa5b57af:

    # s cocky2 "It's so subtle. So many different moving parts in such a tiny machine... you must have had this custom built as well. Oh, what money can buy, aye?"
    s cocky2 "È così sottile. Tante parti mobili diverse in una macchina così piccola... dev'essere stata costruita su misura anche questa. Oh, cosa si può comprare con i soldi, eh?"

# game/act1.rpy:2438
translate italian act1_649d6845:

    # s "But, well… this is all speculation. You’re welcome to clear your name, Matteo. I’m open to be proven wrong."
    s "Ma, beh… sono solo speculazioni. Sei libero di riabilitare il tuo nome, Matteo. Sono aperto a ricredermi."

# game/act1.rpy:2441
translate italian act1_f782f380:

    # s "But I’m right, aren’t I? You can’t {i}really{/i} play cards. You’re just some Hollywood Hills frat douche playing casino with Daddy's money and scamming those weaker than you to, what? Get his approval?"
    s "Ma ho ragione, no? Non sai {i}davvero{/i} giocare a carte. Sei solo un idiota di una confraternita di Hollywood Hills che gioca al casinò con i soldi di papà e truffa quelli più deboli di te per, cosa? Ottenere la sua approvazione?"

# game/act1.rpy:2445
translate italian act1_81f6a3d9:

    # s angry "Why don’t you gamble like a real man instead of cheating like a pussy?"
    s angry "Perché non giochi d'azzardo come un vero uomo invece di barare come un codardo?"

# game/act1.rpy:2452
translate italian act1_db24d056:

    # m "You motherfucker…! Just who the hell do you think you are?!"
    m "Figlio di puttana...! Ma chi diavolo credi di essere?!"

# game/act1.rpy:2453
translate italian act1_b29e22fa:

    # s "My name’s Seb-"
    s "Mi chiamo Seb-"

# game/act1.rpy:2455
translate italian act1_145456e4:

    # m "I DON’T GIVE A FUCK!! If you think you know a SINGLE thing about me, you’re dead fucking wrong!!"
    m "NON ME NE FREGA UN CAZZO!! Se pensi di sapere ANCHE SOLO una cosa su di me, ti sbagli di grosso!!"

# game/act1.rpy:2456
translate italian act1_f3a2d03d:

    # m arrogant "Yeah, I’ll admit it. I cheated. This is MY ring, and I can do whatever the FUCK I want! And if you think you’re gonna change that, then you’re an even bigger idiot than this Valentine!!"
    m arrogant "Sì, lo ammetto. Ho barato. Questo è il MIO anello e posso farci quello che CAZZO voglio! E se pensi di poter cambiare le cose, allora sei un idiota ancora più grande di questo San Valentino!!"

# game/act1.rpy:2458
translate italian act1_2adb451d:

    # a flustered "{i}Why am I catching strays…?"
    a flustered "{i}Perché sto catturando animali randagi...?"

# game/act1.rpy:2461
translate italian act1_4d23d4ae:

    # s hm "You know, maybe you’re right, Matteo. I thought you’d be willing to gamble with me even without the cheat, but…"
    s hm "Sai, forse hai ragione, Matteo. Pensavo che saresti stato disposto a scommettere con me anche senza imbrogliare, ma…"

# game/act1.rpy:2464
translate italian act1_da6653fe:

    # s "I guess I really am a fool to ever think you’d be capable of doing that."
    s "Credo di essere stato davvero uno sciocco a pensare che tu fossi capace di fare una cosa del genere."

# game/act1.rpy:2465
translate italian act1_f05f65d0_5:

    # m "…"
    m "…"

# game/act1.rpy:2468
translate italian act1_df6f056c:

    # "Matteo sinks back into his seat, almost in slow motion, staring daggers at Sebas as he quietly seethes for a moment."
    "Matteo si lascia cadere all'indietro sul sedile, quasi al rallentatore, lanciando sguardi di fuoco a Sebas mentre per un attimo cova rabbia in silenzio."

# game/act1.rpy:2471
translate italian act1_e81f75a8:

    # m cocky "You’ve got balls, Sebas, I’ll give you that. Spying on our game, calling me out in front of my staff, disrespecting me. You’re lucky I haven’t shot you square between the eyes."
    m cocky "Hai fegato, Sebas, te lo concedo. Spiare la nostra partita, insultarmi davanti al mio staff, mancarmi di rispetto. Sei fortunato che non ti abbia sparato dritto in mezzo agli occhi."

# game/act1.rpy:2472
translate italian act1_0f16a195:

    # m arrogant "But you know what? I respect it."
    m arrogant "Ma sapete una cosa? Lo rispetto."

# game/act1.rpy:2473
translate italian act1_51c94c36:

    # m "So I will play. And I’ll make sure to get every penny of those fifty-thousand dollars from that black card of yours when I win."
    m "Quindi giocherò. E mi assicurerò di intascare fino all'ultimo centesimo di quei cinquantamila dollari dalla tua carta nera quando vincerò."

# game/act1.rpy:2474
translate italian act1_fb10e910:

    # m angry "And if I ever see your stupid face again…{w} I’ll kill you right where you stand."
    m angry "E se mai rivedrò la tua stupida faccia...{w} ti ucciderò sul posto."

# game/act1.rpy:2476
translate italian act1_1be75051:

    # s flirty "Now we’re talking."
    s flirty "Ora sì che ci siamo."

# game/act1.rpy:2477
translate italian act1_13e9fb9a:

    # m serious "Thomas. Go get a normal deck."
    m serious "Thomas. Vai a comprarti un mazzo di carte normale."

# game/act1.rpy:2479
translate italian act1_306308e1:

    # "Thomas nods, disappearing somewhere for a moment."
    "Thomas annuisce, scomparendo per un attimo da qualche parte."

# game/act1.rpy:2481
translate italian act1_8b369ab2:

    # a concern "{i}Wait a minute… so I was being screwed over from the very beginning?"
    a concern "Aspetta un attimo... quindi mi hanno fregato fin dall'inizio?"

# game/act1.rpy:2482
translate italian act1_737c6bb3:

    # a sad "{i}Maybe Ethan was right… I’m not cut out for this. If I couldn’t even tell I was being conned on my first ever gamble, what business do I have being here?"
    a sad "Forse Ethan aveva ragione... non sono fatto per questo. Se non mi sono nemmeno accorto di essere stato truffato alla mia prima scommessa, che ci faccio qui?"

# game/act1.rpy:2483
translate italian act1_d72eeebf:

    # a worried "{i}…I guess it’s too late to back out now."
    a worried "{i}…Immagino che ormai sia troppo tardi per tirarsi indietro."

# game/act1.rpy:2485
translate italian act1_3829c8bc:

    # "Thomas reappears with a deck of cards in his hands, opening the pack and spreading it through the table with the precision of a magician. Sure enough, the cards are in the order you’d expect, from ace to king."
    "Thomas ricompare con un mazzo di carte in mano, lo apre e lo sparge sul tavolo con la precisione di un mago. E infatti, le carte sono nell'ordine previsto, dall'asso al re."

# game/act1.rpy:2486
translate italian act1_1d4afc82:

    # "He then grabs them all up again, cuts the deck in two and gives them a shuffle, repeating this process about three more times before finally dealing out the cards, four for each, just like before."
    "Poi li raccoglie tutti, taglia il mazzo a metà e lo mescola, ripetendo questo processo altre tre volte circa prima di distribuire finalmente le carte, quattro per ciascuno, proprio come prima."

# game/act1.rpy:2490
translate italian act1_eedf27b0:

    # a "{i}With the bets already placed… that means there’s no bluffing this time. It’s a game of pure luck."
    a "Con le scommesse già piazzate... significa che questa volta non si può bluffare. È un gioco di pura fortuna."

# game/act1.rpy:2491
translate italian act1_3f42d274:

    # a "{i}How the hell is Sebas going to win like this??"
    a "{i}Come diavolo farà Sebas a vincere in questo modo??"

# game/act1.rpy:2493
translate italian act1_2d4376b0_2:

    # s "…"
    s "…"

# game/act1.rpy:2494
translate italian act1_f05f65d0_6:

    # m "…"
    m "…"

# game/act1.rpy:2495
translate italian act1_bbb9ecb6:

    # dealer "You… may reveal your cards at any time."
    dealer "Tu… puoi rivelare le tue carte in qualsiasi momento."

# game/act1.rpy:2497
translate italian act1_249804fd:

    # s "I’m surprised you ended up agreeing to this in the end. I suppose the Milan’s do have a bit of honor left."
    s "Sono sorpreso che alla fine tu abbia accettato. Suppongo che ai Milan sia rimasto ancora un po' di onore."

# game/act1.rpy:2498
translate italian act1_45694f05:

    # m "You gonna play, or what?"
    m "Hai intenzione di giocare o no?"

# game/act1.rpy:2500
translate italian act1_b491320f:

    # dealer "At the count of three, then, gentlemen… please reveal your cards."
    dealer "Al conto di tre, signori… vi prego, mostrate le vostre carte."

# game/act1.rpy:2501
translate italian act1_ffee86be:

    # dealer "One…"
    dealer "Uno…"

# game/act1.rpy:2502
translate italian act1_ff751cf1:

    # dealer "Two…"
    dealer "Due…"

# game/act1.rpy:2503
translate italian act1_fdc32eb0:

    # dealer "Three."
    dealer "Tre."

# game/act1.rpy:2505
translate italian act1_cf50905c_1:

    # a surprised "…!"
    a surprised "…!"

# game/act1.rpy:2506
translate italian act1_4a63b5dd:

    # "They both have complete pigs... but Sebas has an Ace! He wins with the high card!"
    "Entrambi hanno delle carte pessime... ma Sebas ha un Asso! Vince con la carta più alta!"

# game/act1.rpy:2507
translate italian act1_00aa30f1:

    # s "{i}Comiste mierda, gomelo.{/i} Looks like I win."
    s "{i}Comiste mierda, gomelo.{/i} Sembra che io abbia vinto."

# game/act1.rpy:2512
translate italian act1_9fedb3ea:

    # "I breathe out a heavy, shaky sigh of relief, chills running through my whole body. He really did win… from the hairs of his chin, but a win is a win."
    "Tiro un sospiro di sollievo pesante e tremante, mentre un brivido mi percorre tutto il corpo. Ha davvero vinto... per un pelo, ma una vittoria è pur sempre una vittoria."

# game/act1.rpy:2513
translate italian act1_50ab7af4:

    # "Matteo stares at the cards on the table, seething in a way I don’t think I’ve seen anyone do before, his paws clenched so tight that his claws must be digging into his pads."
    "Matteo fissa le carte sul tavolo, ribollendo di rabbia in un modo che non credo di aver mai visto prima, con le zampe serrate così forte che gli artigli gli si conficcano nei cuscinetti plantari."

# game/act1.rpy:2514
translate italian act1_c9fc4b60:

    # "Sebas, on the other hand, just stands up, as calm and collected as ever."
    "Sebas, d'altro canto, rimane semplicemente in piedi, calmo e imperturbabile come sempre."

# game/act1.rpy:2518
translate italian act1_60742e52:

    # s "Well, I can’t say I didn’t enjoy this, but it’s getting quite late now. {i}Ángel, ¿nos vamos?{/i}"
    s "Beh, non posso dire che non mi sia piaciuto, ma ormai si sta facendo piuttosto tardi. {i}Ángel, ¿nos vamos?{/i}"

# game/act1.rpy:2520
translate italian act1_aebc4e7b:

    # "Instinctively, somehow, I know that means we should get the hell out of here. I nod, still shaken by the entire ordeal, as if I just woke up from a fever dream."
    "Istintivamente, in qualche modo, so che significa che dovremmo andarcene di qui al più presto. Annuisco, ancora scosso da tutta la vicenda, come se mi fossi appena svegliato da un incubo febbrile."

# game/act1.rpy:2522
translate italian act1_796fbd31:

    # "Sebas places his large paw on my lower back and starts to lead me to the doorway, when we hear Matteo slam the table, his chair sliding backwards."
    "Sebas mi appoggia la sua grossa zampa sulla parte bassa della schiena e inizia a condurmi verso la porta, quando sentiamo Matteo sbattere il tavolo e la sedia scivolare all'indietro."

# game/act1.rpy:2525
translate italian act1_93c00ebe:

    # m "Don’t think for a second this is over, Valentine! Your pimp may have saved you this time, but you’re not safe anymore."
    m "Non pensare nemmeno per un secondo che sia finita, Valentine! Il tuo pappone ti avrà anche salvata stavolta, ma non sei più al sicuro."

# game/act1.rpy:2527
translate italian act1_e6d9bcd6:

    # m angry "You're deep in my world now, {i}Angel{/i}. And I won't let you forget it."
    m angry "Sei ormai profondamente immerso nel mio mondo, {i}Angelo{/i}. E non te lo lascerò dimenticare."

# game/act1.rpy:2528
translate italian act1_1ab72481_17:

    # a concern "…"
    a concern "…"

# game/act1.rpy:2529
translate italian act1_c79d4b77:

    # s stan "Come on. Let’s go."
    s stan "Dai, andiamo."

# game/act1.rpy:2531
translate italian act1_65486dd6:

    # "Sebas nudges me to start walking again, and the last thing I see as we exit the room is Matteo’s eyes glaring deep into mine…"
    "Sebas mi spinge a riprendere a camminare, e l'ultima cosa che vedo mentre usciamo dalla stanza sono gli occhi di Matteo che mi fissano intensamente…"

# game/act1.rpy:2535
translate italian act1_18f74fcb:

    # "The bar is mostly empty once we walk out, and Sebas leads me towards a different exit of the bar, the back door. It leads to a dark alleyway full of dumpsters, but the cold midnight breeze carries the smell somewhere else."
    "Quando usciamo, il bar è quasi vuoto e Sebas mi conduce verso un'altra uscita, quella sul retro. Conduce a un vicolo buio pieno di cassonetti, ma la fredda brezza notturna porta via l'odore."

# game/act1.rpy:2540
translate italian act1_7e2f9528:

    # s "Stay here for a second."
    s "Resta qui un secondo."

# game/act1.rpy:2541
translate italian act1_629844bc:

    # a hm "Why?"
    a hm "Perché?"

# game/act1.rpy:2542
translate italian act1_1f398e3d:

    # s hm "I’m going to check if the coast is clear."
    s hm "Vado a controllare se la costa è libera."

# game/act1.rpy:2543
translate italian act1_244665f5:

    # a "Is that really necessary?"
    a "È davvero necessario?"

# game/act1.rpy:2544
translate italian act1_d8801749:

    # s "If you don’t want people seeing a Valentine come out of a bar that’s rumored to be a gambling ring this late, then yes, I think so."
    s "Se non vuoi che la gente veda un Valentine uscire da un bar che si dice sia un giro di bische clandestine a quest'ora tarda, allora sì, penso di sì."

# game/act1.rpy:2545
translate italian act1_2a4ff97c_13:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:2547
translate italian act1_c55eecb3:

    # a pout "Touché."
    a pout "Touché."

# game/act1.rpy:2550
translate italian act1_06f39335_5:

    # a stan "…"
    a stan "…"

# game/act1.rpy:2552
translate italian act1_b0c084cf:

    # "I blink, my eyelids heavy but my mind feeling wide awake. Did all of that really just happen?"
    "Sbatto le palpebre, pesanti ma con la mente perfettamente sveglia. È successo davvero tutto questo?"

# game/act1.rpy:2553
translate italian act1_ac73130a:

    # "I was almost fifty-thousand dollars deeper in debt… That’s my {i}entire{/i} debt right now to the Valentine Agency. I really {i}would{/i} have spent my whole life paying that off, and then some."
    "Ero indebitato per quasi cinquantamila dollari in più... Questo è il mio {i}intero{/i} debito attuale nei confronti della Valentine Agency. Avrei davvero {i}passato{/i} tutta la mia vita a ripagarlo, e anche di più."

# game/act1.rpy:2554
translate italian act1_842e8da1:

    # "How could I be so stupid…? I was conned, then rescued, and by some miracle walked away like nothing ever happened. But something did happen, and Matteo’s parting words echoes in my mind."
    "Come ho potuto essere così stupida...? Sono stata raggirata, poi salvata e, per miracolo, me ne sono andata come se nulla fosse successo. Ma qualcosa è successo, e le ultime parole di Matteo mi risuonano ancora nella mente."

# game/act1.rpy:2555
translate italian act1_3eef5548:

    # "I’ve bitten the fruit.{w} No way back to Eden now."
    "Ho morso il frutto.{w} Ormai non c'è più modo di tornare all'Eden."

# game/act1.rpy:2557
translate italian act1_ca2dd096:

    # s "Okay, it’s good. Come on."
    s "Okay, va bene. Andiamo."

# game/act1.rpy:2564
translate italian act1_8d722ccb:

    # "I hug myself as we walk onto the sidewalk, the chilly air only deepening my nerves. I feel like the world’s ending, for some reason. Like I’m still at that table…"
    "Mi abbraccio mentre camminiamo sul marciapiede, l'aria gelida non fa che aumentare il mio nervosismo. Ho la sensazione che il mondo stia per finire, per qualche ragione. Come se fossi ancora seduta a quel tavolo..."

# game/act1.rpy:2566
translate italian act1_902387aa:

    # s "What a rush, ‘ey, {i}chelito?"
    s "Che emozione, ehi, {i}chelito?"

# game/act1.rpy:2568
translate italian act1_1ab72481_18:

    # a concern "…"
    a concern "…"

# game/act1.rpy:2571
translate italian act1_a5ee0cb6:

    # a "You owe me {i}a lot{/i} of explanations."
    a "Mi devi {i}molte{/i} spiegazioni."

# game/act1.rpy:2572
translate italian act1_e10c64b4:

    # a "What were you doing down there? Why were you spying on our game? Why did you help me?"
    a "Cosa stavi facendo laggiù? Perché stavi spiando la nostra partita? Perché mi hai aiutato?"

# game/act1.rpy:2575
translate italian act1_bcddc353:

    # a angry "Who are you…?"
    a angry "Chi sei…?"

# game/act1.rpy:2578
translate italian act1_2d4376b0_3:

    # s "…"
    s "…"

# game/act1.rpy:2579
translate italian act1_e6d0c064:

    # s smile "You know what? I’m starving."
    s smile "Sai una cosa? Sto morendo di fame."

# game/act1.rpy:2580
translate italian act1_fbbaaad5:

    # s "There’s a diner open twenty-four hours not too far from here. Wanna check it out?"
    s "Non molto lontano da qui c'è una tavola calda aperta ventiquattro ore su ventiquattro. Ti va di darci un'occhiata?"

# game/act1.rpy:2582
translate italian act1_91937056:

    # "I really don’t. But something tells me I won’t get my answers otherwise…"
    "In realtà no. Ma qualcosa mi dice che altrimenti non otterrò le risposte che cerco…"

# game/act1.rpy:2584
translate italian act1_154ca5ad:

    # a hm "I could eat."
    a hm "Potrei mangiare."

# game/act1.rpy:2594
translate italian act1_33692f58:

    # "A short, quiet walk later, Sebas and I are seated face-to-face inside a booth of a cheap diner, the restaurant completely empty aside from us. Sebas spins a straw in one hand over and over again, in an almost hypnotizing motion."
    "Dopo una breve e tranquilla passeggiata, io e Sebas siamo seduti uno di fronte all'altro in un tavolino di una tavola calda economica, il locale completamente vuoto a parte noi due. Sebas fa roteare una cannuccia in una mano, ripetutamente, con un movimento quasi ipnotico."

# game/act1.rpy:2595
translate italian act1_cf8f7c65:

    # "An older woman takes our order. Sebas asks if they’re still serving food, and the lady replies no (obviously). So he orders a slice of pie instead.{w} I just get a water."
    "Una signora anziana prende la nostra ordinazione. Sebas chiede se servono ancora da mangiare e la signora risponde di no (ovviamente). Quindi ordina una fetta di torta. Io prendo solo dell'acqua."

# game/act1.rpy:2596
translate italian act1_ff3d644e:

    # "She walks away, probably wondering to herself what the hell a Valentine and some Hispanic guy are doing here in the middle of the night. I can’t say I blame her. I’m wondering the same thing."
    "Lei se ne va, probabilmente chiedendosi cosa ci facciano lì, nel cuore della notte, un innamorato e un tizio ispanico. Non posso darle torto. Me lo chiedo anch'io."

# game/act1.rpy:2599
translate italian act1_9945e21c:

    # s smile "Ever been here before?"
    s smile "Sei già stato qui?"

# game/act1.rpy:2600
translate italian act1_46e77115:

    # a hm "Can’t say I have. You?"
    a hm "Non posso dire di averlo fatto. E tu?"

# game/act1.rpy:2601
translate italian act1_79b69356:

    # s "Once or twice."
    s "Una o due volte."

# game/act1.rpy:2603
translate italian act1_cdc60a08:

    # a "I thought you were a tourist."
    a "Pensavo fossi un turista."

# game/act1.rpy:2604
translate italian act1_daffc9c7:

    # s hm "I never said that."
    s hm "Non ho mai detto una cosa del genere."

# game/act1.rpy:2605
translate italian act1_0050a61e:

    # a frown "You implied it."
    a frown "Lo hai sottinteso."

# game/act1.rpy:2606
translate italian act1_2c04a831:

    # s cocky "I imply a lot of things."
    s cocky "Insinuare molte cose."

# game/act1.rpy:2607
translate italian act1_4a530c3d_3:

    # a hm "…"
    a hm "…"

# game/act1.rpy:2609
translate italian act1_33ed8eeb:

    # "Whatever the fuck {i}that{/i} means."
    "Qualunque cosa significhi {i}quello{/i}."

# game/act1.rpy:2613
translate italian act1_c3490153:

    # a frown "How did you know you’d win?"
    a frown "Come hai fatto a sapere che avresti vinto?"

# game/act1.rpy:2614
translate italian act1_dc1cd401:

    # s "Hm?"
    s "Mh?"

# game/act1.rpy:2615
translate italian act1_55f4c34b:

    # a "The poker game. How’d you win?"
    a "La partita a poker. Come hai vinto?"

# game/act1.rpy:2619
translate italian act1_4a229730:

    # s "Oh, that?{w} I just got lucky."
    s "Oh, quello?{w} Ho avuto solo fortuna."

# game/act1.rpy:2621
translate italian act1_25a8eca1:

    # a concern "What?"
    a concern "Che cosa?"

# game/act1.rpy:2622
translate italian act1_77e938bf:

    # s "I had no idea what was going to happen there. I figured he’d challenge me to a regular game of poker, not that four-card bullshit. But, it worked out for me in the end."
    s "Non avevo idea di cosa sarebbe successo lì. Pensavo mi avrebbe sfidato a una normale partita a poker, non a quella roba da quattro carte. Ma alla fine mi è andata bene."

# game/act1.rpy:2624
translate italian act1_a8e3956a:

    # s "A little anticlimactic, but hey. That’s just how gambling is. Highs and lows."
    s "Un finale un po' deludente, ma tant'è. Il gioco d'azzardo è fatto così: alti e bassi."

# game/act1.rpy:2625
translate italian act1_d8eb5386_5:

    # a scared "…"
    a scared "…"

# game/act1.rpy:2627
translate italian act1_e2debb73:

    # a "You risked fifty-thousand dollars on a game you weren’t even sure you’d win? How would you have paid it off if you lost?!"
    a "Hai rischiato cinquantamila dollari in una partita di cui non eri nemmeno sicuro di vincere? Come avresti fatto a ripagare il debito se avessi perso?!"

# game/act1.rpy:2629
translate italian act1_86721776:

    # "Sebas just keeps on twirling the straw, an amused smile on his face as he stares at the table."
    "Sebas continua a far roteare la cannuccia, con un sorriso divertito sul volto mentre fissa il tavolo."

# game/act1.rpy:2631
translate italian act1_ce37b945:

    # s "I have my ways. As for the risk…"
    s "Ho i miei metodi. Quanto al rischio…"

# game/act1.rpy:2632
translate italian act1_2263cd3a:

    # s smile "If you don’t risk, you’re guaranteed to fail. If you do risk, there’s at least a chance you’ll win. One percent is better than zero, no?"
    s smile "Se non rischi, il fallimento è assicurato. Se rischi, c'è almeno una possibilità di vincere. L'uno per cento è meglio di zero, no?"

# game/act1.rpy:2634
translate italian act1_1f0b38f8:

    # a concern "That’s... an insane mentality to have."
    a concern "Questa è... una mentalità folle."

# game/act1.rpy:2635
translate italian act1_50c44be2:

    # s flirty "Hah. Maybe. But you have to be a little crazy to gamble in the first place."
    s flirty "Ah. Forse. Ma bisogna essere un po' pazzi per iniziare a giocare d'azzardo."

# game/act1.rpy:2637
translate italian act1_af14fc33:

    # "The waitress comes back and sets Sebas’ pie in front of him, and he gives her a kind smile. To my surprise, she returns it, despite her grumpy demeanor."
    "La cameriera torna e posa la torta di Sebas davanti a lui, e lui le rivolge un gentile sorriso. Con mia sorpresa, lei gliela restituisce, nonostante il suo atteggiamento scontroso."

# game/act1.rpy:2638
translate italian act1_21a27e21:

    # "I watch as he shovels a large forkful of lukewarm apple pie down his maw, thinking back to our meeting at Shogey’s, then The Albatross, then in Matteo’s ring…"
    "Lo guardo mentre si ingozza con una grossa forchettata di torta di mele tiepida, ripensando al nostro incontro da Shogey's, poi all'Albatross, e infine sul ring di Matteo..."

# game/act1.rpy:2642
translate italian act1_3de5b904:

    # a stan "What are you after?"
    a stan "Che cosa cerchi?"

# game/act1.rpy:2644
translate italian act1_0cc3caa6:

    # s "How do you mean?"
    s "In che modo vuoi dire?"

# game/act1.rpy:2646
translate italian act1_e8977957:

    # a frown "You asked me for a place to gamble even though you knew about The Albatross and Corona’s. You approached me at the bar to tell me how to get inside, and then proceeded to follow me in without my knowledge."
    a frown "Mi hai chiesto un posto dove giocare d'azzardo pur sapendo dell'Albatross e del Corona's. Mi hai avvicinato al bar per dirmi come entrare, e poi mi hai seguito all'interno senza che io me ne accorgessi."

# game/act1.rpy:2647
translate italian act1_1c24b1d1:

    # a angry "And to top it all off, spied on my poker game and saved me from the con. All of that… for what?"
    a angry "E per finire, mi ha spiato durante una partita a poker e mi ha salvato dalla truffa. Tutto questo... per cosa?"

# game/act1.rpy:2648
translate italian act1_62f30686:

    # a "What are you after, ‘Sebas’? Is that even your real name?"
    a "Che cosa vuoi, \"Sebas\"? È davvero il tuo vero nome?"

# game/act1.rpy:2651
translate italian act1_f5a2cffe:

    # s "Is ‘Angel’ yours?"
    s "'Angel' è tuo?"

# game/act1.rpy:2653
translate italian act1_4b6e6cdc_1:

    # a dejected "…"
    a dejected "…"

# game/act1.rpy:2654
translate italian act1_637cdec1:

    # s lookaway "What I’m after…"
    s lookaway "Quello che cerco…"

# game/act1.rpy:2656
translate italian act1_3bc4a639:

    # "He shoves another bite of pie into his mouth, looking right back at me."
    "Si infila un altro boccone di torta in bocca, guardandomi dritto negli occhi."

# game/act1.rpy:2658
translate italian act1_6424958f:

    # s hm "I wouldn’t say I’m ‘after’ anything. But I do have a dream."
    s hm "Non direi di essere \"alla ricerca\" di qualcosa in particolare. Ma ho un sogno."

# game/act1.rpy:2660
translate italian act1_d1f43556:

    # a concern "A dream?"
    a concern "Un sogno?"

# game/act1.rpy:2661
translate italian act1_8c6d0fc6:

    # s smile "Yes. Don’t you?"
    s smile "Sì. Tu no?"

# game/act1.rpy:2662
translate italian act1_2a4ff97c_14:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:2663
translate italian act1_9fdcdf03:

    # a bashful "You’re the second person to ask me that today…"
    a bashful "Sei la seconda persona che me lo chiede oggi…"

# game/act1.rpy:2666
translate italian act1_d9400327:

    # a dejected "No. I don’t have a dream."
    a dejected "No. Non ho un sogno."

# game/act1.rpy:2667
translate italian act1_83d61407:

    # a "I’m a Valentine. We don’t get to dream."
    a "Sono una Valentine. Noi non possiamo sognare."

# game/act1.rpy:2668
translate italian act1_8d51f30f:

    # s "Everyone is allowed to dream. Your thoughts are the one thing that are completely your own."
    s "Ognuno ha il diritto di sognare. I tuoi pensieri sono l'unica cosa che ti appartiene completamente."

# game/act1.rpy:2670
translate italian act1_993ceb94:

    # s "I believe you have a dream, somewhere inside you. You must be too scared to admit what it is."
    s "Credo che tu abbia un sogno, da qualche parte dentro di te. Devi essere troppo spaventato per ammettere di cosa si tratta."

# game/act1.rpy:2672
translate italian act1_da553f34:

    # s "Because then… you’ll want to fight for that dream."
    s "Perché allora… vorrai lottare per quel sogno."

# game/act1.rpy:2673
translate italian act1_1ab72481_19:

    # a concern "…"
    a concern "…"

# game/act1.rpy:2674
translate italian act1_d19f2b16:

    # a hm "Well… what’s your dream?"
    a hm "Beh... qual è il tuo sogno?"

# game/act1.rpy:2676
translate italian act1_098210d1:

    # s lookaway "My dream…"
    s lookaway "Il mio sogno…"

# game/act1.rpy:2678
translate italian act1_4c3e40c5:

    # "He looks out the window to the deserted streets of Sonora… or, maybe at his own reflection against the glass. I’m not sure. But his eyes keep that razor sharp focus they always seem to have."
    "Guarda fuori dalla finestra, verso le strade deserte di Sonora… o forse verso il suo riflesso sul vetro. Non ne sono sicuro. Ma i suoi occhi mantengono quella nitidezza penetrante che sembra sempre avere."

# game/act1.rpy:2681
translate italian act1_ee7d02fe:

    # s stan "My dream…{w} is to destroy Corona’s Casino."
    s stan "Il mio sogno...{w} è distruggere il casinò di Corona."

# game/act1.rpy:2684
translate italian act1_876081e6:

    # "And then he takes another bite, as if he didn’t just say that."
    "E poi dà un altro morso, come se non l'avesse appena detto."

# game/act1.rpy:2691
translate italian act1_f453af24:

    # "We spend the rest of our time there in silence. I offer to pay Sebas for the pie, as a thank you for saving me, but he simply shoos me away. Something about being a gentleman."
    "Trascorriamo il resto del tempo lì in silenzio. Mi offro di pagare la torta a Sebas, come ringraziamento per avermi salvato, ma lui mi manda via con un gesto della mano. Qualcosa a proposito di essere un gentiluomo."

# game/act1.rpy:2692
translate italian act1_140cfe4a:

    # "We walk outside again, and Sebas stays by my side as we wait for a cab to pass by. I’m exhausted, my brain feels foggy, and my nerves are at high alert. I feel like my entire body is buzzing with anxiety."
    "Usciamo di nuovo e Sebas mi resta accanto mentre aspettiamo che passi un taxi. Sono esausta, ho la mente annebbiata e i nervi a fior di pelle. Sento che tutto il corpo mi vibra per l'ansia."

# game/act1.rpy:2693
translate italian act1_e59a4cf9:

    # "I sneak a glance at the wolf next to me, wondering when the hell I got caught in his web. There’s more, so much more I want to talk about, to ask, to wring out of him… but I know I can’t right now."
    "Lancio un'occhiata furtiva al lupo accanto a me, chiedendomi quando diavolo sono finita nella sua tela. C'è molto altro di cui vorrei parlare, che vorrei chiedergli, che vorrei estorcergli... ma so che non posso adesso."

# game/act1.rpy:2695
translate italian act1_e32b913d:

    # "A cab finally stops in front of us, and Sebas opens the back door for me. I’m about to slip inside the taxi when he and I lock eyes… {w}and my heart skips a beat."
    "Finalmente un taxi si ferma davanti a noi e Sebas mi apre la portiera posteriore. Sto per salire quando i nostri sguardi si incrociano... {w}e il mio cuore perde un battito."

# game/act1.rpy:2697
translate italian act1_7354f530:

    # "Sebas… those eyes seem to hold a familar sadness behind them. Why do I feel like I've seen them before?{w} What secrets lie beyond that smile?"
    "Sebas… quegli occhi sembrano celare una tristezza familiare. Perché ho la sensazione di averli già visti? Quali segreti si celano dietro quel sorriso?"

# game/act1.rpy:2699
translate italian act1_2350b82d:

    # "And why do I want to find out?"
    "E perché voglio scoprirlo?"

# game/act1.rpy:2702
translate italian act1_9cea01bb:

    # a worried "Sebas…?"
    a worried "Sebas…?"

# game/act1.rpy:2703
translate italian act1_a98b773d:

    # s smile "Yes, {i}chele?"
    s smile "Sì, {i}chele?"

# game/act1.rpy:2706
translate italian act1_44afa7d6:

    # a concern "Your dream…{w} I want to help make it a reality."
    a concern "Il tuo sogno...{w} Voglio aiutarti a realizzarlo."

# game/act1.rpy:2708
translate italian act1_2d4376b0_4:

    # s "…"
    s "…"

# game/act1.rpy:2710
translate italian act1_10860cc7:

    # "The words slip out of my mouth before I can stop them, and as I’m left wondering why I even said that, Sebas just smiles at me."
    "Le parole mi sfuggono di bocca prima che io possa fermarle, e mentre mi chiedo perché mai le abbia dette, Sebas mi sorride."

# game/act1.rpy:2712
translate italian act1_6162e889:

    # s flirty "Yeah? Well… I’ll be counting on you then, {i}chele."
    s flirty "Sì? Bene… allora conto su di te, {i}chele."

# game/act1.rpy:2713
translate italian act1_06f39335_6:

    # a stan "…"
    a stan "…"

# game/act1.rpy:2718
translate italian act1_deb8044f:

    # "As the driver takes me home, Corona’s peeks through the cluster of buildings in this dark city, making its presence known at every possible second of my existence."
    "Mentre l'autista mi riporta a casa, Corona fa capolino tra gli edifici di questa città buia, rendendo nota la sua presenza in ogni singolo istante della mia esistenza."

# game/act1.rpy:2719
translate italian act1_4f19e8a8:

    # "Mr. Gray must be in there now, sitting in his big, fancy desk, doing whatever it is that billionaires do in their free time. Is he thinking of me, the way I am thinking of him now?"
    "Il signor Gray dev'essere lì dentro adesso, seduto alla sua grande e lussuosa scrivania, a fare chissà cosa fanno i miliardari nel loro tempo libero. Starà pensando a me, come io sto pensando a lui ora?"

# game/act1.rpy:2720
translate italian act1_955e99a8:

    # "The offer to change my life seemed so ludicrous at the time. Now I wonder… if I should have taken it after all?"
    "L'offerta di cambiarmi la vita mi sembrava così assurda all'epoca. Ora mi chiedo... se avrei dovuto accettarla, dopotutto?"

# game/act1.rpy:2722
translate italian act1_ff41eb96:

    # "I guess it doesn’t matter anymore."
    "Immagino che ormai non importi più."

# game/act1.rpy:2725
translate italian act1_21c30658:

    # "After all... {w}this game has only just begun."
    "Dopotutto... {w}questo gioco è appena iniziato."

# game/act1.rpy:2727
translate italian act1_b6238fae:

    # "{i}To Be Continued…"
    "{i}Continua…"

