﻿translate italian strings:

    # game/screens.rpy:251
    old "Back"
    new "Indietro"

    # game/screens.rpy:252
    old "History"
    new "Storia"

    # game/screens.rpy:253
    old "Skip"
    new "Saltare"

    # game/screens.rpy:254
    old "Auto"
    new "Auto"

    # game/screens.rpy:255
    old "Save"
    new "Salva"

    # game/screens.rpy:256
    old "Q.Save"
    new "Q.Salva"

    # game/screens.rpy:257
    old "Q.Load"
    new "Q.Carica"

    # game/screens.rpy:258
    old "Prefs"
    new "Preferenze"

    # game/screens.rpy:276
    old "Menu"
    new "Menu"

    # game/screens.rpy:315
    old "Return"
    new "Ritorno"

    # game/screens.rpy:319
    old "Start"
    new "Inizio"

    # game/screens.rpy:321
    old "Main Menu"
    new "Menù principale"

    # game/screens.rpy:324
    old "Load"
    new "Carico"

    # game/screens.rpy:327
    old "Preferences"
    new "Preferenze"

    # game/screens.rpy:330
    old "About"
    new "Di"

    # game/screens.rpy:333
    old "Quit"
    new "Esentato"

    # game/screens.rpy:575
    old "Version [config.version!t]\n"
    new "Versione [config.version!t]\n"

    # game/screens.rpy:582
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t] \n\nGame by {a=https://twitter.com/konpeitocat}Konpeito{/a} \n\nMusic:\n'dans la nuit' - Fred Irie \n'last hours' - Qazers \n'EARLY SUMMER' - Tokyo Music Walker \n'Casino Jazz' - Pink Banana \n'STARLIGHT' - Prod.RYOICHI! \n'think of you' - sickboi \n'Noire #1' - MusicByPedro \n'want u to know' - connor \n'Evidence' - soundridemusic \n'Velvet' - Oak Studios \n'jupiter' - prod. phil! \n'moonlight' - waves \n'Noire #3' - MusicByPedro \n'A World of Blue (Instrumental' - Matthew Pablo \n'I Remember' - Giorgio Di Campo \n'Dinero' - Crue Beats \n\n\nSpecial Thanks to: \nTeirisu Reynard \nLost Fox \nArkynAlvarez \nMary \nKusabi \ndel \nYoDatsCrazy \nAlastor TND \nLaz \nTheHWolf94 \nZIHE WANG \n Easton Euros \nsandpeach \nSnowflake22245 \nGirrith \nPlor \nDaniel \nJonathan Buffoni \nBrxce \nOceanBlu \nAriadne \nAl \nFirstGuard \ntiddy_boi \nomndragon"
    new "Realizzato con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t] \n\nGioco di {a=https://twitter.com/konpeitocat}Konpeito{/a} \n\nMusica:\n'dans la nuit' - Fred Irie \n'last hours' - Qazers \n'EARLY SUMMER' - Tokyo Music Walker \n'Casino Jazz' - Pink Banana \n'STARLIGHT' - Prod.RYOICHI! \n'think of you' - sickboi \n'Noire #1' - MusicByPedro \n'want u to know' - connor \n'Evidence' - soundridemusic \n'Velvet' - Oak Studios \n'jupiter' - prod. phil! \n'moonlight' - Waves \n'Noire #3' - MusicByPedro \n'A World of Blue (Instrumental' - Matthew Pablo \n'I Remember' - Giorgio Di Campo \n'Dinero' - Crue Beats \n\n\nRingraziamenti speciali a: \nTeirisu Reynard \nLost Fox \nArkynAlvarez \nMary \nKusabi \ndel \nYoDatsCrazy \nAlastor TND \nLaz \nTheHWolf94 \nZIHE WANG \n Easton Euros \nsandpeach \nSnowflake22245 \nGirrith \nPlor \nDaniel \nJonathan Buffoni \nBrxce \nOceanBlu \nAriadne \nAl \nPrimaGuardia \ntiddy_boi \nomndragon"

    # game/screens.rpy:620
    old "Page {}"
    new "Pagina {}"

    # game/screens.rpy:620
    old "Automatic saves"
    new "Salvataggi automatici"

    # game/screens.rpy:620
    old "Quick saves"
    new "Salvataggi rapidi"

    # game/screens.rpy:663
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:663
    old "empty slot"
    new "slot vuoto"

    # game/screens.rpy:684
    old "<"
    new "<"

    # game/screens.rpy:688
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:691
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:701
    old ">"
    new ">"

    # game/screens.rpy:706
    old "Upload Sync"
    new "Caricamento sincronizzazione"

    # game/screens.rpy:713
    old "Download Sync"
    new "Scarica sincronizzazione"

    # game/screens.rpy:777
    old "Display"
    new "Display"

    # game/screens.rpy:778
    old "Window"
    new "Finestra"

    # game/screens.rpy:779
    old "Fullscreen"
    new "A schermo intero"

    # game/screens.rpy:784
    old "Unseen Text"
    new "Testo nascosto"

    # game/screens.rpy:785
    old "After Choices"
    new "Dopo le scelte"

    # game/screens.rpy:786
    old "Transitions"
    new "Transizioni"

    # game/screens.rpy:789
    old "Menu Theme"
    new "Tema del menu"

    # game/screens.rpy:793
    old "Default"
    new "Predefinito"

    # game/screens.rpy:804
    old "Language"
    new "Lingua"

    # game/screens.rpy:805
    old "English"
    new "Inglese"

    # game/screens.rpy:806
    old "Spanish"
    new "spagnolo"

    # game/screens.rpy:807
    old "Italian"
    new "Italiano"

    # game/screens.rpy:817
    old "Text Speed"
    new "Velocità del testo"

    # game/screens.rpy:821
    old "Auto-Forward Time"
    new "Avanzamento automatico dell'ora"

    # game/screens.rpy:828
    old "Music Volume"
    new "Volume musicale"

    # game/screens.rpy:835
    old "Sound Volume"
    new "Volume del suono"

    # game/screens.rpy:841
    old "Test"
    new "Test"

    # game/screens.rpy:845
    old "Voice Volume"
    new "Volume vocale"

    # game/screens.rpy:856
    old "Mute All"
    new "Disattiva audio per tutti"

    # game/screens.rpy:975
    old "The dialogue history is empty."
    new "La cronologia dei dialoghi è vuota."

    # game/screens.rpy:1038
    old "Help"
    new "Aiuto"

    # game/screens.rpy:1047
    old "Keyboard"
    new "Tastiera"

    # game/screens.rpy:1048
    old "Mouse"
    new "Topo"

    # game/screens.rpy:1051
    old "Gamepad"
    new "Gamepad"

    # game/screens.rpy:1064
    old "Enter"
    new "Inserisci"

    # game/screens.rpy:1065
    old "Advances dialogue and activates the interface."
    new "Avanza il dialogo e attiva l'interfaccia."

    # game/screens.rpy:1068
    old "Space"
    new "Spazio"

    # game/screens.rpy:1069
    old "Advances dialogue without selecting choices."
    new "Fa avanzare il dialogo senza selezionare le opzioni."

    # game/screens.rpy:1072
    old "Arrow Keys"
    new "Tasti freccia"

    # game/screens.rpy:1073
    old "Navigate the interface."
    new "Esplora l'interfaccia."

    # game/screens.rpy:1076
    old "Escape"
    new "Fuga"

    # game/screens.rpy:1077
    old "Accesses the game menu."
    new "Consente di accedere al menu di gioco."

    # game/screens.rpy:1080
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1081
    old "Skips dialogue while held down."
    new "Salta i dialoghi finché si tiene premuto."

    # game/screens.rpy:1084
    old "Tab"
    new "Tab"

    # game/screens.rpy:1085
    old "Toggles dialogue skipping."
    new "Attiva/disattiva la possibilità di saltare i dialoghi."

    # game/screens.rpy:1088
    old "Page Up"
    new "Pagina su"

    # game/screens.rpy:1089
    old "Rolls back to earlier dialogue."
    new "Si torna al dialogo precedente."

    # game/screens.rpy:1092
    old "Page Down"
    new "Pagina giù"

    # game/screens.rpy:1093
    old "Rolls forward to later dialogue."
    new "Si passa poi a un dialogo successivo."

    # game/screens.rpy:1097
    old "Hides the user interface."
    new "Nasconde l'interfaccia utente."

    # game/screens.rpy:1101
    old "Takes a screenshot."
    new "Esegue uno screenshot."

    # game/screens.rpy:1105
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Attiva/disattiva la funzione di auto-vocalizzazione assistiva {a=https://www.renpy.org/l/voicing}."

    # game/screens.rpy:1109
    old "Opens the accessibility menu."
    new "Apre il menu di accessibilità."

    # game/screens.rpy:1115
    old "Left Click"
    new "Clic sinistro"

    # game/screens.rpy:1119
    old "Middle Click"
    new "Clic centrale"

    # game/screens.rpy:1123
    old "Right Click"
    new "clic destro"

    # game/screens.rpy:1127
    old "Mouse Wheel Up"
    new "Rotellina del mouse verso l'alto"

    # game/screens.rpy:1131
    old "Mouse Wheel Down"
    new "Rotellina del mouse verso il basso"

    # game/screens.rpy:1138
    old "Right Trigger\nA/Bottom Button"
    new "Grilletto destro\nA/Pulsante inferiore"

    # game/screens.rpy:1142
    old "Left Trigger\nLeft Shoulder"
    new "Grilletto sinistro\nSpalla sinistra"

    # game/screens.rpy:1146
    old "Right Shoulder"
    new "Spalla destra"

    # game/screens.rpy:1150
    old "D-Pad, Sticks"
    new "D-pad, levette"

    # game/screens.rpy:1154
    old "Start, Guide, B/Right Button"
    new "Pulsante Start, Guida, B/Destra"

    # game/screens.rpy:1158
    old "Y/Top Button"
    new "Pulsante Y/Superiore"

    # game/screens.rpy:1161
    old "Calibrate"
    new "Calibrare"

    # game/screens.rpy:1226
    old "Yes"
    new "SÌ"

    # game/screens.rpy:1227
    old "No"
    new "NO"

    # game/screens.rpy:1273
    old "Skipping"
    new "Saltare"

