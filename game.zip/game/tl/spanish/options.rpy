﻿translate spanish strings:

    # game/options.rpy:15
    old "Casino x Forte x Scandal"
    new "Casino x Forte x Scandal"

