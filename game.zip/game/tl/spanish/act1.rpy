﻿# game/act1.rpy:5
translate spanish act1_92fdd6e9:

    # centered "{i}Why…?"
    centered "{i}¿Por qué…?"

# game/act1.rpy:8
translate spanish act1_830ead0c:

    # "Within the city limits of Sonora, the people who reside here live and die by its motto: ‘Turn a penny into a million!’."
    "Dentro de los límites de la ciudad de Sonora, la gente que reside aquí vive y muere según su lema: \"¡Convierte un centavo en un millón!\"."

# game/act1.rpy:9
translate spanish act1_ed108da8:

    # "That’s right – even I started to foolishly believe it. That everyone within these lines was intellectual equals, and that all it took to become someone grand and elite was a little perseverance, a bit of skill… and a lot of luck."
    "Así es, incluso yo empecé a creerlo ingenuamente. Que todos los que estábamos dentro de ese círculo éramos intelectualmente iguales, y que para convertirse en alguien importante y de élite solo hacía falta un poco de perseverancia, algo de habilidad... y mucha suerte."

# game/act1.rpy:10
translate spanish act1_b97ff407:

    # "That, in the ocean of lights, in the sea of people, I could escape the bounds of being nothing more than a minnow, pulled by the current and helplessly toyed with by the sharks of this world."
    "Que, en el océano de luces, en el mar de gente, pudiera escapar de los límites de no ser más que un pececillo, arrastrado por la corriente y manipulado sin piedad por los tiburones de este mundo."

# game/act1.rpy:11
translate spanish act1_941dd8a9:

    # "But, just like sharks, the elites of this city can’t stop moving, even for a second. Those who do meet the same fate as their aquatic counterparts."
    "Pero, al igual que los tiburones, las élites de esta ciudad no pueden dejar de moverse ni un segundo. Quienes lo hacen, corren la misma suerte que sus contrapartes acuáticas."

# game/act1.rpy:12
translate spanish act1_df641876:

    # "And that meant the most dangerous enemy to a shark, who cannot sleep… is the foolish minnow who dares to dream."
    "Y eso significaba que el enemigo más peligroso para un tiburón, que no puede dormir... es el pececillo tonto que se atreve a soñar."

# game/act1.rpy:14
translate spanish act1_5cbebd49:

    # centered "{i}So, why…?"
    centered "{i}Entonces, ¿por qué…?"

# game/act1.rpy:16
translate spanish act1_ce1d5703:

    # tr_text "Well, then. That’s… how much? Oh, right…"
    tr_text "Bueno, entonces. Eso es… ¿cuánto? Ah, claro…"

# game/act1.rpy:19
translate spanish act1_cb241121:

    # tr_text2 "Twelve-thousand dollars. You have the money, don’t you?"
    tr_text2 "Doce mil dólares. Tienes el dinero, ¿verdad?"

# game/act1.rpy:20
translate spanish act1_44d3afcd:

    # tr_text3 "Aw, don't look so distraught. \nSorry to clip your wings, Valentine."
    tr_text3 "Ay, no te veas tan angustiada. \nSiento cortarte las alas, Valentine."

# game/act1.rpy:21
translate spanish act1_a9ed576d:

    # tr_text "But you really should’ve known better~"
    tr_text "Pero realmente deberías haberlo sabido~"

# game/act1.rpy:26
translate spanish act1_ef767577:

    # "…or so I thought."
    "…o eso creía yo."

# game/act1.rpy:27
translate spanish act1_6ca22e14:

    # "But sometimes, a fool isn’t a visionary, a secret genius whose ways of thinking defy the norm and set you free."
    "Pero a veces, un tonto no es un visionario, un genio secreto cuyas formas de pensar desafían la norma y te liberan."

# game/act1.rpy:29
translate spanish act1_f105c54a:

    # centered "Why… was I so stupid?!"
    centered "¿Por qué... fui tan estúpido?"

# game/act1.rpy:32
translate spanish act1_fbd7b7f9:

    # "Sometimes… {w}a fool is just a fool."
    "A veces… {w}un tonto es solo un tonto."

# game/act1.rpy:35
translate spanish act1_6962edba:

    # centered "24 hours earlier.{w}\nHanasaka Bar & Inn"
    centered "24 horas antes.{w}\nHanasaka Bar & Inn"

# game/act1.rpy:39
translate spanish act1_a2abb429:

    # "Light reflects from the rain-soaked asphalt like a hazy mirror, rippling on occasion from the droplets still falling to the ground."
    "La luz se refleja en el asfalto empapado por la lluvia como en un espejo empañado, creando ondulaciones ocasionales debido a las gotas que aún caen al suelo."

# game/act1.rpy:40
translate spanish act1_e814e384:

    # "The signs hanging overhead are a bright, deep red, making my fur shine pink in its neon glow. I bathe in it, lingering for just a second longer than I know I should."
    "Los letreros que cuelgan sobre mí son de un rojo intenso y brillante, que hace que mi pelaje resplandezca de color rosa con su resplandor neón. Me sumerjo en él, deteniéndome un segundo más de lo que debería."

# game/act1.rpy:41
translate spanish act1_48f93f51:

    # "Maybe it suits me. At least, more than white does... God knows I don’t match the purity my snow-colored fur exudes."
    "Tal vez me sienta bien. Al menos, mejor que el blanco... Dios sabe que no estoy a la altura de la pureza que emana mi pelaje color nieve."

# game/act1.rpy:43
translate spanish act1_b8f76885:

    # "I’m stalling."
    "Estoy ganando tiempo."

# game/act1.rpy:44
translate spanish act1_6523784f:

    # "I know I am, but even so, I let myself stay still for a few seconds longer, steeling myself for the exchange that’s to come."
    "Sé que lo estoy, pero aun así, me permito permanecer quieto unos segundos más, preparándome para el intercambio que está por venir."

# game/act1.rpy:45
translate spanish act1_92e359d9:

    # "I should be used to it by now. Interviewing is my least favorite part of my job, but it’s also the most important. So, I do what I always do: I swallow down my own desires and focus on what needs to be done."
    "Ya debería estar acostumbrada. Las entrevistas son la parte que menos me gusta de mi trabajo, pero también la más importante. Así que hago lo de siempre: dejo de lado mis deseos y me concentro en lo que hay que hacer."

# game/act1.rpy:46
translate spanish act1_2cb4dfb8:

    # "With one last exhale, I put my best poker face on and enter the bar."
    "Tras un último suspiro, puse mi mejor cara de póker y entré en el bar."

# game/act1.rpy:51
translate spanish act1_6fe08d8f:

    # "It’s cold inside, contrasting the humid post-rain air of the city streets. Someone plays a piano quietly across the bar, and idle chatter resonates throughout the room."
    "Adentro hace frío, en contraste con el aire húmedo de las calles de la ciudad tras la lluvia. Alguien toca el piano suavemente al otro lado de la barra, y el murmullo de las conversaciones resuena por toda la sala."

# game/act1.rpy:52
translate spanish act1_fd201b63:

    # "It’s fancier than the bars I’m accustomed to, but I relax my shoulders, casually scanning the room while I pretend to fit right in with these higher-class people."
    "Es más elegante que los bares a los que estoy acostumbrado, pero relajo los hombros y echo un vistazo disimuladamente a la sala mientras finjo encajar perfectamente con esta gente de clase alta."

# game/act1.rpy:53
translate spanish act1_baf2c34d:

    # "It doesn’t take long to find him. Sitting alone in a corner booth, drinking what appears to be whiskey, Mr. Yoshida stares out the rain-splattered window, deep in thought. I quietly walk towards him, and without a word, slip into the booth in front of him."
    "No tardé en encontrarlo. Sentado solo en una cabina de la esquina, bebiendo lo que parecía ser whisky, el señor Yoshida miraba por la ventana salpicada por la lluvia, sumido en sus pensamientos. Me acerqué sigilosamente y, sin decir palabra, me senté en la cabina frente a él."

# game/act1.rpy:55
translate spanish act1_9c3bb6cd:

    # a uniform stan "…"
    a uniform stan "…"

# game/act1.rpy:57
translate spanish act1_8670a23c:

    # "Although I’m certain he knows I’m here, he doesn’t turn to face me, his eyes fixed outside in a trance-like state. I clear my throat to get his attention. If he’s dragging this out on purpose, I want none of it."
    "Aunque estoy segura de que sabe que estoy aquí, no se gira para mirarme; sus ojos están fijos en el exterior, como en trance. Me aclaro la garganta para llamar su atención. Si está alargando esto a propósito, no quiero saber nada de eso."

# game/act1.rpy:58
translate spanish act1_27bbfe2c:

    # "He finally turns to look at me, a far-off look in his eyes as he measures me up, his gaze locked on me."
    "Finalmente se vuelve para mirarme, con la mirada perdida mientras me evalúa, con la mirada fija en mí."

# game/act1.rpy:60
translate spanish act1_ee4a9501:

    # y "Ah… good evening, Valentine. A pleasure to finally meet you."
    y "Ah… buenas noches, Valentine. Un placer conocerte finalmente."

# game/act1.rpy:61
translate spanish act1_d91e2571:

    # a "{i}Yoroshiku onegai shimasu, Mr. Yoshida."
    a "{i}Yoroshiku onegai shimasu, Sr. Yoshida."

# game/act1.rpy:63
translate spanish act1_86388077:

    # "He smiles, genuinely, and chuckles as he brings the glass to his maw."
    "Sonríe sinceramente y se ríe entre dientes mientras se lleva el vaso a la boca."

# game/act1.rpy:65
translate spanish act1_7ab080c1:

    # y "{i}Kochira koso… Yoru ga ii janai ka?"
    y "{i}Kochira koso… Yoru ga ii janai ka?"

# game/act1.rpy:68
translate spanish act1_77f14b59:

    # a bashful "U-um… sorry. ‘Nice to meet you’ and ‘Where’s the bathroom?’ are kind of the extent of my Japanese."
    a bashful "U-um… lo siento. 'Encantado de conocerte' y '¿Dónde está el baño?' son prácticamente todo mi conocimiento de japonés."

# game/act1.rpy:69
translate spanish act1_8a625145:

    # y cocky "Hah! Of course. My apologies. I simply said that tonight’s a nice night, isn’t it?"
    y cocky "¡Ja! Claro. Mis disculpas. Simplemente dije que esta noche es una noche agradable, ¿no?"

# game/act1.rpy:71
translate spanish act1_f51c1138:

    # "I glance out the window. Steam rises from the ground as the cold rain meets the hot asphalt, and a small stream of dirt-colored water flows down the sidewalk."
    "Miro por la ventana. El vapor se eleva del suelo al chocar la lluvia fría con el asfalto caliente, y un pequeño riachuelo de agua color tierra corre por la acera."

# game/act1.rpy:73
translate spanish act1_dfa3e98f:

    # a stan "…if you think so."
    a stan "…si así lo crees."

# game/act1.rpy:74
translate spanish act1_827b836d:

    # y hm "You don’t?"
    y hm "¿No lo haces?"

# game/act1.rpy:75
translate spanish act1_7da94968:

    # a frown "I’m not a fan of the rain."
    a frown "No me gusta la lluvia."

# game/act1.rpy:76
translate spanish act1_b43f824b:

    # y smile "Hm~ I welcome it. It almost feels like someone up above is trying to wash this city free of sin."
    y smile "Hm~ Lo agradezco. Casi parece que alguien allá arriba está tratando de limpiar esta ciudad del pecado."

# game/act1.rpy:77
translate spanish act1_b6875aae:

    # y "Though, it may need to rain much longer for that to happen."
    y "Sin embargo, para que eso suceda, es posible que tenga que llover mucho más tiempo."

# game/act1.rpy:78
translate spanish act1_a7d70aab:

    # a stan "Hm."
    a stan "Hm."

# game/act1.rpy:80
translate spanish act1_41e5754b:

    # "He gives me a knowing smile, dripping with fake nicety."
    "Me dedica una sonrisa cómplice, cargada de falsa amabilidad."

# game/act1.rpy:82
translate spanish act1_6d8c5401:

    # y smile "Of course. You Valentines are all the same. All business, no pleasure."
    y smile "Por supuesto. Ustedes, los de San Valentín, son todos iguales. Todo negocios, nada de placer."

# game/act1.rpy:84
translate spanish act1_c86ca835:

    # "He leisurely takes out a cigar from his coat pocket, taking his time lighting it and sucking in a few puffs, his glassy eyes locked on me the whole time as he exhales the smoke against the window."
    "Saca tranquilamente un cigarro del bolsillo de su abrigo, se toma su tiempo para encenderlo y da unas cuantas caladas, con la mirada perdida en mí todo el tiempo mientras exhala el humo contra la ventana."

# game/act1.rpy:86
translate spanish act1_33c1a6a5:

    # y "Well, then."
    y "Bueno, entonces."

# game/act1.rpy:88
translate spanish act1_fed5782d:

    # y stan "Talk."
    y stan "Hablar."

# game/act1.rpy:89
translate spanish act1_4d8672f4:

    # a "…{w}right."
    a "…{w}correcto."

# game/act1.rpy:91
translate spanish act1_464483f8:

    # "I slide my voice recorder and notebook onto the table, pen in hand, mirroring his stare."
    "Deslicé mi grabadora de voz y mi cuaderno sobre la mesa, con el bolígrafo en la mano, reflejando su mirada."

# game/act1.rpy:93
translate spanish act1_8879b358:

    # "He blinks.{w} I blink back."
    "Él parpadea.{w} Yo le devuelvo el parpadeo."

# game/act1.rpy:95
translate spanish act1_453bb462:

    # a frown "Megumi Yoshida went missing on March 21st of this year, approximately three months ago. Her last whereabouts are unknown, and the cause of her disappearance has also been questioned."
    a frown "Megumi Yoshida desapareció el 21 de marzo de este año, hace aproximadamente tres meses. Se desconoce su último paradero y se han planteado interrogantes sobre la causa de su desaparición."

# game/act1.rpy:97
translate spanish act1_c17d2bbe:

    # y frown "Yes. I’m quite aware of all this, Valentine."
    y frown "Sí. Estoy muy al tanto de todo esto, Valentine."

# game/act1.rpy:99
translate spanish act1_e999472e:

    # "He almost hisses this out, the pleasantness he once evoked now nowhere to be seen behind his glare."
    "Casi lo susurra con un siseo, y la amabilidad que antes evocaba ahora no se vislumbra por ninguna parte tras su mirada fulminante."

# game/act1.rpy:100
translate spanish act1_61821a83:

    # "I swallow hard.{w} I was never any good at stating the facts."
    "Trago saliva con dificultad.{w} Nunca he sido bueno para decir los hechos."

# game/act1.rpy:102
translate spanish act1_33e16fde:

    # a worried "Right… of course. Moving on…"
    a worried "Claro… por supuesto. Sigamos…"

# game/act1.rpy:103
translate spanish act1_b764639b:

    # a concern "The police reports I’ve been granted are full of confidential information. That is to say, I haven’t gotten very far with them."
    a concern "Los informes policiales que me han facilitado están llenos de información confidencial. Es decir, no he podido avanzar mucho con ellos."

# game/act1.rpy:104
translate spanish act1_0e189f54:

    # a frown "I have little information about her disappearance, and even less about her life before that. Considering you’re the only family member listed on her records, I was hoping you could shed some light on who she was."
    a frown "Tengo poca información sobre su desaparición, y aún menos sobre su vida antes de eso. Dado que usted es el único familiar que figura en sus registros, esperaba que pudiera arrojar algo de luz sobre quién era."

# game/act1.rpy:105
translate spanish act1_02d38658:

    # a worried "Perhaps it could help us find her."
    a worried "Quizás eso nos ayude a encontrarla."

# game/act1.rpy:106
translate spanish act1_c046734e:

    # y stan "…"
    y stan "…"

# game/act1.rpy:108
translate spanish act1_1d5f96ff:

    # "He lets out another puff of smoke, tapping the table with one finger, staring at my hand holding the pen. I try to hide my shakiness, but something tells me he’s caught onto it."
    "Exhala otra bocanada de humo, tamborilea sobre la mesa con un dedo y se queda mirando mi mano que sostiene el bolígrafo. Intento disimular mi nerviosismo, pero algo me dice que se ha dado cuenta."

# game/act1.rpy:110
translate spanish act1_0e153d47:

    # y frown "Don’t hide your questioning behind a façade of kindness, Valentine. It doesn’t suit your kind."
    y frown "No ocultes tus preguntas tras una fachada de amabilidad, Valentine. No va contigo."

# game/act1.rpy:111
translate spanish act1_14e13729:

    # a frown "…I assure you, that’s not what I’m doing."
    a frown "…Les aseguro que eso no es lo que estoy haciendo."

# game/act1.rpy:112
translate spanish act1_43ac0ca6:

    # y smile "Heh. Of course."
    y smile "Je. Por supuesto."

# game/act1.rpy:115
translate spanish act1_57cd2c5e:

    # y "Megumi was-{w} is… my niece."
    y "Megumi era-{w} es… mi sobrina."

# game/act1.rpy:116
translate spanish act1_abb8b7aa:

    # y ponder "My brother’s daughter. After his passing, he entrusted her and her brother to me. In a lot of ways, I’m more like her father than her uncle. But that’s a position I could never take."
    y ponder "La hija de mi hermano. Tras su fallecimiento, me la confió a mí, junto con su hermano. En muchos sentidos, soy más como su padre que como su tío. Pero esa es una posición que jamás podría adoptar."

# game/act1.rpy:118
translate spanish act1_25404381:

    # "His gaze returns to the outside, and I take the opportunity to jot some things down. To say I’m surprised he’s opening up to me so easily is an understatement, but I make sure to not let it show on my face."
    "Su mirada vuelve a posarse en el exterior, y aprovecho para anotar algunas cosas. Decir que me sorprende que se esté abriendo tan fácilmente es quedarse corto, pero me aseguro de que no se note en mi rostro."

# game/act1.rpy:119
translate spanish act1_d5949f6d:

    # "He continues."
    "Él continúa."

# game/act1.rpy:121
translate spanish act1_a88bfeab:

    # y "She was always a troublesome kid. Mixing with the bad crowds, no matter how many times I scolded her. She never learned… or perhaps she simply chose not to listen."
    y "Siempre fue una niña problemática. Se juntaba con malas compañías, por mucho que la regañara. Nunca aprendió… o quizás simplemente decidió no escuchar."

# game/act1.rpy:122
translate spanish act1_3e8c9b08:

    # a surprised "What kind of bad crowds?"
    a surprised "¿Qué clase de multitudes problemáticas?"

# game/act1.rpy:123
translate spanish act1_a506e366:

    # y "…"
    y "…"

# game/act1.rpy:124
translate spanish act1_2b3a4ab7:

    # y frown "She loved to roughhouse with boys. Pull pranks on teachers. It started off innocent in that way."
    y frown "Le encantaba jugar bruscamente con los chicos. Gastar bromas a los profesores. Empezó de forma inocente."

# game/act1.rpy:125
translate spanish act1_d1198d7a:

    # y "But then she grew up."
    y "Pero luego creció."

# game/act1.rpy:128
translate spanish act1_71dffd1c:

    # y stan "It was one vice after the other. First it was smoking, which I’m sure she caught from me. Then, it was liquor."
    y stan "Fue un vicio tras otro. Primero fue fumar, algo que estoy seguro que ella aprendió de mí. Luego, el alcohol."

# game/act1.rpy:130
translate spanish act1_639dd4a5:

    # y frown "And then…{w} it was gambling."
    y frown "Y entonces…{w} se trataba de apostar."

# game/act1.rpy:132
translate spanish act1_87c584fc:

    # "My fur stands on end."
    "Se me eriza el pelo."

# game/act1.rpy:133
translate spanish act1_03e5d30d:

    # a concern "…gambling?"
    a concern "…¿juego?"

# game/act1.rpy:134
translate spanish act1_29f07dd0:

    # y ponder "Yes. Gambling."
    y ponder "Sí. Apuestas."

# game/act1.rpy:135
translate spanish act1_f4c8dbb2:

    # y stan "You’re aware, aren’t you, Valentine? The heart of this city is gambling. The casinos are the veins, and money, the blood."
    y stan "Lo sabes, ¿verdad, Valentine? El corazón de esta ciudad es el juego. Los casinos son las venas, y el dinero, la sangre."

# game/act1.rpy:136
translate spanish act1_b0bb5786:

    # y "I figured that since she never knew poverty, never went hungry, she wouldn’t be interested in such an activity as foolish as that."
    y "Supuse que, dado que ella nunca conoció la pobreza ni pasó hambre, no estaría interesada en una actividad tan tonta como esa."

# game/act1.rpy:138
translate spanish act1_d9518279:

    # y frown "How wrong I was.{w} It's the rich who crave to use their money in such ways, not the poor. I see that now..."
    y frown "Qué equivocada estaba.{w} Son los ricos quienes ansían usar su dinero de esa manera, no los pobres. Ahora lo entiendo..."

# game/act1.rpy:139
translate spanish act1_835ac230:

    # y "Megumi lived to gamble. It was casino after casino… each one that kicked her out, she’d just find a new one, and if there weren’t any left, she’d find a more illegal way of doing it."
    y "Megumi vivía para apostar. Iba de casino en casino… cada vez que la echaban, encontraba otro, y si no quedaba ninguno, encontraba una forma más ilegal de hacerlo."

# game/act1.rpy:140
translate spanish act1_6cce9cd9:

    # y surprised "It was her drug, her breathing. The money we had saved for her to study… was gone in a matter of months."
    y surprised "Era su droga, su respiración. El dinero que habíamos ahorrado para que estudiara... se esfumó en cuestión de meses."

# game/act1.rpy:141
translate spanish act1_131acb26:

    # y frown "It’s one thing to be a gambler. It’s another thing to be a {i}terrible{/i} gambler."
    y frown "Una cosa es ser un jugador. Otra cosa es ser un jugador pésimo."

# game/act1.rpy:143
translate spanish act1_f220c059:

    # "He lets his cigar keep burning out, unable to put it back onto his lips."
    "Deja que su cigarro se consuma por completo, incapaz de volver a llevárselo a los labios."

# game/act1.rpy:145
translate spanish act1_3440713f:

    # y ponder "That…"
    y ponder "Eso…"

# game/act1.rpy:147
translate spanish act1_cec72d90:

    # y stan "Is all I feel like sharing with you today, Valentine."
    y stan "Es todo lo que me apetece compartir contigo hoy, San Valentín."

# game/act1.rpy:148
translate spanish act1_1e9598f8:

    # a worried "…"
    a worried "…"

# game/act1.rpy:149
translate spanish act1_96a00ba1:

    # a "Could you please just tell me… where you last saw her?"
    a "¿Podrías decirme, por favor, dónde la viste por última vez?"

# game/act1.rpy:150
translate spanish act1_a506e366_1:

    # y "…"
    y "…"

# game/act1.rpy:152
translate spanish act1_4b9d0a7f:

    # y frown "In my house.{w} Two years ago."
    y frown "En mi casa.{w} Hace dos años."

# game/act1.rpy:153
translate spanish act1_1f805e02:

    # y stan "She moved out. And I never saw her again."
    y stan "Se mudó. Y nunca más la volví a ver."

# game/act1.rpy:154
translate spanish act1_923fbe92:

    # y ponder "Until her picture showed up on the news."
    y ponder "Hasta que su foto apareció en las noticias."

# game/act1.rpy:157
translate spanish act1_1b640637:

    # a "I’m… terribly sorry, Mr. Yoshida."
    a "Lo siento muchísimo, señor Yoshida."

# game/act1.rpy:158
translate spanish act1_4714fc24:

    # y ponder "Don’t be."
    y ponder "No lo seas."

# game/act1.rpy:159
translate spanish act1_e9736e8e:

    # y frown "If she chose to be insolent and reckless, then whatever fate she met was what she deserved."
    y frown "Si optó por ser insolente e imprudente, entonces cualquier destino que le deparara sería el que se merecía."

# game/act1.rpy:161
translate spanish act1_e9137f27:

    # "His voice doesn’t waver when he says this. Yet, somehow, I don’t believe he truly means it."
    "Su voz no tiembla al decir esto. Sin embargo, de alguna manera, no creo que lo diga en serio."

# game/act1.rpy:163
translate spanish act1_e09f4140:

    # "I close my notebook, sighing quietly through my nose. Although there’s still a lot I’d like to ask, I decide not to push my luck. Any information is good information, and I’ll just have to make do with what I have."
    "Cierro mi cuaderno y suspiro suavemente por la nariz. Aunque todavía tengo muchas preguntas, decido no tentar a la suerte. Cualquier información es útil, y tendré que conformarme con lo que tengo."

# game/act1.rpy:165
translate spanish act1_36fe7ade:

    # a frown "Well, I appreciate you giving me your time, Mr. Yoshida. I promise you; I’m doing what I can to try and bring this story to light."
    a frown "Bueno, le agradezco que me haya dedicado su tiempo, señor Yoshida. Le prometo que estoy haciendo todo lo posible para sacar a la luz esta historia."

# game/act1.rpy:167
translate spanish act1_be487d7f:

    # "He sneers at me, a cynical air to his grin."
    "Me mira con desprecio, con una sonrisa cínica."

# game/act1.rpy:169
translate spanish act1_02544cc6:

    # y "I don’t doubt that. I’m sure this ‘story’ is of utmost importance to you."
    y "No lo dudo. Estoy seguro de que esta \"historia\" es de suma importancia para usted."

# game/act1.rpy:170
translate spanish act1_66a5e221:

    # y "After all, you get a nice reward if you solve it, don’t you?"
    y "Al fin y al cabo, obtendrás una buena recompensa si lo resuelves, ¿no?"

# game/act1.rpy:171
translate spanish act1_2a4ff97c:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:172
translate spanish act1_9ac41913:

    # a worried "Like I said, Mr. Yoshida, that has nothing to do with my desire to find Ms. Megumi."
    a worried "Como ya le dije, señor Yoshida, eso no tiene nada que ver con mi deseo de encontrar a la señorita Megumi."

# game/act1.rpy:174
translate spanish act1_7c4aef21:

    # y smile "Lying doesn’t suit you, Valentine. Perhaps it’s a good thing you, of all people, don’t gamble."
    y smile "Mentir no te sienta bien, Valentine. Quizás sea bueno que tú, precisamente tú, no apuestes."

# game/act1.rpy:176
translate spanish act1_3a71e83c:

    # "I inhale sharply, feeling flustered. Just who does this old man think he is, anyway? And more importantly, what makes him think he knows me so well?"
    "Respiro hondo, sintiéndome nerviosa. ¿Quién se cree este viejo? Y, lo que es más importante, ¿qué le hace pensar que me conoce tan bien?"

# game/act1.rpy:178
translate spanish act1_2ceac7a3:

    # "I get up, tucking my things into my bag and giving him a halfhearted bow."
    "Me levanto, guardo mis cosas en la mochila y le hago una reverencia poco entusiasta."

# game/act1.rpy:180
translate spanish act1_062cf843:

    # a frown "Have a good rest of your evening, Mr. Yoshida."
    a frown "Que tenga una buena tarde, señor Yoshida."

# game/act1.rpy:182
translate spanish act1_c47fd351:

    # "I start to head towards the doorway, but as I pass his side of the booth, his hand latches onto my wrist, making me freeze in place. He looks at me through the corner of his eyes, dark and elusive, and panic starts to form in my stomach."
    "Empiezo a dirigirme hacia la puerta, pero al pasar junto a su lado de la cabina, me agarra la muñeca con fuerza, dejándome paralizada. Me mira de reojo, con una mirada oscura y esquiva, y siento que el pánico se apodera de mí."

# game/act1.rpy:184
translate spanish act1_4fbd7740:

    # y "I don’t believe you expected this chat without any sort of incentive for me… did you, Valentine?"
    y "No creo que esperaras esta charla sin ningún tipo de incentivo para mí... ¿verdad, Valentine?"

# game/act1.rpy:185
translate spanish act1_38956b2c:

    # a concern "Incentive?"
    a concern "¿Incentivo?"

# game/act1.rpy:186
translate spanish act1_0f32b27b:

    # y "I’m a very busy man, as I’m sure you’re aware of. I don’t just organize meetings without some sort of gain on my end."
    y "Soy un hombre muy ocupado, como seguramente ya sabes. No organizo reuniones sin obtener algún beneficio a cambio."

# game/act1.rpy:188
translate spanish act1_c2f8d11d:

    # "His grip on my wrist relaxes in an instant, his fingers starting to delicately trace the inside of my palm in an almost… {i}seductive{/i} way."
    "Su agarre en mi muñeca se relaja en un instante, sus dedos comienzan a trazar delicadamente el interior de mi palma de una manera casi… {i}seductora{/i}."

# game/act1.rpy:190
translate spanish act1_ac389fe8:

    # y "Tell me… how do you plan on repaying my time?"
    y "Dime... ¿cómo piensas devolverme el tiempo?"

# game/act1.rpy:191
translate spanish act1_620b4cf8:

    # a flustered "…"
    a flustered "…"

# game/act1.rpy:192
translate spanish act1_9cd0c3c7:

    # a "I-"
    a "I-"

# game/act1.rpy:194
translate spanish act1_96ceb886:

    # "I’m about to come up with some excuse when a heavy hand falls on my shoulder, and a familiar body presses against me."
    "Estaba a punto de inventar alguna excusa cuando una mano pesada se posó sobre mi hombro y un cuerpo familiar se apretó contra mí."

# game/act1.rpy:196
translate spanish act1_ceb80cb2:

    # e "Mr. Yoshida. Fancy running into you here."
    e "Señor Yoshida. ¡Qué casualidad encontrarle aquí!"

# game/act1.rpy:199
translate spanish act1_40d0b271:

    # "Ethan’s voice comes from behind me, his voice full of that authoritarian tone he reserves for everyone but me.{w} His grip on me tightens somewhat."
    "La voz de Ethan proviene de detrás de mí, su voz llena de ese tono autoritario que reserva para todos menos para mí.{w} Su agarre sobre mí se aprieta un poco."

# game/act1.rpy:202
translate spanish act1_af97d8ff:

    # y smile "Officer Hutcherson. I’m surprised you’re still working this late."
    y smile "Oficial Hutcherson, me sorprende que siga trabajando hasta tan tarde."

# game/act1.rpy:203
translate spanish act1_ccc2f37b:

    # e smile "Just had some business with… this Valentine here."
    e smile "Acabo de tener algunos asuntos con… este San Valentín de aquí."

# game/act1.rpy:204
translate spanish act1_0f76b66b:

    # "My eye twitches."
    "Me tiembla el ojo."

# game/act1.rpy:205
translate spanish act1_6820a2eb:

    # e "I’ll be heading home soon."
    e "Pronto me iré a casa."

# game/act1.rpy:207
translate spanish act1_fc0fccec:

    # e stan "Maybe you should, too. This side of the neighborhood isn’t very safe at night."
    e stan "Tal vez tú también deberías. Esta zona del barrio no es muy segura por la noche."

# game/act1.rpy:208
translate spanish act1_2939b09d:

    # y "I’m well aware."
    y "Soy muy consciente de ello."

# game/act1.rpy:210
translate spanish act1_bebc79d8:

    # "Mr. Yoshida turns his attention to me now, that same sneer on his face."
    "El señor Yoshida ahora dirige su atención hacia mí, con la misma mueca de desprecio en su rostro."

# game/act1.rpy:212
translate spanish act1_123b4330:

    # y "You poor thing. They have such a short leash on you. I didn’t know Valentines had a curfew."
    y "Pobrecita. Te tienen muy controlada. No sabía que en San Valentín había toque de queda."

# game/act1.rpy:213
translate spanish act1_8ef2c679:

    # a frown "…"
    a frown "…"

# game/act1.rpy:214
translate spanish act1_fc6a906c:

    # y smile "Oh, well. Figures as much."
    y smile "Bueno, era de esperar."

# game/act1.rpy:216
translate spanish act1_b3dd97c3:

    # "He finally lets go of my hand, grabbing his glass again."
    "Finalmente me suelta la mano y vuelve a coger su vaso."

# game/act1.rpy:218
translate spanish act1_92298cdc:

    # y "All business, no pleasure."
    y "Todo son negocios, nada de placer."

# game/act1.rpy:220
translate spanish act1_1d50824a:

    # e "You have a nice rest of your evening, Mr. Yoshida."
    e "Que tenga una buena tarde, señor Yoshida."

# game/act1.rpy:221
translate spanish act1_e03a1446:

    # "Without another word, Ethan ushers me towards the exit, leaving Mr. Yoshida alone in the dim bar."
    "Sin decir una palabra más, Ethan me indica la salida, dejando al señor Yoshida solo en el bar con poca luz."

# game/act1.rpy:229
translate spanish act1_f0322940:

    # "In the passenger seat of Ethan’s car, I watch as the city lights blur and blend into one another, and from the corner of my eye, his stoic stare focuses on the road. Anger flushes against my face, in a slow, uncomfortable way."
    "En el asiento del copiloto del coche de Ethan, observo cómo las luces de la ciudad se difuminan y se funden entre sí, y por el rabillo del ojo, su mirada impasible se fija en la carretera. La ira me sube a la cara, de forma lenta e incómoda."

# game/act1.rpy:231
translate spanish act1_074cd341:

    # a frown "I didn’t need you to come pick me up."
    a frown "No necesitaba que vinieras a recogerme."

# game/act1.rpy:233
translate spanish act1_baa8824d:

    # a "I could’ve handled it."
    a "Podría haberlo manejado."

# game/act1.rpy:234
translate spanish act1_87a176c7:

    # e "Sure you could’ve."
    e "Claro que podrías haberlo hecho."

# game/act1.rpy:235
translate spanish act1_ab534df3:

    # a angry "I’m serious."
    a angry "Lo digo en serio."

# game/act1.rpy:236
translate spanish act1_ac38fc99:

    # "I practically hiss this."
    "Prácticamente silbo esto."

# game/act1.rpy:237
translate spanish act1_e178313d:

    # a "Why do you feel the need to babysit me? Maybe I should just stop telling you where I’m gonna be."
    a "¿Por qué sientes la necesidad de cuidarme? Quizás debería dejar de decirte dónde voy a estar."

# game/act1.rpy:238
translate spanish act1_9dc4202d:

    # e "You know I’d still be able to find you."
    e "Sabes que aún podría encontrarte."

# game/act1.rpy:239
translate spanish act1_49b2380f:

    # "I scoff at him."
    "Me burlo de él."

# game/act1.rpy:240
translate spanish act1_e19984e5:

    # a "Are you that desperate to control me?"
    a "¿Estás tan desesperado por controlarme?"

# game/act1.rpy:241
translate spanish act1_ccf3a0d7:

    # e "You know that’s not what I’m doing."
    e "Sabes que eso no es lo que estoy haciendo."

# game/act1.rpy:242
translate spanish act1_3c2b6593:

    # a "That’s exactly what it feels like to me."
    a "Eso es exactamente lo que siento yo."

# game/act1.rpy:244
translate spanish act1_6318d271:

    # "He lets out a heavy sigh, clearly exhausted, but I don’t let him off the hook so easily."
    "Deja escapar un profundo suspiro, claramente exhausto, pero no lo dejo escapar tan fácilmente."

# game/act1.rpy:245
translate spanish act1_b23cd9bb:

    # a hm "{i}It’s about the principle. I didn’t ask for his help."
    a hm "{i}Se trata de una cuestión de principios. Yo no le pedí ayuda."

# game/act1.rpy:246
translate spanish act1_1f24a5a1:

    # a pout "{i}…even if I might have needed it…"
    a pout "{i}…aunque lo hubiera necesitado…"

# game/act1.rpy:249
translate spanish act1_12f0418f:

    # "The car comes to a stop, right in front of Ethan’s apartment complex. I shoot him a nasty look, and he puts his hands up, feigning innocence."
    "El coche se detiene justo delante del complejo de apartamentos de Ethan. Le lanzo una mirada fulminante y él levanta las manos, fingiendo inocencia."

# game/act1.rpy:251
translate spanish act1_ffc463ca:

    # e "Just come inside for a minute. I promise I’ll take you home after."
    e "Entra un momento. Te prometo que te llevaré a casa después."

# game/act1.rpy:252
translate spanish act1_4a530c3d:

    # a hm "…"
    a hm "…"

# game/act1.rpy:254
translate spanish act1_ab5d56fe:

    # a hmph "Fine. But you’re ordering takeout."
    a hmph "De acuerdo. Pero estás pidiendo comida para llevar."

# game/act1.rpy:256
translate spanish act1_ded5af8c:

    # "He finally cracks a smile, realizing I’m not as mad as he thinks I was, and drops his hands back to his lap."
    "Finalmente, esboza una sonrisa al darse cuenta de que no estoy tan enfadada como él cree, y vuelve a bajar las manos hasta su regazo."

# game/act1.rpy:258
translate spanish act1_288bf64c:

    # e "Deal."
    e "Trato."

# game/act1.rpy:261
translate spanish act1_5c76d7d2:

    # "There’s a certain vibe to Ethan’s apartment that I haven’t been able to pinpoint for as long as I’ve been here."
    "El apartamento de Ethan tiene una atmósfera particular que no he podido definir a pesar del tiempo que llevo aquí."

# game/act1.rpy:262
translate spanish act1_391dad16:

    # "On one hand, it’s pretty sad; it’s your stereotypical bachelor pad. Posters of TV shows I’ve never had the time to watch, empty bottles of beer and soda on his coffee table, that damn prehistoric radio that never wants to turn on."
    "Por un lado, es bastante triste; es el típico apartamento de soltero. Pósters de series de televisión que nunca he tenido tiempo de ver, botellas vacías de cerveza y refrescos en la mesa de centro, esa maldita radio prehistórica que nunca quiere encenderse."

# game/act1.rpy:263
translate spanish act1_82626eaf:

    # "But, on the other hand… it’s cozy. It’s familiar, and the area has a distinct smell of something foreign, but nice. It’s the kind of place I’d like to stay in more often… and call home."
    "Pero, por otro lado… es acogedor. Es familiar, y la zona tiene un olor peculiar, a algo extranjero, pero agradable. Es el tipo de lugar donde me gustaría quedarme más a menudo… y llamar hogar."

# game/act1.rpy:264
translate spanish act1_bffd7ef2:

    # "Unfortunately, that kind of wishful thinking never does me any good. I shake the thought away, walking deeper into the apartment, my hands tracing the radio as Ethan takes off his vest."
    "Por desgracia, ese tipo de ilusiones nunca me benefician. Sacudo la cabeza para alejar ese pensamiento y me adentro más en el apartamento, mientras mis manos recorren la radio y Ethan se quita el chaleco."

# game/act1.rpy:265
translate spanish act1_4ded9b34:

    # "I push the button to turn it on… to no response."
    "Pulso el botón para encenderlo… pero no hay respuesta."

# game/act1.rpy:267
translate spanish act1_101c45ee:

    # a bored "Of course."
    a bored "Por supuesto."

# game/act1.rpy:268
translate spanish act1_7e5be565:

    # e "What?"
    e "¿Qué?"

# game/act1.rpy:269
translate spanish act1_20d5e264:

    # a hm "Your radio doesn’t work. I keep telling you to throw the damn thing out."
    a hm "Tu radio no funciona. Te digo una y otra vez que tires esa maldita cosa."

# game/act1.rpy:270
translate spanish act1_85413874:

    # e "What’re you talking about? It works fine."
    e "¿De qué estás hablando? Funciona perfectamente."

# game/act1.rpy:271
translate spanish act1_c7ed074f:

    # "He comes over and presses the button again, to the same response."
    "Se acerca y vuelve a pulsar el botón, obteniendo la misma respuesta."

# game/act1.rpy:275
translate spanish act1_f213923e:

    # "He then gives the top of the radio a fierce {i}SMACK{/i} that makes even me jump, and suddenly, the radio sputters its first words, full of static."
    "Luego le da a la parte superior de la radio un fuerte {i}GOLPE{/i} que me hace saltar incluso a mí, y de repente, la radio balbucea sus primeras palabras, llenas de estática."

# game/act1.rpy:277
translate spanish act1_9096d56f:

    # e cocky "Ehh?~"
    e cocky "¿Eh?~"

# game/act1.rpy:278
translate spanish act1_e951962d:

    # a bashful "R-right… I’d rather not have to beat up my appliances every time I want to use them."
    a bashful "S-sí… Prefiero no tener que maltratar mis electrodomésticos cada vez que quiera usarlos."

# game/act1.rpy:279
translate spanish act1_19bf5813:

    # e "See, that's the difference between you and me. You're just too much of a softy."
    e "Mira, esa es la diferencia entre tú y yo. Tú eres demasiado blando."

# game/act1.rpy:280
translate spanish act1_aa157141:

    # a "If that’s what you wanna call it."
    a "Si así es como quieres llamarlo."

# game/act1.rpy:282
translate spanish act1_2ae003f8:

    # "I sit on his couch with a sigh, crossing my arms and eyeing him as he steps in front of me, hands on his hips."
    "Me siento en su sofá con un suspiro, cruzo los brazos y lo observo mientras él se coloca frente a mí, con las manos en las caderas."

# game/act1.rpy:284
translate spanish act1_230841a8:

    # a pout "…"
    a pout "…"

# game/act1.rpy:285
translate spanish act1_e13efb7e:

    # e hm "…"
    e hm "…"

# game/act1.rpy:286
translate spanish act1_23693c98:

    # a hmph "Hmph."
    a hmph "Hmph."

# game/act1.rpy:287
translate spanish act1_3dc4eb12:

    # e uh "Don’t give me that."
    e uh "No me vengas con esas."

# game/act1.rpy:288
translate spanish act1_19f52485:

    # a superhmph "Hmmmmph."
    a superhmph "Hmmmmph."

# game/act1.rpy:289
translate spanish act1_63b27157:

    # e hm "Fine. Pout all you want. I’m not apologizing."
    e hm "De acuerdo. Haz pucheros todo lo que quieras. No voy a disculparme."

# game/act1.rpy:290
translate spanish act1_2f2e1132:

    # e surprised "And I guess you don’t want to see what’s inside my bag tonight…"
    e surprised "Y supongo que no quieres ver lo que hay dentro de mi bolso esta noche…"

# game/act1.rpy:291
translate spanish act1_2a4ff97c_1:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:292
translate spanish act1_184afd34:

    # a excited "Is it a present?"
    a excited "¿Es un regalo?"

# game/act1.rpy:293
translate spanish act1_4e08234b:

    # e smile "Of sorts."
    e smile "Algo así."

# game/act1.rpy:295
translate spanish act1_8784ee50:

    # "He carefully takes out a stack of folders that I recognize to be straight from the police station, and my eyes light up at the sight of them."
    "Con cuidado, saca una pila de carpetas que reconozco como procedentes directamente de la comisaría, y mis ojos se iluminan al verlas."

# game/act1.rpy:297
translate spanish act1_31de4269:

    # a surprised "That’s not-?"
    a surprised "Eso no es...?"

# game/act1.rpy:298
translate spanish act1_b57b3c9e:

    # e "It might be."
    e "Podría ser."

# game/act1.rpy:299
translate spanish act1_53bfa339:

    # a "How did you get those?"
    a "¿Cómo conseguiste eso?"

# game/act1.rpy:300
translate spanish act1_fcfc991f:

    # e "I pulled a few strings… called in a favor. It wasn’t that hard. I’ll put it back first thing tomorrow, no one will know."
    e "Moví algunos hilos… pedí un favor. No fue tan difícil. Lo devolveré mañana a primera hora, nadie se enterará."

# game/act1.rpy:302
translate spanish act1_208c2e5a:

    # "He tucks them back inside, sighing dramatically."
    "Los vuelve a meter dentro, suspirando dramáticamente."

# game/act1.rpy:304
translate spanish act1_f21315e3:

    # e pout "Oh, but you’re too upset to even think about reading all of this. Much less accept it from me, who you so obviously hate now…"
    e pout "Oh, pero estás demasiado molesto como para siquiera pensar en leer todo esto. Mucho menos aceptarlo de mí, a quien obviamente ahora odias…"

# game/act1.rpy:306
translate spanish act1_ecb100ef:

    # a flustered "I don’t hate you! I, uh, love you! So~ much…!"
    a flustered "¡No te odio! ¡Yo, eh, te amo! ¡Muchísimo…!"

# game/act1.rpy:307
translate spanish act1_cf2eda62:

    # e "Uhuh."
    e "Ajá."

# game/act1.rpy:308
translate spanish act1_2132660d:

    # a excited "Come on~ I swear I’m not even mad anymore. Just gimme the files!"
    a excited "¡Vamos~! Te juro que ya ni siquiera estoy enfadado. ¡Solo dame los archivos!"

# game/act1.rpy:309
translate spanish act1_69d9592c:

    # e frown "Say thank you first."
    e frown "Primero, da las gracias."

# game/act1.rpy:310
translate spanish act1_a4ca8edd:

    # a concern "For what?!"
    a concern "¡¿Para qué?!"

# game/act1.rpy:311
translate spanish act1_a94a8060:

    # e hm "The files. AND saving you."
    e hm "Los archivos. Y salvarte."

# game/act1.rpy:312
translate spanish act1_1ab72481:

    # a concern "…"
    a concern "…"

# game/act1.rpy:313
translate spanish act1_45946726:

    # a pout "Thank you for saving me and getting me the files…{w} {size=*0.5}hoe."
    a pout "Gracias por salvarme y conseguirme los archivos…{w} {size=*0.5}hoe."

# game/act1.rpy:314
translate spanish act1_df86bc02:

    # e frown "What was that?"
    e frown "¿Qué fue eso?"

# game/act1.rpy:315
translate spanish act1_0d3e5c0b:

    # a eyeroll "I said ‘bro’. Geez."
    a eyeroll "Dije 'hermano'. Dios mío."

# game/act1.rpy:317
translate spanish act1_641bfd01:

    # e hm "Fine. Here."
    e hm "Bien. Aquí."

# game/act1.rpy:319
translate spanish act1_b597a80c:

    # "He finally hands me the files, and a quick flip to the first page tells me this is the jackpot:{w} {i}{b}Megumi Yoshida – Missing Person Case."
    "Finalmente me entrega los archivos, y una rápida ojeada a la primera página me dice que este es el premio gordo: {w} {i}{b}Megumi Yoshida – Caso de persona desaparecida."

# game/act1.rpy:321
translate spanish act1_c94832f4:

    # e "Knock yourself out. I’ll order the food. Is Chinese okay?"
    e "Haz lo que quieras. Yo pediré la comida. ¿Te parece bien comida china?"

# game/act1.rpy:322
translate spanish act1_bde3eb7f:

    # a excited "Yeah yeah, fine…"
    a excited "Sí, sí, está bien…"

# game/act1.rpy:324
translate spanish act1_d1a1e3e8:

    # "He chuckles, shaking his head and disappearing into the kitchen."
    "Se ríe entre dientes, niega con la cabeza y desaparece en la cocina."

# game/act1.rpy:326
translate spanish act1_2a4ff97c_2:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:329
translate spanish act1_5a43a784:

    # "I take a deep breath, excitement coursing through my fingertips as I rub the sheets of paper in my hands. Any information is good information, and this seems like it’ll be {b}very{/b} good."
    "Respiro hondo, la emoción recorre mis dedos mientras froto las hojas de papel entre mis manos. Cualquier información es buena información, y esta parece que será muy buena."

# game/act1.rpy:331
translate spanish act1_5c8a29df:

    # "The first page reveals Megumi’s personal case file. It’s nothing I hadn’t seen before, but this seems to be the original copy without all of the redacted information."
    "La primera página muestra el expediente personal de Megumi. No es nada que no hubiera visto antes, pero parece ser la copia original sin la información censurada."

# game/act1.rpy:332
translate spanish act1_17a17669:

    # "Extra notes have been added to the bottom of the page, detailing the exact time and area she was last seen on a security camera.{w} But why would it be redacted on my copy?"
    "Se han añadido notas adicionales al final de la página, detallando la hora exacta y el lugar donde fue vista por última vez en una cámara de seguridad.{w} Pero ¿por qué estaría censurado en mi copia?"

# game/act1.rpy:334
translate spanish act1_286f0a41:

    # a hm "{i}'Footage courtesy of C.C.’ Who is that?"
    a hm "{i}'Imágenes cortesía de CC' ¿Quién es ese?"

# game/act1.rpy:336
translate spanish act1_118b9452:

    # "The next page holds Megumi’s criminal record. Petty theft, assault charges, D.U.I.’s. Minor offenses in the grand scheme of things."
    "La página siguiente contiene el historial delictivo de Megumi. Hurtos menores, cargos por agresión, conducir bajo los efectos del alcohol. Delitos menores en comparación con otros."

# game/act1.rpy:337
translate spanish act1_81046e04:

    # "Unfortunately, there aren’t many details of these charges, and it seems like she only served minor jail time. Looks like she was bailed out every time."
    "Lamentablemente, no se conocen muchos detalles sobre estos cargos, y parece que solo cumplió una breve condena en prisión. Al parecer, salió bajo fianza en todas las ocasiones."

# game/act1.rpy:339
translate spanish act1_829ed93e:

    # a hm "{i}Must be nice having a rich family. All those mistakes, and never any responsibility for the consequences."
    a hm "{i}Qué suerte tener una familia rica. Tantos errores y ninguna responsabilidad por las consecuencias."

# game/act1.rpy:341
translate spanish act1_65c0cc13:

    # "I flip over to the next page…"
    "Paso a la página siguiente…"

# game/act1.rpy:343
translate spanish act1_b33ac013:

    # "…and my heart skips a beat."
    "…y mi corazón da un vuelco."

# game/act1.rpy:345
translate spanish act1_c4a143d0:

    # a concern "{i}Corona’s…"
    a concern "{i}Corona…"

# game/act1.rpy:347
translate spanish act1_5feac77d:

    # "Photos of her walking out of Corona’s Casino on the last day she was seen litter the page, and I now realize why they redacted that little detail out."
    "La página está repleta de fotos de ella saliendo del casino de Corona el último día que fue vista, y ahora entiendo por qué censuraron ese pequeño detalle."

# game/act1.rpy:348
translate spanish act1_cbf467cd:

    # "Valentines aren’t allowed to enter casinos, full stop. And that’s especially true for Corona’s."
    "Los enamorados no pueden entrar en los casinos, punto. Y eso es especialmente cierto en el caso de Corona."

# game/act1.rpy:350
translate spanish act1_9915c9c6:

    # "That being said… this is big. Very big. Is the S.P.D. hiding this from every major news outlet?"
    "Dicho esto… esto es grave. Muy grave. ¿Acaso el Departamento de Policía de Seattle (SPD) está ocultando esto a todos los principales medios de comunicación?"

# game/act1.rpy:352
translate spanish act1_20af90f5:

    # "I flip the page over, revealing a complete stranger’s personal file. ‘James Smith’."
    "Le doy la vuelta a la página y descubro el expediente personal de un completo desconocido. 'James Smith'."

# game/act1.rpy:354
translate spanish act1_e0f2493b:

    # a eyeroll "{i}Bleh. Might as well be called ‘John Doe’."
    a eyeroll "{i}Puaj. Bien podría llamarse 'John Doe'."

# game/act1.rpy:356
translate spanish act1_b4b79627:

    # "I’m confused as to why it’s here, until I reach the bottom of the page; {i}’Gone missing. Last seen September 24th at 8:16 p.m.{w} Images courtesy of C.C.'"
    "Estoy confundido sobre por qué está aquí, hasta que llego al final de la página; {i}'Desaparecido. Visto por última vez el 24 de septiembre a las 8:16 pm{w} Imágenes cortesía de CC'"

# game/act1.rpy:358
translate spanish act1_64539f81:

    # a angry "…what the hell?"
    a angry "…¿qué demonios?"

# game/act1.rpy:360
translate spanish act1_86e4d42a:

    # "A missing person case six months prior to this one that I had zero knowledge about, and they’re both last seen in the same location? That can’t be coincidence, can it?"
    "¿Un caso de persona desaparecida seis meses antes del mío del que no tenía ni idea, y ambos fueron vistos por última vez en el mismo lugar? Eso no puede ser una coincidencia, ¿verdad?"

# game/act1.rpy:361
translate spanish act1_31114165:

    # "I take a look at the files attached to it, and the similarities are uncanny: A criminal record of small crimes, followed by pictures of his last sighting in the casino."
    "Reviso los archivos adjuntos y las similitudes son asombrosas: antecedentes penales por delitos menores, seguidos de fotografías de su última aparición en el casino."

# game/act1.rpy:362
translate spanish act1_5e53f370:

    # "A knot starts to form in my stomach."
    "Se me empieza a formar un nudo en el estómago."

# game/act1.rpy:364
translate spanish act1_0ac9d95b:

    # a concern "{i}What am I going to do…?"
    a concern "{i}¿Qué voy a hacer...?"

# game/act1.rpy:370
translate spanish act1_98b77848:

    # "I find Ethan slumped over his kitchen table, a frown on his face as he mulls over a set of files of his own, drumming his fingers against the wooden surface over and over again."
    "Encuentro a Ethan desplomado sobre la mesa de la cocina, con el ceño fruncido mientras repasaba unos archivos, tamborileando una y otra vez con los dedos sobre la superficie de madera."

# game/act1.rpy:371
translate spanish act1_6b225464:

    # "I place a hand on his shoulder, and it only seems to tense up even more."
    "Le pongo una mano en el hombro, y parece que se tensa aún más."

# game/act1.rpy:373
translate spanish act1_95d6c9b2:

    # a worried "Hey."
    a worried "Ey."

# game/act1.rpy:374
translate spanish act1_ca95b42c:

    # e "Hey."
    e "Ey."

# game/act1.rpy:375
translate spanish act1_47b79484:

    # a hm "What’s that?"
    a hm "¿Qué es eso?"

# game/act1.rpy:377
translate spanish act1_47aa9d3a:

    # "A quick glance tells me it’s a long-written report on some suspect. Nothing of my concern."
    "Un vistazo rápido me dice que es un informe extenso sobre algún sospechoso. Nada que me incumba."

# game/act1.rpy:379
translate spanish act1_f0b58833:

    # e uh "Just some shit I’ve had to deal with for a while. Some guy who’s running around, entering bars and clubs with several fake I.D.’s and somehow getting away with it."
    e uh "Es una mierda con la que he tenido que lidiar últimamente. Un tipo que anda por ahí, entrando en bares y discotecas con varios documentos de identidad falsos y saliéndose con la suya."

# game/act1.rpy:381
translate spanish act1_5a00c89c:

    # "He sighs and rubs his temples, which prompts me to start rubbing his shoulders to ease him a bit."
    "Suspira y se frota las sienes, lo que me impulsa a empezar a frotarle los hombros para tranquilizarlo un poco."

# game/act1.rpy:383
translate spanish act1_894b5508:

    # a flattered "Hey, it’ll be fine. Entering a club with a fake I.D. is like, a rite of passage for the average citizen, right?"
    a flattered "Oye, no pasa nada. Entrar en un club con un documento de identidad falso es como un rito de iniciación para el ciudadano medio, ¿no?"

# game/act1.rpy:384
translate spanish act1_5950a915:

    # e "Yeah, but this guy’s… different. Somehow."
    e "Sí, pero este tipo es... diferente. De alguna manera."

# game/act1.rpy:385
translate spanish act1_a3aff8ca:

    # a "Well, it’s nothing you can’t leave for tomorrow."
    a "Bueno, no es nada que no puedas dejar para mañana."

# game/act1.rpy:386
translate spanish act1_91f04cf7:

    # e uh "…maybe you’re right."
    e uh "…quizás tengas razón."

# game/act1.rpy:388
translate spanish act1_7052ee72:

    # "He finally relaxes a bit, but the firmness of his shoulders remains the same under the pressure of my fingers."
    "Finalmente se relaja un poco, pero la firmeza de sus hombros permanece inalterable bajo la presión de mis dedos."

# game/act1.rpy:390
translate spanish act1_cb0fdbbe:

    # e flattered "Were the files any good?"
    e flattered "¿Los archivos eran buenos?"

# game/act1.rpy:392
translate spanish act1_1eda7aba:

    # a bashful "They, uh… were. Yeah."
    a bashful "Ellos, eh… eran. Sí."

# game/act1.rpy:393
translate spanish act1_085d506b:

    # e "That’s not convincing."
    e "Eso no es convincente."

# game/act1.rpy:394
translate spanish act1_e78f53d0:

    # a "It’s a little complicated."
    a "Es un poco complicado."

# game/act1.rpy:395
translate spanish act1_1043f72d:

    # e "How so?"
    e "¿Cómo es eso?"

# game/act1.rpy:398
translate spanish act1_a98c2ef8:

    # a worried "Corona’s is involved."
    a worried "Corona está involucrado."

# game/act1.rpy:400
translate spanish act1_f899c20d:

    # e "Oh."
    e "Oh."

# game/act1.rpy:402
translate spanish act1_0a644488:

    # e hm "Well, shit."
    e hm "Bueno, mierda."

# game/act1.rpy:403
translate spanish act1_2c754e57:

    # a flattered "Yeah. Exactly."
    a flattered "Sí. Exactamente."

# game/act1.rpy:404
translate spanish act1_d3b26f53:

    # e worried "What are you gonna do?"
    e worried "¿Qué vas a hacer?"

# game/act1.rpy:405
translate spanish act1_b3ab9e35:

    # a worried "I’m not sure… maybe ask the staff when they have days off? I’ll have to find their schedules… which could be tedious. But, doable, I guess."
    a worried "No estoy segura… ¿quizás debería preguntarles al personal cuándo tienen días libres? Tendré que buscar sus horarios… lo cual podría ser tedioso. Pero supongo que es posible."

# game/act1.rpy:406
translate spanish act1_ed4b0783:

    # e hm "And you think that’ll help?"
    e hm "¿Y crees que eso ayudará?"

# game/act1.rpy:407
translate spanish act1_45dcd46e:

    # a surprised "Maybe."
    a surprised "Tal vez."

# game/act1.rpy:409
translate spanish act1_7a39d65b:

    # "The lie comes out quick, hoping he’d somehow believe me. The truth is, I don’t believe for a second that’ll work, but I don’t have many other options, do I?"
    "La mentira sale a la luz rápidamente, con la esperanza de que de alguna manera me crea. La verdad es que no creo ni por un segundo que vaya a funcionar, pero no tengo muchas otras opciones, ¿verdad?"

# game/act1.rpy:411
translate spanish act1_ea311f7b:

    # e "And if it doesn’t?"
    e "¿Y si no es así?"

# game/act1.rpy:413
translate spanish act1_52864ca0:

    # a cocky "Then… I’ll sneak my way inside and get some intel. Super-Secret-Spy style."
    a cocky "Entonces… me colaré dentro y conseguiré información. Al estilo de un superespía secreto."

# game/act1.rpy:414
translate spanish act1_d02d54c4:

    # e "…"
    e "…"

# game/act1.rpy:415
translate spanish act1_893a58fc:

    # a bored "That was a joke. Laugh."
    a bored "Era una broma. Ríanse."

# game/act1.rpy:416
translate spanish act1_248f51c0:

    # e frown "I don’t find that funny."
    e frown "No me parece gracioso."

# game/act1.rpy:417
translate spanish act1_fa06ffe6:

    # a eyeroll "Ugh. You’re such a buzzkill. I was kidding."
    a eyeroll "Uf. Eres un aguafiestas. Estaba bromeando."

# game/act1.rpy:418
translate spanish act1_c02f591c:

    # e "Not completely."
    e "No del todo."

# game/act1.rpy:419
translate spanish act1_230841a8_1:

    # a pout "…"
    a pout "…"

# game/act1.rpy:420
translate spanish act1_ab174506:

    # a concern "Yeah, well, this is a really important story. People are going missing, Ethan. It’s not something I can just sweep under the rug."
    a concern "Sí, bueno, esta es una historia muy importante. Hay gente desaparecida, Ethan. No es algo que pueda simplemente ignorar."

# game/act1.rpy:422
translate spanish act1_0524686a:

    # a surprised "And besides… do you have any idea the commission I’ll make if we can actually track down Megumi?"
    a surprised "Y además… ¿tienes idea de la comisión que te haré si logramos encontrar a Megumi?"

# game/act1.rpy:423
translate spanish act1_21e9effd:

    # a excited "That would be enough to go to Vienna for a full week at a {i}fancy{/i} hotel. Imagine!"
    a excited "Eso sería suficiente para ir a Viena durante una semana entera en un hotel de lujo. ¡Imagínate!"

# game/act1.rpy:424
translate spanish act1_cfbb29ef:

    # e "I know you want to go visit your mom, but the casino doesn’t play those kinds of games, Angel. If they find out you’re sneaking inside, snooping around, they’re gonna screw your ass."
    e "Sé que quieres ir a visitar a tu mamá, pero en el casino no se andan con esas tonterías, Ángel. Si descubren que te estás colando y husmeando, te van a dar una buena paliza."

# game/act1.rpy:426
translate spanish act1_505ab5a3:

    # a silly "My ass has been needing a good screwing, anyway."
    a silly "De todos modos, mi culo necesitaba una buena follada."

# game/act1.rpy:427
translate spanish act1_1154ebd9:

    # e frown "Angel."
    e frown "Ángel."

# game/act1.rpy:428
translate spanish act1_08f782e8:

    # a smile "All I’m saying is it’s not anything I can’t handle."
    a smile "Lo único que digo es que no es nada que no pueda manejar."

# game/act1.rpy:429
translate spanish act1_512f4327:

    # e "It’s a bad idea."
    e "Es una mala idea."

# game/act1.rpy:430
translate spanish act1_57880eae:

    # a excited "I’ll be super careful. I’ll check out the area, talk to a few people, and then-"
    a excited "Tendré mucho cuidado. Revisaré la zona, hablaré con algunas personas y luego..."

# game/act1.rpy:432
translate spanish act1_036da1a0:

    # e angry "Why can’t you just take the shit that I tell you seriously for once?!"
    e angry "¿Por qué no puedes tomarte en serio, aunque sea por una vez, las tonterías que te digo?"

# game/act1.rpy:434
translate spanish act1_2a4ff97c_3:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:435
translate spanish act1_2da57d79:

    # e concern "…"
    e concern "…"

# game/act1.rpy:436
translate spanish act1_4b6e6cdc:

    # a dejected "…"
    a dejected "…"

# game/act1.rpy:439
translate spanish act1_dc0fa98c:

    # "I mumble an apology, shame bubbling inside me as I start to back away, when his hands quickly grab onto my waist, pulling me over to him."
    "Murmuro una disculpa, la vergüenza burbujeando en mi interior mientras empiezo a retroceder, cuando sus manos rápidamente me agarran por la cintura, atrayéndome hacia él."

# game/act1.rpy:441
translate spanish act1_ecfea7cf:

    # e "Hey, no. I’m sorry. Don’t go."
    e "Oye, no. Lo siento. No te vayas."

# game/act1.rpy:445
translate spanish act1_d5f7df22:

    # "He envelops me in his arms, hugging me against him and burying his face against my stomach, squeezing me in one of his tight embraces."
    "Me envuelve en sus brazos, me abraza contra él y entierra su rostro contra mi estómago, apretándome en uno de sus fuertes abrazos."

# game/act1.rpy:447
translate spanish act1_5b820f3b:

    # e worried "I’m sorry… I didn’t mean to yell."
    e worried "Lo siento… No quise gritar."

# game/act1.rpy:449
translate spanish act1_4a03fc76:

    # a worried "I… I-It’s okay…"
    a worried "Yo… yo… está bien…"

# game/act1.rpy:450
translate spanish act1_2f0745f0:

    # e sigh "I’m tired, a-and stressed, and-"
    e sigh "Estoy cansado, y estresado, y..."

# game/act1.rpy:452
translate spanish act1_536a847c:

    # a "It’s okay, Ethan. Seriously."
    a "Está bien, Ethan. En serio."

# game/act1.rpy:454
translate spanish act1_01eee57d:

    # e concern "It’s just…{w} you’re one of the few things I care about in this city. If something happened to you… if I somehow lost you…"
    e concern "Es que…{w} eres una de las pocas cosas que me importan en esta ciudad. Si te pasara algo… si de alguna manera te perdiera…"

# game/act1.rpy:455
translate spanish act1_49c77f63:

    # e "I don’t know what I’d do."
    e "No sé qué haría."

# game/act1.rpy:456
translate spanish act1_2a4ff97c_4:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:458
translate spanish act1_3dbb158c:

    # "The silent rage boiling inside me quickly dissipates into nothing, and I hold Ethan closer to my body, cradling his giant head in my arms."
    "La rabia silenciosa que hervía en mi interior se disipó rápidamente, y estreché a Ethan contra mi cuerpo, acunando su enorme cabeza entre mis brazos."

# game/act1.rpy:460
translate spanish act1_b78aecce:

    # a sad "I know. I’m sorry."
    a sad "Lo sé. Lo siento."

# game/act1.rpy:461
translate spanish act1_d02d54c4_1:

    # e "…"
    e "…"

# game/act1.rpy:462
translate spanish act1_a17dae96:

    # e "Just… be careful, Angel. Nothing good can come of you messing with that side of this city."
    e "Solo... ten cuidado, Ángel. Nada bueno puede salir de que te metas con ese lado de esta ciudad."

# game/act1.rpy:464
translate spanish act1_7ad10a14:

    # a flattered "Yeah. I promise... I’ll be careful."
    a flattered "Sí. Lo prometo... tendré cuidado."

# game/act1.rpy:466
translate spanish act1_e2b98bc6:

    # "He looks up at me, and when our eyes lock, something inside me stirs. Something familiar."
    "Él levanta la vista hacia mí, y cuando nuestras miradas se cruzan, algo se remueve dentro de mí. Algo familiar."

# game/act1.rpy:468
translate spanish act1_feb7a7f0:

    # "We stay that way, staring into each other, neither one of us moving an inch, daring to breathe or even blink."
    "Nos quedamos así, mirándonos fijamente, sin que ninguno de los dos se mueva ni un centímetro, sin atrevernos a respirar ni siquiera a parpadear."

# game/act1.rpy:471
translate spanish act1_745e1205:

    # e "That’s… probably the delivery."
    e "Esa es… probablemente la entrega."

# game/act1.rpy:472
translate spanish act1_1b9077e0:

    # a surprised "Right. No, yeah, um…"
    a surprised "Bien. No, sí, eh…"

# game/act1.rpy:476
translate spanish act1_d9070db7:

    # "He lets me go as I bashfully step aside, smoothing out my clothes as he gets up to answer the door."
    "Me suelta mientras me hago a un lado tímidamente, alisándome la ropa mientras él se levanta para abrir la puerta."

# game/act1.rpy:478
translate spanish act1_3bea2f9e:

    # "I sigh out a long breath. It wouldn’t be the first time we’ve had one of these kinds of moments. I guess I’ll rest assured it won’t be the last, either."
    "Exhalo un largo suspiro. No sería la primera vez que vivimos un momento así. Supongo que puedo estar tranquilo, tampoco será la última."

# game/act1.rpy:480
translate spanish act1_d6c86588:

    # "Dinner was eaten mostly in silence, only interrupted by the occasional chit-chat of our day and how work is going. Seems like neither of us have any energy to hold a conversation tonight."
    "La cena transcurrió casi en silencio, interrumpida solo por alguna que otra charla sobre nuestro día y cómo nos iba el trabajo. Parece que ninguno de los dos tiene energía para conversar esta noche."

# game/act1.rpy:484
translate spanish act1_ec2164fb:

    # e "Hey. Stay the night. I know I said I’d drive you home, but I’m seriously drained..."
    e "Hola. Quédate a pasar la noche. Sé que dije que te llevaría a casa, pero estoy realmente agotado..."

# game/act1.rpy:485
translate spanish act1_9c0c0bb8:

    # a surprised "Are you sure? I mean, I don’t mind… I’ll take the couch, if you want your space."
    a surprised "¿Estás seguro? Quiero decir, no me importa... Tomaré el sofá, si quieres tu espacio."

# game/act1.rpy:486
translate spanish act1_f217d170:

    # e smile "Nah. Come."
    e smile "No. Ven."

# game/act1.rpy:493
translate spanish act1_3d246a96:

    # "He takes me by the hand into his bedroom, and although the situation makes my blood start pumping – especially in certain areas – it’s clear that nothing will happen tonight."
    "Me toma de la mano y entra a su dormitorio, y aunque la situación me acelera el pulso, especialmente en ciertas zonas, está claro que no pasará nada esta noche."

# game/act1.rpy:495
translate spanish act1_57000b47:

    # "So when he starts to undress in front of me, I have to pretend I don’t care about how good his body looks underneath that uniform, or that there may or may not be a slight tent in his boxers as he climbs into bed."
    "Así que cuando empieza a desvestirse delante de mí, tengo que fingir que no me importa lo bien que le queda el cuerpo debajo del uniforme, o que pueda o no haber una ligera protuberancia en sus calzoncillos cuando se mete en la cama."

# game/act1.rpy:499
translate spanish act1_c311d6e3:

    # "Once I’m undressed too, I slide under his covers, stiffly lying beside him as we lock eyes."
    "Una vez que yo también me desvisto, me deslizo bajo sus sábanas, tumbada rígidamente a su lado mientras nuestras miradas se cruzan."

# game/act1.rpy:501
translate spanish act1_c286388c:

    # "He’s lying on his stomach, blinking slowly, and the uncontrollable urge to brush his hair surges through my whole body. He suddenly chuckles, and it makes me crack a smile."
    "Está tumbado boca abajo, parpadeando lentamente, y siento un impulso irresistible de peinarle el pelo. De repente, suelta una risita, y eso me arranca una sonrisa."

# game/act1.rpy:503
translate spanish act1_4a55fc80:

    # a -uniform cocky "What?"
    a -uniform cocky "¿Qué?"

# game/act1.rpy:504
translate spanish act1_c8310393:

    # e cocky "Nothing. You just have a stupid look on your face."
    e cocky "Nada. Simplemente tienes una expresión estúpida en la cara."

# game/act1.rpy:505
translate spanish act1_5379f623:

    # "His voice is somewhat muffled, since his cheek is firmly pressed against the mattress, making him involuntarily pout his lips a little."
    "Su voz se escucha algo amortiguada, ya que su mejilla está firmemente presionada contra el colchón, lo que hace que involuntariamente haga un pequeño puchero."

# game/act1.rpy:506
translate spanish act1_5920e065:

    # a flirty "Uhuh. Go to sleep, fatty."
    a flirty "Ajá. Vete a dormir, gordito."

# game/act1.rpy:508
translate spanish act1_77db2ff9:

    # "He frowns, but that smile never leaves his face."
    "Frunce el ceño, pero esa sonrisa nunca desaparece de su rostro."

# game/act1.rpy:510
translate spanish act1_8f212335:

    # e "Fatty? Who you callin’ fatty?"
    e "¿Gordo? ¿A quién llamas gordo?"

# game/act1.rpy:511
translate spanish act1_0a9570b7:

    # a cocky "The only fatty that’s taking up more than half the bed."
    a cocky "El único gordo que ocupa más de la mitad de la cama."

# game/act1.rpy:512
translate spanish act1_22cac25e:

    # e pout "It’s me-sized. Not you-sized."
    e pout "Es de mi talla. No de tu talla."

# game/act1.rpy:514
translate spanish act1_21d5baa0:

    # a "So it’s fatty-sized."
    a "Así que es de tamaño gordo."

# game/act1.rpy:515
translate spanish act1_19a5483d:

    # e flirty "Shut up."
    e flirty "Callarse la boca."

# game/act1.rpy:518
translate spanish act1_1d1a5dc9:

    # e flattered "Hey. Angel."
    e flattered "Hola. Ángel."

# game/act1.rpy:519
translate spanish act1_85a989be:

    # a smile "Yeah?"
    a smile "¿Sí?"

# game/act1.rpy:520
translate spanish act1_f46504e3:

    # e "You know, you could stay over more often. I don’t mind."
    e "Sabes, podrías quedarte a dormir más a menudo. No me importa."

# game/act1.rpy:521
translate spanish act1_2a4ff97c_5:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:523
translate spanish act1_4768e1c9:

    # "It feels like a drunken confession with the way he says it, and it might as well be, considering how woozy the sleepiness is making him. I smile warmly, but by now, his eyes are fully closed."
    "Suena como una confesión de borracho por la forma en que lo dice, y bien podría serlo, considerando lo aturdido que lo tiene el sueño. Le sonrío con ternura, pero para entonces, tiene los ojos completamente cerrados."

# game/act1.rpy:525
translate spanish act1_08be709d:

    # a blush "Okay."
    a blush "Bueno."

# game/act1.rpy:526
translate spanish act1_e64396b1:

    # e "Hrmph. ‘Okay’ shut-up-you’re-so-annoying, or ‘Okay’ okay?"
    e "Hrmph. 'Vale', cállate, eres tan molesto, o 'Vale', ¿vale?"

# game/act1.rpy:527
translate spanish act1_076d405c:

    # a eyeroll "’Okay’ okay, you moron. I…"
    a eyeroll "'Vale', vale, idiota. Yo…"

# game/act1.rpy:528
translate spanish act1_3652a158:

    # a blush "I like being here, too. Your bed’s a lot comfier than mine."
    a blush "A mí también me gusta estar aquí. Tu cama es mucho más cómoda que la mía."

# game/act1.rpy:529
translate spanish act1_4dd70457:

    # a bashful "Well… the third of your bed that I can fit into, anyway."
    a bashful "Bueno… en el tercio de tu cama en el que puedo caber, al menos."

# game/act1.rpy:531
translate spanish act1_05bf1520:

    # "He smiles. I watch him in silence for about a minute, seeing how it fades in real time, and about thirty seconds after that, he’s already snoring."
    "Él sonríe. Lo observo en silencio durante aproximadamente un minuto, viendo cómo la sonrisa se desvanece en tiempo real, y unos treinta segundos después, ya está roncando."

# game/act1.rpy:533
translate spanish act1_06f39335:

    # a stan "…"
    a stan "…"

# game/act1.rpy:535
translate spanish act1_bb59f8ed:

    # "It’s moments like these that make me forget about my silent promise of not daydreaming about him. About us."
    "Son momentos como estos los que me hacen olvidar mi promesa silenciosa de no fantasear con él. Con nosotros."

# game/act1.rpy:536
translate spanish act1_9204291d:

    # "I let my own thoughts run wild, telling myself that I’ll allow it for a minute. Just one minute."
    "Dejé que mis pensamientos volaran libremente, diciéndome a mí misma que me lo permitiría por un minuto. Solo un minuto."

# game/act1.rpy:537
translate spanish act1_38038703:

    # "And in that minute, I see him closing the distance between us in this bed, his large arms wrapping around me, his warm breath against my ears. I feel the heat of his crotch pressing against me, how it would throb in rhythm to my own."
    "Y en ese instante, lo veo acortando la distancia entre nosotros en esta cama, sus grandes brazos rodeándome, su cálido aliento rozando mis oídos. Siento el calor de su entrepierna presionando contra mí, cómo palpitaría al ritmo de la mía."

# game/act1.rpy:538
translate spanish act1_1a7a9a84:

    # "He’d whisper something sweet into my ear – something romantic, because he’d allow himself to do that. To be completely himself."
    "Me susurraba algo dulce al oído, algo romántico, porque se permitía hacerlo. Ser completamente él mismo."

# game/act1.rpy:539
translate spanish act1_d54e4d7d:

    # "He’d tell me he wants me, but that he’s too tired right now. He promises to make it up to me in the morning, and I’d laugh against his chest, buzzing with excitement for tomorrow to come."
    "Me decía que me deseaba, pero que estaba demasiado cansado. Me prometía compensármelo por la mañana, y yo reía apoyada en su pecho, rebosante de emoción por el día siguiente."

# game/act1.rpy:540
translate spanish act1_6fe29ed2:

    # "He would hold me, and I would touch him. And we’d both drift off to sleep together."
    "Él me abrazaba y yo lo tocaba. Y ambos nos quedábamos dormidos juntos."

# game/act1.rpy:542
translate spanish act1_82213f1f:

    # "And then the vision fades.{w} My minute is up."
    "Y entonces la visión se desvanece.{w} Mi minuto ha terminado."

# game/act1.rpy:543
translate spanish act1_d1519caf:

    # "But the yearning persists, as it always does after a daydream. That’s why it’s so dangerous to do it. If a minute can make me feel this way, I can’t imagine how I’d feel if I had no restraint on these fantasies."
    "Pero el anhelo persiste, como siempre ocurre después de una ensoñación. Por eso es tan peligroso hacerlo. Si un minuto puede hacerme sentir así, no puedo imaginar cómo me sentiría si no tuviera límites para estas fantasías."

# game/act1.rpy:547
translate spanish act1_2702b521:

    # a closedworry "{i}I would surely go insane."
    a closedworry "{i}Seguro que me volvería loco."

# game/act1.rpy:549
translate spanish act1_e1fc0a36:

    # a "{i}That kind of freedom… is nothing but torture."
    a "{i}Ese tipo de libertad… no es más que tortura."

# game/act1.rpy:553
translate spanish act1_3d40c031:

    # e "Angel…"
    e "Ángel…"

# game/act1.rpy:554
translate spanish act1_6a8757a7:

    # a1 "Mm?"
    a1 "¿Mmm?"

# game/act1.rpy:555
translate spanish act1_ee0ba040:

    # e "Pick up your fucking phone."
    e "Coge el maldito teléfono."

# game/act1.rpy:556
translate spanish act1_83d9daad:

    # a1 "Mm…"
    a1 "Mm…"

# game/act1.rpy:559
translate spanish act1_89463b25:

    # "I stir awake, blinking back a deep grogginess as I reach for my pant leg and grab my phone, flipping it open and pressing it into my ear."
    "Me despierto, parpadeando para disipar el profundo sueño mientras busco mi pantalón, agarro mi teléfono, lo abro y me lo pongo en la oreja."

# game/act1.rpy:561
translate spanish act1_06af801e:

    # a -uniform hm "Hello?"
    a -uniform hm "¿Hola?"

# game/act1.rpy:562
translate spanish act1_dfc3e367:

    # anon "How kind of you to finally pick up the phone, Angel."
    anon "Qué amable de tu parte finalmente contestar el teléfono, Ángel."

# game/act1.rpy:564
translate spanish act1_45263d9d:

    # "And just like that, my grogginess disappears in an instant."
    "Y así, mi somnolencia desaparece en un instante."

# game/act1.rpy:566
translate spanish act1_f48354de:

    # a flustered "M-Mr. Valentine…"
    a flustered "S-Señor Valentine…"

# game/act1.rpy:567
translate spanish act1_1211f1f2:

    # v "Did I wake you?"
    v "¿Te desperté?"

# game/act1.rpy:569
translate spanish act1_7642fec8:

    # "His voice drips with snarkiness, no trace of an apologetic tone in his sentence. I swallow hard, rubbing my eyes of the drowsiness that I want to so desperately stay in."
    "Su voz rezuma sarcasmo, sin rastro de disculpa. Trago saliva con dificultad, frotándome los ojos para combatir el sueño en el que tanto anhelo permanecer."

# game/act1.rpy:571
translate spanish act1_8b849210:

    # a bashful "N-no, of course not. I was just about to head into the office."
    a bashful "N-no, por supuesto que no. Estaba a punto de entrar en la oficina."

# game/act1.rpy:572
translate spanish act1_dcb6ffb3:

    # v "At five a.m.? How diligent. If only we all had your work ethic."
    v "¿A las cinco de la mañana? ¡Qué diligente! Ojalá todos tuviéramos tu ética de trabajo."

# game/act1.rpy:574
translate spanish act1_461e7036:

    # "Is it really that early? No wonder I’m so tired."
    "¿De verdad es tan temprano? No me extraña que esté tan cansada."

# game/act1.rpy:575
translate spanish act1_795d48a4:

    # "But even in my half-lucid state, I know how painfully obvious it is that Mr. Valentine is just fucking with me. Plain and simple."
    "Pero incluso en mi estado de semiconsciencia, sé lo dolorosamente obvio que es que el señor Valentine simplemente se está burlando de mí. Así de simple."

# game/act1.rpy:577
translate spanish act1_85383b07:

    # a "Ahaha… how can I help you, sir?"
    a "Ahaha… ¿en qué puedo ayudarle, señor?"

# game/act1.rpy:578
translate spanish act1_31da0ee5:

    # v "Well, as luck would have it, I’m heading back to the office myself. Santa Blanca was quite the... {i}skid row{/i}, to put it lightly."
    v "Bueno, como suele suceder, yo también regreso a la oficina. Santa Blanca era un lugar bastante... {i}barrio marginal{/i}, por decirlo suavemente."

# game/act1.rpy:579
translate spanish act1_2e694926:

    # v "I’d absolutely love a box of donuts from Big Joe’s. Oh, and a dark roast from Nova. You can do that for me, can’t you?"
    v "Me encantaría una caja de donas de Big Joe's. Ah, y un café tostado oscuro de Nova. ¿Me lo puedes hacer, verdad?"

# game/act1.rpy:580
translate spanish act1_6f9e2919:

    # a flustered "Um… y-yes sir."
    a flustered "Eh… s-sí señor."

# game/act1.rpy:581
translate spanish act1_900ad62f:

    # v "Good. I’ll be at the office in about half an hour. Please do have them there by then."
    v "Bien. Estaré en la oficina dentro de media hora. Por favor, tenlos allí para entonces."

# game/act1.rpy:582
translate spanish act1_0057f2f7:

    # a concern "Wha… but Big Joe’s and Nova Café are twenty minutes away from each other."
    a concern "¿Qué...? Pero Big Joe's y Nova Café están a veinte minutos de distancia el uno del otro."

# game/act1.rpy:583
translate spanish act1_acf9cfd4:

    # v "I thought you were already heading out? That should be plenty of time, is it not?"
    v "¿No te ibas a ir ya? Debería haber tiempo de sobra, ¿no?"

# game/act1.rpy:584
translate spanish act1_d4d38d3e:

    # v "Or perhaps I should ask someone more qualified… and hand them over your story, while I’m at it."
    v "O tal vez debería preguntarle a alguien más cualificado... y, de paso, pasarle tu historia."

# game/act1.rpy:585
translate spanish act1_ba173338:

    # a flustered "Ah- N-no! No, no, I’m on it, sir!"
    a flustered "¡Ah-N-no! ¡No, no, estoy en ello, señor!"

# game/act1.rpy:586
translate spanish act1_adcb6d1a:

    # v "Good."
    v "Bien."

# game/act1.rpy:588
translate spanish act1_dc96d132:

    # "And he just hangs up, without another word."
    "Y simplemente cuelga, sin decir una palabra más."

# game/act1.rpy:590
translate spanish act1_0b54fa84:

    # e "You're leaving already?"
    e "¿Ya te vas?"

# game/act1.rpy:592
translate spanish act1_d2d5b675:

    # "I turn to see Ethan lying next to me, half asleep, one eye peeping up to look at me."
    "Me giro y veo a Ethan tumbado a mi lado, medio dormido, con un ojo asomando para mirarme."

# game/act1.rpy:594
translate spanish act1_0a9109cc:

    # a worried "Yeah. I’m sorry."
    a worried "Sí. Lo siento."

# game/act1.rpy:596
translate spanish act1_975093ce:

    # "He groans, then turns to his side and lets out a big huff, clearly a little annoyed."
    "Gime, luego se gira de lado y suelta un gran resoplido, claramente algo molesto."

# game/act1.rpy:598
translate spanish act1_0e42454f:

    # e "Your boss is Satan..."
    e "Tu jefe es Satanás..."

# game/act1.rpy:599
translate spanish act1_56f6c8cb:

    # a hm "Don't say that. He's really not that bad..."
    a hm "No digas eso. En realidad no es tan malo..."

# game/act1.rpy:600
translate spanish act1_a0dc2ed0:

    # e "Ugh. He is and you know it."
    e "Uf. Lo es y lo sabes."

# game/act1.rpy:601
translate spanish act1_1e9598f8_1:

    # a worried "…"
    a worried "…"

# game/act1.rpy:602
translate spanish act1_51d0a6b6:

    # e "Let’s…"
    e "Vamos…"

# game/act1.rpy:604
translate spanish act1_5e1df7d5:

    # "He yawns mid-sentence, loud and for a solid ten seconds."
    "Bosteza a mitad de la frase, ruidosamente y durante diez segundos."

# game/act1.rpy:606
translate spanish act1_6bdb8c36:

    # e "Let’s have lunch together, then."
    e "Almorcemos juntos, entonces."

# game/act1.rpy:607
translate spanish act1_7800fb0f:

    # a flattered "…"
    a flattered "…"

# game/act1.rpy:608
translate spanish act1_57ab5745:

    # a "Okay. I really gotta go now."
    a "Vale. De verdad que tengo que irme ya."

# game/act1.rpy:609
translate spanish act1_dab4fa57:

    # e "Yeah… okay…"
    e "Sí… está bien…"

# game/act1.rpy:611
translate spanish act1_c94a258d:

    # "He drifts back to sleep, and a part of me wants to just curl back up and sleep with him, possibly forever."
    "Él vuelve a quedarse dormido, y una parte de mí desea acurrucarse y dormir con él, posiblemente para siempre."

# game/act1.rpy:612
translate spanish act1_5551840a:

    # "{i}If only{/i}, is the last thought I have as I jump out of bed and start to get dressed."
    "{i}Si tan solo{/i}, es el último pensamiento que tengo mientras salto de la cama y empiezo a vestirme."

# game/act1.rpy:617
translate spanish act1_3442efd0:

    # "The cold morning air bites my ears as I step out into the sidewalk. The usually buzzing city of Sonora is half-asleep, and only a few cars and taxis drive past the mostly empty roads."
    "El aire frío de la mañana me congela las orejas al salir a la acera. La bulliciosa ciudad de Sonora está medio dormida, y solo unos pocos coches y taxis circulan por las calles prácticamente vacías."

# game/act1.rpy:618
translate spanish act1_c7e8b0c1:

    # "In the distance, like a centerpiece, glowing lights illuminate a building so grandiose and luxurious, anyone who doesn’t live here would be attracted to it. Like a moth to a flame...{w} Corona's Casino."
    "A lo lejos, como una pieza central, luces brillantes iluminan un edificio tan grandioso y lujoso que cualquiera que no viva aquí se sentiría atraído por él. Como una polilla a la llama...{w} Casino de Corona."

# game/act1.rpy:619
translate spanish act1_39ff3fca:

    # "Money, spectacle, risk… an entire life blooms behind those enormous red doors, a life that couldn’t be more different than mine."
    "Dinero, espectáculo, riesgo… toda una vida florece tras esas enormes puertas rojas, una vida que no podría ser más diferente a la mía."

# game/act1.rpy:620
translate spanish act1_8bab13ee:

    # "And yet, just like everyone else in this city, I can’t help but wonder…{w} what if?"
    "Y sin embargo, al igual que todos los demás en esta ciudad, no puedo evitar preguntarme…{w} ¿y si?"

# game/act1.rpy:621
translate spanish act1_b76f8c18:

    # "What if I played a game – just one game – where I bet my entire life on the line? What if losing meant dying, and winning meant riches beyond my wildest dreams?"
    "¿Y si jugara una partida, solo una, en la que apostara mi vida entera? ¿Y si perder significara morir y ganar riquezas inimaginables?"

# game/act1.rpy:623
translate spanish act1_15596431:

    # "Wouldn’t I be free either way?"
    "¿No sería libre de cualquier manera?"

# game/act1.rpy:625
translate spanish act1_383e3b17:

    # a uniform frown "…"
    a uniform frown "…"

# game/act1.rpy:626
translate spanish act1_d9b977f3:

    # "How idiotic. It’s thoughts like these that make me positive that my own imagination would get me killed, if I let it run this wild."
    "Qué idiotez. Son pensamientos como estos los que me hacen estar seguro de que mi propia imaginación me mataría si la dejara volar sin control."

# game/act1.rpy:627
translate spanish act1_fe347ebb:

    # "I don’t have time for stupidity.{w} I raise my paw and hail a cab."
    "No tengo tiempo para estupideces.{w} Levanto la pata y llamo a un taxi."

# game/act1.rpy:631
translate spanish act1_ea1cd4a1:

    # "Forty minutes later and I’m rushing through the doors of the Valentine Report, donut box in one hand and coffee cup in the other."
    "Cuarenta minutos después, entro corriendo por las puertas del Valentine Report, con una caja de donuts en una mano y una taza de café en la otra."

# game/act1.rpy:632
translate spanish act1_e75b5ea7:

    # "I dash into Mr. Valentine’s office, praying to God that he somehow got delayed, that he got caught in traffic – or better yet, in a minor car accident, even!"
    "Entro corriendo en la oficina del Sr. Valentine, rogando a Dios que se haya retrasado, que se haya quedado atascado en el tráfico, ¡o mejor aún, que haya tenido un pequeño accidente de coche!"

# game/act1.rpy:633
translate spanish act1_2e2b67e5:

    # "Unfortunately, I’m not so lucky."
    "Por desgracia, no tengo tanta suerte."

# game/act1.rpy:636
translate spanish act1_878552ca:

    # v "You’re late."
    v "Llegas tarde."

# game/act1.rpy:637
translate spanish act1_28ba70bf:

    # a flustered "I’m sorry, I-"
    a flustered "Lo siento, yo-"

# game/act1.rpy:638
translate spanish act1_d83113a5:

    # v hm "Bore someone else with your excuses. Hand me my coffee."
    v hm "Deja de aburrir a otra persona con tus excusas. Pásame mi café."

# game/act1.rpy:640
translate spanish act1_218759ec:

    # "I slide everything onto his desk, and he lets out a long, drawn-out sigh."
    "Deslizo todo sobre su escritorio y él deja escapar un largo y prolongado suspiro."

# game/act1.rpy:642
translate spanish act1_cdd82002:

    # v hm "Is everyone in the world incompetent?"
    v hm "¿Acaso todo el mundo es incompetente?"

# game/act1.rpy:643
translate spanish act1_1e9598f8_2:

    # a worried "…"
    a worried "…"

# game/act1.rpy:644
translate spanish act1_d7c8aceb:

    # v frown "That wasn’t rhetorical. I’d like an answer."
    v frown "No era una pregunta retórica. Me gustaría una respuesta."

# game/act1.rpy:645
translate spanish act1_12397fa4:

    # a flustered "Huh? Uh…{w} no?"
    a flustered "¿Eh? Eh…{w} ¿no?"

# game/act1.rpy:647
translate spanish act1_3b69ecde:

    # "He rubs his temple, taking a sip of his coffee. Thankfully, no complaints there…"
    "Se frota la sien mientras toma un sorbo de café. Por suerte, no hay quejas al respecto…"

# game/act1.rpy:649
translate spanish act1_76f895d8:

    # v hm "Well, that certainly seems to be the case..."
    v hm "Bueno, ciertamente parece ser así..."

# game/act1.rpy:651
translate spanish act1_effb38fa:

    # "Mr. Valentine has been running the corporation ever since I even started training to become a Valentine myself. In all the years that I’ve known him, he’s been more or less the same; a stoic, cold-mannered man with little regard for other’s feelings."
    "El señor Valentine ha estado al frente de la corporación desde que comencé mi formación para convertirme en un Valentine. En todos los años que lo conozco, ha sido más o menos el mismo: un hombre estoico y frío, con poca consideración por los sentimientos ajenos."

# game/act1.rpy:652
translate spanish act1_f3366767:

    # "I sometimes wonder if he’s even mortal. I’ve never once heard him complain about being tired, overworked, hungry, sad... you know, basic emotions we all have?"
    "A veces me pregunto si siquiera es mortal. Nunca lo he oído quejarse de estar cansado, sobrecargado de trabajo, hambriento, triste... ya sabes, emociones básicas que todos tenemos."

# game/act1.rpy:653
translate spanish act1_38770b13:

    # "I have a few theories that include sociopathy and/or vampirism, but I think the most likely reason is he’s just an asshole."
    "Tengo algunas teorías que incluyen sociopatía y/o vampirismo, pero creo que la razón más probable es que simplemente es un imbécil."

# game/act1.rpy:655
translate spanish act1_f80bbf20:

    # a yeesh "{i}Sometimes, the answer is the most obvious explanation."
    a yeesh "{i}A veces, la respuesta es la explicación más obvia."

# game/act1.rpy:657
translate spanish act1_94817ef0:

    # "Still, to say I hate him wouldn't be the whole truth. My feelings for Mr. Valentine are as complex as the tasks he so wilfully makes me do..."
    "Aun así, decir que lo odio no sería del todo cierto. Mis sentimientos por el señor Valentine son tan complejos como las tareas que él tan obstinadamente me obliga a realizar..."

# game/act1.rpy:659
translate spanish act1_3e32c7a1:

    # v hm "So, Angel. Do tell… what advancements have you made on the missing person’s story? I haven’t gotten a single report from you all week."
    v hm "Entonces, Ángel, cuéntanos... ¿qué avances has logrado en la investigación de la persona desaparecida? No he recibido ni un solo informe tuyo en toda la semana."

# game/act1.rpy:660
translate spanish act1_2c55d2a5:

    # a bashful "Ah, y-yes, sorry… I was actually planning on writing one today. I’ll go do that now, if you’ll excuse me…"
    a bashful "Ah, sí, lo siento… En realidad pensaba escribir uno hoy. Iré a hacerlo ahora, si me disculpas…"

# game/act1.rpy:661
translate spanish act1_28402040:

    # v stan "No need. I’m right here, after all."
    v stan "No hace falta. Al fin y al cabo, estoy aquí."

# game/act1.rpy:662
translate spanish act1_7bebfa4a:

    # v "Talk to me."
    v "Háblame."

# game/act1.rpy:663
translate spanish act1_620b4cf8_1:

    # a flustered "…"
    a flustered "…"

# game/act1.rpy:664
translate spanish act1_48ba359a:

    # a bashful "Yes… well, I have made a few advancements…"
    a bashful "Sí… bueno, he hecho algunos avances…"

# game/act1.rpy:665
translate spanish act1_79ae6925:

    # v hm "Such as?"
    v hm "¿Como?"

# game/act1.rpy:666
translate spanish act1_836c9b1f:

    # a flustered "Um…"
    a flustered "Eh…"

# game/act1.rpy:667
translate spanish act1_508a4113:

    # v glare "Hm? Spit it out."
    v glare "¿Eh? Suéltalo."

# game/act1.rpy:668
translate spanish act1_a80539b9:

    # v "What have you figured out, my Valentine?"
    v "¿Qué has descubierto, mi San Valentín?"

# game/act1.rpy:669
translate spanish act1_2a4ff97c_6:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:671
translate spanish act1_800c8b73:

    # "He knows I know something. Of course he does. A flick of the ear, a twitch of the eye, a single spasm in your finger, and Mr. Valentine can read your mind. Just like that."
    "Sabe que sé algo. Claro que sí. Un simple movimiento de oreja, un leve gesto con el ojo, un leve espasmo en el dedo, y el señor Valentine puede leerte la mente. Así de fácil."

# game/act1.rpy:673
translate spanish act1_06f39335_1:

    # a stan "…"
    a stan "…"

# game/act1.rpy:675
translate spanish act1_e1c5830c:

    # a frown "I believe Corona’s is somehow involved, sir."
    a frown "Creo que Corona está involucrado de alguna manera, señor."

# game/act1.rpy:676
translate spanish act1_bed3fbbc:

    # v "…"
    v "…"

# game/act1.rpy:679
translate spanish act1_09e2ee76:

    # v "Is that so…?"
    v "Es eso así…?"

# game/act1.rpy:681
translate spanish act1_73172134:

    # "He says that more to himself than to me, and I have a feeling he already knew. However, his face still seems a bit surprised by this."
    "Lo dice más para sí mismo que para mí, y tengo la sensación de que ya lo sabía. Sin embargo, su rostro aún refleja cierta sorpresa."

# game/act1.rpy:683
translate spanish act1_942a14b9:

    # v hm "What are your sources?"
    v hm "¿Cuáles son tus fuentes?"

# game/act1.rpy:684
translate spanish act1_c0f17b45:

    # a surprised "Oh. Um…"
    a surprised "Oh. Eh…"

# game/act1.rpy:685
translate spanish act1_08c74c0f:

    # v "I’m guessing your partner had something to do with it?"
    v "Supongo que tu pareja tuvo algo que ver, ¿no?"

# game/act1.rpy:686
translate spanish act1_8e5db748:

    # a flustered "My partner?"
    a flustered "¿Mi pareja?"

# game/act1.rpy:687
translate spanish act1_d4199ab5:

    # v "Your police escort? Hutcherson, was it?"
    v "¿Su escolta policial? ¿Hutcherson, verdad?"

# game/act1.rpy:688
translate spanish act1_33d2e68f:

    # a surprised "Oh! Yes, forgive me. Hutcherson wasn’t, um, involved, so-"
    a surprised "¡Oh! Sí, perdóname. Hutcherson no estaba, eh, involucrado, así que..."

# game/act1.rpy:689
translate spanish act1_93056945:

    # v frown "Oh please. I won’t get your little boyfriend in trouble. If he’s giving you valuable information, all the better."
    v frown "¡Por favor! No voy a meter en problemas a tu noviecito. Si te está dando información valiosa, mucho mejor."

# game/act1.rpy:690
translate spanish act1_06c2a380:

    # a "He’s not my-"
    a "Él no es mi-"

# game/act1.rpy:691
translate spanish act1_7423d5ad:

    # v glare "In any case, your next step is clear, isn’t it?"
    v glare "En cualquier caso, el siguiente paso está claro, ¿no?"

# game/act1.rpy:692
translate spanish act1_ebab04de:

    # a flustered "Huh? Um…"
    a flustered "¿Eh? Mmm…"

# game/act1.rpy:693
translate spanish act1_158912f3:

    # v hm "Isn’t it? Or do you want me to pass this story to someone more… capable?"
    v hm "¿No es así? ¿O prefieres que le pase esta historia a alguien más... capaz?"

# game/act1.rpy:695
translate spanish act1_6af7789b:

    # a surprised "Of course not!"
    a surprised "¡Por supuesto que no!"

# game/act1.rpy:698
translate spanish act1_4a036494:

    # a concern "…sir."
    a concern "…Señor."

# game/act1.rpy:700
translate spanish act1_4665d401:

    # v frown "Listen. Angel. I gave you this case because I have faith in your abilities. I always have."
    v frown "Escucha, Ángel. Te di este caso porque tengo fe en tus capacidades. Siempre la he tenido."

# game/act1.rpy:701
translate spanish act1_5d9c1143:

    # v hm "Despite what you may think of yourself, you’re one of the few Valentines with decent people's skills. I believe when it comes to these more… sensitive stories, the Valentines don’t have such a great reputation."
    v hm "A pesar de lo que pienses de ti mismo, eres uno de los pocos San Valentín con buenas habilidades sociales. Creo que, cuando se trata de historias más… delicadas, los San Valentín no tienen muy buena reputación."

# game/act1.rpy:702
translate spanish act1_9fc54b64:

    # v frown "We’re seen as cold, calculated… unfeeling."
    v frown "Se nos percibe como fríos, calculadores… insensibles."

# game/act1.rpy:703
translate spanish act1_35889f11:

    # a yeesh "{i}I wonder why…"
    a yeesh "{i}Me pregunto por qué…"

# game/act1.rpy:704
translate spanish act1_5f66f15e:

    # v stan "But you seem to have a more empathetic air to you. People open up to you. They want to tell you things because they believe you want to help them."
    v stan "Pero pareces tener una actitud más empática. La gente se abre contigo. Quieren contarte cosas porque creen que quieres ayudarlos."

# game/act1.rpy:705
translate spanish act1_e952fc8f:

    # a concern "…I do want to help them."
    a concern "…Sí quiero ayudarlos."

# game/act1.rpy:707
translate spanish act1_6558c85a:

    # v frown "Then do it."
    v frown "Entonces hazlo."

# game/act1.rpy:708
translate spanish act1_9ad414a4:

    # v glare "But don’t forget who comes first."
    v glare "Pero no olvides quién es lo primero."

# game/act1.rpy:709
translate spanish act1_bcae0112:

    # v frown "Now get out of my office. I’ve wasted enough time on this conversation."
    v frown "Ahora, sal de mi oficina. Ya he perdido suficiente tiempo con esta conversación."

# game/act1.rpy:710
translate spanish act1_24c25ff2:

    # v hm "And take these donuts with you. This coffee is sweet enough as it is."
    v hm "Y llévate estas rosquillas. Este café ya está bastante dulce."

# game/act1.rpy:712
translate spanish act1_e976ae02:

    # "And there’s the complaint."
    "Y ahí está la queja."

# game/act1.rpy:714
translate spanish act1_76b307d7:

    # a sad "…{w}yes sir."
    a sad "…{w}sí señor."

# game/act1.rpy:716
translate spanish act1_ab3b900c:

    # "I hang my head low as I grab the box of donuts from his desk, and I leave quietly, closing the door behind me."
    "Bajo la cabeza mientras cojo la caja de rosquillas de su escritorio y me marcho en silencio, cerrando la puerta tras de mí."

# game/act1.rpy:722
translate spanish act1_3735040f:

    # "I take the donuts to the breakroom, and I stuff one into my mouth as the conversation replays in my head."
    "Llevo las rosquillas a la sala de descanso y me meto una en la boca mientras la conversación se repite en mi cabeza."

# game/act1.rpy:723
translate spanish act1_42c316c9:

    # "Does Mr. Valentine really believe in me? Does he think I have what it takes to solve this case? Or does he say that to everyone?"
    "¿De verdad cree el señor Valentine en mí? ¿Piensa que tengo lo necesario para resolver este caso? ¿O es que se lo dice a todo el mundo?"

# game/act1.rpy:724
translate spanish act1_dc8111a9:

    # "And he didn’t say anything about Corona’s involvement… what is he plotting?"
    "Y no dijo nada sobre la implicación de Corona... ¿qué estará tramando?"

# game/act1.rpy:725
translate spanish act1_cf2a8ab2:

    # "I don’t know what to think anymore {nw}"
    "Ya no sé qué pensar {nw}"

# game/act1.rpy:729
translate spanish act1_767f091f:

    # anon "BOO!"
    anon "¡ABUCHEO!"

# game/act1.rpy:731
translate spanish act1_06f39335_2:

    # a stan "…"
    a stan "…"

# game/act1.rpy:732
translate spanish act1_b77a292a:

    # c uh "…"
    c uh "…"

# game/act1.rpy:734
translate spanish act1_7f94504a:

    # a smile "Morning."
    a smile "Mañana."

# game/act1.rpy:735
translate spanish act1_86b37a63:

    # c disappointed "Aw, man…"
    c disappointed "Ay, hombre…"

# game/act1.rpy:738
translate spanish act1_113ad0c5:

    # c "You used to get so scared when I did that before. You’d be all like-"
    c "Antes te asustabas mucho cuando hacía eso. Te ponías como..."

# game/act1.rpy:740
translate spanish act1_48e3a9bb:

    # c "WAH!"
    c "¡WAH!"

# game/act1.rpy:741
translate spanish act1_28ef1c35:

    # c disappointed "It was so cute… when did you grow out of it?"
    c disappointed "Era tan lindo... ¿cuándo te quedó pequeño?"

# game/act1.rpy:742
translate spanish act1_89f3717b:

    # a cocky "Probably after the thousandth time you did it."
    a cocky "Probablemente después de haberlo hecho mil veces."

# game/act1.rpy:743
translate spanish act1_78f9119a:

    # c pout "You’re no fun anymore."
    c pout "Ya no eres divertido."

# game/act1.rpy:744
translate spanish act1_d83d6c60:

    # c stan "Ooh, donuts."
    c stan "¡Oh, donas!"

# game/act1.rpy:746
translate spanish act1_8220dd5a:

    # "Cameron, my coworker in the journalist unit of the corporation and annoying manchild, grabs two donuts from the dozen and eats them both at the same time, alternating bites between the two and chewing with his mouth open."
    "Cameron, mi compañero de trabajo en la sección de periodismo de la corporación y un inmaduro insoportable, agarra dos donas de la docena y se las come ambas al mismo tiempo, alternando bocados entre las dos y masticando con la boca abierta."

# game/act1.rpy:748
translate spanish act1_8737e597:

    # a smile "What are you doing here so early, anyway?"
    a smile "¿Qué haces aquí tan temprano?"

# game/act1.rpy:750
translate spanish act1_d0f31de8:

    # "Cameron leans coolly against the counter, rolling his eyes."
    "Cameron se apoya con indiferencia en el mostrador, poniendo los ojos en blanco."

# game/act1.rpy:752
translate spanish act1_0fca3adb:

    # c "Valentine’s on my ass about punching in on time. When have we ever needed to punch in? This isn’t some office job."
    c "Valentine me está presionando para que fiche a tiempo. ¿Cuándo hemos tenido que fichar? Esto no es un trabajo de oficina."

# game/act1.rpy:753
translate spanish act1_afa6c99a:

    # c cocky "But he did assign me a very cool, very special story."
    c cocky "Pero sí me asignó una historia muy interesante y muy especial."

# game/act1.rpy:754
translate spanish act1_3d4ea273:

    # a surprised "Really?"
    a surprised "¿En realidad?"

# game/act1.rpy:755
translate spanish act1_cd2f9355:

    # c "Yup. I have the honor of writing an article for the grand opening of the second public library here in Sonora."
    c "Sí. Tengo el honor de escribir un artículo para la gran inauguración de la segunda biblioteca pública aquí en Sonora."

# game/act1.rpy:757
translate spanish act1_ab391241:

    # a yeesh "Wow. Monumental…"
    a yeesh "Guau. Monumental…"

# game/act1.rpy:758
translate spanish act1_bb78aab7:

    # c "I know."
    c "Lo sé."

# game/act1.rpy:760
translate spanish act1_ed0b5f88:

    # "He takes another bite, chewing in pent up frustration."
    "Da otro bocado, masticando con frustración contenida."

# game/act1.rpy:762
translate spanish act1_6118f869:

    # a bashful "Sorry you get the low hanging fruit."
    a bashful "Lamento que te toque lo más fácil."

# game/act1.rpy:763
translate spanish act1_6d29e0ee:

    # c cocky "It’s fine. If Valentine wants to give {i}me{/i} these cheese-ass stories… then I’ll take my time with them. Treat it as a mini vacation."
    c cocky "Está bien. Si Valentine quiere contarme estas historias tan cursis… entonces me tomaré mi tiempo con ellas. Lo consideraré como unas mini vacaciones."

# game/act1.rpy:767
translate spanish act1_6129a2cf:

    # "He suddenly leans closer to me, invading my personal space and looking me right in the eyes with an odd, piercing glare."
    "De repente, se inclina hacia mí, invadiendo mi espacio personal y mirándome directamente a los ojos con una mirada extraña y penetrante."

# game/act1.rpy:769
translate spanish act1_83425007:

    # c flirty "But you can’t say the same, can you? Little Angel got a big story, didn’t he?"
    c flirty "Pero tú no puedes decir lo mismo, ¿verdad? El pequeño Ángel tiene una gran historia, ¿no?"

# game/act1.rpy:770
translate spanish act1_2a4ff97c_7:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:771
translate spanish act1_06766ba4:

    # a flustered "I, uh… I guess so…"
    a flustered "Yo, eh… supongo que sí…"

# game/act1.rpy:773
translate spanish act1_20634e04:

    # a bashful "Mr. Valentine said it’s because I have more ‘people’s skills’, if you can believe that."
    a bashful "El señor Valentine dijo que es porque tengo más \"habilidades para relacionarme con la gente\", aunque parezca increíble."

# game/act1.rpy:774
translate spanish act1_121198f1:

    # c cocky "Hah!"
    c cocky "¡Ja!"

# game/act1.rpy:777
translate spanish act1_07e37438:

    # "He backs off, the mood growing light again in an instant."
    "Él retrocede, y el ambiente se vuelve más distendido en un instante."

# game/act1.rpy:779
translate spanish act1_1cf03f8b:

    # c "More than me? That’s hard to believe."
    c "¿Más que yo? Eso es difícil de creer."

# game/act1.rpy:781
translate spanish act1_7e23a12a:

    # anon "Is it, though?"
    anon "¿En serio?"

# game/act1.rpy:784
translate spanish act1_e23fb6bd:

    # a smile "Oh, hi Mika."
    a smile "Oh, hola Mika."

# game/act1.rpy:785
translate spanish act1_4be652ed:

    # c hm "Here comes the fun police."
    c hm "Aquí viene la policía de la diversión."

# game/act1.rpy:786
translate spanish act1_c1168a2b:

    # mk stan "Don’t let him fool you, Angel. Cam is only somewhat capable in what he does."
    mk stan "No te dejes engañar, Ángel. Cam solo es medianamente competente en lo que hace."

# game/act1.rpy:787
translate spanish act1_e35e0d49:

    # c "I’ve been here longer than you."
    c "Llevo aquí más tiempo que tú."

# game/act1.rpy:788
translate spanish act1_1cdbd353:

    # mk hm "Doesn’t make you better."
    mk hm "Eso no te hace mejor."

# game/act1.rpy:789
translate spanish act1_f01800d0:

    # c "Uh, yeah, it does."
    c "Sí, así es."

# game/act1.rpy:791
translate spanish act1_06c2f801:

    # "Mika is my only other coworker in the journalist unit, making three of us in total. I guess you can say we’re all friends… that never hang out outside of work. Probably because none of us actually want to be here."
    "Mika es mi única compañera en la sección de periodismo, así que somos tres en total. Supongo que se podría decir que somos amigas… aunque nunca salimos fuera del trabajo. Probablemente porque ninguna de nosotras quiere estar aquí."

# game/act1.rpy:792
translate spanish act1_42e5cb90:

    # "Mika is kind of Cameron’s opposite; quiet and very no nonsense. Despite this though, I find myself opening up to her more than anyone else in the corporation."
    "Mika es, en cierto modo, lo opuesto a Cameron: callada y muy pragmática. A pesar de ello, me doy cuenta de que me abro más con ella que con cualquier otra persona en la corporación."

# game/act1.rpy:793
translate spanish act1_2a6f2ada:

    # "Compared to me, both of them have more experience in serious stories like this. So, maybe…"
    "Comparados conmigo, ambos tienen más experiencia en historias serias como esta. Así que, tal vez…"

# game/act1.rpy:796
translate spanish act1_0bb99e50:

    # a "Hey, you two… I have a bit of a weird question."
    a "Hola, ustedes dos… tengo una pregunta un poco extraña."

# game/act1.rpy:797
translate spanish act1_074b93cc:

    # mk "Oh?"
    mk "¿Oh?"

# game/act1.rpy:798
translate spanish act1_8f1a8e41:

    # c hm "Is this about your cop boyfriend? I’m telling you, kid, never trust a narc."
    c hm "¿Se trata de tu novio policía? Te lo digo, chico, nunca confíes en un soplón."

# game/act1.rpy:801
translate spanish act1_54923d8b:

    # a flustered "What? No! And he’s not my boyfriend!"
    a flustered "¿Qué? ¡No! ¡Y él no es mi novio!"

# game/act1.rpy:802
translate spanish act1_3ac9b187:

    # a worried "This is… about my story."
    a worried "Esto es… sobre mi historia."

# game/act1.rpy:806
translate spanish act1_91731e29:

    # a "What would you guys do if… Corona was involved?"
    a "¿Qué harían ustedes si... el coronavirus estuviera involucrado?"

# game/act1.rpy:808
translate spanish act1_6fa85c4d:

    # a concern "What? What’s with the faces?"
    a concern "¿Qué? ¿Qué les pasa a esas caras?"

# game/act1.rpy:811
translate spanish act1_c9be7db5:

    # mk worried "That’s just… a very heavy claim, Angel."
    mk worried "Esa es una afirmación muy fuerte, Ángel."

# game/act1.rpy:812
translate spanish act1_8de031a3:

    # c hm "Shit, Corona? Are you sure? There’s a lot of different casinos here. That’s like, the whole appeal of this city."
    c hm "Mierda, ¿Corona? ¿Estás seguro? Hay muchos casinos diferentes aquí. Ese es, precisamente, el atractivo de esta ciudad."

# game/act1.rpy:813
translate spanish act1_1099be1c:

    # a surprised "I know… but, I’m pretty sure Corona is at the center of this. I’ve got evidence pointing back to them, all of the missing person’s cases that involve high-class individuals falling into gambling addiction."
    a surprised "Lo sé… pero estoy bastante seguro de que Corona está en el centro de todo esto. Tengo pruebas que apuntan a ellos, todos los casos de personas desaparecidas que involucran a individuos de clase alta que caen en la adicción al juego."

# game/act1.rpy:814
translate spanish act1_dcc7e2fd:

    # a frown "Isn’t it possible? I mean, if I could just… question the staff…"
    a frown "¿No es posible? Es decir, si pudiera... interrogar al personal..."

# game/act1.rpy:817
translate spanish act1_0e10e33f:

    # mk "You can’t!"
    mk "¡No puedes!"

# game/act1.rpy:820
translate spanish act1_d58a08c7:

    # mk worried "I mean… You shouldn’t…"
    mk worried "Quiero decir… No deberías…"

# game/act1.rpy:822
translate spanish act1_16244947:

    # c "What Mika means is that Corona isn’t {i}just{/i} a casino."
    c "Lo que Mika quiere decir es que Corona no es {i}solo{/i} un casino."

# game/act1.rpy:829
translate spanish act1_a59ec0a7:

    # c "This city was built around it. Quite literally."
    c "Esta ciudad se construyó a su alrededor. Literalmente."

# game/act1.rpy:830
translate spanish act1_3c12c00a:

    # c "It’s not just some tourist attraction, or a fancy five-star hotel... Corona’s is everything that makes Sonora a powerhouse of a society."
    c "No es solo una atracción turística o un lujoso hotel de cinco estrellas... Corona's representa todo lo que hace de Sonora una sociedad poderosa."

# game/act1.rpy:831
translate spanish act1_fc24abd3:

    # c "The hold it has on the economy, on the minds of the people, on the elites of this world… it’s on a whole other level. They're basically the government here. You {i}cannot{/i} mess with them without consequence."
    c "El control que ejerce sobre la economía, sobre la mentalidad de la gente, sobre las élites de este mundo… está en otro nivel. Básicamente, son el gobierno aquí. No puedes meterte con ellos sin consecuencias."

# game/act1.rpy:838
translate spanish act1_4abec6a2:

    # c "They’re untouchable. The only way into their inner circle is either being a damn good gambler or being stupid rich. And a little reminder, kid, you’re neither of those things."
    c "Son intocables. La única forma de entrar en su círculo íntimo es ser un jugador excepcional o ser increíblemente rico. Y un pequeño recordatorio, chico: tú no eres ninguna de las dos cosas."

# game/act1.rpy:839
translate spanish act1_9b6ef9d3:

    # mk "Mixing with Corona and getting too close is a bad idea, Angel."
    mk "Mezclarse con Corona y acercarse demasiado es una mala idea, Ángel."

# game/act1.rpy:840
translate spanish act1_1ab72481_1:

    # a concern "…"
    a concern "…"

# game/act1.rpy:842
translate spanish act1_b08f0221:

    # a "But… we’re Valentines. Surely, we have some immunity, right? I mean, we’re not high-class elites, but we do have protection from the S.P.D., don’t we?"
    a "Pero… somos San Valentín. Seguramente tenemos cierta inmunidad, ¿no? Quiero decir, no somos de la élite, pero tenemos protección del SPD, ¿no?"

# game/act1.rpy:844
translate spanish act1_9328924b:

    # c hm "Angel, if the Casino had to choose between facing the punishment of killing a Valentine, or protecting their own reputation… do you really think it’s a close call?"
    c hm "Ángel, si el Casino tuviera que elegir entre afrontar el castigo por matar a una persona de San Valentín o proteger su propia reputación... ¿de verdad crees que la decisión sería difícil?"

# game/act1.rpy:845
translate spanish act1_72e94c19:

    # a "…"
    a "…"

# game/act1.rpy:848
translate spanish act1_cef03c43:

    # a "Wh… why, then? Why did Mr. Valentine even give me a story like this in the first place?"
    a "¿Por qué... por qué, entonces? ¿Por qué el señor Valentine me contó una historia como esta en primer lugar?"

# game/act1.rpy:850
translate spanish act1_e91e1474:

    # mk worried "Honestly?"
    mk worried "¿Honestamente?"

# game/act1.rpy:851
translate spanish act1_4246521a:

    # mk "I think he expected you to fail."
    mk "Creo que esperaba que fracasaras."

# game/act1.rpy:853
translate spanish act1_7d5f8d55:

    # a sad "…"
    a sad "…"

# game/act1.rpy:854
translate spanish act1_6218b584:

    # c "…"
    c "…"

# game/act1.rpy:856
translate spanish act1_59d328cd:

    # c cocky "Hey, cheer up. Valentine’s a freak, anyway. You’re still practically a newbie at this. One failed assignment isn’t gonna stain your record. Maybe it’ll hurt your bonus, but, uh… what can you do, y’know…?"
    c cocky "¡Ánimo! San Valentín es un caso aparte. Todavía eres prácticamente un novato en esto. Un trabajo fallido no va a manchar tu expediente. Quizás afecte a tu bono, pero... ¿qué se le va a hacer?"

# game/act1.rpy:858
translate spanish act1_9907a90e:

    # "He chuckles, trying to lighten the mood a bit, but it only makes this whole situation seem more like what it truly is: a big joke.{w} And I’m the punchline."
    "Se ríe entre dientes, tratando de aligerar un poco el ambiente, pero eso solo hace que toda esta situación parezca más lo que realmente es: una gran broma.{w} Y yo soy el remate."

# game/act1.rpy:860
translate spanish act1_1452821e:

    # mk worried "Listen, Angel. Corona’s influence in this city is so grand, that even if you’re outside of its walls, you’re {i}still{/i} gambling. Still risking your livelihood by even thinking about getting involved with it."
    mk worried "Escucha, Ángel. La influencia del coronavirus en esta ciudad es tan grande que, incluso si estás fuera de sus muros, sigues arriesgándote. Sigues arriesgando tu sustento con solo pensar en involucrarte."

# game/act1.rpy:861
translate spanish act1_5d05f955:

    # mk "And as Valentines, we can’t take that risk."
    mk "Y como pareja, no podemos correr ese riesgo."

# game/act1.rpy:862
translate spanish act1_ae62c068:

    # mk "Because we aren’t just risking our own lives."
    mk "Porque no solo estamos arriesgando nuestras propias vidas."

# game/act1.rpy:866
translate spanish act1_91db3ebe:

    # a "Mom…"
    a "Mamá…"

# game/act1.rpy:871
translate spanish act1_c5d8b108:

    # c cocky "Well, that’s that, then! You just treat this like a vacation, too. Dick around, talk to people around the missing person’s inner circle, and tell Valentine he’s shit outta luck. You’re not messing with Corona."
    c cocky "Bueno, ¡entonces eso es todo! Tómatelo como si fueran unas vacaciones. Haz el tonto, habla con la gente del círculo íntimo de la persona desaparecida y dile a Valentine que no tiene suerte. Con el coronavirus no te juegas."

# game/act1.rpy:873
translate spanish act1_b5ba8976:

    # "He slaps his paw on my shoulder, forcing a smile."
    "Me da una palmada en el hombro con la pata, forzando una sonrisa."

# game/act1.rpy:875
translate spanish act1_44b405fd:

    # c cocky "And if you get bored, we can play chess in the breakroom when the boss ain’t around. I might even let you win next time."
    c cocky "Y si te aburres, podemos jugar al ajedrez en la sala de descanso cuando el jefe no esté. Puede que incluso te deje ganar la próxima vez."

# game/act1.rpy:876
translate spanish act1_2084c278:

    # a cocky "Tch. You’re on."
    a cocky "Tch. Estás en el aire."

# game/act1.rpy:879
translate spanish act1_b373285f:

    # "He gives me a hard squeeze, then turns around and heads out the door, sharing a glance with Mika as he exits the room."
    "Me da un fuerte apretón, luego se da la vuelta y sale por la puerta, intercambiando una mirada con Mika al salir de la habitación."

# game/act1.rpy:883
translate spanish act1_7d5f8d55_1:

    # a sad "…"
    a sad "…"

# game/act1.rpy:884
translate spanish act1_4a7e75cf:

    # mk "I know you want to help her, Angel. But sometimes, the smartest move in a game is to not play at all."
    mk "Sé que quieres ayudarla, Ángel. Pero a veces, lo más inteligente en un juego es no jugar en absoluto."

# game/act1.rpy:885
translate spanish act1_97005c09:

    # a bashful "…maybe you’re right."
    a bashful "…quizás tengas razón."

# game/act1.rpy:887
translate spanish act1_1ddc2c35:

    # a flattered "Thanks, Mika."
    a flattered "Gracias, Mika."

# game/act1.rpy:888
translate spanish act1_e3530c2c:

    # mk "I’ll leave you to it, then."
    mk "Te dejo con eso, entonces."

# game/act1.rpy:892
translate spanish act1_1ab72481_2:

    # a concern "…"
    a concern "…"

# game/act1.rpy:894
translate spanish act1_cc2adb1b:

    # "Doubts fill my head, swirling around until it numbs the rest of my body."
    "Las dudas me invaden la cabeza, dando vueltas hasta adormecer el resto de mi cuerpo."

# game/act1.rpy:895
translate spanish act1_4a358500:

    # "Am I maybe just not good enough to solve this? Is Mr. Valentine just pulling a really big, elaborate ‘fuck you’ right in my face?"
    "¿Será que no soy lo suficientemente bueno para resolver esto? ¿Acaso el Sr. Valentine me está haciendo un gran y elaborado \"que te jodan\" en la cara?"

# game/act1.rpy:896
translate spanish act1_31e1bb4b:

    # "What is he expecting me to do? And, more importantly…"
    "¿Qué espera que haga? Y, lo que es más importante…"

# game/act1.rpy:897
translate spanish act1_548ef30c:

    # "What {i}am{/i} I going to do?"
    "¿Qué voy a hacer?"

# game/act1.rpy:899
translate spanish act1_2cfdf537:

    # "I think back to Mr. Yoshida, his strained expression as he spoke about his missing niece. I think about all the other missing people who came before Megumi, and how people seem to be going missing more and more frequently lately."
    "Recuerdo al señor Yoshida, su expresión de angustia mientras hablaba de su sobrina desaparecida. Pienso en todas las demás personas desaparecidas antes que Megumi, y en cómo últimamente parece que la gente desaparece con mayor frecuencia."

# game/act1.rpy:900
translate spanish act1_47304362:

    # "And I think of Mr. Valentine’s cold, knowing look, telling me exactly what I should do."
    "Y recuerdo la mirada fría y perspicaz del señor Valentine, diciéndome exactamente lo que debía hacer."

# game/act1.rpy:902
translate spanish act1_d4768e5a:

    # "My job."
    "Mi trabajo."

# game/act1.rpy:906
translate spanish act1_9e17a4d9:

    # "Fear bubbles in my chest as I look up to see the grand building before me."
    "El miedo me invade el pecho al alzar la vista y contemplar el imponente edificio que se alza ante mí."

# game/act1.rpy:907
translate spanish act1_9c3a1209:

    # "For being so off-limits, the casino is incredibly inviting; people pour inside despite it being relatively early, and there seems to be no one guarding the actual entrance."
    "A pesar de estar tan restringido el acceso, el casino resulta increíblemente atractivo; la gente entra en masa a pesar de ser relativamente temprano, y parece que no hay nadie vigilando la entrada."

# game/act1.rpy:908
translate spanish act1_52648680:

    # "I take small glances inside, the flickering of lights and the sounds of slot machines being audible even from all the way out here."
    "Echo pequeños vistazos al interior; el parpadeo de las luces y el sonido de las máquinas tragamonedas se oyen incluso desde aquí afuera."

# game/act1.rpy:909
translate spanish act1_330d49a5:

    # "It sounds… fun."
    "Suena… divertido."

# game/act1.rpy:911
translate spanish act1_2a4ff97c_8:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:912
translate spanish act1_a5e10b62:

    # a flustered "{i}N-no way. There I go again, thinking stupid things. How can throwing money into a machine and hoping it matches three symbols in a row possibly be any fun at all?"
    a flustered "{i}¡De ninguna manera! Ahí voy de nuevo, pensando tonterías. ¿Cómo puede ser divertido tirar dinero a una máquina y esperar que salgan tres símbolos seguidos?"

# game/act1.rpy:914
translate spanish act1_5cb2a6e0:

    # "That’s right. It’s just the allure of the casino. That’s what they’re designed to do."
    "Así es. Es simplemente el atractivo del casino. Para eso están diseñados."

# game/act1.rpy:916
translate spanish act1_3094c3bf:

    # "I’m stalling. {w}Again."
    "Estoy ganando tiempo. {w}Otra vez."

# game/act1.rpy:917
translate spanish act1_8a753b57:

    # "My heart’s hammering in my chest as I take yet another quick peek inside. I mean… there’s no {i}explicit{/i} rule a Valentine can’t just {i}enter{/i} a casino, right? Surely, Mr. Valentine would’ve stopped me had that been the case."
    "Mi corazón late con fuerza en mi pecho mientras echo otro vistazo rápido al interior. Quiero decir… no hay ninguna regla explícita que impida que un San Valentín entre en un casino, ¿verdad? Seguramente, el señor San Valentín me habría detenido si ese hubiera sido el caso."

# game/act1.rpy:919
translate spanish act1_06f39335_3:

    # a stan "…"
    a stan "…"

# game/act1.rpy:920
translate spanish act1_8ef2c679_1:

    # a frown "…"
    a frown "…"

# game/act1.rpy:922
translate spanish act1_d649132f:

    # "No. I can’t let my own fears and desires get in the way of my work. I’m a Valentine, not some amateur freelancer. This is what I was made to do."
    "No. No puedo permitir que mis miedos y deseos se interpongan en mi trabajo. Soy una profesional, no una aficionada independiente. Para esto nací."

# game/act1.rpy:924
translate spanish act1_16a9b7a9:

    # a "{i}That’s right. Unfeeling, calculated, and efficient. Get the job done."
    a "Así es. Insensibles, calculadores y eficientes. Hacen el trabajo."

# game/act1.rpy:925
translate spanish act1_e6c9e262:

    # a "{i}Your livelihood isn’t the only thing on the line…"
    a "{i}Tu sustento no es lo único que está en juego…"

# game/act1.rpy:927
translate spanish act1_eefe62a7:

    # "I brush back my hair in a slow, soothing way… and take a step forward, entering the casino."
    "Me aparto el pelo con movimientos lentos y suaves… y doy un paso adelante, entrando en el casino."

# game/act1.rpy:930
translate spanish act1_c1c64b14:

    # "The lobby itself is a beautiful, spacious area, with a fountain at its center, filling the room with the sound of rushing water."
    "El vestíbulo en sí es un espacio hermoso y amplio, con una fuente en el centro que llena la sala con el sonido del agua que fluye."

# game/act1.rpy:931
translate spanish act1_3e987cfa:

    # "Prestigious looking people banter quietly around it, and further along this room is an entryway to where I’m positive the casino is. To my right, a hall leads towards the registration desk, and even further seems to be a restaurant."
    "Gente de aspecto distinguido charla en voz baja a su alrededor, y más adelante en esta sala hay una entrada que, estoy seguro, lleva al casino. A mi derecha, un pasillo conduce a la recepción, y aún más allá parece haber un restaurante."

# game/act1.rpy:932
translate spanish act1_5b74122a:

    # "I can only guess that even deeper inside the building is the actual hotel lobby, where I’m sure leads to the many rooms available in this resort."
    "Supongo que aún más adentro del edificio se encuentra el vestíbulo del hotel, desde donde seguramente se accede a las numerosas habitaciones disponibles en este complejo."

# game/act1.rpy:933
translate spanish act1_38654dfb:

    # "Access is most likely only granted with a room keycard, and I wouldn’t be surprised if even the elevators won’t function if you don’t have one on you."
    "Lo más probable es que el acceso solo se conceda con la tarjeta de acceso a la habitación, y no me sorprendería que ni siquiera los ascensores funcionaran si no llevas una contigo."

# game/act1.rpy:934
translate spanish act1_435cd0bc:

    # "This place truly has it all…"
    "Este lugar realmente lo tiene todo…"

# game/act1.rpy:935
translate spanish act1_9004a9c6:

    # "I walk aimlessly around the fountain, feigning interest… well, maybe not feigning it. I am quite interested, but not so much in the architecture of the place, as beautiful as it may be. There’s something else that caught my attention."
    "Camino sin rumbo fijo alrededor de la fuente, fingiendo interés… bueno, quizás no lo finjo del todo. Me interesa bastante, pero no tanto la arquitectura del lugar, por muy bonita que sea. Hay algo más que me llamó la atención."

# game/act1.rpy:936
translate spanish act1_3d0008e5:

    # "This is the very last room Megumi was last seen in. I’m positive of it."
    "Esta es la última habitación en la que se vio a Megumi. Estoy completamente seguro."

# game/act1.rpy:937
translate spanish act1_098c2984:

    # "The patterns on the floor match exactly… but, how? Corona’s is in the middle of the city. Surely, some other camera must have picked up her trail…?"
    "Los dibujos del suelo coinciden a la perfección… pero ¿cómo? Corona está en pleno centro de la ciudad. Seguro que alguna otra cámara la ha captado…"

# game/act1.rpy:938
translate spanish act1_b990767b:

    # "All the more reason to question the staff. And speaking of…"
    "Con más razón hay que cuestionar al personal. Y hablando de eso…"

# game/act1.rpy:939
translate spanish act1_446f16d2:

    # a body2 uniform thinking "Hm…"
    a body2 uniform thinking "Hm…"

# game/act1.rpy:941
translate spanish act1_827db9a8:

    # "I walk up to the fountain, staring down at my distorted reflection in the ripples of the water. I do my best to appear unassuming, with my hands behind my back, looking at nothing in particular."
    "Me acerco a la fuente, contemplando mi reflejo distorsionado en las ondas del agua. Intento parecer despreocupado, con las manos a la espalda, sin mirar a ningún punto en particular."

# game/act1.rpy:942
translate spanish act1_1f1551c5:

    # "In reality, I’m gathering a ton of information."
    "En realidad, estoy recopilando muchísima información."

# game/act1.rpy:943
translate spanish act1_498205b5:

    # "In the entryway to the casino, just shy of my peripheral vision, stand two large men on either side. A polar bear to the right, a bull to the left. Stereotypical bouncers, but I suppose they can’t afford to have anything less than the biggest and strongest in a place like this."
    "En la entrada del casino, justo fuera de mi campo de visión periférica, se encuentran dos hombres corpulentos a cada lado. Un oso polar a la derecha, un toro a la izquierda. Los típicos porteros, pero supongo que no pueden permitirse el lujo de tener a nadie menos que los más grandes y fuertes en un lugar como este."

# game/act1.rpy:944
translate spanish act1_06ab6df9:

    # "I close my eyes, yawning without a sound as I try to pick up on anything they might be saying, the urge to flick my ears to their direction as strong as it ever is. Like an itch I’m not allowed to scratch."
    "Cierro los ojos, bostezo sin hacer ruido mientras intento captar lo que puedan estar diciendo, con la misma fuerza de siempre al girar las orejas hacia ellos. Como una picazón que no me debo rascar."

# game/act1.rpy:945
translate spanish act1_6eca5595:

    # "I resist, of course… but unfortunately for me, the two men don’t make a sound."
    "Me resisto, por supuesto… pero, por desgracia para mí, los dos hombres no emiten ningún sonido."

# game/act1.rpy:947
translate spanish act1_acd7ab5c:

    # a body2 frown2 "{i}This isn’t good. I’m not getting anything useful just standing here, and it’s not like I can just go up and talk to them…"
    a body2 frown2 "{i}Esto no está bien. No estoy consiguiendo nada útil quedándome aquí parado, y no es como si pudiera acercarme y hablar con ellos…"

# game/act1.rpy:948
translate spanish act1_98614485:

    # a body2 hm2 "{i}Well, it’s not the end of the world. I at least know what they look like. If I can talk to Ethan and ask him to get me information on every bull and polar bear in the city…"
    a body2 hm2 "{i}Bueno, no es el fin del mundo. Al menos sé cómo son. Si puedo hablar con Ethan y pedirle que me consiga información sobre cada toro y oso polar de la ciudad…"

# game/act1.rpy:949
translate spanish act1_7a14a2f0:

    # a body concern "{i}But what good would that do for my story? Agh, that’s so needlessly complicated…! Why can’t I just go inside?!"
    a body concern "{i}¿Pero de qué serviría eso para mi historia? ¡Ay, qué complicado es todo…! ¿Por qué no puedo simplemente entrar?!"

# game/act1.rpy:951
translate spanish act1_8e0f8278:

    # "I guess technically I could… but I’m terrified of the consequences. I’d rather play it safe… like I always do."
    "Supongo que técnicamente podría... pero me aterra pensar en las consecuencias. Prefiero ir a lo seguro... como siempre."

# game/act1.rpy:952
translate spanish act1_ddb28b00:

    # "The casino itself might be off limits… but, maybe I could gather information at the registration? Even just going up to the hotel to snoop around would be wonderful."
    "Puede que el casino en sí esté fuera de mi alcance… pero, ¿quizás podría obtener información en la recepción? Incluso con solo ir al hotel a curiosear sería estupendo."

# game/act1.rpy:953
translate spanish act1_28e0dea0:

    # "I’m just about to head towards the registration desk when something coming from the casino entryway catches my eye. Or rather-"
    "Estaba a punto de dirigirme al mostrador de registro cuando algo que venía de la entrada del casino llamó mi atención. O mejor dicho..."

# game/act1.rpy:955
translate spanish act1_631d3f96:

    # anon "Oh my… a Valentine in my casino? To what do I owe the pleasure?"
    anon "¡Oh, vaya!... ¿Un San Valentín en mi casino? ¿A qué debo el placer?"

# game/act1.rpy:957
translate spanish act1_3ef8f47e:

    # "…someone."
    "…alguien."

# game/act1.rpy:959
translate spanish act1_a9737fa7:

    # "The man before me is none other than Leonidas Grey, the current owner of Corona's Casino. To say he’s rich and powerful would be downplaying his status – he’s one of the richest people in the entire country, probably top ten in the world."
    "El hombre que tengo delante no es otro que Leonidas Grey, el actual propietario del Casino Corona. Decir que es rico y poderoso sería subestimar su estatus: es una de las personas más ricas de todo el país, probablemente entre las diez más ricas del mundo."

# game/act1.rpy:960
translate spanish act1_e0c2f3dd:

    # "So, to see him in broad daylight, unprompted and with no security behind him is…"
    "Así que, verlo a plena luz del día, sin que nadie se lo pidiera y sin seguridad detrás de él es…"

# game/act1.rpy:961
translate spanish act1_d3e01b42:

    # "The large lion walks straight up to me, speaking in a sultry, sophisticated way that makes my skin crawl. My pulse quickens, and that feeling of fear comes right back, but I swallow it down, {i}hard."
    "El enorme león se acerca directamente a mí, hablando de una manera sensual y sofisticada que me pone los pelos de punta. Mi pulso se acelera y esa sensación de miedo regresa, pero la reprimo con todas mis fuerzas."

# game/act1.rpy:962
translate spanish act1_f9fb622a:

    # "No one can see that I’m afraid. An emotion means death in this world."
    "Nadie puede ver que tengo miedo. En este mundo, una emoción significa la muerte."

# game/act1.rpy:963
translate spanish act1_4ad61f65:

    # "I stand up straighter, putting one hand on my chest, the other behind my back. I bow, keeping my eyes locked on his, making sure he can’t read anything that might be written on my face."
    "Me irguié, poniendo una mano en el pecho y la otra a la espalda. Hice una reverencia, manteniendo la mirada fija en la suya, asegurándome de que no pudiera leer nada que pudiera estar escrito en mi rostro."

# game/act1.rpy:965
translate spanish act1_8d760f82:

    # a stan "Excuse my intrusion, sir. Angel Valentine, of the Valentine Report. The pleasure is all mine."
    a stan "Disculpe mi intromisión, señor. Soy Angel Valentine, del Valentine Report. El placer es mío."

# game/act1.rpy:967
translate spanish act1_5b7685b5:

    # "He smiles, a low purr rumbling in the back of his throat as he does.{w} I don’t smile back."
    "Él sonríe, un ronroneo bajo retumba en el fondo de su garganta mientras lo hace.{w} Yo no le devuelvo la sonrisa."

# game/act1.rpy:969
translate spanish act1_a6800a27:

    # l "What a rare sight. The last time we had a Valentine enter these premises… oh, far too long."
    l "¡Qué espectáculo tan raro! La última vez que tuvimos a alguien de San Valentín por aquí… ¡ay, hace demasiado tiempo!"

# game/act1.rpy:970
translate spanish act1_1153e934:

    # a frown "Forgive my audacity, sir. I was simply…"
    a frown "Perdone mi osadía, señor. Simplemente…"

# game/act1.rpy:972
translate spanish act1_58790042:

    # "I freeze. I can’t think of a single excuse, and the fear of what this man might do to me is getting to my head."
    "Me quedo paralizada. No se me ocurre ni una sola excusa, y el miedo a lo que este hombre pueda hacerme me está afectando."

# game/act1.rpy:974
translate spanish act1_2534a904:

    # a concern "I… was simply waiting for a client who requested we meet-"
    a concern "Yo… simplemente estaba esperando a un cliente que solicitó que nos reuniéramos."

# game/act1.rpy:975
translate spanish act1_8e15d252:

    # l stan "I have no interest in fictional stories, Valentine. You of all people must understand that, as a seeker of truth."
    l stan "No me interesan las historias de ficción, Valentine. Tú, más que nadie, debes entenderlo, como buscador de la verdad."

# game/act1.rpy:976
translate spanish act1_497e7220:

    # "He purrs when he speaks, that English accent of his making every word that comes out of his mouth sound like something important."
    "Ronronea al hablar, y ese acento inglés suyo hace que cada palabra que sale de su boca suene como algo importante."

# game/act1.rpy:978
translate spanish act1_72e94c19_1:

    # a "…"
    a "…"

# game/act1.rpy:979
translate spanish act1_bdb7e440:

    # l ponder "As a matter of fact… I believe you have some business with me, do you not?"
    l ponder "De hecho… creo que tienes algún asunto que tratar conmigo, ¿no es así?"

# game/act1.rpy:980
translate spanish act1_afa540c7:

    # a surprised "Business? No, I-"
    a surprised "¿Negocios? No, yo-"

# game/act1.rpy:981
translate spanish act1_8c2ea5f9:

    # l surprised "No? There isn’t anything that you’d like to talk about with me?"
    l surprised "¿No? ¿No hay nada de lo que quieras hablar conmigo?"

# game/act1.rpy:982
translate spanish act1_9e0a61a1:

    # l peek "Is the reason you’re here… none of my concern?"
    l peek "¿El motivo por el que estás aquí... no me incumbe?"

# game/act1.rpy:985
translate spanish act1_f3e195f2:

    # "The gross, icky feeling of being wrapped around someone else’s finger seeps into me, his eyes drilling into mine, not even blinking once."
    "La desagradable y repulsiva sensación de estar envuelta en las garras de otra persona se filtra en mí, sus ojos clavados en los míos, sin siquiera parpadear una sola vez."

# game/act1.rpy:986
translate spanish act1_fba30e4e:

    # "It’s the same feeling I had with Mr. Yoshida, Mr. Valentine… and now, Mr. Grey. That’s my place in this city: nothing more than a pawn in the bigger game of chess these men play with each other."
    "Es la misma sensación que tuve con el señor Yoshida, el señor Valentine… y ahora, el señor Grey. Ese es mi lugar en esta ciudad: nada más que un peón en la partida de ajedrez que estos hombres juegan entre sí."

# game/act1.rpy:988
translate spanish act1_1ab72481_3:

    # a concern "…"
    a concern "…"

# game/act1.rpy:989
translate spanish act1_dd558478:

    # a "I do have some business with you, sir."
    a "Tengo algunos asuntos que tratar con usted, señor."

# game/act1.rpy:990
translate spanish act1_f5891c95:

    # l ponder "That’s what I thought. Come then, Valentine."
    l ponder "Eso es lo que pensaba. Vamos, Valentine."

# game/act1.rpy:992
translate spanish act1_f42dbed1:

    # "He turns and heads deeper into the building, not checking to see if I follow him; he knows I will. With a racing pulse, I lift my chin up and walk a few feet behind him, silently wondering if I’ll make it out of here alive."
    "Se da la vuelta y se adentra más en el edificio, sin comprobar si lo sigo; sabe que lo haré. Con el pulso acelerado, levanto la barbilla y camino unos pasos detrás de él, preguntándome en silencio si saldré de aquí con vida."

# game/act1.rpy:995
translate spanish act1_b287243b:

    # "Walking straight past the reception desk, we enter the main lobby of the building: a beautiful, vast room with large staircases leading up to the rooms of the many elites who will no doubt enjoy their time here."
    "Pasando directamente por la recepción, entramos en el vestíbulo principal del edificio: una sala hermosa y espaciosa con grandes escaleras que conducen a las habitaciones de las numerosas personalidades de la élite que sin duda disfrutarán de su estancia aquí."

# game/act1.rpy:997
translate spanish act1_b038933a:

    # a yeesh "{i}And spend a ton of cash in the process."
    a yeesh "{i}Y gastar una tonelada de dinero en el proceso."

# game/act1.rpy:999
translate spanish act1_e84a32a7:

    # "I’m in awe at such a luxurious place. Even in my wildest dreams, I don’t dream something this big."
    "Estoy maravillada ante un lugar tan lujoso. Ni en mis sueños más descabellados imagino algo tan grandioso."

# game/act1.rpy:1000
translate spanish act1_664d556c:

    # "Mr. Grey keeps his stride as we walk up the steps, and to my surprise, strikes up a friendly conversation with me."
    "El señor Grey mantuvo su paso firme mientras subíamos los escalones y, para mi sorpresa, entabló una conversación amistosa conmigo."

# game/act1.rpy:1002
translate spanish act1_d31e48d4:

    # l "Is this your first time inside?"
    l "¿Es la primera vez que entras?"

# game/act1.rpy:1003
translate spanish act1_b3754221:

    # a flustered "Yes, sir."
    a flustered "Sí, señor."

# game/act1.rpy:1004
translate spanish act1_0612a485:

    # l "Marvelous, isn’t it? Its brilliance doesn’t get any easier to get used to, I’ve come to experience."
    l "Maravilloso, ¿verdad? Su brillantez no se vuelve más fácil de apreciar con el tiempo, según he podido comprobar."

# game/act1.rpy:1005
translate spanish act1_06f39335_4:

    # a stan "…"
    a stan "…"

# game/act1.rpy:1007
translate spanish act1_0b995d43:

    # "That’s right… If I remember correctly, Mr. Grey isn’t actually a descendant of the original owners of this place. The details of how he came to be are muddled, and kept under wraps. Even the Valentine Report doesn’t have any files on it."
    "Así es… Si no me equivoco, el Sr. Grey no es descendiente de los dueños originales de este lugar. Los detalles de su origen son confusos y se mantienen en secreto. Ni siquiera el Informe Valentine contiene información al respecto."

# game/act1.rpy:1008
translate spanish act1_df242a5b:

    # "All the more reason to be guarded. This man must be as dangerous as he is enigmatic."
    "Con mayor razón debemos estar alerta. Este hombre debe ser tan peligroso como enigmático."

# game/act1.rpy:1011
translate spanish act1_6b7f354c:

    # "We reach a hallway that leads down an elevator, and with the push of a button, it opens for him instantly."
    "Llegamos a un pasillo que conduce a un ascensor, y con solo pulsar un botón, este se abre para él al instante."

# game/act1.rpy:1013
translate spanish act1_464520cd:

    # l "After you."
    l "Después de usted."

# game/act1.rpy:1015
translate spanish act1_3e3d84fa:

    # "We both get inside of it. He presses his fingers on some sort of fingerprint scanner, making the elevator shoot up with surprising speed."
    "Entramos los dos. Él presiona sus dedos sobre una especie de escáner de huellas dactilares, lo que hace que el ascensor suba a una velocidad sorprendente."

# game/act1.rpy:1016
translate spanish act1_1b226aed:

    # "I fiddle with my bangs, taking in my surroundings. A high-tech elevator going at max speed, a camera on the upper right corner with a glowing red dot, mirrors on every wall. It’s an assault on the senses, to say the least."
    "Me acaricio el flequillo mientras observo mi entorno. Un ascensor de alta tecnología a toda velocidad, una cámara en la esquina superior derecha con un punto rojo brillante, espejos en todas las paredes. Es un asalto a los sentidos, por decir lo menos."

# game/act1.rpy:1017
translate spanish act1_74406a91:

    # "Finally, we reach an undefined number of floors up, and the doors open again. Mr. Grey gestures for me to walk out first, and I think to myself how if I’m going to be killed here, it’s nice he’s being a gentleman about it."
    "Finalmente, llegamos a un número indeterminado de pisos más arriba, y las puertas se abren de nuevo. El señor Grey me hace un gesto para que salga primero, y pienso para mis adentros que, si me van a matar aquí, es un detalle que se comporte como un caballero."

# game/act1.rpy:1018
translate spanish act1_ddfb6ff3:

    # "After another short walk down a hallway, we reach a door he opens with zero hesitation, leading to what I can only assume is his office."
    "Tras un breve paseo por un pasillo, llegamos a una puerta que él abre sin dudarlo, y que da a lo que supongo que es su oficina."

# game/act1.rpy:1023
translate spanish act1_7b073ca2:

    # l "Have a seat, Valentine. Would you like a drink?"
    l "Toma asiento, Valentine. ¿Quieres algo de beber?"

# game/act1.rpy:1025
translate spanish act1_7dec20c7:

    # "I subtly look around as I do what I’m told, sitting down as he pours himself a glass of what is most likely whiskey."
    "Miro disimuladamente a mi alrededor mientras hago lo que me dicen, sentándome mientras él se sirve un vaso de lo que probablemente sea whisky."

# game/act1.rpy:1027
translate spanish act1_677dd66f:

    # a "No, thank you."
    a "No, gracias."

# game/act1.rpy:1029
translate spanish act1_e850918b:

    # "He drapes his coat on his large chair and sits down in front of me with a sigh, leaning back on his chair in a cool, collected manner. He looks at me… {i}really{/i} looks at me, eyeing me up and down and taking everything in.{w} It makes me feel naked."
    "Él deja caer su abrigo sobre su gran silla y se sienta frente a mí con un suspiro, reclinándose en su silla de una manera fría y serena. Me mira… {i}realmente{/i}me mira, observándome de arriba abajo y absorbiendo todo.{w} Me hace sentir desnuda."

# game/act1.rpy:1032
translate spanish act1_74d66e96:

    # l ponder "Before we discuss anything, I’d like to make one simple condition."
    l ponder "Antes de hablar de nada, me gustaría hacer una simple condición."

# game/act1.rpy:1034
translate spanish act1_9af356c8:

    # a concern "And… that is?"
    a concern "¿Y... eso es?"

# game/act1.rpy:1036
translate spanish act1_7ec6b243:

    # l serious "No lies."
    l serious "No hay mentiras."

# game/act1.rpy:1038
translate spanish act1_8225f837:

    # l stan "You’ve come here for the truth, yes? Then, I’ll give it to you. I only ask for the same treatment in return."
    l stan "Has venido aquí en busca de la verdad, ¿verdad? Entonces, te la daré. Solo pido el mismo trato a cambio."

# game/act1.rpy:1039
translate spanish act1_e482e608:

    # l surprised "Do we have a deal, Valentine?"
    l surprised "¿Tenemos un trato, Valentine?"

# game/act1.rpy:1042
translate spanish act1_71ad9d89:

    # a "Yes, sir."
    a "Sí, señor."

# game/act1.rpy:1044
translate spanish act1_86a916a1:

    # l peek "Good.{w} I hope you mean it. I’m quite good at calling someone’s bluff."
    l peek "Bien.{w} Espero que lo digas en serio. Soy bastante bueno desenmascarando a la gente."

# game/act1.rpy:1045
translate spanish act1_89086a83:

    # a hm "{i}I’m sure you are…"
    a hm "{i}Estoy seguro de que lo eres…"

# game/act1.rpy:1046
translate spanish act1_44691850:

    # l stan "Very well, Valentine. Please, do tell what business it is you have with me."
    l stan "Muy bien, Valentine. Por favor, dime qué asunto tienes conmigo."

# game/act1.rpy:1049
translate spanish act1_47aa83e4:

    # "I swallow hard. Do I really just… lay it out honestly to him? It’s what he asked for, but…"
    "Trago saliva con dificultad. ¿De verdad debo... decírselo con total sinceridad? Es lo que me pidió, pero..."

# game/act1.rpy:1052
translate spanish act1_4c145d88:

    # "Something tells me he won’t appreciate anything but the cold, hard truth."
    "Algo me dice que no apreciará nada que no sea la cruda y dura verdad."

# game/act1.rpy:1054
translate spanish act1_1ab72481_4:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1055
translate spanish act1_ac50d5dc:

    # a frown "{i}Fine. Have it your way."
    a frown "{i}Bien. Como quieras."

# game/act1.rpy:1057
translate spanish act1_ddbc6019:

    # a bashful "You won’t mind if I record this, would you, Mr. Grey?"
    a bashful "¿No le importará que grabe esto, señor Grey?"

# game/act1.rpy:1058
translate spanish act1_e616ed6c:

    # l ponder "Certainly not. By all means."
    l ponder "Desde luego que no. Por supuesto."

# game/act1.rpy:1060
translate spanish act1_8f2ca2b0:

    # "I lay my recorder on his desk, pressing the button to start it up, and lean back on my seat, mirroring his gaze."
    "Dejé la grabadora sobre su escritorio, pulsé el botón para encenderla y me recosté en mi asiento, reflejando su mirada."

# game/act1.rpy:1062
translate spanish act1_6208a9ee:

    # a stan "Ms. Megumi Yoshida has been missing for the past three months. She was last seen here, in your casino. Several reports indicate that she isn’t the only missing person in the last twelve months that was last seen in this location."
    a stan "La Sra. Megumi Yoshida lleva desaparecida tres meses. Fue vista por última vez aquí, en su casino. Varios informes indican que no es la única persona desaparecida en los últimos doce meses que fue vista por última vez en este lugar."

# game/act1.rpy:1064
translate spanish act1_91055c0c:

    # a frown "Every other press has been silent; the police have also made little attempts to actually search for these individuals… which is why their families have come to us: The Valentine Report."
    a frown "El resto de la prensa ha guardado silencio; la policía también ha hecho pocos intentos por buscar a estas personas... razón por la cual sus familias han acudido a nosotros: El Informe Valentine."

# game/act1.rpy:1065
translate spanish act1_877caacc:

    # a "Do you have any explanations for this… Mr. Grey?"
    a "¿Tiene usted alguna explicación para esto, señor Grey?"

# game/act1.rpy:1068
translate spanish act1_96aec05d:

    # "He grins, a somewhat satisfied look on his face. Whatever I did right, it must have pleased him.{w} Not that I could care in the slightest."
    "Sonríe, con una expresión de cierta satisfacción en el rostro. Lo que sea que haya hecho bien, debió haberle complacido.{w} No es que me importe lo más mínimo."

# game/act1.rpy:1070
translate spanish act1_7b7a8542:

    # l surprised "This is all very true, Valentine. People have been going missing for quite some time now in Sonora. The number seems to pile up every day."
    l surprised "Es totalmente cierto, Valentine. La gente lleva desapareciendo desde hace bastante tiempo en Sonora. El número parece aumentar cada día."

# game/act1.rpy:1071
translate spanish act1_67e3cebf:

    # l shocked "As for explanations…{w} I’m afraid I have none."
    l shocked "En cuanto a explicaciones…{w} me temo que no tengo ninguna."

# game/act1.rpy:1073
translate spanish act1_9b636321:

    # a concern "Pardon?"
    a concern "¿Indulto?"

# game/act1.rpy:1074
translate spanish act1_62cdc8a8:

    # l "It’s true. I’m as dumbfounded as you are, love. I have no involvement in any of these disappearances, and my staff has been closely monitored to ensure no one is up to anything nefarious behind my back."
    l "Es cierto. Estoy tan perplejo como tú, cariño. No tengo nada que ver con ninguna de estas desapariciones, y mi personal ha sido vigilado de cerca para asegurar que nadie esté tramando nada turbio a mis espaldas."

# game/act1.rpy:1075
translate spanish act1_10c63832:

    # l serious "It’s a pity and a shame what happened to those people… but unfortunately for you, Valentine, my hands are clean."
    l serious "Es una lástima y una vergüenza lo que les pasó a esas personas... pero, por desgracia para ti, Valentine, mis manos están limpias."

# game/act1.rpy:1076
translate spanish act1_8ef2c679_2:

    # a frown "…"
    a frown "…"

# game/act1.rpy:1078
translate spanish act1_a7f95762:

    # "Bullshit. There’s no way one of the most powerful men on this earth doesn’t know what’s going on at every given moment."
    "Tonterías. Es imposible que uno de los hombres más poderosos del planeta no sepa lo que ocurre en cada momento."

# game/act1.rpy:1079
translate spanish act1_f6e35ec2:

    # "He’s lying to me. He has to be…"
    "Me está mintiendo. Tiene que ser…"

# game/act1.rpy:1081
translate spanish act1_9fdce16c:

    # l hm "Tell me, Valentine… why would I stain my own reputation, and my casino’s reputation for that matter, by committing such an atrocity right here in this very building? What would the people say about me? What must they be saying now?"
    l hm "Dime, Valentine… ¿por qué mancharía mi reputación, y la de mi casino, cometiendo semejante atrocidad aquí mismo, en este edificio? ¿Qué diría la gente de mí? ¿Qué estarán diciendo ahora?"

# game/act1.rpy:1082
translate spanish act1_fcc463d7:

    # l serious "I have no desire to enact violence. No need to resort to crimes to exact justice. I am just as you see me: a businessman."
    l serious "No tengo ningún deseo de recurrir a la violencia. No necesito recurrir a delitos para hacer justicia. Soy tal como me ven: un hombre de negocios."

# game/act1.rpy:1083
translate spanish act1_cc4fa49c:

    # l shocked "Ms. Yoshida did frequent our casino, but she did so of her own volition. She never owed us any money, as Corona never loans to anyone."
    l shocked "La Sra. Yoshida frecuentaba nuestro casino, pero lo hacía por voluntad propia. Nunca nos debió dinero, ya que Corona nunca presta dinero a nadie."

# game/act1.rpy:1084
translate spanish act1_d6131dcd:

    # l ponder "Now what reason would I possibly have to harm a young woman who gives me business?"
    l ponder "¿Qué motivo tendría yo para hacerle daño a una joven que me da trabajo?"

# game/act1.rpy:1087
translate spanish act1_1ab72481_5:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1089
translate spanish act1_f33cee1c:

    # "As much as I hate to admit it, he might have a point. Megumi wasn’t exactly indebted to the casino… and having so many disappearances all center Corona’s... someone like Mr. Grey couldn’t possibly be dumb enough to overlook that."
    "Aunque me cueste admitirlo, puede que tenga razón. Megumi no estaba precisamente endeudada con el casino… y con tantas desapariciones relacionadas con Corona… alguien como el Sr. Grey no podría ser tan tonto como para pasarlo por alto."

# game/act1.rpy:1091
translate spanish act1_889601ec:

    # a "So, then… if not you, it must be someone from your staff. Someone with access to the video footage of the casino? Someone trying to harm your reputation?"
    a "Entonces, si no fuiste tú, debe ser alguien de tu personal. ¿Alguien con acceso a las grabaciones de vídeo del casino? ¿Alguien que intenta dañar tu reputación?"

# game/act1.rpy:1092
translate spanish act1_7ce92d85:

    # l ponder "Rest assured, these are all scenarios I’ve accounted for. My staff is under my watchful eye. None of them are involved. The full, unedited tape was willfully given to the police department. And as for someone trying to harm my image…"
    l ponder "Tengan la seguridad de que he previsto todos estos escenarios. Mi personal está bajo mi atenta supervisión. Ninguno de ellos está involucrado. La grabación completa, sin editar, fue entregada voluntariamente al departamento de policía. Y en cuanto a alguien que intenta dañar mi imagen…"

# game/act1.rpy:1093
translate spanish act1_1e57f20e:

    # l serious "Perhaps that may be the case. But it is no one I personally know, or anyone under me."
    l serious "Quizás sea así. Pero no es nadie que yo conozca personalmente, ni nadie que esté bajo mi mando."

# game/act1.rpy:1096
translate spanish act1_60fe82d1:

    # a frown "Why should I just take your word for it?"
    a frown "¿Por qué debería simplemente creerte?"

# game/act1.rpy:1098
translate spanish act1_f11dcd81:

    # l ponder "Oh, Valentine… did we not have an agreement? My word is good."
    l ponder "Oh, Valentine… ¿no teníamos un acuerdo? Mi palabra es buena."

# game/act1.rpy:1099
translate spanish act1_c2267708:

    # l peek "And I think, deep down, you know that."
    l peek "Y creo que, en el fondo, lo sabes."

# game/act1.rpy:1101
translate spanish act1_c44d2f4a:

    # l "Don’t you, Angel?"
    l "¿Verdad, Ángel?"

# game/act1.rpy:1103
translate spanish act1_6c249d5a:

    # "My stomach drops."
    "Se me revuelve el estómago."

# game/act1.rpy:1104
translate spanish act1_c4312f07:

    # a scared "H… How do you…?"
    a scared "H… ¿Cómo lo haces…?"

# game/act1.rpy:1105
translate spanish act1_130ddcba:

    # l "You see, I’ve done my homework."
    l "Como ves, he hecho mi tarea."

# game/act1.rpy:1107
translate spanish act1_9752d698:

    # "He grabs a folder that had been sitting on his desk, flipping it open as a cold feeling trickles down my spine."
    "Agarra una carpeta que estaba sobre su escritorio y la abre mientras un escalofrío me recorre la espalda."

# game/act1.rpy:1109
translate spanish act1_b320a40d:

    # l peek "Mr. Angel Valentine. Unlike many of your peers, you began training to become a Valentine at a remarkably young age, and graduated with flying colors. At just twenty-three, you now have a high-profile case in your hands at the investigation unit of the company."
    l peek "Señor Ángel Valentine. A diferencia de muchos de sus compañeros, usted comenzó su formación como Valentine a una edad muy temprana y se graduó con honores. Con tan solo veintitrés años, ahora tiene entre manos un caso de gran relevancia en la unidad de investigación de la empresa."

# game/act1.rpy:1110
translate spanish act1_52556f33:

    # l surprised "Most Valentines don’t even get to be in the ‘Journalist’ unit, much less receive important cases such as these… one has to wonder, how did you do it?"
    l surprised "La mayoría de los Valentine ni siquiera llegan a estar en la unidad de \"Periodismo\", y mucho menos a recibir casos importantes como estos... uno se pregunta, ¿cómo lo hiciste?"

# game/act1.rpy:1111
translate spanish act1_50806284:

    # a nngh "…"
    a nngh "…"

# game/act1.rpy:1112
translate spanish act1_3b153748:

    # l peek "Hm… perhaps because you’ve had to work twice as hard for it? I mean, if your debt is anything to base my assumptions on."
    l peek "Mmm... ¿quizás porque has tenido que trabajar el doble para conseguirlo? Es decir, si me baso en tu deuda para deducir algo."

# game/act1.rpy:1113
translate spanish act1_60a29c2f:

    # l shocked "50,000 dollars, Angel. How does a teenager garner that much debt?"
    l shocked "50.000 dólares, Ángel. ¿Cómo puede un adolescente acumular tanta deuda?"

# game/act1.rpy:1116
translate spanish act1_7c65ec3e:

    # a "That… doesn’t concern you, Mr. Grey."
    a "Eso… no le incumbe, señor Grey."

# game/act1.rpy:1117
translate spanish act1_89451eb4:

    # l ponder "Oh? Perhaps you’re right."
    l ponder "¿Ah, sí? Quizás tengas razón."

# game/act1.rpy:1118
translate spanish act1_5838cd4b:

    # l peek "It doesn’t concern me… this is between you and your mother, isn’t it?"
    l peek "No me incumbe... esto es algo entre tú y tu madre, ¿no?"

# game/act1.rpy:1119
translate spanish act1_07ceb950:

    # a scared "…!"
    a scared "…!"

# game/act1.rpy:1120
translate spanish act1_af4a0232:

    # l hm "This must be {i}her{/i} debt… how cruel. Pushing it onto her thirteen-year-old son, giving him no choice but to work it off for her. Tell me, Angel… when do you estimate you’ll pay this off?"
    l hm "Esta debe ser su deuda… ¡qué cruel! Echándosela a su hijo de trece años, sin darle más remedio que pagarla. Dime, Ángel… ¿cuándo crees que la pagarás?"

# game/act1.rpy:1121
translate spanish act1_90b79f9a:

    # a nngh "Please…"
    a nngh "Por favor…"

# game/act1.rpy:1122
translate spanish act1_f22f1395:

    # l shocked "If my calculations are correct - and rest assured, they are - you’ve paid off less than ten percent of your total debt. Have you done the math, love?"
    l shocked "Si mis cálculos son correctos —y te aseguro que lo son— has pagado menos del diez por ciento de tu deuda total. ¿Has hecho los cálculos, cariño?"

# game/act1.rpy:1123
translate spanish act1_bacbc201:

    # l serious "It’ll take more than forty years for your debt to be finalized."
    l serious "Su deuda tardará más de cuarenta años en saldarse definitivamente."

# game/act1.rpy:1124
translate spanish act1_d8eb5386:

    # a scared "…"
    a scared "…"

# game/act1.rpy:1125
translate spanish act1_01658988:

    # l ponder "Of course, I’m not counting bonuses. That must shave off a few months or two in the equation, correct? Now, why don’t we-?"
    l ponder "Por supuesto, no estoy contando las bonificaciones. Eso debe restar un par de meses en la ecuación, ¿verdad? Ahora, ¿por qué no...?"

# game/act1.rpy:1129
translate spanish act1_48ca1703:

    # a scared "Please, stop!!"
    a scared "¡Por favor, detente!"

# game/act1.rpy:1131
translate spanish act1_9fa7f313:

    # a "Please… why are you doing this...?"
    a "Por favor… ¿por qué estás haciendo esto...?"

# game/act1.rpy:1134
translate spanish act1_d66ee287:

    # l "My apologies, Angel. I did not mean to upset you."
    l "Lo siento mucho, Ángel. No quise molestarte."

# game/act1.rpy:1135
translate spanish act1_f07a8d7f:

    # l ponder "You see… I just find you…{w} fascinating."
    l ponder "Verás… simplemente me pareces…{w} fascinante."

# game/act1.rpy:1137
translate spanish act1_fc143fa3:

    # a concern "…what?"
    a concern "…¿qué?"

# game/act1.rpy:1139
translate spanish act1_95fe2f03:

    # l stan "Indeed. Someone who wasn’t given a choice as to what their life may look like, how their story will play out. It’s exceptionally cruel… so much potential, so much intelligence… but has anyone ever asked you…"
    l stan "En efecto. Alguien a quien no se le dio la opción de elegir cómo sería su vida, cómo se desarrollaría su historia. Es excepcionalmente cruel… tanto potencial, tanta inteligencia… pero ¿alguna vez te han preguntado…"

# game/act1.rpy:1140
translate spanish act1_a7c3abd5:

    # l peek "What it is that {i}you{/i} want to do with your life, Angel? When you fall asleep at night, do you allow yourself to dream? Or is the very notion utterly ridiculous?"
    l peek "¿Qué es lo que quieres hacer con tu vida, Ángel? Cuando te duermes por la noche, ¿te permites soñar? ¿O es la sola idea completamente ridícula?"

# game/act1.rpy:1143
translate spanish act1_acee1a87:

    # "I just stare at him, that cold feeling still permeating throughout my body, flowing through my bloodstream right up to my fingertips."
    "Me quedo mirándolo fijamente, con esa sensación de frío aún recorriendo todo mi cuerpo, fluyendo por mi torrente sanguíneo hasta la punta de mis dedos."

# game/act1.rpy:1144
translate spanish act1_9b097c91:

    # "Just who is this man…?"
    "¿Quién es este hombre...?"

# game/act1.rpy:1147
translate spanish act1_25fb7bdb:

    # l ponder "It fascinates me…{w} so I’d like to play a game with you."
    l ponder "Me fascina…{w} así que me gustaría jugar un juego contigo."

# game/act1.rpy:1150
translate spanish act1_659527a9:

    # a "A… game?"
    a "¿Un… juego?"

# game/act1.rpy:1151
translate spanish act1_2b01422b:

    # l "Precisely. As you might already know, this casino wasn’t mine to begin with, and I have no familial ties to its original owners."
    l "Exactamente. Como ya sabrás, este casino no era mío desde un principio, y no tengo ningún vínculo familiar con sus dueños originales."

# game/act1.rpy:1152
translate spanish act1_f145c840:

    # l ponder "To make a very long story short… I won it. In a gamble."
    l ponder "Para resumir una historia muy larga… lo gané. En una apuesta."

# game/act1.rpy:1153
translate spanish act1_1ab72481_6:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1154
translate spanish act1_42e9e275:

    # l "It was a surprisingly ordinary game of poker… but oh, how wonderful it was. It still stays in my memory as one of the most thrilling experiences of my life."
    l "Fue una partida de póker sorprendentemente normal… pero ¡qué maravillosa fue! Aún la recuerdo como una de las experiencias más emocionantes de mi vida."

# game/act1.rpy:1155
translate spanish act1_fd8d5b35:

    # l surprised "Baring it all on the line, your entire life… for the chance of success. {i}That{/i} is what I believe divides the strong from the weak."
    l surprised "Arriesgarlo todo, toda tu vida… por la posibilidad de éxito. {i}Eso{/i} es lo que creo que separa a los fuertes de los débiles."

# game/act1.rpy:1156
translate spanish act1_4fa8003e:

    # l ponder "How much are we willing to risk for the greatest return…?"
    l ponder "¿Cuánto estamos dispuestos a arriesgar para obtener la mayor rentabilidad...?"

# game/act1.rpy:1158
translate spanish act1_32098d40:

    # "He opens a drawer on his desk, and slowly, carefully, places a gold coin in the middle of the surface, the weight of it making a deep sounding {i}clink{/i} against the smooth wood. It has a crown engraved on one side, a jester's hat on the other."
    "Abre un cajón de su escritorio y, lentamente y con cuidado, coloca una moneda de oro en el centro de la superficie. Su peso produce un profundo tintineo contra la madera lisa. Tiene una corona grabada en un lado y un sombrero de bufón en el otro."

# game/act1.rpy:1160
translate spanish act1_090b14d8:

    # l ponder "It’s a simple coin flip. A fifty-fifty chance."
    l ponder "Es como lanzar una moneda al aire. Una probabilidad del cincuenta por ciento."

# game/act1.rpy:1161
translate spanish act1_fcd43039:

    # l stan "If you win…{w} I’ll give you my casino."
    l stan "Si ganas…{w} te daré mi casino."

# game/act1.rpy:1163
translate spanish act1_d8eb5386_1:

    # a scared "…"
    a scared "…"

# game/act1.rpy:1165
translate spanish act1_e5aedeb0:

    # a "That’s… it…?"
    a "Eso es todo…?"

# game/act1.rpy:1167
translate spanish act1_f595ad40:

    # "He lifts his brows in genuine amusement."
    "Él levanta las cejas con genuina diversión."

# game/act1.rpy:1169
translate spanish act1_4134af49:

    # l surprised "Oh? Would you like something more?"
    l surprised "¿Oh? ¿Te gustaría algo más?"

# game/act1.rpy:1170
translate spanish act1_ed0591ac:

    # a concern "N-No no! I mean… Just like that?! What… Why would you do that?!"
    a concern "¡N-No, no! Quiero decir… ¿Así sin más? ¿Qué… Por qué harías eso?"

# game/act1.rpy:1171
translate spanish act1_f12140c4:

    # l cocky "Why? Well…"
    l cocky "¿Por qué? Bueno…"

# game/act1.rpy:1172
translate spanish act1_2de68f0f:

    # l ponder "Because if you lose…"
    l ponder "Porque si pierdes…"

# game/act1.rpy:1173
translate spanish act1_755a6a34:

    # l peek "I want you to work as my personal assistant.{w} For the rest of your days."
    l peek "Quiero que trabajes como mi asistente personal.{w} Por el resto de tus días."

# game/act1.rpy:1174
translate spanish act1_19e37536:

    # l ponder "All of the knowledge that the Valentine Academy has taught you, all of your experiences in the agency… someone like you, working in {i}my{/i} casino…"
    l ponder "Todo el conocimiento que la Academia Valentine te ha enseñado, todas tus experiencias en la agencia… alguien como tú, trabajando en {i}mi{/i} casino…"

# game/act1.rpy:1175
translate spanish act1_a0ba2d50:

    # l peek "Better still, under my watchful gaze… {w}and under my complete mercy..."
    l peek "Mejor aún, bajo mi atenta mirada… {w}y bajo mi completa clemencia…"

# game/act1.rpy:1176
translate spanish act1_94184006:

    # l grin "Oh, I’d wager much more than my casino for a chance to have that."
    l grin "Oh, apostaría mucho más que mi casino por tener la oportunidad de conseguir eso."

# game/act1.rpy:1179
translate spanish act1_9169c6d7:

    # a scared "You’re… insane… That’s just crazy! Why would you make such a gamble?!"
    a scared "Estás... loco... ¡Eso es una locura! ¿Por qué harías semejante riesgo?"

# game/act1.rpy:1181
translate spanish act1_0e96fe73:

    # l surprised "Isn’t it fair? In the world of gambling, it doesn’t matter what your status is, who you are, what you’ve done… all that matters is what you put on the line, and who will emerge victorious."
    l surprised "¿No es justo? En el mundo de las apuestas, no importa cuál sea tu estatus, quién seas, qué hayas hecho... lo único que importa es lo que te juegas y quién saldrá victorioso."

# game/act1.rpy:1182
translate spanish act1_89dbef3e:

    # l ponder "We decide our fates. We choose to put our livelihoods on the line. What greater act of rebellion against the world exists? To decide to risk your life, and leave it up to fate?"
    l ponder "Nosotros decidimos nuestro destino. Elegimos arriesgar nuestro sustento. ¿Qué mayor acto de rebeldía contra el mundo existe? ¿Decidir arriesgar la vida y dejarla en manos del destino?"

# game/act1.rpy:1183
translate spanish act1_b8ae10f7:

    # l grin "I truly believe… that the risk makes the man. How can you live in a world where you’re afraid of its natural state – of loss? Of change?"
    l grin "Creo firmemente que el riesgo forja al hombre. ¿Cómo se puede vivir en un mundo donde se le teme a su estado natural, a la pérdida? ¿Al cambio?"

# game/act1.rpy:1184
translate spanish act1_1ab72481_7:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1185
translate spanish act1_5d6cf7e9:

    # l ponder "So, tell me, Angel… right here, right now, you and I are equals. We can both lose our livelihoods in the blink of an eye… or, we can gain something truly remarkable… and truly lifechanging."
    l ponder "Así que, dime, Ángel… aquí y ahora, tú y yo somos iguales. Ambos podemos perder nuestro sustento en un abrir y cerrar de ojos… o podemos obtener algo verdaderamente extraordinario… y que nos cambie la vida."

# game/act1.rpy:1186
translate spanish act1_3efc1ae2:

    # l grin "You can be free… and I’ll have the most fascinating thing my eyes have ever laid upon, right on the palm of my paw."
    l grin "Podrás ser libre... y yo tendré lo más fascinante que mis ojos hayan visto jamás, justo en la palma de mi mano."

# game/act1.rpy:1187
translate spanish act1_2e13a4b5:

    # l "The choice is now fully yours."
    l "La decisión ahora es completamente suya."

# game/act1.rpy:1189
translate spanish act1_d8eb5386_2:

    # a scared "…"
    a scared "…"

# game/act1.rpy:1191
translate spanish act1_8b788452:

    # "I stare at the coin, one simple gold coin that probably isn’t worth much… holding so much power inside of it, so much potential."
    "Me quedo mirando la moneda, una simple moneda de oro que probablemente no valga mucho... pero que encierra tanto poder, tanto potencial."

# game/act1.rpy:1192
translate spanish act1_aa149f53:

    # "When have I ever been given the chance to decide on… anything, really? Mr. Grey is right. My life was carefully laid out for me from the moment I was forced to join the Valentine Agency."
    "¿Cuándo he tenido la oportunidad de decidir sobre... algo, en realidad? El señor Grey tiene razón. Mi vida fue cuidadosamente planificada desde el momento en que me obligaron a unirme a la Agencia Valentine."

# game/act1.rpy:1193
translate spanish act1_7fa7d4b8:

    # "But now… I’ve been given a choice. A ‘What if?’ scenario."
    "Pero ahora… me han dado a elegir. Un escenario de \"¿Qué pasaría si…?\"."

# game/act1.rpy:1194
translate spanish act1_235129c4:

    # "What if…{w} I accept?"
    "¿Y si…{w} acepto?"

# game/act1.rpy:1195
translate spanish act1_3e5ca1a8:

    # "I could win. The odds aren’t that bad… I could own Corona, pay off my debt in an instant, do whatever I wanted for the rest of my life…!"
    "Podría ganar. Las probabilidades no son tan malas… ¡Podría ser dueño de Corona, pagar mis deudas en un instante, hacer lo que quisiera por el resto de mi vida…!"

# game/act1.rpy:1196
translate spanish act1_2455f43b:

    # "Or… I could lose. I could live the rest of my life by this lunatic’s side, doing God knows what with him, probably still trying to pay off my debt until I’m sixty…"
    "O… podría perder. Podría pasarme el resto de mi vida al lado de este lunático, haciendo quién sabe qué con él, probablemente intentando seguir pagando mi deuda hasta los sesenta años…"

# game/act1.rpy:1197
translate spanish act1_fea24e1f:

    # "With no hope in sight."
    "Sin ninguna esperanza a la vista."

# game/act1.rpy:1198
translate spanish act1_af7b4225:

    # "Is that really a risk… I’m capable of taking?{w} Allowed to take?"
    "¿Es ese realmente un riesgo... que soy capaz de correr?{w} ¿Permitido correr?"

# game/act1.rpy:1203
translate spanish act1_384472ec:

    # a sad "No."
    a sad "No."

# game/act1.rpy:1205
translate spanish act1_b4150a31:

    # l serious "No…"
    l serious "No…"

# game/act1.rpy:1207
translate spanish act1_88279e59:

    # "Mr. Grey lets out a long sigh, deflating against his sturdy chair, the glimmer that was once in his eyes fizzling out in a heartbeat."
    "El señor Grey deja escapar un largo suspiro, dejándose caer contra su robusta silla, y el brillo que una vez iluminó sus ojos se desvanece en un instante."

# game/act1.rpy:1209
translate spanish act1_804b02be:

    # l "Of course, the answer is no."
    l "Por supuesto, la respuesta es no."

# game/act1.rpy:1210
translate spanish act1_dbd3547a:

    # l serious "As always, those who are afraid to lose will never play any kind of game."
    l serious "Como siempre, quienes tienen miedo a perder nunca jugarán ningún tipo de juego."

# game/act1.rpy:1211
translate spanish act1_4e9b20ee:

    # a concern "I’m sorry… but I’m not just gambling my own life… I have someone who depends on me…"
    a concern "Lo siento… pero no solo estoy arriesgando mi propia vida… tengo a alguien que depende de mí…"

# game/act1.rpy:1212
translate spanish act1_f05c3207:

    # a frown "And Valentines don’t gamble."
    a frown "Y los enamorados no juegan."

# game/act1.rpy:1214
translate spanish act1_05affc4a:

    # l disappointed "I suppose you’re right. You have a life you simply can’t afford to lose, it seems."
    l disappointed "Supongo que tienes razón. Parece que tienes una vida que simplemente no puedes permitirte perder."

# game/act1.rpy:1215
translate spanish act1_35921a3f:

    # l serious "Very well."
    l serious "Muy bien."

# game/act1.rpy:1217
translate spanish act1_996e4abc:

    # "He grabs the coin and haphazardly throws it back in his cabinet, leaning back in his chair."
    "Agarra la moneda y la arroja descuidadamente de vuelta a su armario, recostándose en su silla."

# game/act1.rpy:1219
translate spanish act1_739187a5:

    # l "Then I believe you no longer have any business with me."
    l "Entonces creo que ya no tienes nada que ver conmigo."

# game/act1.rpy:1220
translate spanish act1_8072122c:

    # l disappointed "Please, see yourself out of the building."
    l disappointed "Por favor, abandone el edificio."

# game/act1.rpy:1223
translate spanish act1_5ef3f08e:

    # l angry "Immediately."
    l angry "Inmediatamente."

# game/act1.rpy:1224
translate spanish act1_49b2f98d:

    # a scared "I-I… yes, sir…"
    a scared "II… sí, señor…"

# game/act1.rpy:1226
translate spanish act1_ecdc46e4:

    # "Holding back my emotions, I quickly stand up and grab my things as I give him one last bow before exiting the room, a shiver running down my spine. I feel his cold eyes watch me the whole way out the door until I shut it firmly behind me."
    "Conteniendo mis emociones, me levanté rápidamente y recogí mis cosas mientras le dedicaba una última reverencia antes de salir de la habitación, con un escalofrío recorriendo mi espalda. Sentí su mirada fría sobre mí durante todo el camino hasta que cerré la puerta con firmeza tras de mí."

# game/act1.rpy:1231
translate spanish act1_0d141f5c:

    # "By the time I’m out of the building, my breathing has gotten heavy, and hot tears threaten to leak out of my eyes as I stare at the spinning floor beneath my feet. ‘Humiliated’ doesn’t even begin to cover how I feel."
    "Cuando salgo del edificio, mi respiración se ha agitado y siento que las lágrimas me brotan mientras contemplo el suelo giratorio bajo mis pies. «Humillada» ni siquiera alcanza a describir cómo me siento."

# game/act1.rpy:1232
translate spanish act1_0d9ea18d:

    # "He knew {i}everything{/i} about me, and I was powerless to it. He tried to play me, tried to make me one of his pawns…{w} didn’t he?"
    "Él lo sabía todo sobre mí, y yo era impotente ante ello. Intentó jugar conmigo, intentó convertirme en uno de sus peones… ¿no es así?"

# game/act1.rpy:1233
translate spanish act1_fccdb881:

    # "Yes, he did. There’s no doubt. That cheeky look in his eyes, that faux kindness… it was all a lie. Offering me the casino? How ridiculous…!"
    "Sí, lo hizo. No cabe duda. Esa mirada pícara en sus ojos, esa falsa amabilidad… todo era mentira. ¿Ofreciéndome el casino? ¡Qué ridículo…!"

# game/act1.rpy:1234
translate spanish act1_50806284_1:

    # a nngh "…"
    a nngh "…"

# game/act1.rpy:1236
translate spanish act1_9eb08190:

    # "I feel like I’m about to throw up on the side of the road when my phone begins to ring."
    "Siento que voy a vomitar al borde de la carretera cuando empieza a sonar mi teléfono."

# game/act1.rpy:1238
translate spanish act1_c79bdf45:

    # "I take a deep breath, brush my hair out of my eyes, and answer it, doing my best to sound calm and collected."
    "Respiro hondo, me aparto el pelo de los ojos y contesto, haciendo todo lo posible por sonar tranquila y serena."

# game/act1.rpy:1240
translate spanish act1_ae7b809f:

    # a concern "Hello?"
    a concern "¿Hola?"

# game/act1.rpy:1241
translate spanish act1_3246f219:

    # e "Hey, Angie. We still on for lunch?"
    e "Hola, Angie. ¿Seguimos con el plan para almorzar?"

# game/act1.rpy:1243
translate spanish act1_27639df5:

    # a nngh "Uh… yeah, sure."
    a nngh "Eh… sí, claro."

# game/act1.rpy:1244
translate spanish act1_ee509009:

    # e "…you okay?"
    e "¿Estás bien?"

# game/act1.rpy:1246
translate spanish act1_4d350d10:

    # a concern "Yeah… yeah, I’m…"
    a concern "Sí… sí, yo soy…"

# game/act1.rpy:1248
translate spanish act1_f5c6d13a:

    # a bashful "Corona’s ended up being a bust. I’m just disappointed."
    a bashful "Lo de Corona resultó ser un fracaso. Estoy muy decepcionado."

# game/act1.rpy:1249
translate spanish act1_95760b1e:

    # e "Aw. Yeah, I get it. Don’t beat yourself up about it. Let’s go to Shogey’s, maybe you’ll cheer up."
    e "Ay. Sí, lo entiendo. No te preocupes. Vamos a Shogey's, a lo mejor te animas."

# game/act1.rpy:1250
translate spanish act1_a2c51ab7:

    # a hm "Shogey’s? The sports bar?"
    a hm "¿Shogey's? ¿El bar deportivo?"

# game/act1.rpy:1251
translate spanish act1_e659f609:

    # e "Yeah. I like their wings. Plus… they have beer."
    e "Sí. Me gustan sus alitas. Además… tienen cerveza."

# game/act1.rpy:1252
translate spanish act1_2a4ff97c_9:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:1253
translate spanish act1_609dce30:

    # a stan "I’ll be there."
    a stan "Voy a estar allí."

# game/act1.rpy:1257
translate spanish act1_831eafea:

    # "Fifteen minutes later, I’m sitting at the bar in the brightly lit room, hearing men talk loudly as they stare at whatever sports game is on the screen on the TV while I wait for Ethan to show up."
    "Quince minutos después, estoy sentada en la barra de la sala, que está muy iluminada, oyendo a unos hombres hablar en voz alta mientras miran fijamente el partido que estén retransmitiendo en la televisión, mientras espero a que llegue Ethan."

# game/act1.rpy:1258
translate spanish act1_76a49148:

    # "I order a beer, and the waiter asks me if Babylon is okay. I tell him no – Babylon is the expensive kind – that a Tonio would be good."
    "Pido una cerveza y el camarero me pregunta si me parece bien la Babylon. Le digo que no, que la Babylon es cara, y que una Tonio estaría bien."

# game/act1.rpy:1259
translate spanish act1_565bfea5:

    # "If I could, I would have ordered a Babylon. I remember the first time I tried one – on my twenty-first birthday at some dive bar near Ethan’s apartment. He had bought me both, as a birthday present, and asked me if I could taste the difference."
    "Si hubiera podido, habría pedido un Babylon. Recuerdo la primera vez que lo probé: el día de mi vigésimo primer cumpleaños en un bar de mala muerte cerca del apartamento de Ethan. Me había comprado ambos como regalo de cumpleaños y me preguntó si notaba la diferencia."

# game/act1.rpy:1260
translate spanish act1_f5250fe9:

    # "At the time, they both tasted equally as bad. Now that I’ve acquired a bit of a taste for them, however, I can tell that Babylon is the superior brand. But, alas, it’s about the price of two and a half Tonios, so it’s unfortunately not worth the extra money."
    "En aquel entonces, ambos sabían igual de mal. Sin embargo, ahora que les he cogido el gusto, puedo decir que Babylon es la mejor marca. Pero, por desgracia, cuesta casi lo mismo que dos Tonios y medio, así que, lamentablemente, no merece la pena pagar más."

# game/act1.rpy:1261
translate spanish act1_2ad00b84:

    # "The bartender comes back with two beers, a Babylon and a Tonio. He slides my drink in front of me, and the other to the guy to my left, who I somehow failed to notice was even there. He takes it, downing about half the bottle in one big gulp."
    "El camarero regresa con dos cervezas, una Babylon y una Tonio. Me desliza la mía y le da la otra al tipo que está a mi izquierda, a quien, por alguna razón, ni siquiera había notado que estaba allí. Él la toma y se bebe casi media botella de un trago."

# game/act1.rpy:1262
translate spanish act1_b031c24e:

    # "Envy boils inside me as I watch him from the corner of my eye. How does someone as disheveled looking as him have the money to afford expensive beers like that? Has he had to work as hard as I do? Will he ever have to?"
    "La envidia me hierve mientras lo observo de reojo. ¿Cómo es posible que alguien con tan aspecto desaliñado tenga dinero para comprar cervezas tan caras? ¿Acaso ha tenido que trabajar tan duro como yo? ¿Tendrá que hacerlo alguna vez?"

# game/act1.rpy:1263
translate spanish act1_2a7cb2ab:

    # "I think back to my conversation with Mr. Grey. How stupid it is to think that he and I could ever be equals. Gambling isn’t going to fix anything. He’s just an insane man who happened to get lucky."
    "Recuerdo mi conversación con el Sr. Grey. Qué tontería pensar que alguna vez podríamos ser iguales. El juego no va a solucionar nada. Es solo un loco que tuvo suerte."

# game/act1.rpy:1266
translate spanish act1_4ee9dd05:

    # a worried "{i}Well… isn’t that the whole point? Getting lucky?"
    a worried "{i}Bueno… ¿no es esa la cuestión? ¿Tener suerte?"

# game/act1.rpy:1267
translate spanish act1_592eefeb:

    # a "{i}What if I could have gotten lucky, too?"
    a "¿Y si yo también hubiera tenido suerte?"

# game/act1.rpy:1271
translate spanish act1_dc2083a4:

    # "I shake my head. When have the odds {i}ever{/i} been in my favor? That coin would have sealed my fate into his hands, no question about it."
    "Niego con la cabeza. ¿Cuándo han estado las probabilidades a mi favor? Esa moneda habría sellado mi destino en sus manos, sin duda alguna."

# game/act1.rpy:1272
translate spanish act1_a153919c:

    # "I seethe internally as I’m about to bring the bottle to my lips, when the stranger next to me slides his bottle to my side. I look over at him completely now, raising an eyebrow."
    "Me hierve la sangre por dentro justo cuando estoy a punto de llevarme la botella a los labios, cuando el desconocido que está a mi lado desliza la suya hacia mí. Lo miro fijamente, alzando una ceja."

# game/act1.rpy:1274
translate spanish act1_2c856a94:

    # anon "Oh, sorry… You seemed to be eyeing my drink. I thought maybe you wanted to have some."
    anon "Oh, disculpa… Parecía que estabas mirando mi bebida. Pensé que tal vez querías probarla."

# game/act1.rpy:1275
translate spanish act1_4a530c3d_1:

    # a hm "…"
    a hm "…"

# game/act1.rpy:1278
translate spanish act1_e8ee194c:

    # "This… man… speaks in a low, almost hushed voice, a serious look on his face that I can’t tell whether it's because of me, or if that’s just how he always looks."
    "Este… hombre… habla en voz baja, casi susurrante, con una expresión seria en el rostro que no puedo descifrar si es por mí o si simplemente es su expresión habitual."

# game/act1.rpy:1279
translate spanish act1_425ea68f:

    # "He has a bit of an accent, as if English isn’t his first language, but I can’t quite discern where it’s from. The ‘disheveled’ look I assessed earlier may not have been completely true; he seems more rugged, like he’s not trying hard to look good."
    "Tiene un ligero acento, como si el inglés no fuera su lengua materna, pero no logro discernir de dónde proviene. La apariencia desaliñada que percibí antes quizás no sea del todo cierta; parece más bien rudo, como si no se esforzara por verse bien."

# game/act1.rpy:1280
translate spanish act1_6f72a3d8:

    # "He doesn’t have to, though. He’s naturally handsome, with dark fur and piercing eyes to match. He’s unlike anyone I’ve ever seen before, at least in person. He could fit right into a movie with that face."
    "Pero no tiene por qué serlo. Es guapo por naturaleza, con pelaje oscuro y una mirada penetrante. Es diferente a cualquier otro que haya visto, al menos en persona. Con ese rostro, encajaría perfectamente en una película."

# game/act1.rpy:1281
translate spanish act1_b3293698:

    # "I laugh off his statement, shaking my head."
    "Me río de su comentario, negando con la cabeza."

# game/act1.rpy:1283
translate spanish act1_0f98a810:

    # a bashful "N-nah, sorry… I’m good with mine. Thanks."
    a bashful "N-no, lo siento… Estoy bien con el mío. Gracias."

# game/act1.rpy:1285
translate spanish act1_8ac3f09b:

    # "He nods, offering me a sheepish smile and grabbing his bottle to clink it against mine."
    "Él asiente con la cabeza, me dedica una sonrisa tímida y toma su botella para chocarla con la mía."

# game/act1.rpy:1287
translate spanish act1_03a2da55:

    # anon "{i}Salud, pues."
    anon "{i}Salud, pues."

# game/act1.rpy:1289
translate spanish act1_25e8efdc:

    # "I stare at him as he practically finishes the bottle in one gulp. So, he’s a Spanish speaker. From where in the world, I couldn’t tell off his accent alone. The last time I met someone who spoke Spanish was... back in the Academy."
    "Lo observo mientras prácticamente se termina la botella de un trago. Así que habla español. ¿De dónde viene? No podría reconocer su acento. La última vez que conocí a alguien que hablara español fue... en la Academia."

# game/act1.rpy:1291
translate spanish act1_af12e8a5:

    # anon "You waiting for someone, {i}chele?"
    anon "¿Estás esperando a alguien, {i}chele?"

# game/act1.rpy:1292
translate spanish act1_1a47636f:

    # a flattered "Uh…{w} yes?"
    a flattered "Eh…{w} ¿sí?"

# game/act1.rpy:1293
translate spanish act1_45edd81e:

    # anon "You don’t sound so sure."
    anon "No pareces muy seguro."

# game/act1.rpy:1294
translate spanish act1_40d0a660:

    # a bashful "I’m sure. I just don’t know what {i}chele{/i} means… it’s nothing bad, is it?"
    a bashful "Estoy segura. Simplemente no sé qué significa {i}chele{/i}… no es nada malo, ¿verdad?"

# game/act1.rpy:1296
translate spanish act1_deb7c2e9:

    # "He laughs a full, hearty laugh, leaning his body a bit closer to mine. My instincts tell me to back away. {w}I don’t, though."
    "Suelta una carcajada sonora y sincera, acercando un poco más su cuerpo al mío. Mis instintos me dicen que me aleje. {w}Pero no lo hago."

# game/act1.rpy:1298
translate spanish act1_9420b883:

    # anon "{i}Chele{/i} just means you have light-colored fur. It’s not offensive."
    anon "{i}Chele{/i} simplemente significa que tienes pelaje de color claro. No es ofensivo."

# game/act1.rpy:1300
translate spanish act1_b79c8c67:

    # a surprised "Oh. Well… how do I know you’re telling the truth?"
    a surprised "Oh. Bueno… ¿cómo sé que estás diciendo la verdad?"

# game/act1.rpy:1301
translate spanish act1_d8d612b6:

    # anon "…"
    anon "…"

# game/act1.rpy:1303
translate spanish act1_da715c31:

    # anon "You don’t. You’re just gonna have to take my word for it."
    anon "No lo harás. Tendrás que creerme cuando te lo diga."

# game/act1.rpy:1305
translate spanish act1_156cb837:

    # "He practically whispers this, looking me right in the eyes as he does."
    "Prácticamente me lo susurra, mirándome fijamente a los ojos mientras lo hace."

# game/act1.rpy:1307
translate spanish act1_8f248a44:

    # a cocky "…"
    a cocky "…"

# game/act1.rpy:1309
translate spanish act1_8526af50:

    # a "Well, just in case you {i}are{/i} calling me something bad, I’d rather you call me by my name."
    a "Bueno, por si acaso me estás llamando algo malo, prefiero que me llames por mi nombre."

# game/act1.rpy:1310
translate spanish act1_f176356c:

    # a smile "I’m Angel. I don’t think I’ve ever seen you around Sonora."
    a smile "Soy Ángel. Creo que nunca te he visto por Sonora."

# game/act1.rpy:1311
translate spanish act1_64b7ac9c:

    # s "Nice to meet you, {i}Ángel{/i}. I’m Sebas."
    s "Encantado de conocerte, {i}Ángel{/i}. Soy Sebas."

# game/act1.rpy:1312
translate spanish act1_12adba69:

    # a surprised "Sebas? I've never heard that name before."
    a surprised "¿Sebas? Nunca había oído ese nombre."

# game/act1.rpy:1313
translate spanish act1_be2de156:

    # s cocky "It’s short for {i}Sebastián{/i}, if you must know. I just like it better this way."
    s cocky "Es la abreviatura de {i}Sebastián{/i}, por si te interesa. Simplemente me gusta más así."

# game/act1.rpy:1315
translate spanish act1_4c01482c:

    # "His accent comes out strong here, and I realize he must have trouble pronouncing his r’s, practically rolling them when he tries to say them. He says my name differently in his accent, {i}Ahn-hel.{/i} It sounds… nice."
    "Su acento se nota mucho aquí, y me doy cuenta de que debe tener problemas para pronunciar las erres, casi vibrando cuando intenta decirlas. Dice mi nombre de forma diferente con su acento, {i}Ahn-hel.{/i} Suena… bien."

# game/act1.rpy:1316
translate spanish act1_c5d52ac1:

    # "He also pronounces his own name completely different than you would in English, his vowels and consonants sounding almost… harsher? {i}Seh-bas-tyan{/i}, with more emphasis in the last syllable."
    "También pronuncia su propio nombre de forma completamente diferente a como lo harías en inglés, sus vocales y consonantes suenan casi… ¿más ásperas? {i}Seh-bas-tyan{/i}, con más énfasis en la última sílaba."

# game/act1.rpy:1318
translate spanish act1_4038d4af:

    # s "So, {i}Ángel{/i}… is this mystery person coming any time soon, or should I keep you company?"
    s "Entonces, {i}Ángel{/i}… ¿esta persona misteriosa vendrá pronto, o debería hacerle compañía?"

# game/act1.rpy:1320
translate spanish act1_45895f19:

    # a smile "He’s being held up at his job. But I wouldn’t mind your company until he gets here."
    a smile "Está retenido en su trabajo. Pero no me importaría que me hicieras compañía hasta que llegue."

# game/act1.rpy:1321
translate spanish act1_8cacac30:

    # s amused "Is that right…?"
    s amused "¿Es correcto...?"

# game/act1.rpy:1323
translate spanish act1_ca293780:

    # "He finishes his drink, licking his muzzle slowly as he stares down the counter."
    "Termina su bebida, lamiéndose el hocico lentamente mientras mira fijamente al fondo del mostrador."

# game/act1.rpy:1325
translate spanish act1_748f9a5a:

    # s hm "I’m surprised to see someone like you here at this hour."
    s hm "Me sorprende ver a alguien como usted aquí a estas horas."

# game/act1.rpy:1326
translate spanish act1_0490af36:

    # a hm "Someone like me?"
    a hm "¿Alguien como yo?"

# game/act1.rpy:1327
translate spanish act1_03a32570:

    # s "You are a Valentine, yeah? I hear it’s quite the demanding job."
    s "Eres un San Valentín, ¿verdad? He oído que es un trabajo bastante exigente."

# game/act1.rpy:1330
translate spanish act1_dce97470:

    # a bashful "That’s right. Never a dull moment… I’m just stopping by for lunch."
    a bashful "Así es. Nunca hay un momento aburrido… Solo paso a almorzar."

# game/act1.rpy:1331
translate spanish act1_2f156776:

    # s smile "I see. It must be interesting though, being a journalist. You get to talk to so many different people, go to different places."
    s smile "Ya veo. Debe ser interesante ser periodista. Tienes la oportunidad de hablar con muchísima gente diferente e ir a lugares distintos."

# game/act1.rpy:1333
translate spanish act1_e8ff743c:

    # a flattered "Hah. No, not really. The Valentine Report only covers stories inside of Sonora, and talking to people isn’t exactly a fun part of the job. Most here don’t really like Valentines."
    a flattered "Ja. No, en realidad no. El Informe de San Valentín solo cubre noticias dentro de Sonora, y hablar con la gente no es precisamente la parte más divertida del trabajo. A la mayoría de aquí no les gusta mucho San Valentín."

# game/act1.rpy:1334
translate spanish act1_f0a46da3:

    # s lookaway "So I’ve come to notice."
    s lookaway "Así que he llegado a notarlo."

# game/act1.rpy:1337
translate spanish act1_d69e8620:

    # a surprised "Where are you from, actually?"
    a surprised "¿De dónde eres, exactamente?"

# game/act1.rpy:1339
translate spanish act1_a0a82255:

    # s smile "Michigan."
    s smile "Michigan."

# game/act1.rpy:1341
translate spanish act1_c8d5007a:

    # a concern "Oh."
    a concern "Oh."

# game/act1.rpy:1343
translate spanish act1_4448f1a3:

    # s "What? Could it be... you wanted to know where I'm {i}really{/i} from?"
    s "¿Qué? ¿Podría ser que... querías saber de dónde soy realmente?"

# game/act1.rpy:1345
translate spanish act1_2e2a7cc9:

    # "My cheeks grow hot. Now he's gonna think I'm some racist."
    "Se me ruborizan las mejillas. Ahora va a pensar que soy racista."

# game/act1.rpy:1347
translate spanish act1_735768f4:

    # a flustered "N-No no, I was just-!"
    a flustered "N-No, no, ¡yo solo estaba...!"

# game/act1.rpy:1349
translate spanish act1_31159a0d:

    # s "Heh. {i}Tranquilo.{/i} I'm messing with you."
    s "Je. {i}Tranquilo.{/i} Estoy bromeando contigo."

# game/act1.rpy:1350
translate spanish act1_9d5527ba:

    # s smile "I'm Colombian. But I do live in Michigan."
    s smile "Soy colombiana, pero vivo en Michigan."

# game/act1.rpy:1351
translate spanish act1_bc28083b:

    # a "I see... good to know."
    a "Ya veo... es bueno saberlo."

# game/act1.rpy:1352
translate spanish act1_23d6c3d3:

    # s amused "I take it you don't see many foreigners around here?"
    s amused "Supongo que no se ven muchos extranjeros por aquí, ¿verdad?"

# game/act1.rpy:1353
translate spanish act1_a334f6f2:

    # a bashful "Well… there are lots of people from all around the world living here, actually. I’ve just never had a proper conversation with anyone who speaks Spanish."
    a bashful "Bueno… en realidad, aquí vive mucha gente de todo el mundo. Simplemente, nunca he tenido una conversación normal con nadie que hable español."

# game/act1.rpy:1354
translate spanish act1_d61f74db:

    # s smile "Maybe I can teach you a thing or two… when you’re not so busy."
    s smile "Quizás pueda enseñarte un par de cosas... cuando no estés tan ocupado."

# game/act1.rpy:1356
translate spanish act1_5b0f6ff7:

    # a blush "I’d like that."
    a blush "Me gustaría eso."

# game/act1.rpy:1358
translate spanish act1_45b8e009:

    # a smile "So what brings you to Sonora, anyway?"
    a smile "¿Y qué es lo que te trae a Sonora?"

# game/act1.rpy:1363
translate spanish act1_e19df76a:

    # "He leans in even closer, as if he’s about to tell me a secret. I get closer too, so close I can smell the beer on his breath. It makes my face burn red."
    "Se inclina aún más, como si estuviera a punto de contarme un secreto. Yo también me acerco, tanto que puedo oler la cerveza en su aliento. Se me ruboriza la cara."

# game/act1.rpy:1365
translate spanish act1_eed73d59:

    # s "I’m here on business... But, that’s not the main reason I came to this city."
    s "Estoy aquí por negocios... Pero esa no es la razón principal por la que vine a esta ciudad."

# game/act1.rpy:1366
translate spanish act1_e09541fe:

    # s cocky "To tell you the truth, {i}chelito…{/i}{w} I came here to gamble."
    s cocky "A decir verdad, {i}chelito…{/i}{w} vine aquí a apostar."

# game/act1.rpy:1369
translate spanish act1_0db9357b:

    # a surprised "Did you, now?"
    a surprised "¿Lo hiciste?"

# game/act1.rpy:1370
translate spanish act1_db7b1833:

    # s amused "That’s right. I was wondering, actually… if you happened to know of any good places for that."
    s amused "Así es. De hecho, me preguntaba si conocías algún buen sitio para eso."

# game/act1.rpy:1375
translate spanish act1_33a52ec1:

    # "I lean back in my own space, sighing."
    "Me recuesto en mi propio espacio, suspirando."

# game/act1.rpy:1377
translate spanish act1_1496192a:

    # a hm "Unfortunately not. Valentines can’t gamble."
    a hm "Lamentablemente no. Los enamorados no pueden apostar."

# game/act1.rpy:1378
translate spanish act1_2611337c:

    # s hm "’Can’t’ or ‘don’t’?"
    s hm "¿'No puedo' o 'no quiero'?"

# game/act1.rpy:1379
translate spanish act1_73910e7a:

    # a hm "That’s… the same thing."
    a hm "Eso es… lo mismo."

# game/act1.rpy:1380
translate spanish act1_d30b3a39:

    # s stan "I don’t think it is."
    s stan "No creo que lo sea."

# game/act1.rpy:1382
translate spanish act1_f98db646:

    # a worried "In any case… the only place I know of is Corona’s, and let’s just say, I don’t recommend it. I’m actually writing a story about the missing person case that happened there not too long ago."
    a worried "En cualquier caso… el único sitio que conozco es Corona's, y digamos que no lo recomiendo. De hecho, estoy escribiendo un artículo sobre el caso de la persona desaparecida que ocurrió allí hace poco."

# game/act1.rpy:1383
translate spanish act1_08f0a55d:

    # s lookaway "I’ve heard about that, too."
    s lookaway "Yo también he oído hablar de eso."

# game/act1.rpy:1385
translate spanish act1_e86985fa:

    # "His casual demeanor falters somewhat, a darkness clouding his already pitch-black eyes."
    "Su actitud despreocupada flaquea un poco, y una oscuridad nubla sus ojos, ya de por sí negros como la noche."

# game/act1.rpy:1387
translate spanish act1_97001861:

    # s hm "Well, doesn’t matter. There’s plenty of other places to go, I’m sure."
    s hm "Bueno, no importa. Seguro que hay muchos otros sitios a los que ir."

# game/act1.rpy:1388
translate spanish act1_63c059ba:

    # s smile "In fact, I’ve heard talk around the town that there’s an underground ring somewhere in Sonora. Maybe I’ll check that out instead."
    s smile "De hecho, he oído rumores por el pueblo de que hay un anillo subterráneo en algún lugar de Sonora. Quizás debería ir a investigar eso."

# game/act1.rpy:1389
translate spanish act1_05ed241b:

    # a hm "Underground? Where did you hear this?"
    a hm "¿Bajo tierra? ¿Dónde oíste eso?"

# game/act1.rpy:1391
translate spanish act1_9fd1a17b:

    # "He tilts his now empty bottle side to side, toying with it as he thinks."
    "Inclina la botella, ahora vacía, de un lado a otro, jugando con ella mientras piensa."

# game/act1.rpy:1393
translate spanish act1_841194e4:

    # s "Where I heard this…? I can’t remember anymore. I get around a lot. But I did remember where it was. Some bar called The Albatross."
    s "¿Dónde escuché esto...? Ya no me acuerdo. Viajo mucho. Pero sí recuerdo dónde fue. En un bar llamado El Albatros."

# game/act1.rpy:1394
translate spanish act1_1ab72481_8:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1396
translate spanish act1_0324b1fb:

    # "That’s… the dive bar near Ethan’s apartment."
    "Ese es… el bar de mala muerte cerca del apartamento de Ethan."

# game/act1.rpy:1398
translate spanish act1_88c4eae3:

    # a body2 thinking "I see…"
    a body2 thinking "Veo…"

# game/act1.rpy:1400
translate spanish act1_b7c2169f:

    # s smile "You know, {i}chele{/i}, I think you should check it out. Those kinds of people are always in the know-how, and if you gamble with them, they might tell you a thing or two. Could help you out with your story."
    s smile "Sabes, {i}chele{/i}, creo que deberías echarle un vistazo. Esa clase de gente siempre está al tanto de todo, y si apuestas con ellos, podrían contarte un par de cosas. Podrían ayudarte con tu historia."

# game/act1.rpy:1402
translate spanish act1_b9dd7fa6:

    # a body cocky "Hah. Fat chance. Even if I wanted to gamble, which I don’t… I don’t even have the money to do it."
    a body cocky "Ja. Ni hablar. Aunque quisiera apostar, que no quiero… ni siquiera tengo dinero para hacerlo."

# game/act1.rpy:1403
translate spanish act1_7c08430d:

    # s hm "Who said anything about money? You have something much more valuable."
    s hm "¿Quién habló de dinero? Tú tienes algo mucho más valioso."

# game/act1.rpy:1404
translate spanish act1_a15d76ee:

    # a hm "And that is…?"
    a hm "¿Y eso es...?"

# game/act1.rpy:1407
translate spanish act1_9c8bec2b:

    # s "Information."
    s "Información."

# game/act1.rpy:1409
translate spanish act1_1237e421:

    # s "Sure, you might have to pay your first time around, but… unlike a casino, money isn’t the only thing you can put on the table in these places."
    s "Claro, puede que tengas que pagar la primera vez, pero... a diferencia de un casino, el dinero no es lo único que puedes poner sobre la mesa en estos lugares."

# game/act1.rpy:1410
translate spanish act1_e1d567d1:

    # s hm2 "Properties, possessions… and yeah, even something as abstract as information. It’s all fair game, as long as both parties agree. And trust me, these people have a lot of information to share as well."
    s hm2 "Propiedades, posesiones… e incluso algo tan abstracto como la información. Todo vale, siempre y cuando ambas partes estén de acuerdo. Y créanme, estas personas también tienen mucha información que compartir."

# game/act1.rpy:1412
translate spanish act1_9f9d836b:

    # s "You’d be surprised how interconnected this world is. Someone knows a guy who knows a guy, who knows a guy…"
    s "Te sorprendería lo interconectado que está este mundo. Alguien conoce a alguien que conoce a alguien, alguien que conoce a alguien…"

# game/act1.rpy:1413
translate spanish act1_04d77b3e:

    # s cocky "And pretty soon, you know every guy. And the person with the most knowledge has the most power."
    s cocky "Y muy pronto, conoces a todos. Y quien más sabe, más poder tiene."

# game/act1.rpy:1414
translate spanish act1_a5587c65:

    # s amused "And isn’t that what you’re after, {i}Ángel{/i}?"
    s amused "¿Y no es eso lo que buscas, {i}Ángel{/i}?"

# game/act1.rpy:1416
translate spanish act1_1ab72481_9:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1418
translate spanish act1_1c90cd1f:

    # "Does he mean information…{w} or power?"
    "¿Se refiere a información...{w} o a poder?"

# game/act1.rpy:1420
translate spanish act1_59b80d18:

    # a "I, um…"
    a "Yo, eh…"

# game/act1.rpy:1422
translate spanish act1_7d58c590:

    # e "Angel."
    e "Ángel."

# game/act1.rpy:1426
translate spanish act1_a2795d4e:

    # "I flinch, quickly turning around to see Ethan standing right behind me, with a look that tells me I’ve done something wrong."
    "Me sobresalto y me giro rápidamente para ver a Ethan de pie justo detrás de mí, con una mirada que me indica que he hecho algo mal."

# game/act1.rpy:1428
translate spanish act1_b6fddf70:

    # a bashful "Ethan… there you are. What took you so long?"
    a bashful "Ethan… ahí estás. ¿Qué te ha llevado tanto tiempo?"

# game/act1.rpy:1429
translate spanish act1_a667392f:

    # e hm "Got held up at work. Who’s your friend?"
    e hm "Me retrasé en el trabajo. ¿Quién es tu amigo?"

# game/act1.rpy:1431
translate spanish act1_13bd0050:

    # "He nods towards Sebas, who, despite being put on the spot, doesn’t seemed phased by Ethan’s pointedness in the slightest."
    "Él asiente con la cabeza hacia Sebas, quien, a pesar de haber sido puesto en un aprieto, no pareció inmutarse lo más mínimo por la franqueza de Ethan."

# game/act1.rpy:1433
translate spanish act1_c319ca04:

    # a "Um… Ethan, this is-"
    a "Eh… Ethan, esto es…"

# game/act1.rpy:1435
translate spanish act1_b10fd209:

    # s "I’m just a stranger making conversation. But unfortunately, I’ve got places to be now."
    s "Solo soy un desconocido entablando conversación. Pero, por desgracia, tengo cosas que hacer ahora."

# game/act1.rpy:1438
translate spanish act1_88e0f826:

    # "He gets up, opening his wallet to leave a bill on the bar, and very smoothly leans close to me as he’s turning to leave, speaking in a hushed voice that I’m sure Ethan couldn’t hear - maybe intentionally so."
    "Se levanta, abre la cartera para dejar un billete en la barra y, con mucha naturalidad, se inclina hacia mí mientras se da la vuelta para marcharse, hablando en voz baja que estoy seguro de que Ethan no pudo oír, tal vez intencionadamente."

# game/act1.rpy:1440
translate spanish act1_c16ecddd:

    # s smile "I’ll see you around, {i}Ángel{/i}."
    s smile "Nos vemos por ahí, {i}Ángel{/i}."

# game/act1.rpy:1442
translate spanish act1_ff2008fc:

    # "I shudder, resisting the urge to turn and watch him leave. Ethan slides into the stool that Sebas was on, giving me a puzzled look."
    "Me estremezco, resistiendo la tentación de girarme y verlo marcharse. Ethan se sienta en el taburete donde estaba Sebas, mirándome con expresión de desconcierto."

# game/act1.rpy:1444
translate spanish act1_f684ca3c:

    # e "Do you know that guy?"
    e "¿Conoces a ese tipo?"

# game/act1.rpy:1446
translate spanish act1_6ff83036:

    # a surprised "Never met him before."
    a surprised "Nunca lo había conocido antes."

# game/act1.rpy:1447
translate spanish act1_2b8e7590:

    # e "Yeah, well let’s hope we don’t run into him again. He gives me the creeps."
    e "Sí, bueno, esperemos no volver a encontrárnoslo. Me da escalofríos."

# game/act1.rpy:1448
translate spanish act1_bfcb83b8:

    # a bashful "Yeah… me too."
    a bashful "Sí… yo también."

# game/act1.rpy:1450
translate spanish act1_4ac584c9:

    # "Or so I say. And, although he does kind of give me the creeps, too… I secretly hope that it won’t be the last time I run into him."
    "O eso digo yo. Y, aunque también me da un poco de miedo… secretamente espero que no sea la última vez que me lo encuentre."

# game/act1.rpy:1452
translate spanish act1_0a6ed9bb:

    # e uh "Stop talking to strangers, too. You're gonna get yourself into trouble."
    e uh "Deja de hablar con desconocidos también. Te vas a meter en problemas."

# game/act1.rpy:1453
translate spanish act1_7197ccdf:

    # a eyeroll "Yes, Dad."
    a eyeroll "Sí, papá."

# game/act1.rpy:1454
translate spanish act1_7cb4947d:

    # e sigh "Ugh. Whatever. I need a drink."
    e sigh "Uf. Da igual. Necesito beber algo."

# game/act1.rpy:1456
translate spanish act1_56e11dcf:

    # "He waves over the bartender and orders - what else - a Tonio. I prop my chin on my hand, resting my elbows on the bar’s countertop as I watch him take three big, manly gulps of his beer."
    "Llama al camarero y pide, cómo no, un Tonio. Apoyo la barbilla en la mano, con los codos sobre la barra, mientras lo observo dar tres grandes y viriles tragos a su cerveza."

# game/act1.rpy:1458
translate spanish act1_e3fea642:

    # a worried "Rough day?"
    a worried "¿Un día difícil?"

# game/act1.rpy:1460
translate spanish act1_1b49255d:

    # "Ethan sighs as he sets the glass down, licking his muzzle clean."
    "Ethan suspira mientras deja el vaso y se lame el hocico para limpiarse."

# game/act1.rpy:1462
translate spanish act1_968f0ed6:

    # e hm "Sort of. The police station is a bit of a mess right now. I don’t want to get too into it, though. I don’t even fully know what’s going on."
    e hm "Más o menos. La comisaría está hecha un desastre ahora mismo. Pero no quiero entrar en detalles. Ni siquiera sé muy bien qué está pasando."

# game/act1.rpy:1463
translate spanish act1_74afa0b7:

    # a "Hm… that does sound tiring…"
    a "Mmm… eso sí que suena agotador…"

# game/act1.rpy:1464
translate spanish act1_e2530fe9:

    # e "Yeah… though, I’ve never seen it this… hectic."
    e "Sí… aunque nunca lo había visto tan… agitado."

# game/act1.rpy:1466
translate spanish act1_6f1b178c:

    # a surprised "Wasn’t it like that when you were younger?"
    a surprised "¿No era así cuando eras más joven?"

# game/act1.rpy:1467
translate spanish act1_84e307a6:

    # e "You mean when my dad was in office?"
    e "¿Te refieres a cuando mi padre estaba en el cargo?"

# game/act1.rpy:1468
translate spanish act1_d925f1ea:

    # a cocky "Kind of, yeah. Or when you first started off. You know… {i}way{/i} back then."
    a cocky "Algo así, sí. O cuando empezaste. Ya sabes… {i}hace mucho{/i} tiempo."

# game/act1.rpy:1469
translate spanish act1_caa46594:

    # e hm "Haha. Well, no. Not when I was starting off."
    e hm "Jaja. Bueno, no. No cuando estaba empezando."

# game/act1.rpy:1470
translate spanish act1_c0550d5e:

    # e surprised "But my dad would work late nights. Mainly because he worked the graveyard shift. I just thought that was how it always was, though. I guess you don’t really catch onto things when you’re a kid."
    e surprised "Pero mi papá trabajaba hasta tarde. Principalmente porque trabajaba en el turno de noche. Yo pensaba que siempre había sido así. Supongo que uno no se da cuenta de las cosas cuando es niño."

# game/act1.rpy:1471
translate spanish act1_556f4b80:

    # a surprised "Hm."
    a surprised "Hm."

# game/act1.rpy:1472
translate spanish act1_1141060d:

    # e frown "Enough about me, though. What about you? What did {i}Mr. Valentine{/i} want?"
    e frown "Pero basta de hablar de mí. ¿Y tú? ¿Qué quería el Sr. Valentine?"

# game/act1.rpy:1474
translate spanish act1_e2886545:

    # "Ethan says his name like it has a taste to it, and not a very good one at that. I just smile, rolling my eyes."
    "Ethan pronuncia su nombre como si tuviera un sabor particular, y no precisamente agradable. Yo solo sonrío, poniendo los ojos en blanco."

# game/act1.rpy:1476
translate spanish act1_02a70138:

    # a cocky "Oh, you know, just to partake in his favorite pastime in the whole wide world… tormenting me for fun. I had to go on a fetch quest for donuts that he didn’t end up eating."
    a cocky "Oh, ya sabes, solo para participar en su pasatiempo favorito en todo el mundo... atormentarme por diversión. Tuve que ir a buscarle unas donas que al final no se comió."

# game/act1.rpy:1477
translate spanish act1_99e258fb:

    # e uh "Seriously? That guy’s a lunatic."
    e uh "¿En serio? Ese tipo está loco."

# game/act1.rpy:1478
translate spanish act1_4aa82261:

    # a bashful "Hah, yeah… but whatever."
    a bashful "Ja, sí… pero da igual."

# game/act1.rpy:1479
translate spanish act1_005c29c6:

    # e flattered "Yeah. What can you do, am I right?"
    e flattered "Sí. ¿Qué se le va a hacer, verdad?"

# game/act1.rpy:1481
translate spanish act1_d7e01f39:

    # "I hum like I agree with him… but, in my head, I can’t help but think about my conversation with Mr. Grey, as much as I’d like to pretend our whole interaction was just some nightmarish dream."
    "Tarareo como si estuviera de acuerdo con él... pero, en mi cabeza, no puedo evitar pensar en mi conversación con el Sr. Grey, por mucho que me gustaría fingir que toda nuestra interacción fue solo una pesadilla."

# game/act1.rpy:1483
translate spanish act1_b3efd907:

    # "Despite what I said, Mr. Grey {i}did{/i} give me an option. Just the very thought is crazy to me, and I still haven’t been able to fully process it."
    "A pesar de lo que dije, el Sr. Grey me dio una opción. Tan solo pensarlo me parece una locura, y todavía no he podido asimilarlo del todo."

# game/act1.rpy:1484
translate spanish act1_499f5003:

    # "I had an {i}option.{/i} I had an out, albeit an extremely risky out, to this life that I’m trapped in, for the first time ever. So, when I hear Ethan say the words ‘What can you do?’… I realize that there {i}is{/i} something I could’ve done."
    "Tenía una opción. Tenía una salida, aunque extremadamente arriesgada, de esta vida en la que estoy atrapada, por primera vez en mi vida. Así que, cuando escucho a Ethan decir las palabras \"¿Qué puedes hacer?\"... me doy cuenta de que hay algo que podría haber hecho."

# game/act1.rpy:1486
translate spanish act1_872a7f7a:

    # "Maybe something I {i}should’ve{/i} done…"
    "Tal vez algo que debería haber hecho…"

# game/act1.rpy:1488
translate spanish act1_517f8b9c:

    # e worried "In any case, what happened in Corona’s?"
    e worried "En cualquier caso, ¿qué pasó en el caso de Corona?"

# game/act1.rpy:1490
translate spanish act1_1376d153:

    # "Ethan’s voice snaps me out of my worrying thoughts, only for his sentence to bring another layer of anxiety to them. No way in hell am I telling him what happened in there."
    "La voz de Ethan me saca de mis pensamientos preocupantes, solo para que su frase les genere aún más ansiedad. Ni loca le voy a contar lo que pasó ahí dentro."

# game/act1.rpy:1492
translate spanish act1_12ef6bd2:

    # a flustered "Huh? Oh, um… it was just… useless."
    a flustered "¿Eh? Oh, um… fue simplemente… inútil."

# game/act1.rpy:1493
translate spanish act1_9be96621:

    # e "Seriously? How come?"
    e "¿En serio? ¿Cómo es posible?"

# game/act1.rpy:1494
translate spanish act1_5ede1711:

    # a flattered "Well… I did try and talk to the staff, but…"
    a flattered "Bueno… intenté hablar con el personal, pero…"

# game/act1.rpy:1495
translate spanish act1_d4d0c6a1:

    # e "But?"
    e "¿Pero?"

# game/act1.rpy:1497
translate spanish act1_015eaa14:

    # a bashful "But nothing worthwhile was said."
    a bashful "Pero no se dijo nada que valiera la pena."

# game/act1.rpy:1499
translate spanish act1_1c9fca34:

    # e worried "Aw. I see."
    e worried "Ah. Ya veo."

# game/act1.rpy:1501
translate spanish act1_cbbbf41b:

    # "He seems somewhat let down by this, but mostly relieved, taking much smaller sips of his beer as he looks at nothing in particular. Did he really wanna know about Corona’s?"
    "Parece algo decepcionado, pero sobre todo aliviado, y bebe su cerveza a sorbos mucho más pequeños mientras mira a la nada. ¿De verdad quería saber sobre Corona?"

# game/act1.rpy:1502
translate spanish act1_5f7e3912:

    # "More importantly, apart from my very strange interaction with Mr. Grey, did I really not learn anything useful today? He claims he has nothing to do with the disappearances, and his staff are all under a watchful eye."
    "Más importante aún, aparte de mi extraña interacción con el Sr. Grey, ¿de verdad no aprendí nada útil hoy? Él afirma no tener nada que ver con las desapariciones y que todo su personal está bajo estricta vigilancia."

# game/act1.rpy:1503
translate spanish act1_d03749f0:

    # "Doesn’t that put me back at square one?"
    "¿Acaso eso no me hace volver al punto de partida?"

# game/act1.rpy:1504
translate spanish act1_04e207b7:

    # "Unless…"
    "A menos que…"

# game/act1.rpy:1505
translate spanish act1_9587a2fa:

    # "My conversation with Sebas replays in my head… but, was he telling me the truth? Or just planting seeds in my mind?"
    "Mi conversación con Sebas se repite una y otra vez en mi cabeza… pero, ¿me estaba diciendo la verdad? ¿O simplemente estaba sembrando dudas en mi mente?"

# game/act1.rpy:1506
translate spanish act1_7659baf8:

    # "Either way, I can find out if I play my cards right."
    "De cualquier manera, podré averiguar si juego bien mis cartas."

# game/act1.rpy:1508
translate spanish act1_cad7c531:

    # a surprised "Well… there was {i}one{/i} thing I found out about."
    a surprised "Bueno… hubo una cosa que descubrí."

# game/act1.rpy:1510
translate spanish act1_6059195a:

    # "Ethan perks up again, listening attentively."
    "Ethan se anima de nuevo y escucha con atención."

# game/act1.rpy:1512
translate spanish act1_6bafbff3:

    # a hm "I was talking to a staff member-"
    a hm "Estaba hablando con un miembro del personal."

# game/act1.rpy:1513
translate spanish act1_d257c14b:

    # e hm "Which one?"
    e hm "¿Cuál?"

# game/act1.rpy:1514
translate spanish act1_1465dab9:

    # a surprised "Uh… I don’t know, they were just walking by in uniform. Maybe a receptionist?"
    a surprised "Eh... no sé, simplemente pasaban por allí uniformados. ¿Quizás una recepcionista?"

# game/act1.rpy:1516
translate spanish act1_66dfc06b:

    # "He nods, urging me to go on."
    "Él asiente con la cabeza, animándome a continuar."

# game/act1.rpy:1517
translate spanish act1_2300f589:

    # "He bought it. Nice."
    "Lo compró. Bien."

# game/act1.rpy:1519
translate spanish act1_a6d0c2ec:

    # a frown "Anyway, they told me something about their boss keeping them under strict surveillance, and that they doubt it was anyone from the staff. But… they also told me to ask around a certain underground ring."
    a frown "En fin, me contaron que su jefe los mantenía bajo estricta vigilancia y que dudaban que fuera alguien del personal. Pero… también me dijeron que preguntara en cierta red clandestina."

# game/act1.rpy:1520
translate spanish act1_739597c0:

    # a hm "The Albatross seems to have some gambling going on underneath the bar. Have you… heard about that?"
    a hm "Parece que en el Albatross hay apuestas debajo de la barra. ¿Has oído hablar de eso?"

# game/act1.rpy:1524
translate spanish act1_30370f1a:

    # "Ethan doesn’t look too surprised by this, which just confirms my suspicions before he even opens his mouth again."
    "Ethan no parece demasiado sorprendido por esto, lo que no hace más que confirmar mis sospechas incluso antes de que vuelva a abrir la boca."

# game/act1.rpy:1526
translate spanish act1_18f0101e:

    # e sigh "There have been reports about underground rings forming in the city in the past couple of months. The Albatross {i}is{/i} a suspect… but we have nothing concrete yet."
    e sigh "En los últimos meses se han reportado casos de anillos subterráneos que se forman en la ciudad. El Albatros es uno de los sospechosos… pero aún no tenemos nada concreto."

# game/act1.rpy:1528
translate spanish act1_783737a0:

    # a hm "Why haven’t you guys investigated it? If it’s something the S.P.D. suspect is happening."
    a hm "¿Por qué no lo han investigado? Si es algo que el SPD sospecha que está sucediendo."

# game/act1.rpy:1529
translate spanish act1_d9e63a93:

    # e hm "It’s not that simple. There are ways of going about these things. You think they’ll just let a cop in the ring, no questions asked?"
    e hm "No es tan sencillo. Hay maneras de hacer estas cosas. ¿Crees que van a dejar entrar a un policía al ring sin hacer preguntas?"

# game/act1.rpy:1530
translate spanish act1_77f545e4:

    # e frown "It’s underground for a reason, Angie. It’s supposed to be a secret, and even if there are rumors going around, without solid proof, we can’t do anything."
    e frown "Está bajo tierra por una razón, Angie. Se supone que es un secreto, e incluso si hay rumores circulando, sin pruebas sólidas, no podemos hacer nada."

# game/act1.rpy:1531
translate spanish act1_67a18015:

    # e hm "Besides… private gambling isn’t {i}technically{/i} illegal in Sonora. There are just certain rules you have to follow. If it’s just a couple of guys playing poker, we can’t really shut that down."
    e hm "Además… el juego privado no es técnicamente ilegal en Sonora. Simplemente hay ciertas reglas que se deben seguir. Si solo son un par de personas jugando al póker, no podemos prohibirlo."

# game/act1.rpy:1532
translate spanish act1_f5b14976:

    # e uh "But if they start sending out invitations, well… then it becomes a problem."
    e uh "Pero si empiezan a enviar invitaciones, bueno… entonces sí que hay un problema."

# game/act1.rpy:1533
translate spanish act1_1ab72481_10:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1535
translate spanish act1_f19967e4:

    # a "But then… what would be the issue? If anyone can just gamble with whoever they want, why does it matter if there are rings?"
    a "Pero entonces… ¿cuál sería el problema? Si cualquiera puede apostar con quien quiera, ¿qué importa si hay anillos?"

# game/act1.rpy:1537
translate spanish act1_8d15e008:

    # e "Because there’s no regulation. Unlike casinos, the house can accept anything as payment, not just money, and that becomes a problem. People lose their homes, their possessions… some people gamble their family members away."
    e "Porque no hay regulación. A diferencia de los casinos, la casa puede aceptar cualquier cosa como pago, no solo dinero, y eso se convierte en un problema. La gente pierde sus casas, sus pertenencias… algunos incluso arruinan a sus familiares con apuestas."

# game/act1.rpy:1538
translate spanish act1_21260edc:

    # e frown "That’s why, when you’re out of physical money, but still think you can turn your luck around somehow…"
    e frown "Por eso, cuando te quedas sin dinero físico, pero aún crees que puedes cambiar tu suerte de alguna manera…"

# game/act1.rpy:1539
translate spanish act1_1f0992e1:

    # a surprised "You go to a ring."
    a surprised "Vas a un ring."

# game/act1.rpy:1540
translate spanish act1_3b6e13c9:

    # e sigh "Exactly."
    e sigh "Exactamente."

# game/act1.rpy:1542
translate spanish act1_2d311620:

    # "So, Sebas was telling the truth after all.{w} What else was he right about?"
    "Así que, después de todo, Sebas decía la verdad.{w} ¿En qué más tenía razón?"

# game/act1.rpy:1544
translate spanish act1_25bd8fed:

    # a body2 thinking "{i}I guess this is my only real lead right now… that doesn’t give me many options. I might have to end up going to The Albatross… How would I even go about doing it?"
    a body2 thinking "{i}Supongo que esta es mi única pista real ahora mismo… eso no me deja muchas opciones. Puede que tenga que acabar yendo a The Albatross… ¿Cómo podría siquiera hacerlo?"

# game/act1.rpy:1545
translate spanish act1_848bcf35:

    # a frown2 "{i}Maybe a disguise? I don’t have many clothes, though…"
    a frown2 "{i}¿Quizás un disfraz? Aunque no tengo mucha ropa…"

# game/act1.rpy:1547
translate spanish act1_42884d1f:

    # e frown "Don’t even think about it."
    e frown "Ni se te ocurra pensarlo."

# game/act1.rpy:1548
translate spanish act1_d0c2f276:

    # a body surprised "Huh?"
    a body surprised "¿Eh?"

# game/act1.rpy:1549
translate spanish act1_ee21b85d:

    # e "I know what you’re thinking. You’re not going there."
    e "Sé lo que estás pensando. No vas a ir allí."

# game/act1.rpy:1550
translate spanish act1_596e1ed8:

    # a frown "What? Why not?"
    a frown "¿Qué? ¿Por qué no?"

# game/act1.rpy:1551
translate spanish act1_570aff14:

    # e "If people have gone missing right on the doorsteps of the most famous casino in the city, imagine what would happen to you at some dingy dive bar."
    e "Si ha habido personas desaparecidas justo a las puertas del casino más famoso de la ciudad, imagínate lo que te podría pasar en un bar de mala muerte."

# game/act1.rpy:1552
translate spanish act1_28c70d46:

    # a "I’m not going to get killed for just walking into a bar. This is part of my job, you know."
    a "No me van a matar solo por entrar en un bar. Es parte de mi trabajo, ¿sabes?"

# game/act1.rpy:1553
translate spanish act1_082d34e9:

    # e "No, your job is to write a story on the disappearance of that girl, not going around shady pubs and entering gambling rings."
    e "No, tu trabajo es escribir un artículo sobre la desaparición de esa chica, no andar por bares de mala muerte ni entrar en casas de apuestas clandestinas."

# game/act1.rpy:1554
translate spanish act1_bc070f24:

    # a concern "That’s… sometimes part of it."
    a concern "Eso… a veces forma parte de ello."

# game/act1.rpy:1555
translate spanish act1_7c1ce8a2:

    # e uh "Don’t start right now. I don’t need to hear how you think you have everything under control, and you don’t care what happens to you."
    e uh "No empieces ahora. No necesito oír cómo crees que tienes todo bajo control y que no te importa lo que te pase."

# game/act1.rpy:1556
translate spanish act1_c918a3a1:

    # a worried "I do care what happens to me. But if I don’t at least try-"
    a worried "Sí me importa lo que me pase. Pero si no lo intento al menos..."

# game/act1.rpy:1557
translate spanish act1_c31f17e1:

    # e angry "Why don’t you try listening to someone who clearly knows more about this than you and just do what you’re supposed to do for once?"
    e angry "¿Por qué no intentas escuchar a alguien que claramente sabe más sobre esto que tú y simplemente haces lo que se supone que debes hacer por una vez?"

# game/act1.rpy:1560
translate spanish act1_1ab72481_11:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1562
translate spanish act1_b0987038:

    # "My cheeks flush, at first in shame, but it quickly morphs into something different. Something stronger."
    "Mis mejillas se enrojecen, al principio de vergüenza, pero rápidamente se transforma en algo diferente. Algo más fuerte."

# game/act1.rpy:1564
translate spanish act1_ad68a591:

    # a angry "So, what? I’m just some idiot who doesn’t know what they’re doing?"
    a angry "¿Y qué? ¿Acaso soy un idiota que no sabe lo que hace?"

# game/act1.rpy:1566
translate spanish act1_dd80b533:

    # e uh "That’s not what I meant. You just..."
    e uh "Eso no es lo que quise decir. Tú solo..."

# game/act1.rpy:1569
translate spanish act1_ba87f978:

    # a "That's exactly what you meant."
    a "Eso es exactamente lo que querías decir."

# game/act1.rpy:1570
translate spanish act1_0c57f51c:

    # e uh "Well, can you blame me? You never take my advice."
    e uh "Bueno, ¿puedes culparme? Nunca sigues mis consejos."

# game/act1.rpy:1571
translate spanish act1_8e0225a5:

    # a "Your 'advice' is to just shut up and do as I'm told."
    a "Tu \"consejo\" es que me calle y haga lo que me dicen."

# game/act1.rpy:1572
translate spanish act1_8504393e:

    # e hm "If that'll keep you safe, then just do it. Better to bite your tongue than the dust."
    e hm "Si eso te mantiene a salvo, hazlo. Es mejor morderse la lengua que dejarse vencer por el polvo."

# game/act1.rpy:1574
translate spanish act1_2f8b1e00:

    # a dejected "Yeah, because I'm too stupid to know better, so you have to tell me what to do so I can stay safe? I think I get it now."
    a dejected "Sí, porque soy demasiado tonto para saberlo, ¿así que tienes que decirme qué hacer para que esté a salvo? Creo que ahora lo entiendo."

# game/act1.rpy:1576
translate spanish act1_ef7c6d9b:

    # "I scoff, getting up to head towards the bathroom when Ethan grabs my arm, starting to protest."
    "Resoplé con desdén y me levanté para dirigirme al baño cuando Ethan me agarró del brazo y empezó a protestar."

# game/act1.rpy:1578
translate spanish act1_783995ab:

    # e "Hey, calm down. I didn’t mean it like that. You {i}know{/i} I didn’t mean it like that."
    e "Oye, cálmate. No lo dije con esa intención. Sabes que no lo dije con esa intención."

# game/act1.rpy:1579
translate spanish act1_45e2de1b:

    # e sigh "Just sit back down, and we’ll{nw}"
    e sigh "Siéntese de nuevo y nosotros..."

# game/act1.rpy:1583
translate spanish act1_2b27af46:

    # a nngh "Stop {i}fucking{/i} telling me what to do, Ethan!"
    a nngh "¡Deja de decirme qué hacer, Ethan!"

# game/act1.rpy:1585
translate spanish act1_188851da:

    # "I yank my arm away, something snapping in my mind that makes me start seeing red."
    "Aparto el brazo de un tirón, algo se rompe en mi mente y empiezo a ver todo rojo."

# game/act1.rpy:1587
translate spanish act1_06907826:

    # a concern "What is wrong with you? Who do you take me for? Why do you feel the need to watch over me like I’m some idiot who can’t take care of himself?"
    a concern "¿Qué te pasa? ¿Por quién me tomas? ¿Por qué sientes la necesidad de vigilarme como si fuera un idiota que no puede valerse por sí mismo?"

# game/act1.rpy:1588
translate spanish act1_8fac8f53:

    # a angry "I’m not your child, or {i}whatever{/i} you think I am that gives you the authority to keep telling me what I can or can’t do! I’m so fucking sick of it!"
    a angry "No soy tu hijo, ni lo que sea que creas que soy para darte la autoridad de decirme lo que puedo o no puedo hacer. ¡Estoy harto de esto!"

# game/act1.rpy:1590
translate spanish act1_b4679918:

    # "All the pent-up frustrations from today stumble out of me all at once, and I couldn’t care less in this moment if I’m making a scene, if I hurt Ethan’s feelings. {w}I just want to go home."
    "Todas las frustraciones acumuladas de hoy salen de mí de golpe, y en este momento me da igual si armo un escándalo o si hiero los sentimientos de Ethan. {w}Solo quiero irme a casa."

# game/act1.rpy:1592
translate spanish act1_ec0fcc5f:

    # a sad "You really think I don’t have enough of that already?"
    a sad "¿De verdad crees que no tengo ya suficiente de eso?"

# game/act1.rpy:1593
translate spanish act1_655f7994:

    # a "You’re the one person I thought I could get away from all of this, and just be myself around… I guess I can’t even do that."
    a "Eres la única persona con la que pensé que podría alejarme de todo esto y ser yo misma... Supongo que ni siquiera puedo hacer eso."

# game/act1.rpy:1595
translate spanish act1_4f94e27b:

    # "I slam a crumpled-up bill on the counter of the bar, giving Ethan one last look of disdain before turning around and exiting the bar."
    "Golpeo con fuerza un billete arrugado contra el mostrador del bar, le dedico a Ethan una última mirada de desdén antes de darme la vuelta y salir del local."

# game/act1.rpy:1600
translate spanish act1_7e8c5916:

    # "Home."
    "Hogar."

# game/act1.rpy:1601
translate spanish act1_b597a209:

    # "Or, at least, the only place in the city that comes to close to it."
    "O, al menos, el único lugar de la ciudad que se le acerca demasiado."

# game/act1.rpy:1603
translate spanish act1_12487595:

    # "It feels like forever since I’ve last step foot in my own apartment, even though it’s only been about a day or two. Life in Sonora can feel endless in that way."
    "Parece que ha pasado una eternidad desde la última vez que pisé mi apartamento, aunque solo han pasado uno o dos días. La vida en Sonora puede parecer interminable en ese sentido."

# game/act1.rpy:1604
translate spanish act1_ba463265:

    # "It wouldn’t matter much, anyway. This space isn’t particularly pretty or cozy – that’s why I spend so much time over at Ethan’s – but it’s the one place in the city where I can be completely, fully alone… which can be both a good and bad thing."
    "De todas formas, no importaría mucho. Este lugar no es particularmente bonito ni acogedor —por eso paso tanto tiempo en casa de Ethan—, pero es el único sitio en la ciudad donde puedo estar completamente sola… lo cual puede ser bueno y malo a la vez."

# game/act1.rpy:1605
translate spanish act1_d06b3471:

    # "I feel my entire body slump from exhaustion as I close the door behind me, and I start to slowly undress from head to toe, trudging towards the bathroom as I peel off each article of clothing from my fur."
    "Siento cómo todo mi cuerpo se desploma por el agotamiento al cerrar la puerta tras de mí, y empiezo a desvestirme lentamente de la cabeza a los pies, arrastrándome hacia el baño mientras me quito cada prenda de ropa de mi abrigo de piel."

# game/act1.rpy:1606
translate spanish act1_7d2a83a2:

    # "The feeling of wanting to burst into tears overtakes my sense, but, just as always, I push it down. Crying wins me nothing. It’s just a waste of time."
    "Me invaden las ganas de llorar, pero, como siempre, las reprimo. Llorar no me sirve de nada. Es una pérdida de tiempo."

# game/act1.rpy:1609
translate spanish act1_8943ecb2:

    # "I turn on the faucet to my bathtub, setting my bare ass on the edge of its porcelain body as I watch the warm water fill up.{w} I think of nothing.{w} I feel nothing. "
    "Abro el grifo de mi bañera, apoyando mi trasero desnudo en el borde de su cuerpo de porcelana mientras veo cómo se llena el agua caliente.{w} No pienso en nada.{w} No siento nada."

# game/act1.rpy:1610
translate spanish act1_a1c95695:

    # "I can’t. I don’t allow myself to. The moment I let my reasoning slip, I know I’ll fall into a sadness so deep, not even I could pull myself out of. If I allow myself to daydream of better times, of a softer, simple life… it would drive me to the brink of madness."
    "No puedo. No me lo permito. En el momento en que deje que mi razón me falle, sé que caeré en una tristeza tan profunda que ni yo misma podría salir de ella. Si me permito soñar despierta con tiempos mejores, con una vida más tranquila y sencilla… me llevaría al borde de la locura."

# game/act1.rpy:1611
translate spanish act1_7fadadf2:

    # "Because it’s impossible. Because I know I’ll sob my eyes out, stomp and throw a tantrum like a child, scream out ferociously how it’s not fair, it’s not fair, not fair…!"
    "Porque es imposible. Porque sé que lloraré desconsoladamente, patalearé y haré una rabieta como una niña, gritaré con furia que no es justo, no es justo, no es justo…!"

# game/act1.rpy:1612
translate spanish act1_12410810:

    # "And when I’ve finally settled down… nothing will have changed. I am still a Valentine. I am still in Sonora. I am still all on my own, with no one to come home to, no chance of living a normal life."
    "Y cuando por fin me haya asentado... nada habrá cambiado. Seguiré siendo una Valentine. Seguiré en Sonora. Seguiré estando sola, sin nadie a quien volver, sin posibilidad de vivir una vida normal."

# game/act1.rpy:1613
translate spanish act1_2daddbf6:

    # "So…{w} I don’t cry. I don’t feel. I simply exist in the life that was laid out for me."
    "Entonces…{w} No lloro. No siento. Simplemente existo en la vida que me fue trazada."

# game/act1.rpy:1616
translate spanish act1_46a88f9b:

    # "The water is warm, hot even. It stings as I slip inside, making my muscles tense up when I submerge myself completely. Eventually, though, my body adjusts to the temperature, and my sense of touch goes numb from the heat."
    "El agua está tibia, incluso caliente. Me escuece al meterme, y mis músculos se tensan al sumergirme por completo. Sin embargo, con el tiempo, mi cuerpo se adapta a la temperatura y el calor me adormece el tacto."

# game/act1.rpy:1617
translate spanish act1_06d768da:

    # "But I can’t relax. The rage I feel for the way Ethan spoke to me starts to spread to the way Mr. Gray looked at me, like I was a toy he really wanted to play with. Then it goes to Mr. Valentine, how he, too, toys with my head any chance he gets."
    "Pero no puedo relajarme. La rabia que siento por la forma en que Ethan me habló empieza a extenderse a la forma en que el señor Gray me miró, como si yo fuera un juguete con el que realmente quería jugar. Luego se dirige al señor Valentine, a cómo él también juega conmigo cada vez que tiene oportunidad."

# game/act1.rpy:1618
translate spanish act1_8ee213d5:

    # "The cycle continues and repeats, until I’m not sure whether the heat I feel is from the bath water or the rage flushing against my cheeks."
    "El ciclo continúa y se repite, hasta que ya no estoy segura de si el calor que siento proviene del agua del baño o de la rabia que me sube a las mejillas."

# game/act1.rpy:1622
translate spanish act1_98d022c7:

    # "I grab my phone sitting on the sink, which I got into a habit of carrying everywhere nowadays. I never know when Mr. Valentine will call me for some other stupid, menial task."
    "Agarro el teléfono que está sobre el lavabo, algo que últimamente llevo conmigo a todas partes. Nunca sé cuándo me llamará el señor Valentine para alguna otra tarea tonta y sin importancia."

# game/act1.rpy:1623
translate spanish act1_956f67eb:

    # "I wonder to myself, is there someone who could talk me out of feeling this way? My mind immediately goes to Ethan. It was always him, in times like these. He would come over, or I would go to his apartment, and he’d show me some old movie I would never really be interested in."
    "Me pregunto si habrá alguien que pueda convencerme de que deje de sentirme así. Inmediatamente pienso en Ethan. Siempre era él, en momentos como este. Venía a mi casa, o yo iba a su apartamento, y me mostraba alguna película antigua que nunca me interesaba."

# game/act1.rpy:1624
translate spanish act1_80ea8416:

    # "And yet, somehow, it made me feel better. To have someone in my life who wanted to share their time with me, not under any transaction, but just because they liked me. It made me feel… normal."
    "Y, sin embargo, de alguna manera, me hizo sentir mejor. Tener a alguien en mi vida que quisiera compartir su tiempo conmigo, no por ningún interés, sino simplemente porque le caía bien. Me hizo sentir… normal."

# game/act1.rpy:1625
translate spanish act1_d17ef062:

    # "But I don’t want to think about Ethan right now."
    "Pero ahora mismo no quiero pensar en Ethan."

# game/act1.rpy:1627
translate spanish act1_8ac8ffeb:

    # "Then, that leaves only one other person…"
    "Entonces, solo queda una persona más…"

# game/act1.rpy:1630
translate spanish act1_018e60c7:

    # "With a shaky hand, I reach for my phone and dial the number I know by heart, pressing it up to my ear. I always get nervous when I call her, as if I’m intruding in her life, but I remind myself to not be ridiculous"
    "Con mano temblorosa, busco mi teléfono y marco el número que me sé de memoria, acercándolo a mi oído. Siempre me pongo nervioso cuando la llamo, como si estuviera entrometiéndome en su vida, pero me repito a mí mismo que no debo ser ridículo."

# game/act1.rpy:1631
translate spanish act1_cf8e66d3:

    # "She’s my mother. Moms want to hear from their kids, don’t they?"
    "Es mi madre. Las madres quieren saber de sus hijos, ¿verdad?"

# game/act1.rpy:1633
translate spanish act1_90fbe6ed:

    # "The phone rings. Once, then twice, three times…"
    "Suena el teléfono. Una vez, luego dos, tres veces…"

# game/act1.rpy:1635
translate spanish act1_fabc1d30:

    # mom "{i}Hello?"
    mom "{i}¿Hola?"

# game/act1.rpy:1636
translate spanish act1_7b14affb:

    # a -uniform surprised "Mom?"
    a -uniform surprised "¿Mamá?"

# game/act1.rpy:1638
translate spanish act1_7964cf38:

    # "My voice comes out pleading, and tears fill my eyes as I hear her voice on the other end of the line. It’s amazing how quickly it soothes me."
    "Mi voz se vuelve suplicante y las lágrimas me llenan los ojos al oír su voz al otro lado de la línea. Es increíble lo rápido que me tranquiliza."

# game/act1.rpy:1640
translate spanish act1_a52c5483:

    # mom "{i}Angel?"
    mom "{i}¿Ángel?"

# game/act1.rpy:1641
translate spanish act1_4a8112e3:

    # a bashful "Mom, hi… yeah, it’s Angel. How are you?"
    a bashful "Mamá, hola… sí, soy Angel. ¿Cómo estás?"

# game/act1.rpy:1642
translate spanish act1_fda62b22:

    # a flattered "I-I’m sorry if I’m interrupting something, or if you're busy, I just… I wanted to talk to you."
    a flattered "Lo siento si interrumpo algo o si estás ocupado, solo... quería hablar contigo."

# game/act1.rpy:1644
translate spanish act1_332f1102:

    # mom "{i}Oh. Well, alright then… how are things going for you, Angel?"
    mom "{i}Oh. Bueno, está bien entonces... ¿cómo te va, Ángel?"

# game/act1.rpy:1645
translate spanish act1_ce32ebbf:

    # a worried "…things are…"
    a worried "…las cosas están…"

# game/act1.rpy:1647
translate spanish act1_7d5f8d55_2:

    # a sad "…"
    a sad "…"

# game/act1.rpy:1648
translate spanish act1_a2d994ac:

    # a bashful "Things are fine. I’m just a little tired lately."
    a bashful "Todo está bien. Últimamente solo estoy un poco cansado."

# game/act1.rpy:1649
translate spanish act1_d16aee84:

    # mom "I understand. I’m sorry, honey… Don’t get bummed out about it, okay? You’re doing a good job, and I’m very grateful for everything you do for me."
    mom "Lo entiendo. Lo siento, cariño… No te preocupes, ¿vale? Estás haciendo un buen trabajo y te agradezco mucho todo lo que haces por mí."

# game/act1.rpy:1650
translate spanish act1_1ab72481_12:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1652
translate spanish act1_b9827c55:

    # "How many times have I heard her say those words to me? They always used to fill me with hope, always made my heart feel warm and proud. So… why do these words feel hollow to me now?"
    "¿Cuántas veces la he oído decirme esas palabras? Siempre me llenaban de esperanza, siempre me hacían sentir una calidez y un orgullo en el corazón. Entonces… ¿por qué ahora me suenan vacías?"

# game/act1.rpy:1654
translate spanish act1_7a3299cb:

    # a flattered "I know, Mom. I was just thinking that maybe… I could come visit soon? I got a new story, and if everything goes well, I think I’ll get a bonus, which would be enough to…"
    a flattered "Lo sé, mamá. Estaba pensando que tal vez… ¿podría ir a visitarte pronto? Tengo una nueva historia, y si todo sale bien, creo que recibiré una bonificación, lo cual sería suficiente para…"

# game/act1.rpy:1656
translate spanish act1_da6716a9:

    # mom "Oh honey… I don’t know. Are you sure you can afford it? Everything is so expensive in Sonora."
    mom "Ay, cariño… no lo sé. ¿Estás segura de que puedes pagarlo? Todo es tan caro en Sonora."

# game/act1.rpy:1658
translate spanish act1_381d122a:

    # "She speaks in that soft, slow manner she always does with me, ever since I was little. Today, for some reason, it only annoys me."
    "Me habla con ese tono suave y pausado que siempre usa conmigo, desde que era pequeña. Hoy, por alguna razón, me irrita."

# game/act1.rpy:1660
translate spanish act1_5454bb4e:

    # a bashful "It’s fine, Mom. I have a bit saved up already. This would just be the last push I need to make it come true. Besides, I think I need a little break, hehe…"
    a bashful "Está bien, mamá. Ya tengo algo ahorrado. Esto sería justo el último empujón que necesito para que se haga realidad. Además, creo que necesito un pequeño descanso, jeje…"

# game/act1.rpy:1662
translate spanish act1_24a5165b:

    # mom "Oh, I know honey. You work very hard. But…"
    mom "Oh, lo sé, cariño. Trabajas muy duro. Pero…"

# game/act1.rpy:1663
translate spanish act1_dc0b48da:

    # mom "Things are just… not very good here on my end, Angel. I got a new job, so I won’t be able to take days off whenever it is that you come to visit. It’s just not good timing, hun."
    mom "Las cosas no van muy bien por aquí, Ángel. Conseguí un nuevo trabajo, así que no podré tomarme días libres cuando vengas de visita. No es un buen momento, cariño."

# game/act1.rpy:1665
translate spanish act1_d8eb5386_3:

    # a scared "…"
    a scared "…"

# game/act1.rpy:1666
translate spanish act1_edd6952c:

    # a "Oh… Okay…"
    a "Ah, okey…"

# game/act1.rpy:1667
translate spanish act1_77d0f8f4:

    # a bashful "No, yeah, that’s fine, um…{w} that’s okay!{w} You just never mentioned a new job, so… I mean, of course you didn’t, haha!"
    a bashful "No, sí, está bien, um…{w} ¡Está bien!{w} Nunca mencionaste un nuevo trabajo, así que… quiero decir, por supuesto que no lo hiciste, ¡jaja!"

# game/act1.rpy:1668
translate spanish act1_14190633:

    # a "When was the last time we called? Last month? Or, the one before that? It’s been a while."
    a "¿Cuándo fue la última vez que llamamos? ¿El mes pasado? ¿O el anterior? Ha pasado bastante tiempo."

# game/act1.rpy:1669
translate spanish act1_33849264:

    # mom "Yeah… yeah, it has. I’m sorry, sweetie…"
    mom "Sí… sí, lo ha hecho. Lo siento, cariño…"

# game/act1.rpy:1670
translate spanish act1_e29620df:

    # a flattered "It’s okay! I know you’re busy… um…"
    a flattered "¡No pasa nada! Sé que estás ocupado… um…"

# game/act1.rpy:1672
translate spanish act1_0d9e6113:

    # "I’m trying to keep my composure, trying to not cry as I feel my one beacon of hope slowly die out in front of. I tilt my head up, looking at my monochrome popcorn ceiling, my breathing ragged and heavy as I try to blink away the tears."
    "Intento mantener la compostura, intento no llorar mientras siento que mi único rayo de esperanza se extingue lentamente ante mis ojos. Levanto la cabeza, mirando el techo monocromático de palomitas de maíz, con la respiración agitada y pesada mientras intento contener las lágrimas."

# game/act1.rpy:1674
translate spanish act1_bfe32573:

    # a bashful "I’ll just… save that money. For next year, when you’re more acclimated to your job."
    a bashful "Voy a... ahorrar ese dinero. Para el año que viene, cuando estés más familiarizado con tu trabajo."

# game/act1.rpy:1675
translate spanish act1_59d4ca8c:

    # mom "Okay sweetie. Whatever it is you decide."
    mom "Está bien, cariño. Lo que sea que decidas."

# game/act1.rpy:1677
translate spanish act1_7c16802d:

    # "I wait for her to tell me more, to try and reassure me we’ll be reunited again soon. Static is all that comes from the other end of the line."
    "Espero a que me cuente más, a que intente asegurarme que pronto nos reuniremos de nuevo. Solo se oye estática al otro lado de la línea."

# game/act1.rpy:1679
translate spanish act1_306f02a4:

    # a sad "I… I love you…"
    a sad "Yo… te amo…"

# game/act1.rpy:1681
translate spanish act1_7a1574c5:

    # mom "I love you too, Angel."
    mom "Yo también te quiero, Ángel."

# game/act1.rpy:1683
translate spanish act1_72e94c19_2:

    # a "…"
    a "…"

# game/act1.rpy:1684
translate spanish act1_da86492f:

    # a "Bye…"
    a "Adiós…"

# game/act1.rpy:1685
translate spanish act1_42ec471b:

    # mom "Goodbye, honey."
    mom "Adiós, cariño."

# game/act1.rpy:1689
translate spanish act1_f30b931d:

    # "She hangs up the call, and I dig my claws into my arm, willing myself not to do it. Don’t cry. Even if my own mother – the person who I’ve been fighting for my whole life – doesn’t want to take time to see me…{w} just don’t cry."
    "Ella cuelga la llamada y yo clavo mis garras en mi brazo, esforzándome por no hacerlo. No llores. Aunque mi propia madre, la persona por la que he luchado toda mi vida, no quiera dedicarme tiempo…{w} simplemente no llores."

# game/act1.rpy:1692
translate spanish act1_3a16345d:

    # "But it’s no use. I’m not made of stone, as much as I wish I was, and after seeking solace in the only family I have to turn to and being met with nothing but indifference…{w} I break down."
    "Pero no sirve de nada. No estoy hecho de piedra, por mucho que lo deseara, y después de buscar consuelo en la única familia a la que puedo recurrir y no encontrar más que indiferencia…{w} me derrumbo."

# game/act1.rpy:1693
translate spanish act1_12b2340b:

    # "I sob. I cry and scream in my tiny, colorless bathroom, my wails echoing against the walls."
    "Sollozo. Lloro y grito en mi pequeño y descolorido baño, mis lamentos resuenan contra las paredes."

# game/act1.rpy:1695
translate spanish act1_da1cf445:

    # a1 "It’s not fair…"
    a1 "No es justo…"

# game/act1.rpy:1697
translate spanish act1_2a55eda3:

    # "The words I didn’t dare even utter now come out in pained cries as my teardrops plop loudly into the water. I was right, though; it fixes nothing. I am still a Valentine, no matter how hard I scream… but it feels good, somehow. To let everything I had inside come out."
    "Las palabras que ni siquiera me atrevía a pronunciar ahora salen en gritos de dolor mientras mis lágrimas caen ruidosamente al agua. Tenía razón, sin embargo; no soluciona nada. Sigo siendo una Valentine, por mucho que grite… pero se siente bien, de alguna manera. Dejar salir todo lo que llevo dentro."

# game/act1.rpy:1699
translate spanish act1_0f42e80c:

    # "By the time I finish crying, my fur is soaked and matted, my bones aching from sitting in the tub for too long. I get up, my throat sore and my eyes red and burning. I meticulously dry myself in front of my mirror, staring hard into my reflection."
    "Para cuando termino de llorar, mi pelaje está empapado y enmarañado, y me duelen los huesos por haber estado sentada en la bañera demasiado tiempo. Me levanto, con la garganta irritada y los ojos rojos y ardientes. Me seco meticulosamente frente al espejo, mirándome fijamente."

# game/act1.rpy:1700
translate spanish act1_c558194c:

    # "It’s just the me that I’ve always seen, if not a little dazed and distressed. I look angry, sad, and deranged… which I guess I am. But I hate to see myself this way. So weak, so pathetic."
    "Soy la misma persona que siempre he visto, aunque un poco aturdida y angustiada. Me veo enojada, triste y desquiciada… y supongo que lo estoy. Pero odio verme así. Tan débil, tan patética."

# game/act1.rpy:1701
translate spanish act1_4f56cfce:

    # "I won’t even be able to be used as a pawn like this. No one wants to play with such a fragile toy."
    "Ni siquiera podré ser utilizado como un peón de esta manera. Nadie quiere jugar con un juguete tan frágil."

# game/act1.rpy:1703
translate spanish act1_c3c63ad1:

    # a1 "…"
    a1 "…"

# game/act1.rpy:1705
translate spanish act1_69ba9a2a:

    # "But no. I’m nowhere near broken. I’m exactly as I was yesterday, and the day before. Nothing in my life has changed."
    "Pero no. No estoy ni mucho menos destrozado. Sigo siendo exactamente igual que ayer y anteayer. Nada en mi vida ha cambiado."

# game/act1.rpy:1706
translate spanish act1_7f1c32e1:

    # "Nothing… except for the dark realization that, in the end, I am truly and completely on my own in in this city."
    "Nada… excepto la oscura constatación de que, al final, estoy verdadera y completamente solo en esta ciudad."

# game/act1.rpy:1708
translate spanish act1_1274d778:

    # "I was never just fighting for my mother… there’s one thing that mattered far more to me than her, as selfish as it is to admit. And that’s my freedom."
    "Nunca luché solo por mi madre… había algo que me importaba mucho más que ella, por egoísta que parezca admitirlo. Y eso era mi libertad."

# game/act1.rpy:1710
translate spanish act1_7fb96abc:

    # "I drop my towel on the floor and walk out of my bathroom, naked, cold, and alone… but now filled with something stronger than just pure determination."
    "Dejo caer la toalla al suelo y salgo del baño, desnuda, con frío y sola... pero ahora llena de algo más fuerte que la mera determinación."

# game/act1.rpy:1712
translate spanish act1_ac4c7fc8:

    # "After all, I still have a job to do."
    "Después de todo, todavía tengo trabajo que hacer."

# game/act1.rpy:1716
translate spanish act1_5f3c12b3:

    # "The Albatross is a stuffy, dingy place. The smell of smoke lingers in the air, and the regulars talk loudly amongst themselves, drowning out the sound of the jukebox with their laughter. It’s cheap and dirty, but somehow finds a way to be cozy."
    "El Albatross es un lugar sofocante y lúgubre. El olor a humo impregna el ambiente, y los clientes habituales hablan a gritos entre sí, ahogando el sonido de la máquina de discos con sus risas. Es barato y sucio, pero de alguna manera logra ser acogedor."

# game/act1.rpy:1717
translate spanish act1_e1c6b5ab:

    # "Basically, it’s for people like me."
    "Básicamente, es para gente como yo."

# game/act1.rpy:1719
translate spanish act1_f7e4691b:

    # a uniform hm "{i}So how is there an underground ring here?"
    a uniform hm "{i}Entonces, ¿cómo es que hay un anillo subterráneo aquí?"

# game/act1.rpy:1721
translate spanish act1_a7e4008d:

    # "It doesn’t make sense. I don’t see anyone suspicious, or people walking into the same room. In fact, I don’t see very many rooms in this place at all, minus the kitchen in the back, where they make the soggiest nachos known to mankind."
    "No tiene sentido. No veo a nadie sospechoso, ni a gente entrando en la misma habitación. De hecho, casi no veo habitaciones en este sitio, salvo la cocina al fondo, donde preparan los nachos más blandos que existen."

# game/act1.rpy:1722
translate spanish act1_c242e7cd:

    # "I think they dip them in water or something. Anyway…"
    "Creo que los sumergen en agua o algo así. En fin…"

# game/act1.rpy:1723
translate spanish act1_038a945b:

    # "I slip a peanut into my mouth, scanning the room, listening in on anything out of the ordinary… but I’m coming up short. Are they being extra careful because I’m here?"
    "Me meto un cacahuete en la boca, escudriño la habitación, intentando oír cualquier cosa fuera de lo común… pero no oigo nada. ¿Estarán siendo más precavidos porque estoy aquí?"

# game/act1.rpy:1724
translate spanish act1_f32f8db6:

    # "I ended up coming in my uniform, but I’m technically off the clock right now. I guess that wouldn’t matter to anyone, though. Valentines aren’t to be trusted…"
    "Al final vine con el uniforme puesto, pero técnicamente ya no estoy trabajando. Supongo que a nadie le importaría. No se puede confiar en los San Valentín…"

# game/act1.rpy:1725
translate spanish act1_9b688d6c:

    # "I sigh. I may have let the idea of getting more information get to my head. Maybe Ethan was right. Maybe I bit off more than I can-"
    "Suspiro. Puede que la idea de obtener más información se me haya subido a la cabeza. Tal vez Ethan tenía razón. Tal vez me he metido en un lío."

# game/act1.rpy:1727
translate spanish act1_992cfc69:

    # anon "{i}Chelito~"
    anon "{i}Chelito~"

# game/act1.rpy:1729
translate spanish act1_35f11f7d:

    # "I feel a hot whisper against my ear and a large hand grab my waist, so sudden that it catches me off guard, shuddering a full body chill."
    "Siento un susurro cálido contra mi oído y una mano grande que me agarra la cintura, tan repentinamente que me toma por sorpresa, provocándome un escalofrío que recorre todo mi cuerpo."

# game/act1.rpy:1731
translate spanish act1_120103f9:

    # a flustered "S-Sebas…"
    a flustered "S-Sebas…"

# game/act1.rpy:1732
translate spanish act1_1a38621c:

    # s "{i}Dichoso los ojos.{/i} I didn’t expect to actually see you here tonight."
    s "{i}Dicho los ojos.{/i} No esperaba verte aquí esta noche."

# game/act1.rpy:1734
translate spanish act1_62c3f639:

    # "He sits down on the stool next to me, and I take the opportunity to compose myself. How did I not notice him walk in? He didn’t even make a sound."
    "Se sienta en el taburete junto a mí, y aprovecho para recomponerme. ¿Cómo no me di cuenta de que había entrado? Ni siquiera emitió un sonido."

# game/act1.rpy:1736
translate spanish act1_c7bf3780:

    # a cocky "Well, I’m full of surprises. Seems like you are, too."
    a cocky "Bueno, estoy lleno de sorpresas. Parece que tú también."

# game/act1.rpy:1738
translate spanish act1_095606c5:

    # s amused "You could say that."
    s amused "Se podría decir eso."

# game/act1.rpy:1739
translate spanish act1_5d9e8d12:

    # s cocky "You want a drink? You look like you could use one."
    s cocky "¿Quieres algo de beber? Pareces necesitarlo."

# game/act1.rpy:1740
translate spanish act1_eca1388d:

    # a hm "Why do you say that?"
    a hm "¿Por qué dices eso?"

# game/act1.rpy:1741
translate spanish act1_16509f2b:

    # s amused "You just seem... tense. Some alcohol will help with that, I'm sure."
    s amused "Simplemente pareces... tenso. Un poco de alcohol te ayudará con eso, estoy seguro."

# game/act1.rpy:1742
translate spanish act1_f0c9ee04:

    # a bashful "Hah. You might be right, but I think I'll pass on the drink."
    a bashful "Ja. Puede que tengas razón, pero creo que paso de la bebida."

# game/act1.rpy:1743
translate spanish act1_d6cfc10e:

    # s cocky "Oh? Well, if there's something else that could help you ease up, let me know. I'm full of ideas."
    s cocky "¿Ah, sí? Bueno, si hay algo más que pueda ayudarte a relajarte, házmelo saber. Tengo muchas ideas."

# game/act1.rpy:1745
translate spanish act1_c251e7fe:

    # "I roll my eyes, but a smile is still on my face. This guy’s clearly full of shit."
    "Pongo los ojos en blanco, pero sigo sonriendo. Este tipo está diciendo puras tonterías."

# game/act1.rpy:1747
translate spanish act1_68aeab4c:

    # a cocky "{i}But even if you’re hot, I won’t let my guard down for someone like you."
    a cocky "{i}Pero aunque seas atractivo, no bajaré la guardia por alguien como tú."

# game/act1.rpy:1749
translate spanish act1_f12264ef:

    # a flattered "I’m okay."
    a flattered "Estoy bien."

# game/act1.rpy:1750
translate spanish act1_1d6dd05a:

    # s "Are you, now? What a shame."
    s "¿En serio? Qué lástima."

# game/act1.rpy:1752
translate spanish act1_e9f64793:

    # "He orders a drink, and I sneak glances at him while he’s distracted with the bartender."
    "Pide una copa y yo le echo miradas furtivas mientras está distraído hablando con el camarero."

# game/act1.rpy:1753
translate spanish act1_f0191cdf:

    # "Yeah, this guy’s eye-candy for sure. His arms are huge, his hair soft and flowy when he moves… but those eyes are what really capture me."
    "Sí, este chico es un bombón, sin duda. Tiene unos brazos enormes, el pelo suave y ondeante cuando se mueve… pero lo que de verdad me cautiva son sus ojos."

# game/act1.rpy:1754
translate spanish act1_6a26abc2:

    # "Tired, and with dark circles under them, but with an intrigue and allure that I can’t help but want to stare into. What secrets lie behind them, I wonder…?"
    "Cansadas y con ojeras, pero con un aire intrigante y seductor que me atrae irresistiblemente. ¿Qué secretos esconden, me pregunto…?"

# game/act1.rpy:1756
translate spanish act1_fb10136e:

    # "He suddenly turns to me, and I quickly glance away, pretending to be very immersed in the pattern of the wooden countertop."
    "De repente, se vuelve hacia mí, y yo aparto la mirada rápidamente, fingiendo estar muy absorta en el dibujo de la encimera de madera."

# game/act1.rpy:1758
translate spanish act1_0739775b:

    # s amused "So, {i}Ángel{/i}… tell me. Are you here because of me?"
    s amused "Entonces, {i}Ángel{/i}… dime. ¿Estás aquí por mí?"

# game/act1.rpy:1759
translate spanish act1_b434f98f:

    # a surprised "What…?"
    a surprised "Qué…?"

# game/act1.rpy:1760
translate spanish act1_62560213:

    # s "Because I told you about {i}that?"
    s "¿Porque te conté sobre {i}eso?"

# game/act1.rpy:1762
translate spanish act1_7fa9e587:

    # "He’s speaking in code now?"
    "¿Ahora está hablando en clave?"

# game/act1.rpy:1764
translate spanish act1_2c941e91:

    # a bashful "…maybe."
    a bashful "…tal vez."

# game/act1.rpy:1766
translate spanish act1_48c51842:

    # "Sebas smiles."
    "Sebas sonríe."

# game/act1.rpy:1768
translate spanish act1_c08d9d08:

    # s "Well, good thing I’m here then. You would’ve been lost without me."
    s "Bueno, entonces menos mal que estoy aquí. Sin mí, te habrías perdido."

# game/act1.rpy:1769
translate spanish act1_1fb89e7e:

    # a hm "Oh? I think I was doing just fine."
    a hm "¿Ah? Creo que lo estaba haciendo bastante bien."

# game/act1.rpy:1770
translate spanish act1_0f127e90:

    # s cocky "Yeah? How were you gonna get in?"
    s cocky "¿Sí? ¿Cómo ibas a entrar?"

# game/act1.rpy:1771
translate spanish act1_2a4ff97c_10:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:1772
translate spanish act1_e0e66212:

    # a flustered "That’s… a work in progress."
    a flustered "Eso es… un trabajo en progreso."

# game/act1.rpy:1773
translate spanish act1_aaea323d:

    # s flirty "Do you even know where you’re supposed to enter from?"
    s flirty "¿Sabes siquiera por dónde se supone que debes entrar?"

# game/act1.rpy:1774
translate spanish act1_72e94c19_3:

    # a "…"
    a "…"

# game/act1.rpy:1775
translate spanish act1_ddfe0f38:

    # a "The… back… door…"
    a "La… puerta… trasera…"

# game/act1.rpy:1776
translate spanish act1_c6b91f77:

    # s amused "{i}Ajá.{/i} It’s fine to admit it, you know. You can ask for help."
    s amused "{i}Ajá.{/i} Está bien admitirlo, ¿sabes? Puedes pedir ayuda."

# game/act1.rpy:1778
translate spanish act1_807244a7:

    # a frown "I don’t {i}need{/i} help."
    a frown "No {i}necesito{/i} ayuda."

# game/act1.rpy:1781
translate spanish act1_c5491485:

    # "He shrugs, grabbing a peanut and popping it in his maw like a pill."
    "Se encoge de hombros, agarra un cacahuete y se lo mete en la boca como si fuera una pastilla."

# game/act1.rpy:1783
translate spanish act1_e19daa53:

    # s smile "Whatever you say, {i}chelito."
    s smile "Lo que tú digas, {i}chelito."

# game/act1.rpy:1786
translate spanish act1_fff9cb32:

    # a hm "If, say, I {i}did{/i} need help… what would you tell me?"
    a hm "Si, por ejemplo, yo {i}necesitara{/i} ayuda… ¿qué me dirías?"

# game/act1.rpy:1788
translate spanish act1_068315e5:

    # s flirty "Well… first, I’d bring you a bit closer…"
    s flirty "Bueno… primero, te acercaré un poco más…"

# game/act1.rpy:1792
translate spanish act1_e71f38df:

    # "He grabs the edge of my stool and effortlessly pulls it right next to his, bringing us shoulder to shoulder."
    "Agarra el borde de mi taburete y, sin esfuerzo, lo acerca al suyo, quedando hombro con hombro."

# game/act1.rpy:1794
translate spanish act1_e474a194:

    # s "…to prevent any listening ears."
    s "…para evitar que alguien escuche."

# game/act1.rpy:1796
translate spanish act1_241be771:

    # "I can smell the peanut on his breath, his muzzle closing in on my ear again. I blush, completely unaccustomed to this level of closeness with another guy that isn’t Ethan."
    "Puedo oler el cacahuete en su aliento, su hocico acercándose de nuevo a mi oreja. Me sonrojo, completamente desacostumbrada a este nivel de cercanía con otro chico que no sea Ethan."

# game/act1.rpy:1797
translate spanish act1_b2d774e5:

    # "Not even he puts his face this close to mine…"
    "Ni siquiera él acerca su cara tanto a la mía…"

# game/act1.rpy:1799
translate spanish act1_95f513c3:

    # s amused "And I’d tell you to order a Death in the Gulf Stream… and tap your fingers-"
    s amused "Y yo te diría que pidas un Death in the Gulf Stream… y tamborilees con los dedos."

# game/act1.rpy:1801
translate spanish act1_f6e01fbc:

    # "He taps his claw on the countertop thrice as he enunciates his next words."
    "Golpea la encimera con la garra tres veces mientras pronuncia las siguientes palabras."

# game/act1.rpy:1803
translate spanish act1_8110a229:

    # s "Just.{w} Like.{w} This."
    s "Así.{w}"

# game/act1.rpy:1808
translate spanish act1_d2e63892:

    # "I pull away to look at him."
    "Me aparto para mirarlo."

# game/act1.rpy:1810
translate spanish act1_39746212:

    # a concern "How do you know all of this?"
    a concern "¿Cómo sabes todo esto?"

# game/act1.rpy:1812
translate spanish act1_e4a0e38c:

    # s cocky "Do you think journalists are the only ones with connections?"
    s cocky "¿Crees que los periodistas son los únicos que tienen contactos?"

# game/act1.rpy:1814
translate spanish act1_140f84be:

    # "He downs his drink – a rum and coke, I think – in three big gulps and sighs, slipping out of his stool to stand behind me."
    "Se bebe su trago —un ron con cola, creo— de un solo trago y suspira, levantándose de su taburete para colocarse detrás de mí."

# game/act1.rpy:1816
translate spanish act1_59cea1f1:

    # s "And speaking of, I’m actually here on business myself, so I’ll have to cut our conversation a little short tonight."
    s "Y hablando de eso, yo también estoy aquí por negocios, así que tendré que acortar un poco nuestra conversación esta noche."

# game/act1.rpy:1818
translate spanish act1_fd49e2ef:

    # "He slips something into my back pocket, his hands lingering there for a moment too long, and I whip around to frown at him."
    "Me mete algo en el bolsillo trasero, sus manos se quedan allí un instante de más, y me giro bruscamente para mirarlo con el ceño fruncido."

# game/act1.rpy:1820
translate spanish act1_361caf04:

    # s "Just my personal number. I wanna hear all about your escapades tonight."
    s "Solo mi número personal. Quiero escuchar todo sobre tus aventuras de esta noche."

# game/act1.rpy:1821
translate spanish act1_4a530c3d_2:

    # a hm "…"
    a hm "…"

# game/act1.rpy:1822
translate spanish act1_b0cd670a:

    # s smile "I’ll see you around… {i}Ángel{/i}."
    s smile "Nos vemos por ahí… {i}Ángel{/i}."

# game/act1.rpy:1824
translate spanish act1_1ab72481_13:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1825
translate spanish act1_ab4a2c78:

    # a "{i}What a freak. Stupidly hot… but a freak nonetheless."
    a "{i}Qué bicho raro. Estúpidamente sexy… pero un bicho raro al fin y al cabo."

# game/act1.rpy:1827
translate spanish act1_c36be69c:

    # "I know exactly what he’s doing. Flirting with me, closing the distance between us (literally) to make me open up to him. I bet he just wants information out of me, too."
    "Sé perfectamente lo que está haciendo. Está coqueteando conmigo, acortando la distancia entre nosotros (literalmente) para que me abra a él. Apuesto a que él también solo quiere sacarme información."

# game/act1.rpy:1828
translate spanish act1_02ac015c:

    # "Sebas… Something is off about that man. So very, very off, and yet…"
    "Sebas… Hay algo raro en ese hombre. Algo muy, muy raro, y sin embargo…"

# game/act1.rpy:1829
translate spanish act1_c21a708e:

    # "I don’t think I’ll be able to resist him, even if I tried."
    "No creo que pueda resistirme a él, ni aunque lo intentara."

# game/act1.rpy:1831
translate spanish act1_6f3e5935:

    # a body2 hm2 "{i}…well, whatever. He did give me some pretty useful information… if it turns out to be true, that is."
    a body2 hm2 "{i}…bueno, da igual. Me dio información bastante útil… si resulta ser cierta, claro."

# game/act1.rpy:1832
translate spanish act1_6e53bf92:

    # "But nerves start to rattle me again. There’s no going back after this, no feigning ignorance; If I’m caught inside a hidden gambling ring, there’s no saving me from the consequences that may come."
    "Pero los nervios vuelven a apoderarse de mí. Después de esto, no hay vuelta atrás, no puedo fingir ignorancia; si me pillan dentro de una red de apuestas clandestinas, no habrá escapatoria a las consecuencias."

# game/act1.rpy:1833
translate spanish act1_66587f2e:

    # "My instincts tell me to just go home – play it safe, do as I’m told… but the anger and refusal that comes from thinking that way overpowers my fears."
    "Mis instintos me dicen que simplemente me vaya a casa, que no me quede de brazos cruzados, que haga lo que me dicen... pero la ira y la negativa que surgen de pensar así superan mis miedos."

# game/act1.rpy:1834
translate spanish act1_dccf32eb:

    # "I don’t want to be a pawn anymore."
    "Ya no quiero ser un peón."

# game/act1.rpy:1836
translate spanish act1_6b24d3e6:

    # a body frown "Excuse me…!"
    a body frown "Disculpe…!"

# game/act1.rpy:1838
translate spanish act1_9391ffbf:

    # "I call the bartender over, my heart pounding in my ears. He nonchalantly stands in front of me, a bored look on his face."
    "Llamo al camarero, con el corazón latiéndome con fuerza. Se para frente a mí con indiferencia y una expresión de aburrimiento en el rostro."

# game/act1.rpy:1840
translate spanish act1_1ab72481_14:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1841
translate spanish act1_af67d12a:

    # a "Gimmie a Death in the Gulf Stream."
    a "Dame una muerte en la Corriente del Golfo."

# game/act1.rpy:1843
translate spanish act1_60bc6f72:

    # "{i}Tap. Tap. Tap."
    "{i}Toca. Toca. Toca."

# game/act1.rpy:1845
translate spanish act1_c7fc7fd4:

    # ba "…"
    ba "…"

# game/act1.rpy:1847
translate spanish act1_82c5671c:

    # ba "We don’t have that in stock."
    ba "No lo tenemos en stock."

# game/act1.rpy:1849
translate spanish act1_7fefe483:

    # a surprised "O… Oh…"
    a surprised "Oh…"

# game/act1.rpy:1851
translate spanish act1_2fb8fd03:

    # "My ears burn as I look down, my face hot in raw embarrassment. Was I really played for a fool by Sebas? When I see that motherfucker again, I swear, I’ll-"
    "Me arden las orejas mientras miro hacia abajo, mi cara arde de pura vergüenza. ¿De verdad Sebas me tomó el pelo? Cuando vuelva a ver a ese cabrón, lo juro, le..."

# game/act1.rpy:1853
translate spanish act1_ace49fc3:

    # ba "But there’s some in the supply closet. In the bathroom."
    ba "Pero hay algunos en el armario de suministros. En el baño."

# game/act1.rpy:1855
translate spanish act1_09db9eaf:

    # a "Huh?"
    a "¿Eh?"

# game/act1.rpy:1857
translate spanish act1_0897c2f6:

    # "The bartender jerks his head towards the bathroom, that same bored look on his face."
    "El camarero hace un gesto brusco con la cabeza hacia el baño, con la misma expresión de aburrimiento en el rostro."

# game/act1.rpy:1859
translate spanish act1_603e722b:

    # ba "Check in there."
    ba "Regístrate allí."

# game/act1.rpy:1861
translate spanish act1_e49b2507:

    # ba "Now."
    ba "Ahora."

# game/act1.rpy:1862
translate spanish act1_1693a0f6:

    # a flustered "Eh? Uh! Right…! Thank you…?"
    a flustered "¿Eh? ¡Uh! ¡Cierto…! ¿Gracias…?"

# game/act1.rpy:1864
translate spanish act1_b9f3af82:

    # "I hop off my stool and hurry over to the bathroom, my head spinning in different directions as I open the door."
    "Salto del taburete y me dirijo rápidamente al baño, con la cabeza dando vueltas en diferentes direcciones mientras abro la puerta."

# game/act1.rpy:1868
translate spanish act1_ace22fb9:

    # a yeesh "Ugh…"
    a yeesh "Puaj…"

# game/act1.rpy:1870
translate spanish act1_4f71162a:

    # "It smells like piss and cigarettes. Do guys not aim for the urinal when they pee?"
    "Huele a orina y cigarrillos. ¿Es que los hombres no apuntan al urinario cuando orinan?"

# game/act1.rpy:1871
translate spanish act1_a375e90d:

    # "It’s quiet, other than the hum of a ventilation fan somewhere in the room. On the other end of the room is the supply closet door, and I slowly approach it, as if I’m some protagonist in those old horror movies Ethan loves so much."
    "Hay silencio, salvo por el zumbido de un ventilador en algún lugar de la habitación. Al otro extremo está la puerta del armario de suministros, y me acerco lentamente, como si fuera el protagonista de esas viejas películas de terror que tanto le gustan a Ethan."

# game/act1.rpy:1872
translate spanish act1_24260409:

    # "I place a sweaty paw on the handle, and taking a deep breath, I turn it-"
    "Coloco una pata sudorosa sobre el mango y, respirando hondo, lo giro."

# game/act1.rpy:1874
translate spanish act1_6bd7b91c:

    # "It’s locked."
    "Está cerrado con llave."

# game/act1.rpy:1876
translate spanish act1_2f86b996:

    # "I turn around, getting more agitated. What, is there a key? Or is everyone in the world pulling some elaborate prank on me?"
    "Me doy la vuelta, cada vez más agitado. ¿Qué? ¿Hay una llave? ¿O es que todo el mundo me está gastando una broma pesada?"

# game/act1.rpy:1877
translate spanish act1_0c1e0bfb:

    # "This is getting so-!"
    "¡Esto se está poniendo tan...!"

# game/act1.rpy:1882
translate spanish act1_bde5f0ad:

    # "The door suddenly swings open behind me, and before I have time to react, a pair of large hands grab onto me and pull me to the other side."
    "La puerta se abre de golpe detrás de mí y, antes de que pueda reaccionar, un par de manos grandes me agarran y me arrastran al otro lado."

# game/act1.rpy:1884
translate spanish act1_1158132d:

    # "I’m thrown onto the ground, disoriented by the sudden change of lighting, and when I open my eyes…"
    "Me arrojan al suelo, desorientado por el repentino cambio de iluminación, y cuando abro los ojos…"

# game/act1.rpy:1886
translate spanish act1_6d416a7a:

    # "I see someplace that doesn’t look like a gambling ring to me."
    "Veo un lugar que no me parece una casa de apuestas clandestina."

# game/act1.rpy:1887
translate spanish act1_b39d87c7:

    # "I expected a rundown, rustic place that would mirror the bar outside. The room I’m in now looks sleek, modern, brand new, even. It’s…{w} kind of beautiful."
    "Esperaba un lugar destartalado y rústico que reflejara el bar de afuera. La habitación en la que estoy ahora se ve elegante, moderna, incluso nueva. Es... bastante bonita."

# game/act1.rpy:1889
translate spanish act1_3fac4603:

    # "But I don’t have much time to admire my surroundings. Someone that seems almost twice my size steps in front of me, and I look up to see what I can only assume to be a pro wrestler with how well built they are."
    "Pero no tengo mucho tiempo para admirar mi entorno. Alguien que parece casi el doble de mi tamaño se para frente a mí, y levanto la vista para ver lo que solo puedo suponer que es un luchador profesional por su musculatura."

# game/act1.rpy:1890
translate spanish act1_3fc8f2dd:

    # "He sneers down at me, obviously trying to intimidate me. I steel my nerves, doing my best to not let it show in my face that he’s unfortunately doing a good job of it."
    "Me mira con desprecio, intentando intimidarme claramente. Me armo de valor, haciendo todo lo posible por no dejar ver en mi rostro que, lamentablemente, lo está consiguiendo."

# game/act1.rpy:1892
translate spanish act1_699cc9e1:

    # guard "Well, lookie what we caught here…"
    guard "Bueno, miren lo que hemos encontrado aquí…"

# game/act1.rpy:1894
translate spanish act1_e78a19c6:

    # "Someone else steps into my view, a woman this time, but surprisingly, she looks just as strong as the alligator."
    "Otra persona aparece en mi campo de visión, esta vez una mujer, pero sorprendentemente, parece tan fuerte como el caimán."

# game/act1.rpy:1896
translate spanish act1_35df2c99:

    # guard2 "A Valentine? What’s he doing here?"
    guard2 "¿Un San Valentín? ¿Qué hace él aquí?"

# game/act1.rpy:1897
translate spanish act1_30b32e56:

    # guard "Maybe he’s gone rogue. Or he’s just plain ol’ stupid."
    guard "Tal vez se haya descontrolado. O simplemente sea un completo idiota."

# game/act1.rpy:1899
translate spanish act1_646c681a:

    # "I frown at him, and that makes his grin grow wider."
    "Lo miro con el ceño fruncido, y eso hace que su sonrisa se amplíe aún más."

# game/act1.rpy:1901
translate spanish act1_5001f9aa:

    # guard "Or…"
    guard "O…"

# game/act1.rpy:1903
translate spanish act1_9d79b084:

    # "He kneels down and grabs me by the arm again, lifting me to my knees with a grip so tight, I’m scared it’ll bruise."
    "Se arrodilla y me agarra del brazo otra vez, levantándome hasta ponerme de rodillas con una fuerza tan grande que temo que me salga un moretón."

# game/act1.rpy:1905
translate spanish act1_f3320fb7:

    # a nngh "H-hey! Let me go!"
    a nngh "¡Eh! ¡Suéltame!"

# game/act1.rpy:1907
translate spanish act1_8fddf079:

    # guard "Or maybe, he’s sticking his little nose where it doesn’t belong."
    guard "O tal vez, está metiendo sus narices donde no le incumbe."

# game/act1.rpy:1908
translate spanish act1_07ceb950_1:

    # a scared "…!"
    a scared "…!"

# game/act1.rpy:1909
translate spanish act1_88bfd07e:

    # anon "Come on now, Darwin… is that really any way to treat a guest?"
    anon "Vamos, Darwin... ¿De verdad es esa la manera de tratar a un invitado?"

# game/act1.rpy:1911
translate spanish act1_fd780de8:

    # "’Darwin’ and I both turn our heads to look up at my savior, and my eyes widen the moment I see who it is."
    "'Darwin' y yo giramos la cabeza para mirar a mi salvador, y mis ojos se abren de par en par en el momento en que veo quién es."

# game/act1.rpy:1914
translate spanish act1_4df5c473:

    # "Matteo Milan... superstar actor and Sonora's golden boy."
    "Matteo Milan... actor superestrella y el niño prodigio de Sonora."

# game/act1.rpy:1915
translate spanish act1_907d36bf:

    # "He's a celebrity in every sense of the word. Movies, TV shows, magazines... hell, I think he has his own fragrance line."
    "Es una celebridad en todo el sentido de la palabra. Películas, programas de televisión, revistas... ¡diablos!, creo que hasta tiene su propia línea de perfumes."

# game/act1.rpy:1916
translate spanish act1_d2a05db2:

    # "From what I can remember, his father owns one of the largest banks in the country, and even his mother is in the entertainment industry...{w}so basically, he's a nepo baby."
    "Por lo que recuerdo, su padre es dueño de uno de los bancos más grandes del país, e incluso su madre está en la industria del entretenimiento...{w}así que básicamente, es un niño mimado por el nepotismo."

# game/act1.rpy:1917
translate spanish act1_87cec0ec:

    # "But I've seen some of his movies, and even I have to admit, he is quite talented. So..."
    "Pero he visto algunas de sus películas, e incluso yo tengo que admitir que tiene bastante talento. Así que..."

# game/act1.rpy:1918
translate spanish act1_16702a35:

    # "What the hell is he doing in a gambling ring on the shittiest side of Sonora?"
    "¿Qué demonios hace en una red de apuestas ilegales en la zona más sórdida de Sonora?"

# game/act1.rpy:1920
translate spanish act1_151ea6c9:

    # m cocky "But I’ll admit, a Valentine does me make even me feel a bit uneasy."
    m cocky "Pero admito que un San Valentín me hace sentir un poco incómodo incluso a mí."

# game/act1.rpy:1922
translate spanish act1_247ff2b5:

    # "He kneels down to look at me, with piercing mismatched colored eyes that make me wonder if they’re even real. I can smell his cologne from how close he is, and I silently wonder if it's his own brand."
    "Se arrodilla para mirarme, con unos ojos penetrantes de colores dispares que me hacen dudar de su autenticidad. Puedo oler su colonia por lo cerca que está, y me pregunto en silencio si será de su propia marca."

# game/act1.rpy:1924
translate spanish act1_f5ac109a:

    # m serious "Why don’t you tell me why you’re really here?"
    m serious "¿Por qué no me dices por qué estás aquí realmente?"

# game/act1.rpy:1925
translate spanish act1_2a4ff97c_11:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:1927
translate spanish act1_bcd77f52:

    # a frown "Why does anyone come down here?"
    a frown "¿Por qué viene alguien aquí?"

# game/act1.rpy:1928
translate spanish act1_65b68bfb:

    # a angry "…I’m here to gamble."
    a angry "…Estoy aquí para apostar."

# game/act1.rpy:1931
translate spanish act1_c639e33d:

    # "Matteo smiles;{w} I answered correctly, it seems."
    "Matteo sonríe;{w} Parece que respondí correctamente."

# game/act1.rpy:1933
translate spanish act1_56549518:

    # m sweet "I bet you are."
    m sweet "Apuesto a que sí."

# game/act1.rpy:1935
translate spanish act1_91ff5b12:

    # "He stands up, addressing Darwin now."
    "Se pone de pie y se dirige ahora a Darwin."

# game/act1.rpy:1937
translate spanish act1_ffd30e6b:

    # m serious "Let him go."
    m serious "Déjalo ir."

# game/act1.rpy:1939
translate spanish act1_3c6eff57:

    # "Darwin hesitates for a moment, then does as he’s told with a grunt. I guess even the strongest yield to the richest."
    "Darwin duda un instante, luego obedece con un gruñido. Supongo que incluso los más fuertes ceden ante los más ricos."

# game/act1.rpy:1940
translate spanish act1_8c93a97a:

    # "Matteo waves a hand at both of his guards, and they wordlessly slip away, manning the door and looking inside with stoic expressions. He offers me his paw, and after a beat, I take it, letting him pull me to my feet."
    "Matteo hace un gesto con la mano a sus dos guardias, quienes se escabullen sin decir palabra, quedándose en la puerta y mirando hacia adentro con expresiones impávidas. Me ofrece su pata y, tras un instante, la tomo, dejando que me ayude a ponerme de pie."

# game/act1.rpy:1942
translate spanish act1_bfca4648:

    # m apologetic "Sorry about that. We can never be too careful down here, and you’re not exactly a friendly face."
    m apologetic "Lo siento. Nunca está de más ser precavidos aquí abajo, y usted no es precisamente una cara amigable."

# game/act1.rpy:1944
translate spanish act1_b1878180:

    # "There’s an odd kindness to him, a smile on his face that I can’t quite tell if it’s fake or not. For the sake of my own safety, I’ll assume the worst... but even I have to admit, I'm a little starstruck."
    "Tiene una amabilidad peculiar, una sonrisa que no logro descifrar si es sincera o fingida. Por mi propia seguridad, prefiero pensar lo peor... pero incluso yo debo admitir que estoy un poco impresionada."

# game/act1.rpy:1945
translate spanish act1_715ac276:

    # "I'm not exactly a 'fan', but to see a celebrity so up close and looking right at me... it does things to my heart that I can't quite control. It helps he's very easy on the eyes, too."
    "No soy precisamente una fan, pero ver a una celebridad tan de cerca y mirándome fijamente... me emociona muchísimo. Además, es muy guapo."

# game/act1.rpy:1947
translate spanish act1_651b1d7c:

    # a bashful "I-It’s fine. I guess I can’t blame you for that."
    a bashful "E-Está bien. Supongo que no puedo culparte por eso."

# game/act1.rpy:1948
translate spanish act1_d044ace3:

    # m sweet "I’m glad we’re on the same page, then."
    m sweet "Me alegra que estemos de acuerdo, entonces."

# game/act1.rpy:1949
translate spanish act1_8d551c42:

    # m stan "I’m Matteo. Welcome to my little… establishment."
    m stan "Soy Matteo. Bienvenidos a mi pequeño… establecimiento."

# game/act1.rpy:1951
translate spanish act1_1c27d2cd:

    # a flattered "I know who you are..."
    a flattered "Sé quién eres..."

# game/act1.rpy:1952
translate spanish act1_18eae385:

    # m "Oh? I'm surprised a Valentine knows about pop culture."
    m "¿Ah, sí? Me sorprende que alguien llamado Valentine sepa de cultura pop."

# game/act1.rpy:1954
translate spanish act1_0866ac8b:

    # a bashful "Kind of hard to miss when your face is on billboards."
    a bashful "Es difícil no ver tu cara en las vallas publicitarias."

# game/act1.rpy:1955
translate spanish act1_6926f79c:

    # m apologetic "Well, you have a point there."
    m apologetic "Bueno, tienes razón."

# game/act1.rpy:1956
translate spanish act1_668a4abf:

    # m stan "Is this your first time gambling?"
    m stan "¿Es la primera vez que juegas?"

# game/act1.rpy:1958
translate spanish act1_0665e59c:

    # "Saying ‘yes’ might make me look too naïve… but saying ‘no’ means I won’t get any explanations about how to play."
    "Decir \"sí\" podría hacerme parecer demasiado ingenuo... pero decir \"no\" significa que no recibiré ninguna explicación sobre cómo jugar."

# game/act1.rpy:1959
translate spanish act1_96d8ef11:

    # "Well, whatever. I’d rather know the rules of whatever game we play in exchange for looking like I’m a dumb amateur."
    "Bueno, da igual. Prefiero saber las reglas del juego al que juguemos a parecer un aficionado ignorante."

# game/act1.rpy:1961
translate spanish act1_f2548162:

    # a flattered "Yeah, it is. Would you mind walking me through it?"
    a flattered "Sí, lo es. ¿Me lo explicarías paso a paso?"

# game/act1.rpy:1962
translate spanish act1_188012cf:

    # m sweet "It’d be an honor."
    m sweet "Sería un honor."

# game/act1.rpy:1963
translate spanish act1_f1a5bcfd:

    # m cocky "What’s your pleasure? Cards? Slots? Roulette?"
    m cocky "¿Qué prefieres? ¿Cartas? ¿Tragamonedas? ¿Ruleta?"

# game/act1.rpy:1965
translate spanish act1_9c88fa3a:

    # "I definitely don’t want to play a game that leaves {i}everything{/i} up to luck. I need to have some kind of control."
    "Definitivamente no quiero jugar un juego que deje {i}todo{/i} al azar. Necesito tener algún tipo de control."

# game/act1.rpy:1967
translate spanish act1_35fdbc41:

    # a surprised "Do you guys have poker?"
    a surprised "¿Tenéis póker?"

# game/act1.rpy:1968
translate spanish act1_25729f79:

    # m cocky "Do we have poker? Do kitchens have forks?"
    m cocky "¿Tenemos póker? ¿Hay tenedores en las cocinas?"

# game/act1.rpy:1969
translate spanish act1_980d7afc:

    # a bashful "Right. Stupid question."
    a bashful "Correcto. Pregunta estúpida."

# game/act1.rpy:1971
translate spanish act1_7f0defe2:

    # "He leads me towards a table, and to my surprise, sits directly in front of me. Someone who doesn’t seem to be a guard approaches us, standing to our left."
    "Me conduce hacia una mesa y, para mi sorpresa, se sienta justo enfrente de mí. Alguien que no parece ser un guardia se acerca a nosotros y se coloca a nuestra izquierda."

# game/act1.rpy:1973
translate spanish act1_b9d29f39:

    # a hm "What’s this?"
    a hm "¿Qué es esto?"

# game/act1.rpy:1974
translate spanish act1_f69b9377:

    # m sweet "We have a different style of poker around here. Our own little creation, to make us stand out. You’ll actually be playing against me."
    m sweet "Aquí tenemos un estilo de póker diferente. Es nuestra propia creación, para que destaquemos. De hecho, jugarás contra mí."

# game/act1.rpy:1976
translate spanish act1_5fc2ecf6:

    # a "What? You guys don’t have the regular kind?"
    a "¿Qué? ¿Ustedes no tienen el tipo normal?"

# game/act1.rpy:1977
translate spanish act1_edd0ffb3:

    # m cocky "If you wanted to play regular poker, you should’ve gone to a casino, Valentine."
    m cocky "Si querías jugar al póker de verdad, deberías haber ido a un casino, Valentine."

# game/act1.rpy:1978
translate spanish act1_1ab72481_15:

    # a concern "…"
    a concern "…"

# game/act1.rpy:1979
translate spanish act1_0ce4550e:

    # m sweet "I’ll simply be acting as the house for this game. If you don’t like it, you’re welcome to walk out at any time."
    m sweet "Simplemente seré el anfitrión de este juego. Si no te gusta, puedes irte cuando quieras."

# game/act1.rpy:1982
translate spanish act1_16469495:

    # a eyeroll "{i}Ugh. Talk about avant-garde bullshit."
    a eyeroll "{i}Uf. Hablando de tonterías vanguardistas."

# game/act1.rpy:1983
translate spanish act1_18847f8f:

    # a hm "Fine. I’ll play. What’re the rules?"
    a hm "De acuerdo. Jugaré. ¿Cuáles son las reglas?"

# game/act1.rpy:1985
translate spanish act1_ec383832:

    # m sweet "The rules are simple."
    m sweet "Las reglas son sencillas."

# game/act1.rpy:1991
translate spanish act1_cb3bab6b:

    # m "We'll be using a standard 52 deck of cards, plus both joker cards, for a total of 54."
    m "Utilizaremos una baraja estándar de 52 cartas, más los dos comodines, para un total de 54 cartas."

# game/act1.rpy:1993
translate spanish act1_2ea0f800:

    # m "The deck gets split in two, and our dealer places both halves on either side of our card shuffler here."
    m "La baraja se divide en dos, y nuestro repartidor coloca ambas mitades a cada lado de nuestra máquina barajadora."

# game/act1.rpy:1996
translate spanish act1_cd065e9a:

    # m "Then, we both get 4 cards each, instead of the standard 5. No exchanges can be made once the cards are dealt."
    m "Luego, ambos recibimos 4 cartas cada uno, en lugar de las 5 habituales. No se pueden realizar cambios una vez repartidas las cartas."

# game/act1.rpy:1997
translate spanish act1_30952b57:

    # m "The hands are all the same, minus one card, so there's a greater chance you'll get a good hand. However..."
    m "Todas las manos son iguales, excepto por una carta, así que hay más posibilidades de que te toque una buena mano. Sin embargo..."

# game/act1.rpy:1998
translate spanish act1_30bd91f0:

    # m "That's where the jokers come in."
    m "Ahí es donde entran los bromistas."

# game/act1.rpy:2002
translate spanish act1_12e71a12:

    # m "The gray joker card is also a 'wild card', but not in the same way. Instead, a random card will be drawn from the deck, and that'll be your joker's value."
    m "El comodín gris también funciona como talón, pero no de la misma manera. En este caso, se extrae una carta al azar de la baraja, y ese será el valor del comodín."

# game/act1.rpy:2003
translate spanish act1_20b201b0:

    # m "It leaves your hand up to fate. You might not want this card, Valentine."
    m "Te deja en manos del destino. Puede que no quieras esta tarjeta, San Valentín."

# game/act1.rpy:2006
translate spanish act1_f0fccda4:

    # m "The colored joker is the good one. It's a wild card, and can be used to make any hand a little better. It'll represent any suit or rank once we move on to the showdown phase."
    m "El comodín de color es el bueno. Es una carta comodín y puede usarse para mejorar cualquier mano. Representará cualquier palo o rango una vez que pasemos a la fase de enfrentamiento."

# game/act1.rpy:2007
translate spanish act1_1575ab1a:

    # m "So, a three of a kind can become a four of a kind. That can be the difference between a win and a loss... so you're gonna want this joker."
    m "Así que, un trío puede convertirse en un póker. Eso puede marcar la diferencia entre ganar y perder... así que vas a querer este comodín."

# game/act1.rpy:2016
translate spanish act1_ee7a4570:

    # m "We each pay a blind to start the game, one small and one big. Since you're new, I'll start off with the big blind and let you play first. So, if you fold, you lose the least amount."
    m "Cada uno paga una ciega para empezar la partida, una pequeña y una grande. Como eres nuevo, yo empezaré con la ciega grande y te dejaré jugar primero. Así, si te retiras, perderás lo mínimo."

# game/act1.rpy:2017
translate spanish act1_f4aecb5c:

    # m stan "Considering this is your first time gambling... let's start with 15 chips. Small blind is one, big blind, two."
    m stan "Considerando que es la primera vez que juegas... comencemos con 15 fichas. La ciega pequeña es uno, la ciega grande, dos."

# game/act1.rpy:2018
translate spanish act1_67860d75:

    # a hm "How much is each chip worth?"
    a hm "¿Cuánto vale cada ficha?"

# game/act1.rpy:2019
translate spanish act1_6f6984ee:

    # m sweet "Let's not worry about that right now. This'll be a practice round. If you win, you keep whatever you make. If you lose, I won't charge you a penny. If you like the game, we'll keep playing."
    m sweet "No nos preocupemos por eso ahora. Esta será una ronda de práctica. Si ganas, te quedas con lo que ganes. Si pierdes, no te cobraré nada. Si te gusta el juego, seguiremos jugando."

# game/act1.rpy:2020
translate spanish act1_2b93c220:

    # m stan "How's that sound?"
    m stan "¿Qué te parece?"

# game/act1.rpy:2021
translate spanish act1_5cd59426:

    # a frown "..."
    a frown "..."

# game/act1.rpy:2023
translate spanish act1_aaa409c0:

    # "It doesn't sound {i}too{/i} bad, I guess. Although I may not know much about gambling, this game doesn't seem too unfair to me. A little more 'luck-of-the-draw' than I was hoping for, but I can make it work."
    "No suena tan mal, supongo. Aunque no sé mucho de apuestas, este juego no me parece demasiado injusto. Depende un poco más de la suerte de lo que esperaba, pero puedo sacarle provecho."

# game/act1.rpy:2024
translate spanish act1_857a5814:

    # "I have to make it work."
    "Tengo que hacer que funcione."

# game/act1.rpy:2026
translate spanish act1_97e19bc4:

    # a stan "Sounds good to me."
    a stan "Me parece bien."

# game/act1.rpy:2029
translate spanish act1_59b5234d:

    # m sweet "Perfect. Let's start then, shall we?"
    m sweet "Perfecto. Empecemos entonces, ¿de acuerdo?"

# game/act1.rpy:2033
translate spanish act1_e375a5a9:

    # "My heart is pounding in my ears as I watch our dealer, a tall, quiet capybara, rips open a fresh pack of cards and splits the deck in half, slipping them into the machine as if he's done it a million times before."
    "El corazón me late con fuerza en los oídos mientras observo a nuestro crupier, un capibara alto y silencioso, abrir una baraja nueva y partirla por la mitad, introduciéndolas en la máquina como si lo hubiera hecho un millón de veces antes."

# game/act1.rpy:2035
translate spanish act1_48a1db47:

    # "Matteo smiles warmly at me, as if sensing my nerves, but I don't return it. Any sign of weakness, and he'll latch onto it until it becomes the death of me. I won't let him do that."
    "Matteo me sonríe cálidamente, como si percibiera mi nerviosismo, pero no le devuelvo la sonrisa. Cualquier señal de debilidad, y se aferrará a ella hasta destruirme. No lo permitiré."

# game/act1.rpy:2037
translate spanish act1_d825fb98:

    # "Four cards are passed out to each of us, as well as three stacks of five chips. Matteo grabs two and throws them into the middle with a satisfying clinking sound, and he looks at me, quietly telling me to do the same."
    "Nos reparten cuatro cartas a cada uno, además de tres pilas de cinco fichas. Matteo toma dos y las lanza al centro con un satisfactorio tintineo, y me mira, indicándome en voz baja que haga lo mismo."

# game/act1.rpy:2038
translate spanish act1_92c9aeef:

    # "I grab one from my stack and slide it into our pile, hoping he doesn’t see just how shaky my hands are."
    "Tomo uno de mi pila y lo deslizo hacia nuestro montón, esperando que no vea lo temblorosas que están mis manos."

# game/act1.rpy:2040
translate spanish act1_a5fcf8a5:

    # a flustered "{i}Am I really doing this? Think about how much trouble I could get myself into if I get found out. I could spend the rest of my life as a Valentine, or worse… in prison."
    a flustered "¿De verdad estoy haciendo esto? Piensa en todos los problemas en los que podría meterme si me descubren. Podría pasar el resto de mi vida como un enamorado, o peor aún… en la cárcel."

# game/act1.rpy:2041
translate spanish act1_e38efd9d:

    # a sad "{i}But… is my situation right now… really any better?"
    a sad "{i}Pero… ¿mi situación actual… es realmente mejor?"

# game/act1.rpy:2044
translate spanish act1_46909a98:

    # "Mr. Grey’s voice echoes in the back of my mind."
    "La voz del señor Grey resuena en mi mente."

# game/act1.rpy:2045
translate spanish act1_2dc7abb5:

    # l "{i}If my calculations are correct - and rest assured, they are - you’ve paid off less than ten percent of your total debt. Have you done the math, love? It’ll take more than forty years for your debt to be finalized."
    l "{i}Si mis cálculos son correctos —y ten por seguro que lo son— has pagado menos del diez por ciento de tu deuda total. ¿Has hecho los cálculos, cariño? Tardarás más de cuarenta años en saldar tu deuda."

# game/act1.rpy:2046
translate spanish act1_72e94c19_4:

    # a "…"
    a "…"

# game/act1.rpy:2047
translate spanish act1_99170d3a:

    # a "{i}That’s basically my entire life. At this rate, whether I do something bad or not doesn’t really matter anymore."
    a "{i}Esa es básicamente toda mi vida. A este paso, si hago algo malo o no, ya no importa realmente."

# game/act1.rpy:2048
translate spanish act1_3aa2ecb4:

    # a frown "{i}Because…"
    a frown "{i}Porque…"

# game/act1.rpy:2049
translate spanish act1_6e05d908:

    # a angry "{i}I want to start living... {w}right now!"
    a angry "{i}Quiero empezar a vivir... {w}¡ahora mismo!"

# game/act1.rpy:2051
translate spanish act1_b425ce55:

    # "I grab my cards and look at them, Matteo following suit.{w} The game has begun."
    "Tomo mis cartas y las miro, Matteo hace lo mismo.{w} El juego ha comenzado."

# game/act1.rpy:2053
translate spanish act1_9f6e9266:

    # "A pair of sixes, a four and a jack. No joker."
    "Un par de seises, un cuatro y una jota. Sin comodín."

# game/act1.rpy:2054
translate spanish act1_cf25c946:

    # a hm "{i}This… is a pretty shitty hand."
    a hm "{i}Esta… es una mano bastante mala."

# game/act1.rpy:2055
translate spanish act1_76b664b0:

    # a frown "{i}But the odds of Matteo having an equally shitty hand is pretty high, too. Considering we can’t even change our hands, the most we can hope for is pairs, or straights if we’re lucky enough."
    a frown "{i}Pero las probabilidades de que Matteo tenga una mano igual de mala también son bastante altas. Teniendo en cuenta que ni siquiera podemos cambiar nuestras manos, lo máximo que podemos esperar son parejas, o escaleras si tenemos suerte."

# game/act1.rpy:2056
translate spanish act1_7ec3e551:

    # a yeesh "{i}That’s where the joker would come into play… if I HAD one. Anyways…"
    a yeesh "Ahí es donde entraría en juego el comodín… si tuviera uno. En fin…"

# game/act1.rpy:2057
translate spanish act1_01d54544:

    # a hm "{i}Seems like I should fold. The only way I’d win is if he has a total pig."
    a hm "{i}Parece que debería retirarme. La única forma en que ganaría es si él tiene un cerdo total."

# game/act1.rpy:2059
translate spanish act1_2c043118:

    # "Matteo looks up at me, a coy smile on his face. That’s right… a big part of poker is bluffing, isn’t it? As long as your opponent {i}thinks{/i} you have a good hand, then you can win, even with a pig."
    "Matteo me mira con una sonrisa pícara. Así es… gran parte del póker es farolear, ¿no? Mientras tu oponente piense que tienes una buena mano, puedes ganar, incluso con una mala."

# game/act1.rpy:2061
translate spanish act1_4c4a65af:

    # "But it’s a risk… if they match you, you can lose, big time."
    "Pero es un riesgo… si te igualan, puedes perder mucho."

# game/act1.rpy:2062
translate spanish act1_92db9dda:

    # "I guess that’s the whole point of gambling, in the end…"
    "Supongo que, al fin y al cabo, ese es el objetivo de los juegos de azar…"

# game/act1.rpy:2064
translate spanish act1_8ef2c679_3:

    # a frown "…"
    a frown "…"

# game/act1.rpy:2065
translate spanish act1_89a9ae70:

    # a "{i}I’m done with taking the safe route. If I can’t take a risk on a practice game of poker, with nothing to lose… then I’m not cut out to be in Sonora."
    a "{i}Ya no quiero ir a lo seguro. Si no puedo arriesgarme en una partida de póker de práctica, sin nada que perder… entonces no sirvo para estar en Sonora."

# game/act1.rpy:2066
translate spanish act1_08b7e6a5:

    # a angry "{i}’The risk makes the man’, huh, Mr. Grey? I’ll show you…"
    a angry "«El riesgo hace al hombre», ¿eh, señor Grey? Te lo demostraré…"

# game/act1.rpy:2068
translate spanish act1_c3dbae8d:

    # "Our dealer places one card from the deck face down, then spreads his hands palms-up to us. I guess that means the betting phase starts now."
    "Nuestro crupier coloca una carta boca abajo de la baraja y luego extiende las palmas de las manos hacia nosotros. Supongo que eso significa que la fase de apuestas comienza ahora."

# game/act1.rpy:2070
translate spanish act1_48f75b7c:

    # m cocky "Your move, Valentine."
    m cocky "Ahora te toca a ti, San Valentín."

# game/act1.rpy:2071
translate spanish act1_8ef2c679_4:

    # a frown "…"
    a frown "…"

# game/act1.rpy:2074
translate spanish act1_5cb9c09a:

    # "I place two chips in the center of our pile, putting up a confident front."
    "Coloco dos fichas en el centro de nuestra pila, mostrando una actitud segura."

# game/act1.rpy:2076
translate spanish act1_c7236708:

    # a stan "Two chips."
    a stan "Dos patatas fritas."

# game/act1.rpy:2078
translate spanish act1_b00bdf74:

    # m amused "Ballsy. I like it."
    m amused "Audaz. Me gusta."

# game/act1.rpy:2079
translate spanish act1_549c91ec:

    # m wink "Then, I’ll raise you by one chip."
    m wink "Entonces, te subo la apuesta con una ficha."

# game/act1.rpy:2081
translate spanish act1_e53fb254:

    # "He throws in three chips of his own, smiling that same kind smile. My eye twitches."
    "Él añade tres fichas, con esa misma sonrisa amable. Me tiembla un ojo."

# game/act1.rpy:2082
translate spanish act1_2098eda2:

    # "So he has a good hand? Is that it? Or is he bluffing? God, I can’t tell at all…"
    "¿Entonces tiene una buena mano? ¿Es eso? ¿O está mintiendo? Dios, no lo sé..."

# game/act1.rpy:2084
translate spanish act1_6af51e81:

    # a frown "{i}Fuck it. It’s a practice round. I can afford to lose a chip or two."
    a frown "{i}Que le den. Es una ronda de práctica. Puedo permitirme perder una o dos fichas."

# game/act1.rpy:2085
translate spanish act1_2bee9c6b:

    # a surprised "I’ll match your bet."
    a surprised "Igualaré tu apuesta."

# game/act1.rpy:2086
translate spanish act1_acf7debb:

    # m cocky "We call that a ‘call’, Valentine."
    m cocky "A eso le llamamos una \"llamada\", Valentine."

# game/act1.rpy:2088
translate spanish act1_b31acd52:

    # a flustered "Uh- r-right… I call."
    a flustered "Eh, s-sí… yo llamo."

# game/act1.rpy:2090
translate spanish act1_95a3bd26:

    # "I slide another chip to the center pile, making 6 chips in total."
    "Deslizo otra ficha al montón central, con lo que tengo 6 fichas en total."

# game/act1.rpy:2092
translate spanish act1_bbcc30c9:

    # dealer "You may now reveal your cards."
    dealer "Ahora puedes revelar tus cartas."

# game/act1.rpy:2093
translate spanish act1_65d756d7:

    # m sweet "You wanna do the honors?"
    m sweet "¿Quieres hacer los honores?"

# game/act1.rpy:2094
translate spanish act1_1ab72481_16:

    # a concern "…"
    a concern "…"

# game/act1.rpy:2096
translate spanish act1_6da85dc9:

    # "With a pounding heart, I flip my cards on the table, showing them off."
    "Con el corazón latiéndome con fuerza, volteo mis cartas sobre la mesa, mostrándolas."

# game/act1.rpy:2098
translate spanish act1_be052b6f:

    # a surprised "A pair of sixes."
    a surprised "Un par de seises."

# game/act1.rpy:2100
translate spanish act1_eba4e660:

    # m apologetic "Agh, darn."
    m apologetic "¡Ay, maldita sea!"

# game/act1.rpy:2102
translate spanish act1_ecec95ad:

    # "Matteo flips his, showing…"
    "Matteo le da la vuelta, mostrando…"

# game/act1.rpy:2104
translate spanish act1_7550c10c:

    # m "Queen high-card. A pig."
    m "Reina carta alta. Un cerdo."

# game/act1.rpy:2105
translate spanish act1_72e94c19_5:

    # a "…"
    a "…"

# game/act1.rpy:2106
translate spanish act1_1539fbdb:

    # m wink "Congrats, Valentine. You won~"
    m wink "¡Felicidades, Valentine! ¡Ganaste~!"

# game/act1.rpy:2107
translate spanish act1_4c4ae253:

    # a "I…"
    a "I…"

# game/act1.rpy:2109
translate spanish act1_856c7772:

    # a blush "{i}I did?"
    a blush "{i}¿Lo hice?"

# game/act1.rpy:2110
translate spanish act1_3670dea4:

    # a excited "{i}H-Hah! I did! I won!!!"
    a excited "{i}¡J-J! ¡Lo hice! ¡Gané!"

# game/act1.rpy:2112
translate spanish act1_c65cb4ea:

    # "It’s impossible to hide my happiness, a giddy smile starting to creep into my face as my shaky hands fold together. I did it… I really did it!"
    "Es imposible ocultar mi felicidad, una sonrisa nerviosa empieza a asomar en mi rostro mientras mis manos temblorosas se juntan. ¡Lo logré… de verdad lo logré!"

# game/act1.rpy:2114
translate spanish act1_7f93398e:

    # "That wasn’t so bad…! Scary, sure, but it was almost… fun…"
    "¡No estuvo tan mal…! Daba miedo, sí, pero casi… era divertido…"

# game/act1.rpy:2115
translate spanish act1_7800fb0f_1:

    # a flattered "…"
    a flattered "…"

# game/act1.rpy:2116
translate spanish act1_297a7038:

    # m amused "So… did ya like it?"
    m amused "Entonces… ¿te gustó?"

# game/act1.rpy:2117
translate spanish act1_d27f371a:

    # m cocky "Would you… like to keep playing?"
    m cocky "¿Te gustaría seguir jugando?"

# game/act1.rpy:2120
translate spanish act1_44577c64:

    # a confident "Let’s do it."
    a confident "Vamos a hacerlo."

# game/act1.rpy:2121
translate spanish act1_f05f65d0:

    # m "…"
    m "…"

# game/act1.rpy:2122
translate spanish act1_27205c47:

    # m amused "I knew you’d say that."
    m amused "Sabía que ibas a decir eso."

# game/act1.rpy:2124
translate spanish act1_22090c1d:

    # "The dealer starts shuffling the deck again, and I look over to Matteo."
    "El crupier comienza a barajar la baraja de nuevo, y miro hacia Matteo."

# game/act1.rpy:2126
translate spanish act1_bd707d0d:

    # a hm "Wait. How much will the chips be worth now?"
    a hm "Espera. ¿Cuánto valdrán ahora las patatas fritas?"

# game/act1.rpy:2127
translate spanish act1_0ef1d36e:

    # m sweet "Hm? Oh, that. Well… let’s say, for this round… 50 dollars each. That sound good to you?"
    m sweet "¿Eh? Ah, eso. Bueno… digamos, para esta ronda… 50 dólares cada uno. ¿Te parece bien?"

# game/act1.rpy:2130
translate spanish act1_6b0e3f4b:

    # "I bite my lip. 50 dollars is pretty generous, but even that much is a lot for me. That’s almost a week’s worth of food, if I stretch it right. Throwing that away in a gamble would be…"
    "Me muerdo el labio. 50 dólares es bastante generoso, pero incluso eso es mucho para mí. Es casi comida para una semana, si lo estiro bien. Tirarlo a la basura en una apuesta sería…"

# game/act1.rpy:2132
translate spanish act1_4e94752d:

    # "I shake my head. No, I can’t chicken out, not now that I’ve already gone all the way! Besides, I’ll make it back twofold if I win this one."
    "Niego con la cabeza. No, no puedo acobardarme, ¡no ahora que ya he llegado hasta el final! Además, recuperaré el doble si gano esta."

# game/act1.rpy:2134
translate spanish act1_4ab8bbcc:

    # a bashful "Sounds good then."
    a bashful "Me parece bien entonces."

# game/act1.rpy:2135
translate spanish act1_13e87235:

    # m sweet "Perfect."
    m sweet "Perfecto."

# game/act1.rpy:2146
translate spanish act1_229e7d38:

    # a confident "A pair of nines."
    a confident "Un par de nueves."

# game/act1.rpy:2147
translate spanish act1_2a4937fd:

    # m apologetic "Another pig on my end. Damn. You’re gonna run me out of business, Valentine."
    m apologetic "Otro cerdo en mi lado. Maldita sea. Vas a arruinarme, Valentine."

# game/act1.rpy:2148
translate spanish act1_0c51c9e3:

    # a silly "I guess I’m a natural~"
    a silly "Supongo que tengo talento natural~"

# game/act1.rpy:2150
translate spanish act1_4711d7e7:

    # a blush "{i}Another win… this is exhilarating!"
    a blush "{i}¡Otra victoria… esto es emocionante!"

# game/act1.rpy:2151
translate spanish act1_af1e0449:

    # a bashful "{i}I shouldn’t get carried away… but, still…! I’m doing so well! I made 250 bucks from this game alone! If I could stay on a winning streak…"
    a bashful "{i}No debería emocionarme demasiado… ¡pero aun así…! ¡Me está yendo tan bien! ¡He ganado 250 dólares solo con este juego! Si pudiera mantener esta racha ganadora…"

# game/act1.rpy:2152
translate spanish act1_ca1ca69c:

    # a blush "{i}My debt could be paid off sooner than I thought!"
    a blush "{i}¡Mi deuda podría saldarse antes de lo que pensaba!"

# game/act1.rpy:2153
translate spanish act1_591a6319:

    # m sweet "Another game?"
    m sweet "¿Otro juego?"

# game/act1.rpy:2154
translate spanish act1_ef176421:

    # a confident "You’re on."
    a confident "Estás en el aire."

# game/act1.rpy:2156
translate spanish act1_5f588122:

    # "I grab my cards and immediately try not to let it show on my face…"
    "Agarro mis cartas e inmediatamente intento que no se note en mi cara…"

# game/act1.rpy:2157
translate spanish act1_7da2e3de:

    # "…That I got the colored joker."
    "…Que me tocó el comodín de color."

# game/act1.rpy:2159
translate spanish act1_2eb7991f:

    # a grin "{i}Yes!! Instant win! I just have to bluff my way into making him bet a lot."
    a grin "{i}¡Sí! ¡Victoria instantánea! Solo tengo que engañarlo para que apueste mucho."

# game/act1.rpy:2161
translate spanish act1_b398cc83:

    # "A three-of-a-kind isn’t bad at all. It’s higher than a double pair, right?"
    "Un trío no está nada mal. Es más alto que un doble par, ¿verdad?"

# game/act1.rpy:2163
translate spanish act1_6e637585:

    # "I push two chips into the center, trying to play it nonchalant."
    "Empujo dos fichas hacia el centro, intentando jugar con indiferencia."

# game/act1.rpy:2165
translate spanish act1_954e1892:

    # a smile "Two chips."
    a smile "Dos patatas fritas."

# game/act1.rpy:2166
translate spanish act1_90f4b9c1:

    # m cocky "You’re becoming a seasoned gambler, aye, Valentine? Well, I can’t stay behind anymore."
    m cocky "Te estás convirtiendo en una jugadora experimentada, ¿verdad, Valentine? Bueno, ya no puedo quedarme atrás."

# game/act1.rpy:2167
translate spanish act1_5306ed51:

    # m stan "I’ll raise you one chip."
    m stan "Te subo la apuesta con una ficha."

# game/act1.rpy:2169
translate spanish act1_dd3d9e3a:

    # "I smile. This {i}is{/i} fun."
    "Sonrío. Esto {i}es{/i} divertido."

# game/act1.rpy:2171
translate spanish act1_b64e355a:

    # a cocky "Let’s see how high you’re willing to go, Milan. I’ll raise you by one myself."
    a cocky "Veamos hasta dónde estás dispuesto a llegar, Milán. Yo mismo te subiré un escalón."

# game/act1.rpy:2173
translate spanish act1_098c1fc2:

    # m sweet "I’m pretty confident in my hand. I’ll raise you by two."
    m sweet "Tengo bastante confianza en mi mano. Te subo la apuesta a dos."

# game/act1.rpy:2174
translate spanish act1_2a4ff97c_12:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:2176
translate spanish act1_c51f100d:

    # a concern "{i}There’s no way his hand is better than mine… right? Yeah, no way. What are the odds he gets a flush, or a straight?"
    a concern "{i}No hay manera de que su mano sea mejor que la mía… ¿verdad? Sí, no hay manera. ¿Cuáles son las probabilidades de que consiga un color o una escalera?"

# game/act1.rpy:2177
translate spanish act1_d74c75c8:

    # a frown "{i}He’s bluffing… I know he is. I just have to out-bluff him, and I’ll win the whole pot."
    a frown "{i}Está faroleando… Lo sé. Solo tengo que superarlo en faroles y ganaré todo el bote."

# game/act1.rpy:2178
translate spanish act1_7ef4a284:

    # a stan "I raise your bet by one."
    a stan "Subo tu apuesta en uno."

# game/act1.rpy:2181
translate spanish act1_193c518f:

    # m sweet "I’m all in."
    m sweet "Estoy totalmente comprometido."

# game/act1.rpy:2183
translate spanish act1_9e90b603:

    # "Matteo pushes all of his chips into the pile, a bead of sweat starting to form on my forehead as I watch him lean back confidently in his chair."
    "Matteo echa todas sus fichas en la pila, y una gota de sudor empieza a formarse en mi frente mientras lo veo recostarse con confianza en su silla."

# game/act1.rpy:2186
translate spanish act1_179ac558:

    # a scared "{i}Jesus… I… I can’t fold now. I’d lose, what, two-hundred? Three-hundred dollars? But if I match him, that’ll be six-hundred dollars…! Matteo can certainly afford to lose that, but can I?"
    a scared "{i}Jesús… yo… no puedo rendirme ahora. Perdería, ¿qué?, ¿doscientos? ¿Trescientos dólares? Pero si lo igualo, ¡serán seiscientos dólares…! Matteo sin duda puede permitirse perder eso, ¿pero yo?"

# game/act1.rpy:2187
translate spanish act1_60ee755b:

    # a concern "{i}In any case, the only way to not lose any money now would be to check him… and hope I win."
    a concern "{i}En cualquier caso, la única forma de no perder dinero ahora sería comprobarlo... y esperar ganar."

# game/act1.rpy:2188
translate spanish act1_8ef2c679_5:

    # a frown "…"
    a frown "…"

# game/act1.rpy:2189
translate spanish act1_90099636:

    # a angry "{i}No. I WILL win. I alone have the colored joker. That makes my hand better than his automatically, doesn’t it?"
    a angry "{i}No. YO GANARÉ. Solo yo tengo el comodín de color. Eso hace que mi mano sea automáticamente mejor que la suya, ¿no?"

# game/act1.rpy:2190
translate spanish act1_bba9693b:

    # a "{i}No more stepping down. I’m doing this now!"
    a "{i}¡No más dimisiones. ¡Lo hago ahora!"

# game/act1.rpy:2192
translate spanish act1_6d155545:

    # a frown "I’m all in, too!"
    a frown "¡Yo también estoy totalmente dentro!"

# game/act1.rpy:2194
translate spanish act1_1f285814:

    # "I push my chips to the center before I can regret it, my adrenaline spiking to levels I’ve never felt before. Matteo seems way too casual about this… but, maybe there’s a hint of nerves in his eyes?"
    "Empujo mis fichas hacia el centro antes de arrepentirme, y mi adrenalina se dispara a niveles que nunca antes había experimentado. Matteo parece demasiado tranquilo al respecto… pero, ¿quizás hay un atisbo de nerviosismo en sus ojos?"

# game/act1.rpy:2196
translate spanish act1_48eb169e:

    # dealer "You may now show your cards."
    dealer "Ahora puedes mostrar tus cartas."

# game/act1.rpy:2199
translate spanish act1_cf50905c:

    # a surprised "…!"
    a surprised "…!"

# game/act1.rpy:2200
translate spanish act1_9d5bc0ad:

    # a "M-mine’s a three-of-a-kind! That means I win, right!"
    a "¡M-mío es un trío! ¡Eso significa que gano, ¿verdad?!"

# game/act1.rpy:2201
translate spanish act1_3d0c4c32:

    # m cocky "Now, hold on… didn’t you notice?"
    m cocky "Un momento… ¿no te diste cuenta?"

# game/act1.rpy:2202
translate spanish act1_24fba808:

    # m sweet "I have a joker card of my own."
    m sweet "Yo también tengo mi propia carta comodín."

# game/act1.rpy:2203
translate spanish act1_5f3979c1:

    # "I blink. He’s right… he has the gray joker. B-but there’s no way…"
    "Parpadeo. Tiene razón… tiene al Joker gris. P-pero no hay manera…"

# game/act1.rpy:2204
translate spanish act1_1effa9ce:

    # m cocky "Thomas?"
    m cocky "¿Thomas?"

# game/act1.rpy:2206
translate spanish act1_745e42ee:

    # "Our dealer – Thomas – draws a card from the deck, and it feels like he flips it in slow motion to reveal…"
    "Nuestro crupier, Thomas, saca una carta de la baraja, y da la sensación de que la voltea a cámara lenta para revelar..."

# game/act1.rpy:2208
translate spanish act1_c1ea52a2:

    # a scared "!!!"
    a scared "!!!"

# game/act1.rpy:2210
translate spanish act1_38ccf612:

    # "My face turns to ice.{w} He drew a six."
    "Mi cara se congela.{w} Sacó un seis."

# game/act1.rpy:2212
translate spanish act1_a7edf123:

    # m sweet "Well, look at my luck! A flush on gray joker! I don’t think that’s {i}ever{/i} happened to me before."
    m sweet "¡Vaya, mira mi suerte! ¡Un color de rosa en un comodín gris! No creo que me haya pasado esto antes."

# game/act1.rpy:2214
translate spanish act1_00502c9f:

    # "I shudder, feeling like I’m about to be sick. {i}Six-hundred dollars on a poker game…"
    "Me estremezco, siento que estoy a punto de vomitar. {i}Seiscientos dólares en una partida de póker…"

# game/act1.rpy:2216
translate spanish act1_af16ec37:

    # "That’s almost half a month’s paycheck… what am I gonna tell Mom? What am I- "
    "Eso es casi la mitad del sueldo de un mes... ¿Qué le voy a decir a mamá? ¿Qué voy a...?"

# game/act1.rpy:2218
translate spanish act1_51b0a3da:

    # m cocky "Oh, shoot. We forgot to establish what the chips were worth this round, didn’t we?"
    m cocky "¡Oh, vaya! Olvidamos establecer el valor de las fichas en esta ronda, ¿verdad?"

# game/act1.rpy:2220
translate spanish act1_0f65fcc3:

    # a "H… huh?"
    a "¿Eh...?"

# game/act1.rpy:2221
translate spanish act1_086a5633:

    # a "N-no, we didn’t. You said 50 dollars…"
    a "N-no, no lo hicimos. Dijiste 50 dólares…"

# game/act1.rpy:2222
translate spanish act1_5164fcfe:

    # m sweet "I said that last round, Valentine. Try and keep up, will ya?"
    m sweet "Ya lo dije en la ronda anterior, Valentine. Intenta seguirme el ritmo, ¿quieres?"

# game/act1.rpy:2223
translate spanish act1_bff02818:

    # m cocky "So, let’s see… how about…"
    m cocky "Veamos… ¿qué tal si…?"

# game/act1.rpy:2224
translate spanish act1_cd0fbc29:

    # m amused "A thousand dollars for each chip. That sounds good, right, Thomas?"
    m amused "Mil dólares por cada ficha. Suena bien, ¿verdad, Thomas?"

# game/act1.rpy:2225
translate spanish act1_bde74b23:

    # a nngh "What?!"
    a nngh "¡¿Qué?!"

# game/act1.rpy:2228
translate spanish act1_dc2944f7:

    # "I stand up, slamming my hand on the table."
    "Me levanto y golpeo la mesa con la mano."

# game/act1.rpy:2230
translate spanish act1_ed4c7114:

    # a pissed "Don’t fuck with me! You can’t just put a price like that! Who do you think you are?!"
    a pissed "¡No te metas conmigo! ¡No puedes ponerle precio así como así! ¿Quién te crees que eres?"

# game/act1.rpy:2233
translate spanish act1_d8a0eebc:

    # m "I think the better question is… who do you think {i}you{/i} are?"
    m "Creo que la pregunta más pertinente es… ¿quién te crees que eres?"

# game/act1.rpy:2235
translate spanish act1_301bd9fa:

    # "He stands up to meet my position, and those jewel-colored eyes turn icy in an instant, as if a switch was flipped in his head."
    "Se pone de pie para mirarme, y esos ojos color joya se vuelven gélidos en un instante, como si se hubiera activado un interruptor en su cabeza."

# game/act1.rpy:2237
translate spanish act1_7d205c1b:

    # m angry "This is my ring, Valentine. You think you have some authority here?"
    m angry "Este es mi anillo, Valentine. ¿Crees que tienes alguna autoridad aquí?"

# game/act1.rpy:2238
translate spanish act1_d8eb5386_4:

    # a scared "…"
    a scared "…"

# game/act1.rpy:2240
translate spanish act1_ee984f78:

    # a "B-but we… we gambled, fair and square…"
    a "P-pero nosotros… apostamos, limpiamente…"

# game/act1.rpy:2242
translate spanish act1_3d84049d:

    # m sweet "Yeah, sorry. Fair’s not really my thing."
    m sweet "Sí, lo siento. La justicia no es lo mío."

# game/act1.rpy:2244
translate spanish act1_f81ee84d:

    # a pissed "You…! You can’t do this! You can’t-!"
    a pissed "¡Tú…! ¡No puedes hacer esto! ¡No puedes…!"

# game/act1.rpy:2245
translate spanish act1_7ae2c0b4:

    # m angry "And who the fuck's gonna stop me?"
    m angry "¿Y quién carajo va a detenerme?"

# game/act1.rpy:2247
translate spanish act1_834d052a:

    # m "Tell me, Valentine. What’re {i}you{/i} gonna do about it?"
    m "Dime, Valentine. ¿Qué vas a hacer al respecto?"

# game/act1.rpy:2248
translate spanish act1_67017425:

    # m cocky "Gonna tell the cops? Go right ahead. Tell them what you did."
    m cocky "¿Vas a avisar a la policía? Adelante. Cuéntales lo que hiciste."

# game/act1.rpy:2249
translate spanish act1_50806284_2:

    # a nngh "…"
    a nngh "…"

# game/act1.rpy:2251
translate spanish act1_17c5e952:

    # "I collapse on my chair, head hung low facing the table, blinking tears onto its surface as Matteo chuckles above me."
    "Me desplomo en la silla, con la cabeza gacha mirando a la mesa, parpadeando para derramar lágrimas sobre su superficie mientras Matteo se ríe entre dientes encima de mí."

# game/act1.rpy:2253
translate spanish act1_1a4dfda4:

    # a sob "{i}Why…?"
    a sob "{i}¿Por qué…?"

# game/act1.rpy:2259
translate spanish act1_ce1d5703_1:

    # tr_text "Well, then. That’s… how much? Oh, right…"
    tr_text "Bueno, entonces. Eso es… ¿cuánto? Ah, claro…"

# game/act1.rpy:2260
translate spanish act1_cb241121_1:

    # tr_text2 "Twelve-thousand dollars. You have the money, don’t you?"
    tr_text2 "Doce mil dólares. Tienes el dinero, ¿verdad?"

# game/act1.rpy:2261
translate spanish act1_90fdc461:

    # tr_text3 "Aw, don’t look so distraught.\nSorry to clip your wings, Valentine."
    tr_text3 "Ay, no te veas tan angustiada.\nSiento cortarte las alas, Valentine."

# game/act1.rpy:2262
translate spanish act1_a9ed576d_1:

    # tr_text "But you really should’ve known better~"
    tr_text "Pero realmente deberías haberlo sabido~"

# game/act1.rpy:2264
translate spanish act1_f947feb2:

    # a_text "{i}Why…{w} was I so stupid?!"
    a_text "{i}¿Por qué…{w} fui tan estúpido?!"

# game/act1.rpy:2268
translate spanish act1_f51fdf43:

    # anon "Sorry to interrupt your game, but… I couldn’t help myself from coming over."
    anon "Disculpen que interrumpa su juego, pero… no pude evitar venir."

# game/act1.rpy:2270
translate spanish act1_a9b59ab7:

    # "A low, familiar voice makes my ears flick, and looking up through my tear-soaked eyes, I see…"
    "Una voz baja y familiar hace que mis oídos se muevan, y alzando la vista a través de mis ojos empapados en lágrimas, veo…"

# game/act1.rpy:2272
translate spanish act1_09e3fdde:

    # s "{i}¿Qué te pasó, angelito?{/i} I thought you said you had this under control?"
    s "{i}¿Qué te pasó, angelito?{/i} Pensé que habías dicho que tenías esto bajo control?"

# game/act1.rpy:2274
translate spanish act1_7c0933b0:

    # "I blink several times to clear my vision and see him properly, dumbfounded by his sudden appearance. What does he want…?"
    "Parpadeo varias veces para aclarar mi vista y poder verlo bien, estupefacta por su repentina aparición. ¿Qué quiere...?"

# game/act1.rpy:2277
translate spanish act1_661b3faa:

    # m "Can I help you?"
    m "¿Puedo ayudarle?"

# game/act1.rpy:2280
translate spanish act1_da7d049c:

    # "An annoyed Matteo does a once-over at Sebas, who just stands to my side, paws in his pockets, slightly hunched over without a care in the world."
    "Un Matteo molesto echa un vistazo a Sebas, que simplemente se queda a mi lado, con las patas en los bolsillos, ligeramente encorvado y sin ninguna preocupación en el mundo."

# game/act1.rpy:2282
translate spanish act1_05d6cb08:

    # s hm "This is my friend here. I’m guessing he lost to you?"
    s hm "Este es mi amigo. Supongo que perdió contra ti, ¿verdad?"

# game/act1.rpy:2283
translate spanish act1_a63407a0:

    # m hm "He did. What’s it to you?"
    m hm "Lo hizo. ¿Y a ti qué te importa?"

# game/act1.rpy:2286
translate spanish act1_41522b81:

    # s "I just hate seeing cute boys cry like that. Don’t you?"
    s "Odio ver a chicos guapos llorar así. ¿A ti no?"

# game/act1.rpy:2288
translate spanish act1_8fa0429a:

    # m angry "I honestly couldn’t care less. Darwin!"
    m angry "Sinceramente, me da completamente igual. ¡Darwin!"

# game/act1.rpy:2290
translate spanish act1_d21fb988:

    # "Darwin starts marching over to us, and a whine escapes my throat, but Sebas stands his ground."
    "Darwin empieza a acercarse a nosotros, y un gemido escapa de mi garganta, pero Sebas se mantiene firme."

# game/act1.rpy:2292
translate spanish act1_015e6191:

    # s cocky "I’m not looking for any trouble. Actually, I just wanted to gamble with you, too."
    s cocky "No busco problemas. En realidad, solo quería apostar contigo también."

# game/act1.rpy:2293
translate spanish act1_f05f65d0_1:

    # m "…"
    m "…"

# game/act1.rpy:2295
translate spanish act1_664f1d5d:

    # "Darwin just about puts his hands on Sebas when Matteo stops him, putting his own paw up in a ‘halt’ gesture."
    "Darwin está a punto de ponerle las manos encima a Sebas cuando Matteo lo detiene, levantando su propia pata en un gesto de \"alto\"."

# game/act1.rpy:2298
translate spanish act1_1cfadca1:

    # m angry "What are you on about?"
    m angry "¿De qué estás hablando?"

# game/act1.rpy:2300
translate spanish act1_d61ef346:

    # s amused "Is the saying ‘double or nothing’ a thing here?"
    s amused "¿Aquí se usa el dicho \"el doble o nada\"?"

# game/act1.rpy:2301
translate spanish act1_f05f65d0_2:

    # m "…"
    m "…"

# game/act1.rpy:2303
translate spanish act1_37cd1574:

    # m cocky "You wanna gamble for double his debt, huh?"
    m cocky "¿Quieres apostar a que duplicará su deuda, eh?"

# game/act1.rpy:2304
translate spanish act1_5965eed5:

    # s "That’s right. If you’d let me."
    s "Así es. Si me lo permitieras."

# game/act1.rpy:2307
translate spanish act1_b651aee8:

    # m arrogant "Hah!"
    m arrogant "¡Ja!"

# game/act1.rpy:2308
translate spanish act1_e248c4a9:

    # m "Hahahaha!!"
    m "¡Jajajaja!"

# game/act1.rpy:2309
translate spanish act1_f02cbf6f:

    # m angry "Who do you think you are?"
    m angry "¿Quién te crees que eres?"

# game/act1.rpy:2310
translate spanish act1_2d986cb6:

    # s "You can call me Sebas."
    s "Puedes llamarme Sebas."

# game/act1.rpy:2312
translate spanish act1_e41bd4d8:

    # "He takes out his wallet and pulls out a shiny black card from inside, making everyone at the table gasp – except for me, who just sits there like an idiot that doesn’t know what he’s looking at."
    "Saca su cartera y extrae una tarjeta negra brillante de su interior, lo que provoca que todos en la mesa se queden boquiabiertos, excepto yo, que me quedo sentado allí como un idiota que no sabe lo que está viendo."

# game/act1.rpy:2314
translate spanish act1_84390099:

    # s smile "And I believe this should show you I’m serious?"
    s smile "¿Y creo que esto debería demostrarte que hablo en serio?"

# game/act1.rpy:2317
translate spanish act1_82a499c6:

    # "Matteo glances at the card, then at me, then Sebas… then the card again."
    "Matteo mira la tarjeta, luego a mí, luego a Sebas… y luego la tarjeta otra vez."

# game/act1.rpy:2319
translate spanish act1_20cff6de:

    # m cocky "Heh. I don’t know who the hell you are, but if you’re willing to go double or nothing for this Valentine, then by all means. Be my guest."
    m cocky "Je. No sé quién demonios eres, pero si estás dispuesto a darlo todo por este San Valentín, adelante. Hazlo."

# game/act1.rpy:2320
translate spanish act1_e2082201:

    # m angry "But I’ve got my conditions. I want fifty thousand. I don’t care how you split it between the two of you."
    m angry "Pero tengo mis condiciones. Quiero cincuenta mil. No me importa cómo lo repartáis entre vosotros dos."

# game/act1.rpy:2321
translate spanish act1_67668bfb:

    # s "And If I win, you let Angel go, debt free."
    s "Y si gano, dejas ir a Angel, libre de deudas."

# game/act1.rpy:2322
translate spanish act1_162065f8:

    # m cocky "Fine. It’s a deal."
    m cocky "De acuerdo. Trato hecho."

# game/act1.rpy:2323
translate spanish act1_fea2857d:

    # s smile "It’s settled, then."
    s smile "Entonces, está decidido."

# game/act1.rpy:2327
translate spanish act1_38e5cbc8:

    # a nngh "Wait, wait, WAIT!"
    a nngh "¡Espera, espera, ESPERA!"

# game/act1.rpy:2332
translate spanish act1_81dce528:

    # "I stand up and grab Sebas by the collar, pulling him lower to my eye level."
    "Me levanto y agarro a Sebas por el cuello, tirando de él hacia abajo hasta que quede a la altura de mis ojos."

# game/act1.rpy:2334
translate spanish act1_2a07158d:

    # a nngh "Who the hell told you to make decisions for me?! You think I’m just going to let you rack up my debt if you lose?!"
    a nngh "¿Quién demonios te dijo que tomaras decisiones por mí? ¿Crees que voy a dejar que aumentes mi deuda si pierdes?"

# game/act1.rpy:2335
translate spanish act1_2d4376b0:

    # s "…"
    s "…"

# game/act1.rpy:2336
translate spanish act1_870f9c42:

    # s stan "I won’t lose, {i}Ángel{/i}."
    s stan "No perderé, {i}Ángel{/i}."

# game/act1.rpy:2337
translate spanish act1_2ed6667b:

    # s "It’s okay to ask for help sometimes."
    s "A veces está bien pedir ayuda."

# game/act1.rpy:2338
translate spanish act1_07ceb950_2:

    # a scared "…!"
    a scared "…!"

# game/act1.rpy:2340
translate spanish act1_be0ff9e2:

    # a concern "Just who the hell are you?"
    a concern "¿Quién demonios eres?"

# game/act1.rpy:2342
translate spanish act1_eb828f94:

    # s smile "I already told you. {w}A friend."
    s smile "Ya te lo dije. {w}Un amigo."

# game/act1.rpy:2345
translate spanish act1_87ea51ac:

    # "I stare into those onyx eyes that are looking right back into my soul as we have one last silent conversation through our gazes alone."
    "Miro fijamente esos ojos de ónix que me devuelven la mirada hasta lo más profundo del alma mientras mantenemos una última conversación silenciosa a través de nuestras miradas."

# game/act1.rpy:2347
translate spanish act1_40f9a900:

    # a concern "{i}How do I know I can trust you…?"
    a concern "{i}¿Cómo sé que puedo confiar en ti...?"

# game/act1.rpy:2349
translate spanish act1_8c560d5d:

    # s hm "{i}You don’t.{w} You're just gonna have to take my word for it."
    s hm "{i}No lo harás.{w} Tendrás que creerme cuando te lo diga."

# game/act1.rpy:2351
translate spanish act1_2acfd085:

    # "Yet another wager."
    "Otra apuesta más."

# game/act1.rpy:2354
translate spanish act1_2d5385e7:

    # a worried "Okay…"
    a worried "Bueno…"

# game/act1.rpy:2356
translate spanish act1_25102470:

    # "I let go of him, and he stands up straight again, giving me a soft, assured smile."
    "Lo solté y él se enderezó de nuevo, dedicándome una sonrisa suave y segura."

# game/act1.rpy:2361
translate spanish act1_ffdf7e95:

    # m "Are you two done? Can we get on with this?"
    m "¿Ya terminaron? ¿Podemos continuar?"

# game/act1.rpy:2362
translate spanish act1_c6e90dec:

    # s smile "With pleasure."
    s smile "Con mucho gusto."

# game/act1.rpy:2368
translate spanish act1_1ba6cf5c:

    # "Sebas takes my seat at the table, and I’m forced to stand next to Thomas, unable to see either of their cards. This works out better for both of us. I don’t think I’d be able to hide the emotions on my face if I saw Sebas’ cards."
    "Sebas toma mi lugar en la mesa, y me veo obligado a quedarme de pie junto a Thomas, sin poder ver las cartas de ninguno de los dos. Esto nos viene mejor a ambos. No creo que pudiera disimular la emoción si viera las cartas de Sebas."

# game/act1.rpy:2369
translate spanish act1_e73e7260:

    # "I swallow hard, both men in front of me showing me nothing on either of their expressions. The once warm and kind façade from Matteo’s smile is nowhere to be seen, now replaced with a cold, calculating glare."
    "Trago saliva con dificultad; ambos hombres frente a mí no me muestran ninguna emoción en sus expresiones. La sonrisa cálida y amable de Matteo, antes imperceptible, ha desaparecido por completo, reemplazada ahora por una mirada fría y calculadora."

# game/act1.rpy:2370
translate spanish act1_5b3bedd7:

    # "Sebas glances at me through the corner of his eyes as Matteo explains the rules to him. Am I supposed to help him out in any way? I’m so confused… and close to puking my guts out."
    "Sebas me mira de reojo mientras Matteo le explica las reglas. ¿Se supone que debo ayudarlo de alguna manera? Estoy tan confundida… y a punto de vomitar."

# game/act1.rpy:2375
translate spanish act1_b504a48a:

    # m "You got all that?"
    m "¿Lo entendiste todo?"

# game/act1.rpy:2376
translate spanish act1_2d4376b0_1:

    # s "…"
    s "…"

# game/act1.rpy:2377
translate spanish act1_9b99e06b:

    # m cocky "What? Getting cold feet?"
    m cocky "¿Qué? ¿Te estás acobardando?"

# game/act1.rpy:2379
translate spanish act1_e7c0b282:

    # s hm "No. I’m just curious why you use an automatic shuffler. Not even Corona’s uses one."
    s hm "No. Simplemente tengo curiosidad por saber por qué usan una mezcladora automática. Ni siquiera Corona la usa."

# game/act1.rpy:2381
translate spanish act1_f76351e6:

    # "I frown. So he {i}did{/i} go to Corona’s?"
    "Frunzo el ceño. ¿Entonces él {i}sí{/i} fue a Corona's?"

# game/act1.rpy:2383
translate spanish act1_230b41b1:

    # m cocky "It’s just to ensure the shuffle is truly random. Nothing else to it."
    m cocky "Es simplemente para asegurar que la mezcla sea verdaderamente aleatoria. No hay nada más."

# game/act1.rpy:2384
translate spanish act1_7e3ec1f8:

    # s stan "Is that right?"
    s stan "¿Es correcto?"

# game/act1.rpy:2388
translate spanish act1_9f054e46:

    # s "Would you care if we just let the dealer shuffle for us?"
    s "¿Les importaría si dejamos que el crupier baraje las cartas por nosotros?"

# game/act1.rpy:2390
translate spanish act1_77ad5c10:

    # m hm "Why, exactly?"
    m hm "¿Por qué, exactamente?"

# game/act1.rpy:2392
translate spanish act1_6c4bd225:

    # s "To make it fair, of course."
    s "Para que sea justo, por supuesto."

# game/act1.rpy:2393
translate spanish act1_96bdcf02:

    # m angry "Are you insinuating I’m cheating?"
    m angry "¿Estás insinuando que te estoy engañando?"

# game/act1.rpy:2394
translate spanish act1_1bfae857:

    # s "No."
    s "No."

# game/act1.rpy:2396
translate spanish act1_52269187:

    # s "I’m… hm, what’s the word? ‘Stating’? Yes, I’m ‘stating’ that you’re cheating."
    s "Estoy… hm, ¿cuál es la palabra? ¿'Afirmando'? Sí, estoy 'afirmando' que estás haciendo trampa."

# game/act1.rpy:2397
translate spanish act1_f05f65d0_3:

    # m "…"
    m "…"

# game/act1.rpy:2399
translate spanish act1_1b80c301:

    # "Matteo looks into Sebas’ eyes with silent fury etched into them, clenching his jaw so tight I’m scared for his teeth."
    "Matteo mira a Sebas a los ojos con una furia silenciosa grabada en ellos, apretando la mandíbula con tanta fuerza que temo por sus dientes."

# game/act1.rpy:2401
translate spanish act1_0445ebdc:

    # m "That’s a {i}bold{/i} claim, whatever-your-name-was."
    m "Esa es una afirmación {i}audaz{/i}, sea cual sea tu nombre."

# game/act1.rpy:2402
translate spanish act1_09bb2a0c:

    # s "It’s Sebas."
    s "Es Sebas."

# game/act1.rpy:2404
translate spanish act1_071db81b:

    # m "Whatever. I don’t have to sit here and take this slander from some punk who thinks he’s hot shit."
    m "Me da igual. No tengo por qué quedarme aquí aguantando estas calumnias de algún cretino que se cree la gran cosa."

# game/act1.rpy:2406
translate spanish act1_5825b205:

    # s "Slander? I can prove it, if you’d like. I mean, even the fact that you’re getting so defensive about letting your dealer shuffle is telling in its own way."
    s "¿Difamación? Puedo probarlo si quieres. Es decir, incluso el hecho de que te pongas tan a la defensiva por dejar que tu crupier baraje las cartas es revelador en sí mismo."

# game/act1.rpy:2408
translate spanish act1_84ec937e:

    # s "But I’ll admit, it’s a {i}very{/i} elaborate cheat. I bet no one’s ever noticed it before, have they?"
    s "Pero admito que es un truco muy elaborado. Apuesto a que nadie se había dado cuenta antes, ¿verdad?"

# game/act1.rpy:2409
translate spanish act1_63c5722b:

    # a concern "What… do you mean?"
    a concern "¿Qué quieres decir?"

# game/act1.rpy:2411
translate spanish act1_378b62a7:

    # "Sebas looks over to me, a smug grin on his face."
    "Sebas me mira con una sonrisa de suficiencia en el rostro."

# game/act1.rpy:2413
translate spanish act1_d84756f4:

    # s "I can’t blame you for not noticing, {i}chele{/i}. Unless you know cards well, you probably would’ve never caught it. Hell, even I had a hard time keeping up."
    s "No te culpo por no haberte dado cuenta, {i}chele{/i}. A menos que conozcas bien las cartas, probablemente nunca lo habrías notado. Incluso a mí me costó seguir el ritmo."

# game/act1.rpy:2414
translate spanish act1_6f3ef5d9:

    # s "And obviously, the culprit is the machine."
    s "Y, obviamente, el culpable es la máquina."

# game/act1.rpy:2416
translate spanish act1_2fddfe22:

    # s "It’s performing a perfect faro shuffle. The deck is split in half, and when they’re shuffled, each card gets interweaved through the other deck via the machine. That alone isn’t a cheat, though."
    s "Realiza una mezcla Faro perfecta. La baraja se divide por la mitad y, al barajarse, cada carta se entrelaza con la otra mediante la máquina. Sin embargo, eso por sí solo no constituye trampa."

# game/act1.rpy:2419
translate spanish act1_8027cac5:

    # s "The real trick comes from the deck itself. You weren’t shown the order before it was placed into the machine, right, Angel?"
    s "El verdadero truco reside en la propia baraja. No te mostraron el orden antes de que lo introdujeran en la máquina, ¿verdad, Ángel?"

# game/act1.rpy:2420
translate spanish act1_5afab5e7:

    # a concern "No… but it was a brand-new deck. Aren’t they all the same order, anyway?"
    a concern "No… pero era una baraja completamente nueva. ¿Acaso no son todas del mismo orden?"

# game/act1.rpy:2421
translate spanish act1_b168d3c5:

    # s "Normally, yes. However, this one wasn’t."
    s "Normalmente, sí. Sin embargo, este no lo era."

# game/act1.rpy:2422
translate spanish act1_f868463c:

    # s "It had a completely different order… a very specific one. Does the Joyal deck ring any bells, Matteo?"
    s "Tenía un orden completamente diferente… uno muy específico. ¿Te suena de algo la baraja Joyal, Matteo?"

# game/act1.rpy:2423
translate spanish act1_6d895f6f:

    # m "…!?"
    m "…!?"

# game/act1.rpy:2424
translate spanish act1_ea3c9060:

    # a hm "Joyal?"
    a hm "¿Alegre?"

# game/act1.rpy:2428
translate spanish act1_3b7400d0:

    # s "It’s a specific pattern of a deck of cards used for different kinds of magic tricks. Matteo here must have them custom made, fresh in the pack."
    s "Es un diseño específico de baraja de cartas que se usa para diferentes tipos de trucos de magia. Matteo debe tenerlas hechas a medida, recién sacadas del paquete."

# game/act1.rpy:2429
translate spanish act1_69246985:

    # s "In other words, the cards weren’t ever going to be randomized."
    s "En otras palabras, las cartas nunca iban a ser elegidas al azar."

# game/act1.rpy:2430
translate spanish act1_3afdad37:

    # s "Whether it was an out or in faro shuffle, each of your hands were predetermined from the very beginning. He must have memorized the outcome of each hand and betted accordingly."
    s "Ya fuera una baraja Faro con salida o entrada, cada una de tus manos estaba predeterminada desde el principio. Debió de memorizar el resultado de cada mano y apostar en consecuencia."

# game/act1.rpy:2435
translate spanish act1_82399fc9:

    # s "What I don’t understand are the jokers… two extra cards messes with the order of the Joyal deck. My guess… a specific button that pushes them out, maybe?"
    s "Lo que no entiendo son los comodines… dos cartas adicionales alteran el orden de la baraja Joyal. Supongo que… ¿quizás un botón específico los hace aparecer?"

# game/act1.rpy:2436
translate spanish act1_f05f65d0_4:

    # m "…"
    m "…"

# game/act1.rpy:2437
translate spanish act1_aa5b57af:

    # s cocky2 "It's so subtle. So many different moving parts in such a tiny machine... you must have had this custom built as well. Oh, what money can buy, aye?"
    s cocky2 "Es tan sutil. Tantas piezas móviles en una máquina tan pequeña... seguro que también la mandaste a hacer a medida. ¡Ah, lo que el dinero puede comprar!"

# game/act1.rpy:2438
translate spanish act1_649d6845:

    # s "But, well… this is all speculation. You’re welcome to clear your name, Matteo. I’m open to be proven wrong."
    s "Pero bueno… todo esto son especulaciones. Puedes demostrar tu inocencia, Matteo. Estoy dispuesto a aceptar que me equivoque."

# game/act1.rpy:2441
translate spanish act1_f782f380:

    # s "But I’m right, aren’t I? You can’t {i}really{/i} play cards. You’re just some Hollywood Hills frat douche playing casino with Daddy's money and scamming those weaker than you to, what? Get his approval?"
    s "Pero tengo razón, ¿no? No puedes jugar a las cartas de verdad. Eres solo un cretino de Hollywood Hills jugando al casino con el dinero de papá y estafando a los más débiles que tú para, ¿qué? ¿Obtener su aprobación?"

# game/act1.rpy:2445
translate spanish act1_81f6a3d9:

    # s angry "Why don’t you gamble like a real man instead of cheating like a pussy?"
    s angry "¿Por qué no apuestas como un hombre de verdad en lugar de hacer trampas como un cobarde?"

# game/act1.rpy:2452
translate spanish act1_db24d056:

    # m "You motherfucker…! Just who the hell do you think you are?!"
    m "¡Hijo de puta...! ¿Quién demonios te crees que eres?!"

# game/act1.rpy:2453
translate spanish act1_b29e22fa:

    # s "My name’s Seb-"
    s "Mi nombre es Seb-"

# game/act1.rpy:2455
translate spanish act1_145456e4:

    # m "I DON’T GIVE A FUCK!! If you think you know a SINGLE thing about me, you’re dead fucking wrong!!"
    m "¡¡ME IMPORTA UNA MIERDA!! Si crees que sabes UNA SOLA COSA sobre mí, ¡estás completamente equivocado!"

# game/act1.rpy:2456
translate spanish act1_f3a2d03d:

    # m arrogant "Yeah, I’ll admit it. I cheated. This is MY ring, and I can do whatever the FUCK I want! And if you think you’re gonna change that, then you’re an even bigger idiot than this Valentine!!"
    m arrogant "Sí, lo admito. Hice trampa. ¡Este es MI anillo, y puedo hacer lo que me dé la gana! Y si crees que vas a cambiar eso, ¡entonces eres aún más idiota que este San Valentín!"

# game/act1.rpy:2458
translate spanish act1_2adb451d:

    # a flustered "{i}Why am I catching strays…?"
    a flustered "{i}¿Por qué estoy atrapando animales callejeros...?"

# game/act1.rpy:2461
translate spanish act1_4d23d4ae:

    # s hm "You know, maybe you’re right, Matteo. I thought you’d be willing to gamble with me even without the cheat, but…"
    s hm "Sabes, tal vez tengas razón, Matteo. Pensé que estarías dispuesto a apostar conmigo incluso sin la trampa, pero…"

# game/act1.rpy:2464
translate spanish act1_da6653fe:

    # s "I guess I really am a fool to ever think you’d be capable of doing that."
    s "Supongo que fui un verdadero tonto al pensar que serías capaz de hacer eso."

# game/act1.rpy:2465
translate spanish act1_f05f65d0_5:

    # m "…"
    m "…"

# game/act1.rpy:2468
translate spanish act1_df6f056c:

    # "Matteo sinks back into his seat, almost in slow motion, staring daggers at Sebas as he quietly seethes for a moment."
    "Matteo se recuesta en su asiento, casi a cámara lenta, fulminando con la mirada a Sebas mientras hierve de rabia en silencio por un instante."

# game/act1.rpy:2471
translate spanish act1_e81f75a8:

    # m cocky "You’ve got balls, Sebas, I’ll give you that. Spying on our game, calling me out in front of my staff, disrespecting me. You’re lucky I haven’t shot you square between the eyes."
    m cocky "Tienes agallas, Sebas, eso sí. Espiar nuestro partido, criticarme delante de mi equipo, faltarme al respeto. Tienes suerte de que no te haya pegado un tiro entre los ojos."

# game/act1.rpy:2472
translate spanish act1_0f16a195:

    # m arrogant "But you know what? I respect it."
    m arrogant "¿Pero sabes qué? Lo respeto."

# game/act1.rpy:2473
translate spanish act1_51c94c36:

    # m "So I will play. And I’ll make sure to get every penny of those fifty-thousand dollars from that black card of yours when I win."
    m "Así que jugaré. Y me aseguraré de sacar hasta el último centavo de esos cincuenta mil dólares de tu tarjeta negra cuando gane."

# game/act1.rpy:2474
translate spanish act1_fb10e910:

    # m angry "And if I ever see your stupid face again…{w} I’ll kill you right where you stand."
    m angry "Y si vuelvo a ver tu estúpida cara…{w} te mataré aquí mismo."

# game/act1.rpy:2476
translate spanish act1_1be75051:

    # s flirty "Now we’re talking."
    s flirty "Ahora sí que hablamos."

# game/act1.rpy:2477
translate spanish act1_13e9fb9a:

    # m serious "Thomas. Go get a normal deck."
    m serious "Thomas. Ve a comprar una baraja normal."

# game/act1.rpy:2479
translate spanish act1_306308e1:

    # "Thomas nods, disappearing somewhere for a moment."
    "Thomas asiente con la cabeza y desaparece un instante."

# game/act1.rpy:2481
translate spanish act1_8b369ab2:

    # a concern "{i}Wait a minute… so I was being screwed over from the very beginning?"
    a concern "{i}Un momento… ¿entonces me estaban estafando desde el principio?"

# game/act1.rpy:2482
translate spanish act1_737c6bb3:

    # a sad "{i}Maybe Ethan was right… I’m not cut out for this. If I couldn’t even tell I was being conned on my first ever gamble, what business do I have being here?"
    a sad "{i}Tal vez Ethan tenía razón… No sirvo para esto. Si ni siquiera me di cuenta de que me estaban engañando en mi primera apuesta, ¿qué hago aquí?"

# game/act1.rpy:2483
translate spanish act1_d72eeebf:

    # a worried "{i}…I guess it’s too late to back out now."
    a worried "{i}…Supongo que ya es demasiado tarde para echarme atrás."

# game/act1.rpy:2485
translate spanish act1_3829c8bc:

    # "Thomas reappears with a deck of cards in his hands, opening the pack and spreading it through the table with the precision of a magician. Sure enough, the cards are in the order you’d expect, from ace to king."
    "Thomas reaparece con una baraja de cartas en las manos, la abre y la extiende sobre la mesa con la precisión de un mago. Efectivamente, las cartas están en el orden esperado, del as al rey."

# game/act1.rpy:2486
translate spanish act1_1d4afc82:

    # "He then grabs them all up again, cuts the deck in two and gives them a shuffle, repeating this process about three more times before finally dealing out the cards, four for each, just like before."
    "Luego las vuelve a coger todas, corta la baraja por la mitad y las baraja, repitiendo este proceso unas tres veces más antes de repartir finalmente las cartas, cuatro para cada uno, igual que antes."

# game/act1.rpy:2490
translate spanish act1_eedf27b0:

    # a "{i}With the bets already placed… that means there’s no bluffing this time. It’s a game of pure luck."
    a "{i}Con las apuestas ya hechas… eso significa que esta vez no hay faroles. Es un juego de pura suerte."

# game/act1.rpy:2491
translate spanish act1_3f42d274:

    # a "{i}How the hell is Sebas going to win like this??"
    a "{i}¿Cómo diablos va a ganar Sebas así?"

# game/act1.rpy:2493
translate spanish act1_2d4376b0_2:

    # s "…"
    s "…"

# game/act1.rpy:2494
translate spanish act1_f05f65d0_6:

    # m "…"
    m "…"

# game/act1.rpy:2495
translate spanish act1_bbb9ecb6:

    # dealer "You… may reveal your cards at any time."
    dealer "Puedes revelar tus cartas en cualquier momento."

# game/act1.rpy:2497
translate spanish act1_249804fd:

    # s "I’m surprised you ended up agreeing to this in the end. I suppose the Milan’s do have a bit of honor left."
    s "Me sorprende que al final hayas aceptado esto. Supongo que a los Milan todavía les queda algo de honor."

# game/act1.rpy:2498
translate spanish act1_45694f05:

    # m "You gonna play, or what?"
    m "¿Vas a jugar o qué?"

# game/act1.rpy:2500
translate spanish act1_b491320f:

    # dealer "At the count of three, then, gentlemen… please reveal your cards."
    dealer "A la cuenta de tres, caballeros… por favor, muestren sus cartas."

# game/act1.rpy:2501
translate spanish act1_ffee86be:

    # dealer "One…"
    dealer "Uno…"

# game/act1.rpy:2502
translate spanish act1_ff751cf1:

    # dealer "Two…"
    dealer "Dos…"

# game/act1.rpy:2503
translate spanish act1_fdc32eb0:

    # dealer "Three."
    dealer "Tres."

# game/act1.rpy:2505
translate spanish act1_cf50905c_1:

    # a surprised "…!"
    a surprised "…!"

# game/act1.rpy:2506
translate spanish act1_4a63b5dd:

    # "They both have complete pigs... but Sebas has an Ace! He wins with the high card!"
    "Ambos son unos auténticos cerdos... ¡pero Sebas tiene un as! ¡Gana con la carta más alta!"

# game/act1.rpy:2507
translate spanish act1_00aa30f1:

    # s "{i}Comiste mierda, gomelo.{/i} Looks like I win."
    s "{i}Comiste mierda, gomelo.{/i}Parece que gano."

# game/act1.rpy:2512
translate spanish act1_9fedb3ea:

    # "I breathe out a heavy, shaky sigh of relief, chills running through my whole body. He really did win… from the hairs of his chin, but a win is a win."
    "Exhalo un suspiro profundo y tembloroso de alivio, con escalofríos recorriendo todo mi cuerpo. Realmente ganó… por los pelos de su barbilla, pero una victoria es una victoria."

# game/act1.rpy:2513
translate spanish act1_50ab7af4:

    # "Matteo stares at the cards on the table, seething in a way I don’t think I’ve seen anyone do before, his paws clenched so tight that his claws must be digging into his pads."
    "Matteo mira fijamente las cartas sobre la mesa, hirviendo de rabia como no creo haber visto nunca antes en nadie, con las patas tan apretadas que sus garras deben estar clavándose en las almohadillas."

# game/act1.rpy:2514
translate spanish act1_c9fc4b60:

    # "Sebas, on the other hand, just stands up, as calm and collected as ever."
    "Sebas, por otro lado, simplemente se pone de pie, tan tranquilo y sereno como siempre."

# game/act1.rpy:2518
translate spanish act1_60742e52:

    # s "Well, I can’t say I didn’t enjoy this, but it’s getting quite late now. {i}Ángel, ¿nos vamos?{/i}"
    s "Bueno, no puedo decir que no lo haya disfrutado, pero ya se está haciendo bastante tarde. {i}Ángel, ¿nos vamos?{/i}"

# game/act1.rpy:2520
translate spanish act1_aebc4e7b:

    # "Instinctively, somehow, I know that means we should get the hell out of here. I nod, still shaken by the entire ordeal, as if I just woke up from a fever dream."
    "Instintivamente, de alguna manera, sé que eso significa que debemos largarnos de aquí. Asiento con la cabeza, aún conmocionada por todo lo sucedido, como si acabara de despertar de un sueño febril."

# game/act1.rpy:2522
translate spanish act1_796fbd31:

    # "Sebas places his large paw on my lower back and starts to lead me to the doorway, when we hear Matteo slam the table, his chair sliding backwards."
    "Sebas coloca su gran pata en mi espalda baja y comienza a guiarme hacia la puerta, cuando oímos a Matteo golpear la mesa y su silla deslizarse hacia atrás."

# game/act1.rpy:2525
translate spanish act1_93c00ebe:

    # m "Don’t think for a second this is over, Valentine! Your pimp may have saved you this time, but you’re not safe anymore."
    m "¡Ni por un segundo pienses que esto ha terminado, Valentine! Puede que tu proxeneta te haya salvado esta vez, pero ya no estás a salvo."

# game/act1.rpy:2527
translate spanish act1_e6d9bcd6:

    # m angry "You're deep in my world now, {i}Angel{/i}. And I won't let you forget it."
    m angry "Ahora estás muy dentro de mi mundo, {i}Ángel{/i}. Y no dejaré que lo olvides."

# game/act1.rpy:2528
translate spanish act1_1ab72481_17:

    # a concern "…"
    a concern "…"

# game/act1.rpy:2529
translate spanish act1_c79d4b77:

    # s stan "Come on. Let’s go."
    s stan "Vamos. Vámonos."

# game/act1.rpy:2531
translate spanish act1_65486dd6:

    # "Sebas nudges me to start walking again, and the last thing I see as we exit the room is Matteo’s eyes glaring deep into mine…"
    "Sebas me da un codazo para que vuelva a caminar, y lo último que veo al salir de la habitación son los ojos de Matteo clavados en los míos…"

# game/act1.rpy:2535
translate spanish act1_18f74fcb:

    # "The bar is mostly empty once we walk out, and Sebas leads me towards a different exit of the bar, the back door. It leads to a dark alleyway full of dumpsters, but the cold midnight breeze carries the smell somewhere else."
    "Cuando salimos, el bar está casi vacío, y Sebas me lleva hacia otra salida, la puerta trasera. Esta conduce a un callejón oscuro lleno de contenedores de basura, pero la fría brisa de medianoche se lleva el olor a otro lugar."

# game/act1.rpy:2540
translate spanish act1_7e2f9528:

    # s "Stay here for a second."
    s "Quédate aquí un segundo."

# game/act1.rpy:2541
translate spanish act1_629844bc:

    # a hm "Why?"
    a hm "¿Por qué?"

# game/act1.rpy:2542
translate spanish act1_1f398e3d:

    # s hm "I’m going to check if the coast is clear."
    s hm "Voy a comprobar si no hay peligro."

# game/act1.rpy:2543
translate spanish act1_244665f5:

    # a "Is that really necessary?"
    a "¿Es eso realmente necesario?"

# game/act1.rpy:2544
translate spanish act1_d8801749:

    # s "If you don’t want people seeing a Valentine come out of a bar that’s rumored to be a gambling ring this late, then yes, I think so."
    s "Si no quieres que la gente vea a una persona llamada Valentine salir de un bar del que se rumorea que es una red de apuestas a estas horas, entonces sí, creo que sí."

# game/act1.rpy:2545
translate spanish act1_2a4ff97c_13:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:2547
translate spanish act1_c55eecb3:

    # a pout "Touché."
    a pout "Touché."

# game/act1.rpy:2550
translate spanish act1_06f39335_5:

    # a stan "…"
    a stan "…"

# game/act1.rpy:2552
translate spanish act1_b0c084cf:

    # "I blink, my eyelids heavy but my mind feeling wide awake. Did all of that really just happen?"
    "Parpadeo, con los párpados pesados ​​pero la mente completamente despierta. ¿De verdad acaba de pasar todo eso?"

# game/act1.rpy:2553
translate spanish act1_ac73130a:

    # "I was almost fifty-thousand dollars deeper in debt… That’s my {i}entire{/i} debt right now to the Valentine Agency. I really {i}would{/i} have spent my whole life paying that off, and then some."
    "Tenía una deuda de casi cincuenta mil dólares... Esa es mi deuda total ahora mismo con la Agencia Valentine. Realmente habría dedicado toda mi vida a pagarla, y aún me sobraría dinero."

# game/act1.rpy:2554
translate spanish act1_842e8da1:

    # "How could I be so stupid…? I was conned, then rescued, and by some miracle walked away like nothing ever happened. But something did happen, and Matteo’s parting words echoes in my mind."
    "¿Cómo pude ser tan estúpido...? Me engañaron, me rescataron y, por algún milagro, salí como si nada hubiera pasado. Pero algo sí pasó, y las últimas palabras de Matteo resuenan en mi mente."

# game/act1.rpy:2555
translate spanish act1_3eef5548:

    # "I’ve bitten the fruit.{w} No way back to Eden now."
    "He mordido la fruta.{w} Ya no hay vuelta atrás al Edén."

# game/act1.rpy:2557
translate spanish act1_ca2dd096:

    # s "Okay, it’s good. Come on."
    s "Vale, está bien. Vamos."

# game/act1.rpy:2564
translate spanish act1_8d722ccb:

    # "I hug myself as we walk onto the sidewalk, the chilly air only deepening my nerves. I feel like the world’s ending, for some reason. Like I’m still at that table…"
    "Me abrazo a mí misma mientras caminamos hacia la acera; el aire frío solo aumenta mi nerviosismo. Siento que el mundo se acaba, por alguna razón. Como si todavía estuviera en esa mesa…"

# game/act1.rpy:2566
translate spanish act1_902387aa:

    # s "What a rush, ‘ey, {i}chelito?"
    s "¡Qué subidón, eh, {i}chelito?"

# game/act1.rpy:2568
translate spanish act1_1ab72481_18:

    # a concern "…"
    a concern "…"

# game/act1.rpy:2571
translate spanish act1_a5ee0cb6:

    # a "You owe me {i}a lot{/i} of explanations."
    a "Me debes {i}muchas{/i} explicaciones."

# game/act1.rpy:2572
translate spanish act1_e10c64b4:

    # a "What were you doing down there? Why were you spying on our game? Why did you help me?"
    a "¿Qué hacías ahí abajo? ¿Por qué espiabas nuestro juego? ¿Por qué me ayudaste?"

# game/act1.rpy:2575
translate spanish act1_bcddc353:

    # a angry "Who are you…?"
    a angry "Quién eres…?"

# game/act1.rpy:2578
translate spanish act1_2d4376b0_3:

    # s "…"
    s "…"

# game/act1.rpy:2579
translate spanish act1_e6d0c064:

    # s smile "You know what? I’m starving."
    s smile "¿Sabes qué? Me muero de hambre."

# game/act1.rpy:2580
translate spanish act1_fbbaaad5:

    # s "There’s a diner open twenty-four hours not too far from here. Wanna check it out?"
    s "Hay un restaurante abierto las veinticuatro horas no muy lejos de aquí. ¿Quieres echarle un vistazo?"

# game/act1.rpy:2582
translate spanish act1_91937056:

    # "I really don’t. But something tells me I won’t get my answers otherwise…"
    "Realmente no lo creo. Pero algo me dice que de otra manera no obtendré mis respuestas…"

# game/act1.rpy:2584
translate spanish act1_154ca5ad:

    # a hm "I could eat."
    a hm "Podría comer."

# game/act1.rpy:2594
translate spanish act1_33692f58:

    # "A short, quiet walk later, Sebas and I are seated face-to-face inside a booth of a cheap diner, the restaurant completely empty aside from us. Sebas spins a straw in one hand over and over again, in an almost hypnotizing motion."
    "Tras un breve y tranquilo paseo, Sebas y yo nos sentamos frente a frente en una cabina de un restaurante de comida rápida, completamente vacío a excepción de nosotros. Sebas hace girar una pajita en una mano una y otra vez, con un movimiento casi hipnotizante."

# game/act1.rpy:2595
translate spanish act1_cf8f7c65:

    # "An older woman takes our order. Sebas asks if they’re still serving food, and the lady replies no (obviously). So he orders a slice of pie instead.{w} I just get a water."
    "Una señora mayor toma nuestro pedido. Sebas pregunta si todavía sirven comida, y la señora responde que no (obviamente). Así que él pide una porción de pastel en su lugar.{w} Yo solo pido agua."

# game/act1.rpy:2596
translate spanish act1_ff3d644e:

    # "She walks away, probably wondering to herself what the hell a Valentine and some Hispanic guy are doing here in the middle of the night. I can’t say I blame her. I’m wondering the same thing."
    "Se aleja, probablemente preguntándose qué demonios hacen allí un San Valentín y un hispano en plena noche. No la culpo. Yo me pregunto lo mismo."

# game/act1.rpy:2599
translate spanish act1_9945e21c:

    # s smile "Ever been here before?"
    s smile "¿Has estado aquí antes?"

# game/act1.rpy:2600
translate spanish act1_46e77115:

    # a hm "Can’t say I have. You?"
    a hm "No puedo decir que lo haya hecho. ¿Y tú?"

# game/act1.rpy:2601
translate spanish act1_79b69356:

    # s "Once or twice."
    s "Una o dos veces."

# game/act1.rpy:2603
translate spanish act1_cdc60a08:

    # a "I thought you were a tourist."
    a "Pensé que eras turista."

# game/act1.rpy:2604
translate spanish act1_daffc9c7:

    # s hm "I never said that."
    s hm "Yo nunca dije eso."

# game/act1.rpy:2605
translate spanish act1_0050a61e:

    # a frown "You implied it."
    a frown "Lo diste a entender."

# game/act1.rpy:2606
translate spanish act1_2c04a831:

    # s cocky "I imply a lot of things."
    s cocky "Quiero decir muchas cosas."

# game/act1.rpy:2607
translate spanish act1_4a530c3d_3:

    # a hm "…"
    a hm "…"

# game/act1.rpy:2609
translate spanish act1_33ed8eeb:

    # "Whatever the fuck {i}that{/i} means."
    "Sea lo que sea que {i}eso{/i} signifique."

# game/act1.rpy:2613
translate spanish act1_c3490153:

    # a frown "How did you know you’d win?"
    a frown "¿Cómo supiste que ibas a ganar?"

# game/act1.rpy:2614
translate spanish act1_dc1cd401:

    # s "Hm?"
    s "¿Eh?"

# game/act1.rpy:2615
translate spanish act1_55f4c34b:

    # a "The poker game. How’d you win?"
    a "La partida de póker. ¿Cómo ganaste?"

# game/act1.rpy:2619
translate spanish act1_4a229730:

    # s "Oh, that?{w} I just got lucky."
    s "¿Ah, eso?{w} Tuve suerte."

# game/act1.rpy:2621
translate spanish act1_25a8eca1:

    # a concern "What?"
    a concern "¿Qué?"

# game/act1.rpy:2622
translate spanish act1_77e938bf:

    # s "I had no idea what was going to happen there. I figured he’d challenge me to a regular game of poker, not that four-card bullshit. But, it worked out for me in the end."
    s "No tenía ni idea de lo que iba a pasar. Pensé que me retaría a una partida de póker normal, no a esa tontería de cuatro cartas. Pero al final, todo salió bien."

# game/act1.rpy:2624
translate spanish act1_a8e3956a:

    # s "A little anticlimactic, but hey. That’s just how gambling is. Highs and lows."
    s "Un poco decepcionante, pero bueno. Así son las apuestas. Altibajos."

# game/act1.rpy:2625
translate spanish act1_d8eb5386_5:

    # a scared "…"
    a scared "…"

# game/act1.rpy:2627
translate spanish act1_e2debb73:

    # a "You risked fifty-thousand dollars on a game you weren’t even sure you’d win? How would you have paid it off if you lost?!"
    a "¿Arriesgaste cincuenta mil dólares en un juego del que ni siquiera estabas seguro de ganar? ¿Cómo lo habrías pagado si hubieras perdido?"

# game/act1.rpy:2629
translate spanish act1_86721776:

    # "Sebas just keeps on twirling the straw, an amused smile on his face as he stares at the table."
    "Sebas sigue haciendo girar la pajita, con una sonrisa divertida en el rostro mientras mira fijamente la mesa."

# game/act1.rpy:2631
translate spanish act1_ce37b945:

    # s "I have my ways. As for the risk…"
    s "Tengo mis métodos. En cuanto al riesgo…"

# game/act1.rpy:2632
translate spanish act1_2263cd3a:

    # s smile "If you don’t risk, you’re guaranteed to fail. If you do risk, there’s at least a chance you’ll win. One percent is better than zero, no?"
    s smile "Si no arriesgas, tienes garantizado el fracaso. Si arriesgas, al menos hay una posibilidad de ganar. Un uno por ciento es mejor que cero, ¿no?"

# game/act1.rpy:2634
translate spanish act1_1f0b38f8:

    # a concern "That’s... an insane mentality to have."
    a concern "Esa es... una mentalidad descabellada."

# game/act1.rpy:2635
translate spanish act1_50c44be2:

    # s flirty "Hah. Maybe. But you have to be a little crazy to gamble in the first place."
    s flirty "Ja. Tal vez. Pero hay que estar un poco loco para apostar, para empezar."

# game/act1.rpy:2637
translate spanish act1_af14fc33:

    # "The waitress comes back and sets Sebas’ pie in front of him, and he gives her a kind smile. To my surprise, she returns it, despite her grumpy demeanor."
    "La camarera regresa y coloca el pastel de Sebas frente a él, y él le dedica una amable sonrisa. Para mi sorpresa, ella le devuelve la sonrisa, a pesar de su semblante malhumorado."

# game/act1.rpy:2638
translate spanish act1_21a27e21:

    # "I watch as he shovels a large forkful of lukewarm apple pie down his maw, thinking back to our meeting at Shogey’s, then The Albatross, then in Matteo’s ring…"
    "Lo observo mientras se atiborra con un gran tenedor de tarta de manzana tibia, recordando nuestro encuentro en Shogey's, luego en The Albatross, y después en el ring de Matteo..."

# game/act1.rpy:2642
translate spanish act1_3de5b904:

    # a stan "What are you after?"
    a stan "¿Qué es lo que buscas?"

# game/act1.rpy:2644
translate spanish act1_0cc3caa6:

    # s "How do you mean?"
    s "¿Qué quieres decir?"

# game/act1.rpy:2646
translate spanish act1_e8977957:

    # a frown "You asked me for a place to gamble even though you knew about The Albatross and Corona’s. You approached me at the bar to tell me how to get inside, and then proceeded to follow me in without my knowledge."
    a frown "Me preguntaste por un lugar para apostar a pesar de que conocías The Albatross y Corona's. Te acercaste a mí en la barra para decirme cómo entrar y luego me seguiste adentro sin que yo lo supiera."

# game/act1.rpy:2647
translate spanish act1_1c24b1d1:

    # a angry "And to top it all off, spied on my poker game and saved me from the con. All of that… for what?"
    a angry "Y para colmo, espió mi partida de póker y me salvó de la estafa. Todo eso… ¿para qué?"

# game/act1.rpy:2648
translate spanish act1_62f30686:

    # a "What are you after, ‘Sebas’? Is that even your real name?"
    a "¿Qué pretendes, 'Sebas'? ¿Ese es siquiera tu verdadero nombre?"

# game/act1.rpy:2651
translate spanish act1_f5a2cffe:

    # s "Is ‘Angel’ yours?"
    s "¿'Angel' es tuyo?"

# game/act1.rpy:2653
translate spanish act1_4b6e6cdc_1:

    # a dejected "…"
    a dejected "…"

# game/act1.rpy:2654
translate spanish act1_637cdec1:

    # s lookaway "What I’m after…"
    s lookaway "Lo que busco…"

# game/act1.rpy:2656
translate spanish act1_3bc4a639:

    # "He shoves another bite of pie into his mouth, looking right back at me."
    "Se mete otro trozo de pastel en la boca, mirándome fijamente."

# game/act1.rpy:2658
translate spanish act1_6424958f:

    # s hm "I wouldn’t say I’m ‘after’ anything. But I do have a dream."
    s hm "No diría que estoy \"buscando\" nada en particular. Pero sí tengo un sueño."

# game/act1.rpy:2660
translate spanish act1_d1f43556:

    # a concern "A dream?"
    a concern "¿Un sueño?"

# game/act1.rpy:2661
translate spanish act1_8c6d0fc6:

    # s smile "Yes. Don’t you?"
    s smile "Sí. ¿Tú no?"

# game/act1.rpy:2662
translate spanish act1_2a4ff97c_14:

    # a surprised "…"
    a surprised "…"

# game/act1.rpy:2663
translate spanish act1_9fdcdf03:

    # a bashful "You’re the second person to ask me that today…"
    a bashful "Eres la segunda persona que me pregunta eso hoy…"

# game/act1.rpy:2666
translate spanish act1_d9400327:

    # a dejected "No. I don’t have a dream."
    a dejected "No. No tengo ningún sueño."

# game/act1.rpy:2667
translate spanish act1_83d61407:

    # a "I’m a Valentine. We don’t get to dream."
    a "Soy un San Valentín. No podemos soñar."

# game/act1.rpy:2668
translate spanish act1_8d51f30f:

    # s "Everyone is allowed to dream. Your thoughts are the one thing that are completely your own."
    s "Todos tienen derecho a soñar. Tus pensamientos son lo único que te pertenece por completo."

# game/act1.rpy:2670
translate spanish act1_993ceb94:

    # s "I believe you have a dream, somewhere inside you. You must be too scared to admit what it is."
    s "Creo que tienes un sueño, en algún lugar dentro de ti. Debes tener demasiado miedo para admitir cuál es."

# game/act1.rpy:2672
translate spanish act1_da553f34:

    # s "Because then… you’ll want to fight for that dream."
    s "Porque entonces… querrás luchar por ese sueño."

# game/act1.rpy:2673
translate spanish act1_1ab72481_19:

    # a concern "…"
    a concern "…"

# game/act1.rpy:2674
translate spanish act1_d19f2b16:

    # a hm "Well… what’s your dream?"
    a hm "Bueno… ¿cuál es tu sueño?"

# game/act1.rpy:2676
translate spanish act1_098210d1:

    # s lookaway "My dream…"
    s lookaway "Mi sueño…"

# game/act1.rpy:2678
translate spanish act1_4c3e40c5:

    # "He looks out the window to the deserted streets of Sonora… or, maybe at his own reflection against the glass. I’m not sure. But his eyes keep that razor sharp focus they always seem to have."
    "Mira por la ventana las calles desiertas de Sonora… o tal vez su propio reflejo en el cristal. No estoy seguro. Pero sus ojos conservan esa mirada penetrante que siempre parecen tener."

# game/act1.rpy:2681
translate spanish act1_ee7d02fe:

    # s stan "My dream…{w} is to destroy Corona’s Casino."
    s stan "Mi sueño…{w} es destruir el Casino de Corona."

# game/act1.rpy:2684
translate spanish act1_876081e6:

    # "And then he takes another bite, as if he didn’t just say that."
    "Y luego da otro bocado, como si no acabara de decir eso."

# game/act1.rpy:2691
translate spanish act1_f453af24:

    # "We spend the rest of our time there in silence. I offer to pay Sebas for the pie, as a thank you for saving me, but he simply shoos me away. Something about being a gentleman."
    "Pasamos el resto del tiempo allí en silencio. Me ofrezco a pagarle a Sebas el pastel, como agradecimiento por haberme salvado, pero él simplemente me despide. Algo sobre ser un caballero."

# game/act1.rpy:2692
translate spanish act1_140cfe4a:

    # "We walk outside again, and Sebas stays by my side as we wait for a cab to pass by. I’m exhausted, my brain feels foggy, and my nerves are at high alert. I feel like my entire body is buzzing with anxiety."
    "Salimos de nuevo y Sebas se queda a mi lado mientras esperamos a que pase un taxi. Estoy agotada, mi mente está nublada y mis nervios están en alerta máxima. Siento que todo mi cuerpo vibra de ansiedad."

# game/act1.rpy:2693
translate spanish act1_e59a4cf9:

    # "I sneak a glance at the wolf next to me, wondering when the hell I got caught in his web. There’s more, so much more I want to talk about, to ask, to wring out of him… but I know I can’t right now."
    "Miro disimuladamente al lobo que tengo al lado, preguntándome cuándo demonios caí en su trampa. Hay mucho más, muchísimo más de lo que quiero hablar, preguntarle, sonsacarle… pero sé que ahora mismo no puedo."

# game/act1.rpy:2695
translate spanish act1_e32b913d:

    # "A cab finally stops in front of us, and Sebas opens the back door for me. I’m about to slip inside the taxi when he and I lock eyes… {w}and my heart skips a beat."
    "Finalmente, un taxi se detiene frente a nosotros y Sebas me abre la puerta trasera. Estoy a punto de entrar al taxi cuando nuestras miradas se cruzan… {w}y mi corazón da un vuelco."

# game/act1.rpy:2697
translate spanish act1_7354f530:

    # "Sebas… those eyes seem to hold a familar sadness behind them. Why do I feel like I've seen them before?{w} What secrets lie beyond that smile?"
    "Sebas… esos ojos parecen esconder una tristeza familiar. ¿Por qué tengo la sensación de haberlos visto antes? ¿Qué secretos se esconden tras esa sonrisa?"

# game/act1.rpy:2699
translate spanish act1_2350b82d:

    # "And why do I want to find out?"
    "¿Y por qué quiero averiguarlo?"

# game/act1.rpy:2702
translate spanish act1_9cea01bb:

    # a worried "Sebas…?"
    a worried "¿Sebas…?"

# game/act1.rpy:2703
translate spanish act1_a98b773d:

    # s smile "Yes, {i}chele?"
    s smile "Sí, {i}chele?"

# game/act1.rpy:2706
translate spanish act1_44afa7d6:

    # a concern "Your dream…{w} I want to help make it a reality."
    a concern "Tu sueño…{w} Quiero ayudarte a hacerlo realidad."

# game/act1.rpy:2708
translate spanish act1_2d4376b0_4:

    # s "…"
    s "…"

# game/act1.rpy:2710
translate spanish act1_10860cc7:

    # "The words slip out of my mouth before I can stop them, and as I’m left wondering why I even said that, Sebas just smiles at me."
    "Las palabras se me escapan de la boca antes de que pueda detenerlas, y mientras me pregunto por qué dije eso, Sebas simplemente me sonríe."

# game/act1.rpy:2712
translate spanish act1_6162e889:

    # s flirty "Yeah? Well… I’ll be counting on you then, {i}chele."
    s flirty "¿Sí? Bueno… entonces contaré contigo, {i}chele."

# game/act1.rpy:2713
translate spanish act1_06f39335_6:

    # a stan "…"
    a stan "…"

# game/act1.rpy:2718
translate spanish act1_deb8044f:

    # "As the driver takes me home, Corona’s peeks through the cluster of buildings in this dark city, making its presence known at every possible second of my existence."
    "Mientras el conductor me lleva a casa, el Corona se asoma entre el conjunto de edificios de esta ciudad oscura, haciendo notar su presencia en cada segundo posible de mi existencia."

# game/act1.rpy:2719
translate spanish act1_4f19e8a8:

    # "Mr. Gray must be in there now, sitting in his big, fancy desk, doing whatever it is that billionaires do in their free time. Is he thinking of me, the way I am thinking of him now?"
    "El señor Gray debe estar ahí dentro ahora mismo, sentado en su gran y elegante escritorio, haciendo lo que sea que hagan los multimillonarios en su tiempo libre. ¿Estará pensando en mí, como yo estoy pensando en él ahora?"

# game/act1.rpy:2720
translate spanish act1_955e99a8:

    # "The offer to change my life seemed so ludicrous at the time. Now I wonder… if I should have taken it after all?"
    "La oferta de cambiar mi vida me pareció tan absurda en aquel momento. Ahora me pregunto… ¿debería haberla aceptado?"

# game/act1.rpy:2722
translate spanish act1_ff41eb96:

    # "I guess it doesn’t matter anymore."
    "Supongo que ya no importa."

# game/act1.rpy:2725
translate spanish act1_21c30658:

    # "After all... {w}this game has only just begun."
    "Después de todo... {w}este juego apenas ha comenzado."

# game/act1.rpy:2727
translate spanish act1_b6238fae:

    # "{i}To Be Continued…"
    "{i}Continuará…"

