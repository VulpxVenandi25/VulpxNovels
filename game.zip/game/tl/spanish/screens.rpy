﻿translate spanish strings:

    # game/screens.rpy:251
    old "Back"
    new "Atrás"

    # game/screens.rpy:252
    old "History"
    new "Historia"

    # game/screens.rpy:253
    old "Skip"
    new "Saltar"

    # game/screens.rpy:254
    old "Auto"
    new "Auto"

    # game/screens.rpy:255
    old "Save"
    new "Guardar"

    # game/screens.rpy:256
    old "Q.Save"
    new "Q.Guardar"

    # game/screens.rpy:257
    old "Q.Load"
    new "Carga Q"

    # game/screens.rpy:258
    old "Prefs"
    new "Prefs"

    # game/screens.rpy:276
    old "Menu"
    new "Menú"

    # game/screens.rpy:315
    old "Return"
    new "Volver"

    # game/screens.rpy:319
    old "Start"
    new "Comenzar"

    # game/screens.rpy:321
    old "Main Menu"
    new "Menú Principal"

    # game/screens.rpy:324
    old "Load"
    new "Carga"

    # game/screens.rpy:327
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:330
    old "About"
    new "Acerca de"

    # game/screens.rpy:333
    old "Quit"
    new "Salir"

    # game/screens.rpy:575
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:582
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t] \n\nGame by {a=https://twitter.com/konpeitocat}Konpeito{/a} \n\nMusic:\n'dans la nuit' - Fred Irie \n'last hours' - Qazers \n'EARLY SUMMER' - Tokyo Music Walker \n'Casino Jazz' - Pink Banana \n'STARLIGHT' - Prod.RYOICHI! \n'think of you' - sickboi \n'Noire #1' - MusicByPedro \n'want u to know' - connor \n'Evidence' - soundridemusic \n'Velvet' - Oak Studios \n'jupiter' - prod. phil! \n'moonlight' - waves \n'Noire #3' - MusicByPedro \n'A World of Blue (Instrumental' - Matthew Pablo \n'I Remember' - Giorgio Di Campo \n'Dinero' - Crue Beats \n\n\nSpecial Thanks to: \nTeirisu Reynard \nLost Fox \nArkynAlvarez \nMary \nKusabi \ndel \nYoDatsCrazy \nAlastor TND \nLaz \nTheHWolf94 \nZIHE WANG \n Easton Euros \nsandpeach \nSnowflake22245 \nGirrith \nPlor \nDaniel \nJonathan Buffoni \nBrxce \nOceanBlu \nAriadne \nAl \nFirstGuard \ntiddy_boi \nomndragon"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t] \n\nJuego de {a=https://twitter.com/konpeitocat}Konpeito{/a} \n\nMúsica:\n'dans la nuit' - Fred Irie \n'last hours' - Qazers \n'EARLY SUMMER' - Tokyo Music Walker \n'Casino Jazz' - Pink Banana \n'STARLIGHT' - Prod.RYOICHI! \n'think of you' - sickboi \n'Noire #1' - MusicByPedro \n'want u to know' - connor \n'Evidence' - soundridemusic \n'Velvet' - Oak Studios \n'jupiter' - prod. phil! \n'moonlight' - ondas \n'Noire #3' - MusicByPedro \n'A World of Blue (Instrumental' - Matthew Pablo \n'I Remember' - Giorgio Di Campo \n'Dinero' - Crue Beats \n\n\nAgradecimiento especial a: \nTeirisu Reynard \nLost Fox \nArkynAlvarez \nMary \nKusabi \ndel \nYoDatsCrazy \nAlastor TND \nLaz \nTheHWolf94 \nZIHE WANG \n Easton Euros \nsandpeach \nSnowflake22245 \nGirrith \nPlor \nDaniel \nJonathan Buffoni \nBrxce \nOceanBlu \nAriadne \nAl \nPrimera Guardia \ntiddy_boi \nomndragón"

    # game/screens.rpy:620
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:620
    old "Automatic saves"
    new "Guardado automático"

    # game/screens.rpy:620
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:663
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:663
    old "empty slot"
    new "espacio vacío"

    # game/screens.rpy:684
    old "<"
    new "<"

    # game/screens.rpy:688
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:691
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:701
    old ">"
    new ">"

    # game/screens.rpy:706
    old "Upload Sync"
    new "Cargar Sincronización"

    # game/screens.rpy:713
    old "Download Sync"
    new "Descargar Sincronización"

    # game/screens.rpy:777
    old "Display"
    new "Mostrar"

    # game/screens.rpy:778
    old "Window"
    new "Ventana"

    # game/screens.rpy:779
    old "Fullscreen"
    new "Pantalla Completa"

    # game/screens.rpy:784
    old "Unseen Text"
    new "Texto no visto"

    # game/screens.rpy:785
    old "After Choices"
    new "Después Elecciones"

    # game/screens.rpy:786
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:789
    old "Menu Theme"
    new "Tema Menú"

    # game/screens.rpy:793
    old "Default"
    new "Por defecto"

    # game/screens.rpy:804
    old "Language"
    new "Idioma"

    # game/screens.rpy:805
    old "English"
    new "Inglés"

    # game/screens.rpy:806
    old "Spanish"
    new "Español"

    # game/screens.rpy:807
    old "Italian"
    new "Italiano"

    # game/screens.rpy:817
    old "Text Speed"
    new "Velocidad Texto"

    # game/screens.rpy:821
    old "Auto-Forward Time"
    new "Avance automático"

    # game/screens.rpy:828
    old "Music Volume"
    new "Volumen Música"

    # game/screens.rpy:835
    old "Sound Volume"
    new "Volumen Sonido"

    # game/screens.rpy:841
    old "Test"
    new "Prueba"

    # game/screens.rpy:845
    old "Voice Volume"
    new "Volumen Voz"

    # game/screens.rpy:856
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:975
    old "The dialogue history is empty."
    new "El historial de diálogos está vacío."

    # game/screens.rpy:1038
    old "Help"
    new "Ayuda"

    # game/screens.rpy:1047
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1048
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:1051
    old "Gamepad"
    new "Gamepad"

    # game/screens.rpy:1064
    old "Enter"
    new "Ingresar"

    # game/screens.rpy:1065
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1068
    old "Space"
    new "Espacio"

    # game/screens.rpy:1069
    old "Advances dialogue without selecting choices."
    new "Avanza en el diálogo sin seleccionar opciones."

    # game/screens.rpy:1072
    old "Arrow Keys"
    new "Teclas de flecha"

    # game/screens.rpy:1073
    old "Navigate the interface."
    new "Navega por la interfaz."

    # game/screens.rpy:1076
    old "Escape"
    new "Escapar"

    # game/screens.rpy:1077
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # game/screens.rpy:1080
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1081
    old "Skips dialogue while held down."
    new "Omite los diálogos mientras se mantiene pulsado."

    # game/screens.rpy:1084
    old "Tab"
    new "Tab"

    # game/screens.rpy:1085
    old "Toggles dialogue skipping."
    new "Activa o desactiva la omisión de diálogos."

    # game/screens.rpy:1088
    old "Page Up"
    new "Página arriba"

    # game/screens.rpy:1089
    old "Rolls back to earlier dialogue."
    new "Vuelve al diálogo anterior."

    # game/screens.rpy:1092
    old "Page Down"
    new "Página abajo"

    # game/screens.rpy:1093
    old "Rolls forward to later dialogue."
    new "Avanza hasta un diálogo posterior."

    # game/screens.rpy:1097
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1101
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1105
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa/desactiva la función de {a=https://www.renpy.org/l/voicing}autovoz{/a} asistida."

    # game/screens.rpy:1109
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1115
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1119
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1123
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1127
    old "Mouse Wheel Up"
    new "Rueda del ratón hacia arriba"

    # game/screens.rpy:1131
    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    # game/screens.rpy:1138
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1142
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nHombro izquierdo"

    # game/screens.rpy:1146
    old "Right Shoulder"
    new "Hombro derecho"

    # game/screens.rpy:1150
    old "D-Pad, Sticks"
    new "Cruceta, joysticks"

    # game/screens.rpy:1154
    old "Start, Guide, B/Right Button"
    new "Inicio, Guía, Botón B/Derecho"

    # game/screens.rpy:1158
    old "Y/Top Button"
    new "Botón superior Y"

    # game/screens.rpy:1161
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1226
    old "Yes"
    new "Sí"

    # game/screens.rpy:1227
    old "No"
    new "No"

    # game/screens.rpy:1273
    old "Skipping"
    new "Saltando"

