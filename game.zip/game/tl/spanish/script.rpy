﻿# game/script.rpy:461
translate spanish start_228acfba:

    # "Hi! I'm Vulpx, the person who translated this novel. I hope you enjoy the experience."
    "¡Hola! Soy Vulpx, la persona que tradujo esta novela. Espero que disfrutes de la experiencia."

# game/script.rpy:462
translate spanish start_f4a59e50:

    # "If you want to know more about my work, you can follow me on {a=https://x.com/VulpxVenandi25}{color=#00acee}Twitter{/color}{/a} or visit my {a=https://vulpxvenandi25.github.io/}{color=#004030}Website{/color}{/a}."
    "Si quieres saber más sobre mi trabajo, puedes seguirme en {a=https://x.com/VulpxVenandi25}{color=#00acee}Twitter{/color}{/a} o visitar mi {a=https://vulpxvenandi25.github.io/}{color=#004030}Sitio web{/color}{/a}."

# game/script.rpy:463
translate spanish start_e5949be7:

    # "You can also support me with a donation at my {a=https://ko-fi.com/vulpxvenandi25}{color=#FF5E5B}Ko-fi{/color}{/a}."
    "También puedes apoyarme con una donación en mi {a=https://ko-fi.com/vulpxvenandi25}{color=#FF5E5B}Ko-fi{/color}{/a}."

# game/script.rpy:464
translate spanish start_f1450563:

    # "And without further ado, I leave you with this novel called \"[config.name]\"."
    "Y sin más preámbulos, los dejo con esta novela titulada \"[config.name]\"."
