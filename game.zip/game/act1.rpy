﻿label act1:
stop music fadeout 1.0
pause 2.0

centered "{i}Why…?"
pause 1.0
play music dissonance 
"Within the city limits of Sonora, the people who reside here live and die by its motto: ‘Turn a penny into a million!’."
"That’s right – even I started to foolishly believe it. That everyone within these lines was intellectual equals, and that all it took to become someone grand and elite was a little perseverance, a bit of skill… and a lot of luck."
"That, in the ocean of lights, in the sea of people, I could escape the bounds of being nothing more than a minnow, pulled by the current and helplessly toyed with by the sharks of this world."
"But, just like sharks, the elites of this city can’t stop moving, even for a second. Those who do meet the same fate as their aquatic counterparts."
"And that meant the most dangerous enemy to a shark, who cannot sleep… is the foolish minnow who dares to dream."
pause 1.0
centered "{i}So, why…?"
show 1-matt with dissolve 
tr_text "Well, then. That’s… how much? Oh, right…"
window hide None  
show 1-ang with dissolve 
tr_text2 "Twelve-thousand dollars. You have the money, don’t you?"
tr_text3 "Aw, don't look so distraught. \nSorry to clip your wings, Valentine."
tr_text "But you really should’ve known better~"
window hide None  
hide 1-matt
hide 1-ang
with dissolve
"…or so I thought."
"But sometimes, a fool isn’t a visionary, a secret genius whose ways of thinking defy the norm and set you free."

centered "Why… was I so stupid?!"

pause 2.0
"Sometimes… {w}a fool is just a fool."
stop music fadeout 2.0
pause 3.0
centered "24 hours earlier.{w}\nHanasaka Bar & Inn"
pause 0.7
show baroutnight with fade 
play music rain 
"Light reflects from the rain-soaked asphalt like a hazy mirror, rippling on occasion from the droplets still falling to the ground."
"The signs hanging overhead are a bright, deep red, making my fur shine pink in its neon glow. I bathe in it, lingering for just a second longer than I know I should."
"Maybe it suits me. At least, more than white does... God knows I don’t match the purity my snow-colored fur exudes."
pause 1.5
"I’m stalling."
"I know I am, but even so, I let myself stay still for a few seconds longer, steeling myself for the exchange that’s to come."
"I should be used to it by now. Interviewing is my least favorite part of my job, but it’s also the most important. So, I do what I always do: I swallow down my own desires and focus on what needs to be done."
"With one last exhale, I put my best poker face on and enter the bar."
stop music fadeout 1.0
hide baroutnight with dissolve 
show hanasaka with fade 
play music fancy 
"It’s cold inside, contrasting the humid post-rain air of the city streets. Someone plays a piano quietly across the bar, and idle chatter resonates throughout the room."
"It’s fancier than the bars I’m accustomed to, but I relax my shoulders, casually scanning the room while I pretend to fit right in with these higher-class people."
"It doesn’t take long to find him. Sitting alone in a corner booth, drinking what appears to be whiskey, Mr. Yoshida stares out the rain-splattered window, deep in thought. I quietly walk towards him, and without a word, slip into the booth in front of him."

a uniform stan "…"

"Although I’m certain he knows I’m here, he doesn’t turn to face me, his eyes fixed outside in a trance-like state. I clear my throat to get his attention. If he’s dragging this out on purpose, I want none of it."
"He finally turns to look at me, a far-off look in his eyes as he measures me up, his gaze locked on me."
show y clothes stan with dissolve 
y "Ah… good evening, Valentine. A pleasure to finally meet you."
a "{i}Yoroshiku onegai shimasu, Mr. Yoshida."
show y smile 
"He smiles, genuinely, and chuckles as he brings the glass to his maw."

y "{i}Kochira koso… Yoru ga ii janai ka?"
pause 1.5
show y surprised 
a bashful "U-um… sorry. ‘Nice to meet you’ and ‘Where’s the bathroom?’ are kind of the extent of my Japanese."
y cocky "Hah! Of course. My apologies. I simply said that tonight’s a nice night, isn’t it?"
show y smile 
"I glance out the window. Steam rises from the ground as the cold rain meets the hot asphalt, and a small stream of dirt-colored water flows down the sidewalk."
show y stan 
a stan "…if you think so."
y hm "You don’t?"
a frown "I’m not a fan of the rain."
y smile "Hm~ I welcome it. It almost feels like someone up above is trying to wash this city free of sin."
y "Though, it may need to rain much longer for that to happen."
a stan "Hm."
show y sweet 
"He gives me a knowing smile, dripping with fake nicety."

y smile "Of course. You Valentines are all the same. All business, no pleasure."

"He leisurely takes out a cigar from his coat pocket, taking his time lighting it and sucking in a few puffs, his glassy eyes locked on me the whole time as he exhales the smoke against the window."

y "Well, then."
pause 0.7
y stan "Talk."
a "…{w}right."

"I slide my voice recorder and notebook onto the table, pen in hand, mirroring his stare."
pause 1.5
"He blinks.{w} I blink back."
pause 2.0
a frown "Megumi Yoshida went missing on March 21st of this year, approximately three months ago. Her last whereabouts are unknown, and the cause of her disappearance has also been questioned."
pause 1.5
y frown "Yes. I’m quite aware of all this, Valentine."

"He almost hisses this out, the pleasantness he once evoked now nowhere to be seen behind his glare." 
"I swallow hard.{w} I was never any good at stating the facts."

a worried "Right… of course. Moving on…"
a concern "The police reports I’ve been granted are full of confidential information. That is to say, I haven’t gotten very far with them."
a frown "I have little information about her disappearance, and even less about her life before that. Considering you’re the only family member listed on her records, I was hoping you could shed some light on who she was."
a worried "Perhaps it could help us find her."
y stan "…"

"He lets out another puff of smoke, tapping the table with one finger, staring at my hand holding the pen. I try to hide my shakiness, but something tells me he’s caught onto it."
pause 1.5
y frown "Don’t hide your questioning behind a façade of kindness, Valentine. It doesn’t suit your kind."
a frown "…I assure you, that’s not what I’m doing."
y smile "Heh. Of course."
show y stan 
pause 1.5
y "Megumi was-{w} is… my niece."
y ponder "My brother’s daughter. After his passing, he entrusted her and her brother to me. In a lot of ways, I’m more like her father than her uncle. But that’s a position I could never take."
show y stan 
"His gaze returns to the outside, and I take the opportunity to jot some things down. To say I’m surprised he’s opening up to me so easily is an understatement, but I make sure to not let it show on my face."
"He continues."

y "She was always a troublesome kid. Mixing with the bad crowds, no matter how many times I scolded her. She never learned… or perhaps she simply chose not to listen."
a surprised "What kind of bad crowds?"
y "…"
y frown "She loved to roughhouse with boys. Pull pranks on teachers. It started off innocent in that way."
y "But then she grew up."
show y ponder 
pause 1.5
y stan "It was one vice after the other. First it was smoking, which I’m sure she caught from me. Then, it was liquor."
pause 2.0
y frown "And then…{w} it was gambling."
pause 2.0
"My fur stands on end."
a concern "…gambling?"
y ponder "Yes. Gambling."
y stan "You’re aware, aren’t you, Valentine? The heart of this city is gambling. The casinos are the veins, and money, the blood."
y "I figured that since she never knew poverty, never went hungry, she wouldn’t be interested in such an activity as foolish as that."
pause 2.0
y frown "How wrong I was.{w} It's the rich who crave to use their money in such ways, not the poor. I see that now..."
y "Megumi lived to gamble. It was casino after casino… each one that kicked her out, she’d just find a new one, and if there weren’t any left, she’d find a more illegal way of doing it."
y surprised "It was her drug, her breathing. The money we had saved for her to study… was gone in a matter of months."
y frown "It’s one thing to be a gambler. It’s another thing to be a {i}terrible{/i} gambler."

"He lets his cigar keep burning out, unable to put it back onto his lips."

y ponder "That…"
pause 2.0
y stan "Is all I feel like sharing with you today, Valentine."
a worried "…"
a "Could you please just tell me… where you last saw her?"
y "…"
pause 2.0
y frown "In my house.{w} Two years ago."
y stan "She moved out. And I never saw her again."
y ponder "Until her picture showed up on the news."
pause 1.5
show y stan
a "I’m… terribly sorry, Mr. Yoshida."
y ponder "Don’t be."
y frown "If she chose to be insolent and reckless, then whatever fate she met was what she deserved."

"His voice doesn’t waver when he says this. Yet, somehow, I don’t believe he truly means it."
show y stan 
"I close my notebook, sighing quietly through my nose. Although there’s still a lot I’d like to ask, I decide not to push my luck. Any information is good information, and I’ll just have to make do with what I have."

a frown "Well, I appreciate you giving me your time, Mr. Yoshida. I promise you; I’m doing what I can to try and bring this story to light."
show y cocky 
"He sneers at me, a cynical air to his grin."

y "I don’t doubt that. I’m sure this ‘story’ is of utmost importance to you."
y "After all, you get a nice reward if you solve it, don’t you?"
a surprised "…"
a worried "Like I said, Mr. Yoshida, that has nothing to do with my desire to find Ms. Megumi."
pause 1.5
y smile "Lying doesn’t suit you, Valentine. Perhaps it’s a good thing you, of all people, don’t gamble."

"I inhale sharply, feeling flustered. Just who does this old man think he is, anyway? And more importantly, what makes him think he knows me so well?"
show y stan 
"I get up, tucking my things into my bag and giving him a halfhearted bow."

a frown "Have a good rest of your evening, Mr. Yoshida."
show y frown 
"I start to head towards the doorway, but as I pass his side of the booth, his hand latches onto my wrist, making me freeze in place. He looks at me through the corner of his eyes, dark and elusive, and panic starts to form in my stomach."

y "I don’t believe you expected this chat without any sort of incentive for me… did you, Valentine?"
a concern "Incentive?"
y "I’m a very busy man, as I’m sure you’re aware of. I don’t just organize meetings without some sort of gain on my end."
show y stan 
"His grip on my wrist relaxes in an instant, his fingers starting to delicately trace the inside of my palm in an almost… {i}seductive{/i} way."

y "Tell me… how do you plan on repaying my time?"
a flustered "…"
a "I-"
show y surprised 
"I’m about to come up with some excuse when a heavy hand falls on my shoulder, and a familiar body presses against me."

e "Mr. Yoshida. Fancy running into you here."
show y surprised at slightleft with move
show e uniform stan at slightright with dissolve 
"Ethan’s voice comes from behind me, his voice full of that authoritarian tone he reserves for everyone but me.{w} His grip on me tightens somewhat."
show y frown
pause 2.0
y smile "Officer Hutcherson. I’m surprised you’re still working this late."
e smile "Just had some business with… this Valentine here."
"My eye twitches."
e "I’ll be heading home soon."
show y stan 
e stan "Maybe you should, too. This side of the neighborhood isn’t very safe at night."
y "I’m well aware."
show y cocky 
"Mr. Yoshida turns his attention to me now, that same sneer on his face."
show e frown 
y "You poor thing. They have such a short leash on you. I didn’t know Valentines had a curfew."
a frown "…"
y smile "Oh, well. Figures as much."

"He finally lets go of my hand, grabbing his glass again."

y "All business, no pleasure."
pause 2.0
e "You have a nice rest of your evening, Mr. Yoshida."
"Without another word, Ethan ushers me towards the exit, leaving Mr. Yoshida alone in the dim bar."
stop music fadeout 1.0
hide e frown
hide y smile
hide hanasaka 
with dissolve 
show carinsidenight with fade 
play music rain 
"In the passenger seat of Ethan’s car, I watch as the city lights blur and blend into one another, and from the corner of my eye, his stoic stare focuses on the road. Anger flushes against my face, in a slow, uncomfortable way."
pause 3.0
a frown "I didn’t need you to come pick me up."
pause 1.5
a "I could’ve handled it."
e "Sure you could’ve."
a angry "I’m serious."
"I practically hiss this."
a "Why do you feel the need to babysit me? Maybe I should just stop telling you where I’m gonna be."
e "You know I’d still be able to find you."
"I scoff at him."
a "Are you that desperate to control me?"
e "You know that’s not what I’m doing."
a "That’s exactly what it feels like to me."

"He lets out a heavy sigh, clearly exhausted, but I don’t let him off the hook so easily."
a hm "{i}It’s about the principle. I didn’t ask for his help."
a pout "{i}…even if I might have needed it…"
stop music fadeout 2.0
hide carinsidenight wityh dissolve 
"The car comes to a stop, right in front of Ethan’s apartment complex. I shoot him a nasty look, and he puts his hands up, feigning innocence."

e "Just come inside for a minute. I promise I’ll take you home after."
a hm "…"
pause 1.5
a hmph "Fine. But you’re ordering takeout."

"He finally cracks a smile, realizing I’m not as mad as he thinks I was, and drops his hands back to his lap."

e "Deal."
show eapartment with fade 
play music familiar 
"There’s a certain vibe to Ethan’s apartment that I haven’t been able to pinpoint for as long as I’ve been here."
"On one hand, it’s pretty sad; it’s your stereotypical bachelor pad. Posters of TV shows I’ve never had the time to watch, empty bottles of beer and soda on his coffee table, that damn prehistoric radio that never wants to turn on."
"But, on the other hand… it’s cozy. It’s familiar, and the area has a distinct smell of something foreign, but nice. It’s the kind of place I’d like to stay in more often… and call home."
"Unfortunately, that kind of wishful thinking never does me any good. I shake the thought away, walking deeper into the apartment, my hands tracing the radio as Ethan takes off his vest."
"I push the button to turn it on… to no response."
show e uniform hm with dissolve 
a bored "Of course."
e "What?"
a hm "Your radio doesn’t work. I keep telling you to throw the damn thing out."
e "What’re you talking about? It works fine."
"He comes over and presses the button again, to the same response."
show eapartment at jumping
show e smile 
play sound thump 
"He then gives the top of the radio a fierce {i}SMACK{/i} that makes even me jump, and suddenly, the radio sputters its first words, full of static."

e cocky "Ehh?~"
a bashful "R-right… I’d rather not have to beat up my appliances every time I want to use them."
e "See, that's the difference between you and me. You're just too much of a softy."
a "If that’s what you wanna call it."
show e smile 
"I sit on his couch with a sigh, crossing my arms and eyeing him as he steps in front of me, hands on his hips."
show e surprised 
a pout "…"
e hm "…"
a hmph "Hmph."
e uh "Don’t give me that."
a superhmph "Hmmmmph."
e hm "Fine. Pout all you want. I’m not apologizing."
e surprised "And I guess you don’t want to see what’s inside my bag tonight…"
a surprised "…"
a excited "Is it a present?"
e smile "Of sorts."

"He carefully takes out a stack of folders that I recognize to be straight from the police station, and my eyes light up at the sight of them."
show e cocky
a surprised "That’s not-?"
e "It might be."
a "How did you get those?"
e "I pulled a few strings… called in a favor. It wasn’t that hard. I’ll put it back first thing tomorrow, no one will know."
show e surprised 
"He tucks them back inside, sighing dramatically."

e pout "Oh, but you’re too upset to even think about reading all of this. Much less accept it from me, who you so obviously hate now…"
show e hm 
a flustered "I don’t hate you! I, uh, love you! So~ much…!"
e "Uhuh."
a excited "Come on~ I swear I’m not even mad anymore. Just gimme the files!"
e frown "Say thank you first."
a concern "For what?!"
e hm "The files. AND saving you."
a concern "…"
a pout "Thank you for saving me and getting me the files…{w} {size=*0.5}hoe."
e frown "What was that?"
a eyeroll "I said ‘bro’. Geez."
pause 2.0
e hm "Fine. Here."

"He finally hands me the files, and a quick flip to the first page tells me this is the jackpot:{w} {i}{b}Megumi Yoshida – Missing Person Case."

e "Knock yourself out. I’ll order the food. Is Chinese okay?"
a excited "Yeah yeah, fine…"
show e flattered 
"He chuckles, shaking his head and disappearing into the kitchen."
hide e flattered with dissolve 
a surprised "…"
stop music fadeout 1.5

"I take a deep breath, excitement coursing through my fingertips as I rub the sheets of paper in my hands. Any information is good information, and this seems like it’ll be {b}very{/b} good."
play music piano 
"The first page reveals Megumi’s personal case file. It’s nothing I hadn’t seen before, but this seems to be the original copy without all of the redacted information."
"Extra notes have been added to the bottom of the page, detailing the exact time and area she was last seen on a security camera.{w} But why would it be redacted on my copy?"

a hm "{i}'Footage courtesy of C.C.’ Who is that?"

"The next page holds Megumi’s criminal record. Petty theft, assault charges, D.U.I.’s. Minor offenses in the grand scheme of things."
"Unfortunately, there aren’t many details of these charges, and it seems like she only served minor jail time. Looks like she was bailed out every time."

a hm "{i}Must be nice having a rich family. All those mistakes, and never any responsibility for the consequences."

"I flip over to the next page…"

"…and my heart skips a beat."

a concern "{i}Corona’s…"

"Photos of her walking out of Corona’s Casino on the last day she was seen litter the page, and I now realize why they redacted that little detail out."
"Valentines aren’t allowed to enter casinos, full stop. And that’s especially true for Corona’s."
pause 1.5
"That being said… this is big. Very big. Is the S.P.D. hiding this from every major news outlet?"

"I flip the page over, revealing a complete stranger’s personal file. ‘James Smith’."

a eyeroll "{i}Bleh. Might as well be called ‘John Doe’."

"I’m confused as to why it’s here, until I reach the bottom of the page; {i}’Gone missing. Last seen September 24th at 8:16 p.m.{w} Images courtesy of C.C.'"

a angry "…what the hell?"

"A missing person case six months prior to this one that I had zero knowledge about, and they’re both last seen in the same location? That can’t be coincidence, can it?"
"I take a look at the files attached to it, and the similarities are uncanny: A criminal record of small crimes, followed by pictures of his last sighting in the casino."
"A knot starts to form in my stomach."
pause 1.5
a concern "{i}What am I going to do…?"
stop music fadeout 2.0
hide eapartment with dissolve
show ekitchen 
show e uniform worried
with dissolve 
"I find Ethan slumped over his kitchen table, a frown on his face as he mulls over a set of files of his own, drumming his fingers against the wooden surface over and over again."
"I place a hand on his shoulder, and it only seems to tense up even more."
play music moments 
a worried "Hey."
e "Hey."
a hm "What’s that?"

"A quick glance tells me it’s a long-written report on some suspect. Nothing of my concern."

e uh "Just some shit I’ve had to deal with for a while. Some guy who’s running around, entering bars and clubs with several fake I.D.’s and somehow getting away with it."
show e hm 
"He sighs and rubs his temples, which prompts me to start rubbing his shoulders to ease him a bit."

a flattered "Hey, it’ll be fine. Entering a club with a fake I.D. is like, a rite of passage for the average citizen, right?"
e "Yeah, but this guy’s… different. Somehow."
a "Well, it’s nothing you can’t leave for tomorrow."
e uh "…maybe you’re right."
show e sigh 
"He finally relaxes a bit, but the firmness of his shoulders remains the same under the pressure of my fingers."

e flattered "Were the files any good?"
show e hm 
a bashful "They, uh… were. Yeah."
e "That’s not convincing."
a "It’s a little complicated."
e "How so?"
pause 2.0
show e surprised 
a worried "Corona’s is involved."
pause 2.0
e "Oh."
pause 1.5
e hm "Well, shit."
a flattered "Yeah. Exactly."
e worried "What are you gonna do?"
a worried "I’m not sure… maybe ask the staff when they have days off? I’ll have to find their schedules… which could be tedious. But, doable, I guess."
e hm "And you think that’ll help?"
a surprised "Maybe."

"The lie comes out quick, hoping he’d somehow believe me. The truth is, I don’t believe for a second that’ll work, but I don’t have many other options, do I?"

e "And if it doesn’t?"
pause 1.5
a cocky "Then… I’ll sneak my way inside and get some intel. Super-Secret-Spy style."
e "…"
a bored "That was a joke. Laugh."
e frown "I don’t find that funny."
a eyeroll "Ugh. You’re such a buzzkill. I was kidding."
e "Not completely."
a pout "…"
a concern "Yeah, well, this is a really important story. People are going missing, Ethan. It’s not something I can just sweep under the rug."
show e hm 
a surprised "And besides… do you have any idea the commission I’ll make if we can actually track down Megumi?"
a excited "That would be enough to go to Vienna for a full week at a {i}fancy{/i} hotel. Imagine!"
e "I know you want to go visit your mom, but the casino doesn’t play those kinds of games, Angel. If they find out you’re sneaking inside, snooping around, they’re gonna screw your ass."
show e surprised 
a silly "My ass has been needing a good screwing, anyway."
e frown "Angel."
a smile "All I’m saying is it’s not anything I can’t handle."
e "It’s a bad idea."
a excited "I’ll be super careful. I’ll check out the area, talk to a few people, and then-"
stop music fadeout 1.0 
e angry "Why can’t you just take the shit that I tell you seriously for once?!"
pause 2.5
a surprised "…"
e concern "…"
a dejected "…"
pause 2.0

"I mumble an apology, shame bubbling inside me as I start to back away, when his hands quickly grab onto my waist, pulling me over to him."

e "Hey, no. I’m sorry. Don’t go."
show e concern at center:
 yalign -0.1
 ease 0.8 zoom 2.0
"He envelops me in his arms, hugging me against him and burying his face against my stomach, squeezing me in one of his tight embraces."
play music soft
e worried "I’m sorry… I didn’t mean to yell."
pause 2.0
a worried "I… I-It’s okay…"
e sigh "I’m tired, a-and stressed, and-"
show e worried 
a "It’s okay, Ethan. Seriously."
pause 2.0
e concern "It’s just…{w} you’re one of the few things I care about in this city. If something happened to you… if I somehow lost you…"
e "I don’t know what I’d do."
a surprised "…"
show e worried 
"The silent rage boiling inside me quickly dissipates into nothing, and I hold Ethan closer to my body, cradling his giant head in my arms."

a sad "I know. I’m sorry."
e "…"
e "Just… be careful, Angel. Nothing good can come of you messing with that side of this city."
pause 2.0
a flattered "Yeah. I promise... I’ll be careful."
show e surprised 
"He looks up at me, and when our eyes lock, something inside me stirs. Something familiar."
show e frown 
"We stay that way, staring into each other, neither one of us moving an inch, daring to breathe or even blink."
show e surprised at jumping 
pause 2.0
e "That’s… probably the delivery."
a surprised "Right. No, yeah, um…"
show e blush:
 ease 1.0 zoom 1.0
 linear 0.0 yalign 0.1
"He lets me go as I bashfully step aside, smoothing out my clothes as he gets up to answer the door."
hide e blush with dissolve 
"I sigh out a long breath. It wouldn’t be the first time we’ve had one of these kinds of moments. I guess I’ll rest assured it won’t be the last, either."
hide ekitchen with dissolve 
"Dinner was eaten mostly in silence, only interrupted by the occasional chit-chat of our day and how work is going. Seems like neither of us have any energy to hold a conversation tonight."
show eapartment 
show e uniform flattered 
with dissolve 
e "Hey. Stay the night. I know I said I’d drive you home, but I’m seriously drained..."
a surprised "Are you sure? I mean, I don’t mind… I’ll take the couch, if you want your space."
e smile "Nah. Come."
hide eapartment
hide e smile
with dissolve 
show ebedroomn
show e uniform smile 
with dissolve 
"He takes me by the hand into his bedroom, and although the situation makes my blood start pumping – especially in certain areas – it’s clear that nothing will happen tonight."
show e pjs smile with dissolve 
"So when he starts to undress in front of me, I have to pretend I don’t care about how good his body looks underneath that uniform, or that there may or may not be a slight tent in his boxers as he climbs into bed."
show e smile at center:
 yalign -0.1
 ease 0.8 zoom 2.0
"Once I’m undressed too, I slide under his covers, stiffly lying beside him as we lock eyes."
show e flattered 
"He’s lying on his stomach, blinking slowly, and the uncontrollable urge to brush his hair surges through my whole body. He suddenly chuckles, and it makes me crack a smile."
show e smile
a -uniform cocky "What?"
e cocky "Nothing. You just have a stupid look on your face."
"His voice is somewhat muffled, since his cheek is firmly pressed against the mattress, making him involuntarily pout his lips a little."
a flirty "Uhuh. Go to sleep, fatty."
show e flirty 
"He frowns, but that smile never leaves his face."

e "Fatty? Who you callin’ fatty?"
a cocky "The only fatty that’s taking up more than half the bed."
e pout "It’s me-sized. Not you-sized."
show e cocky 
a "So it’s fatty-sized."
e flirty "Shut up."
show e smile 
pause 1.5
e flattered "Hey. Angel."
a smile "Yeah?"
e "You know, you could stay over more often. I don’t mind."
a surprised "…"
hide e flattered with dissolve 
"It feels like a drunken confession with the way he says it, and it might as well be, considering how woozy the sleepiness is making him. I smile warmly, but by now, his eyes are fully closed."

a blush "Okay."
e "Hrmph. ‘Okay’ shut-up-you’re-so-annoying, or ‘Okay’ okay?"
a eyeroll "’Okay’ okay, you moron. I…"
a blush "I like being here, too. Your bed’s a lot comfier than mine."
a bashful "Well… the third of your bed that I can fit into, anyway."

"He smiles. I watch him in silence for about a minute, seeing how it fades in real time, and about thirty seconds after that, he’s already snoring."

a stan "…"

"It’s moments like these that make me forget about my silent promise of not daydreaming about him. About us."
"I let my own thoughts run wild, telling myself that I’ll allow it for a minute. Just one minute."
"And in that minute, I see him closing the distance between us in this bed, his large arms wrapping around me, his warm breath against my ears. I feel the heat of his crotch pressing against me, how it would throb in rhythm to my own."
"He’d whisper something sweet into my ear – something romantic, because he’d allow himself to do that. To be completely himself."
"He’d tell me he wants me, but that he’s too tired right now. He promises to make it up to me in the morning, and I’d laugh against his chest, buzzing with excitement for tomorrow to come."
"He would hold me, and I would touch him. And we’d both drift off to sleep together."
pause 2.0
"And then the vision fades.{w} My minute is up."
"But the yearning persists, as it always does after a daydream. That’s why it’s so dangerous to do it. If a minute can make me feel this way, I can’t imagine how I’d feel if I had no restraint on these fantasies."
stop music fadeout 5.0
pause 2.0
hide ebedroomn with dissolve 
a closedworry "{i}I would surely go insane."
pause 2.0
a "{i}That kind of freedom… is nothing but torture."
play music ringtone 
pause 2.0

e "Angel…"
a1 "Mm?"
e "Pick up your fucking phone."
a1 "Mm…"
show ebedroomn with fade 
stop music 
"I stir awake, blinking back a deep grogginess as I reach for my pant leg and grab my phone, flipping it open and pressing it into my ear."

a -uniform hm "Hello?"
anon "How kind of you to finally pick up the phone, Angel."

"And just like that, my grogginess disappears in an instant."
play music ambience 
a flustered "M-Mr. Valentine…"
v "Did I wake you?"

"His voice drips with snarkiness, no trace of an apologetic tone in his sentence. I swallow hard, rubbing my eyes of the drowsiness that I want to so desperately stay in."

a bashful  "N-no, of course not. I was just about to head into the office."
v "At five a.m.? How diligent. If only we all had your work ethic."

"Is it really that early? No wonder I’m so tired."
"But even in my half-lucid state, I know how painfully obvious it is that Mr. Valentine is just fucking with me. Plain and simple."

a "Ahaha… how can I help you, sir?"
v "Well, as luck would have it, I’m heading back to the office myself. Santa Blanca was quite the... {i}skid row{/i}, to put it lightly."
v "I’d absolutely love a box of donuts from Big Joe’s. Oh, and a dark roast from Nova. You can do that for me, can’t you?"
a flustered "Um… y-yes sir."
v "Good. I’ll be at the office in about half an hour. Please do have them there by then."
a concern "Wha… but Big Joe’s and Nova Café are twenty minutes away from each other."
v "I thought you were already heading out? That should be plenty of time, is it not?"
v "Or perhaps I should ask someone more qualified… and hand them over your story, while I’m at it."
a flustered "Ah- N-no! No, no, I’m on it, sir!"
v "Good."

"And he just hangs up, without another word."

e "You're leaving already?"

"I turn to see Ethan lying next to me, half asleep, one eye peeping up to look at me."

a worried "Yeah. I’m sorry."

"He groans, then turns to his side and lets out a big huff, clearly a little annoyed."

e "Your boss is Satan..."
a hm "Don't say that. He's really not that bad..."
e "Ugh. He is and you know it."
a worried "…"
e "Let’s…"

"He yawns mid-sentence, loud and for a solid ten seconds."

e "Let’s have lunch together, then."
a flattered "…"
a "Okay. I really gotta go now."
e "Yeah… okay…"

"He drifts back to sleep, and a part of me wants to just curl back up and sleep with him, possibly forever."
"{i}If only{/i}, is the last thought I have as I jump out of bed and start to get dressed."
stop music fadeout 2.0
hide ebedroomn with dissolve 
show streetsnight with fade 
play music city 
"The cold morning air bites my ears as I step out into the sidewalk. The usually buzzing city of Sonora is half-asleep, and only a few cars and taxis drive past the mostly empty roads."
"In the distance, like a centerpiece, glowing lights illuminate a building so grandiose and luxurious, anyone who doesn’t live here would be attracted to it. Like a moth to a flame...{w} Corona's Casino."
"Money, spectacle, risk… an entire life blooms behind those enormous red doors, a life that couldn’t be more different than mine."
"And yet, just like everyone else in this city, I can’t help but wonder…{w} what if?"
"What if I played a game – just one game – where I bet my entire life on the line? What if losing meant dying, and winning meant riches beyond my wildest dreams?"
pause 2.0
"Wouldn’t I be free either way?"
pause 1.5
a uniform frown "…"
"How idiotic. It’s thoughts like these that make me positive that my own imagination would get me killed, if I let it run this wild."
"I don’t have time for stupidity.{w} I raise my paw and hail a cab."
stop music fadeout 1.0
hide streetsnight with dissolve 
show voffice with fade 
"Forty minutes later and I’m rushing through the doors of the Valentine Report, donut box in one hand and coffee cup in the other."
"I dash into Mr. Valentine’s office, praying to God that he somehow got delayed, that he got caught in traffic – or better yet, in a minor car accident, even!"
"Unfortunately, I’m not so lucky."
play music jazz
show v clothes glare with dissolve 
v "You’re late."
a flustered "I’m sorry, I-"
v hm "Bore someone else with your excuses. Hand me my coffee."
show v stan 
"I slide everything onto his desk, and he lets out a long, drawn-out sigh."

v hm "Is everyone in the world incompetent?"
a worried "…"
v frown "That wasn’t rhetorical. I’d like an answer."
a flustered "Huh? Uh…{w} no?"
show v stan 
"He rubs his temple, taking a sip of his coffee. Thankfully, no complaints there…"

v hm "Well, that certainly seems to be the case..."
show v stan 
"Mr. Valentine has been running the corporation ever since I even started training to become a Valentine myself. In all the years that I’ve known him, he’s been more or less the same; a stoic, cold-mannered man with little regard for other’s feelings."
"I sometimes wonder if he’s even mortal. I’ve never once heard him complain about being tired, overworked, hungry, sad... you know, basic emotions we all have?"
"I have a few theories that include sociopathy and/or vampirism, but I think the most likely reason is he’s just an asshole."

a yeesh "{i}Sometimes, the answer is the most obvious explanation."

"Still, to say I hate him wouldn't be the whole truth. My feelings for Mr. Valentine are as complex as the tasks he so wilfully makes me do..."

v hm "So, Angel. Do tell… what advancements have you made on the missing person’s story? I haven’t gotten a single report from you all week."
a bashful "Ah, y-yes, sorry… I was actually planning on writing one today. I’ll go do that now, if you’ll excuse me…"
v stan "No need. I’m right here, after all."
v "Talk to me."
a flustered "…"
a bashful "Yes… well, I have made a few advancements…"
v hm "Such as?"
a flustered "Um…"
v glare "Hm? Spit it out."
v "What have you figured out, my Valentine?"
a surprised "…"

"He knows I know something. Of course he does. A flick of the ear, a twitch of the eye, a single spasm in your finger, and Mr. Valentine can read your mind. Just like that."

a stan "…"
show v surprised 
a frown "I believe Corona’s is somehow involved, sir."
v "…"
show v stan 
pause 2.0
v "Is that so…?"

"He says that more to himself than to me, and I have a feeling he already knew. However, his face still seems a bit surprised by this."

v hm "What are your sources?"
a surprised "Oh. Um…"
v "I’m guessing your partner had something to do with it?"
a flustered "My partner?"
v "Your police escort? Hutcherson, was it?"
a surprised "Oh! Yes, forgive me. Hutcherson wasn’t, um, involved, so-"
v frown "Oh please. I won’t get your little boyfriend in trouble. If he’s giving you valuable information, all the better."
a "He’s not my-"
v glare "In any case, your next step is clear, isn’t it?"
a flustered "Huh? Um…"
v hm "Isn’t it? Or do you want me to pass this story to someone more… capable?"
show v surprised 
a surprised "Of course not!"
pause 1.5
show v stan 
a concern "…sir."
pause 2.0
v frown "Listen. Angel. I gave you this case because I have faith in your abilities. I always have."
v hm "Despite what you may think of yourself, you’re one of the few Valentines with decent people's skills. I believe when it comes to these more… sensitive stories, the Valentines don’t have such a great reputation." 
v frown "We’re seen as cold, calculated… unfeeling."
a yeesh "{i}I wonder why…"
v stan "But you seem to have a more empathetic air to you. People open up to you. They want to tell you things because they believe you want to help them."
a concern "…I do want to help them."
pause 2.0
v frown "Then do it."
v glare "But don’t forget who comes first."
v frown "Now get out of my office. I’ve wasted enough time on this conversation."
v hm "And take these donuts with you. This coffee is sweet enough as it is."

"And there’s the complaint."

a sad "…{w}yes sir."

"I hang my head low as I grab the box of donuts from his desk, and I leave quietly, closing the door behind me."
stop music fadeout 2.0
hide v hm
hide voffice 
with dissolve 
show breakroom with fade 
"I take the donuts to the breakroom, and I stuff one into my mouth as the conversation replays in my head."
"Does Mr. Valentine really believe in me? Does he think I have what it takes to solve this case? Or does he say that to everyone?"
"And he didn’t say anything about Corona’s involvement… what is he plotting?"
"I don’t know what to think anymore {nw}"
show c clothes grin at center, jumping:
 yalign 0.1
 zoom 2.0
anon "BOO!"
pause 2.0
a stan "…"
c uh "…"
play music ambience 
a smile "Morning."
c disappointed "Aw, man…"
hide c disappointed with qdis 
show c clothes disappointed with qdis
c "You used to get so scared when I did that before. You’d be all like-"
show c surprised at jumping 
c "WAH!"
c disappointed "It was so cute… when did you grow out of it?"
a cocky "Probably after the thousandth time you did it."
c pout "You’re no fun anymore."
c stan "Ooh, donuts."

"Cameron, my coworker in the journalist unit of the corporation and annoying manchild, grabs two donuts from the dozen and eats them both at the same time, alternating bites between the two and chewing with his mouth open."

a smile "What are you doing here so early, anyway?"
show c hm 
"Cameron leans coolly against the counter, rolling his eyes."

c "Valentine’s on my ass about punching in on time. When have we ever needed to punch in? This isn’t some office job."
c cocky "But he did assign me a very cool, very special story."
a surprised "Really?"
c "Yup. I have the honor of writing an article for the grand opening of the second public library here in Sonora."
show c hm 
a yeesh "Wow. Monumental…"
c "I know."

"He takes another bite, chewing in pent up frustration."

a bashful "Sorry you get the low hanging fruit."
c cocky "It’s fine. If Valentine wants to give {i}me{/i} these cheese-ass stories… then I’ll take my time with them. Treat it as a mini vacation."
show c cocky at center:
 yalign 0.1
 ease 0.8 zoom 2.0
"He suddenly leans closer to me, invading my personal space and looking me right in the eyes with an odd, piercing glare."

c flirty "But you can’t say the same, can you? Little Angel got a big story, didn’t he?"
a surprised "…"
a flustered "I, uh… I guess so…"
show c surprised 
a bashful "Mr. Valentine said it’s because I have more ‘people’s skills’, if you can believe that."
c cocky "Hah!"
show c cocky:
 ease 0.6 zoom 1.0 yalign 1.0
"He backs off, the mood growing light again in an instant."

c "More than me? That’s hard to believe."
show c surprised 
anon "Is it, though?"
show c surprised at slightright with move 
show mk clothes hm at slightleft with dissolve
a smile "Oh, hi Mika."
c hm "Here comes the fun police."
mk stan "Don’t let him fool you, Angel. Cam is only somewhat capable in what he does."
c "I’ve been here longer than you."
mk hm "Doesn’t make you better."
c "Uh, yeah, it does."

"Mika is my only other coworker in the journalist unit, making three of us in total. I guess you can say we’re all friends… that never hang out outside of work. Probably because none of us actually want to be here."
"Mika is kind of Cameron’s opposite; quiet and very no nonsense. Despite this though, I find myself opening up to her more than anyone else in the corporation."
"Compared to me, both of them have more experience in serious stories like this. So, maybe…"
show c surprised 
show mk surprised 
a "Hey, you two… I have a bit of a weird question."
mk "Oh?"
c hm "Is this about your cop boyfriend? I’m telling you, kid, never trust a narc."
show c cocky
show mk stan 
a flustered "What? No! And he’s not my boyfriend!"
a worried "This is… about my story."
show mk surprised 
show c surprised 
stop music fadeout 2.0
a "What would you guys do if… Corona was involved?"
pause 1.5
a concern "What? What’s with the faces?"
show c worried 
play music noir 
mk worried "That’s just… a very heavy claim, Angel."
c hm "Shit, Corona? Are you sure? There’s a lot of different casinos here. That’s like, the whole appeal of this city."
a surprised "I know… but, I’m pretty sure Corona is at the center of this. I’ve got evidence pointing back to them, all of the missing person’s cases that involve high-class individuals falling into gambling addiction."
a frown "Isn’t it possible? I mean, if I could just… question the staff…"
show mk concern at jumping 
show c surprised 
mk "You can’t!"
pause 2.0
show c worried 
mk worried "I mean… You shouldn’t…"
pause 1.5
c "What Mika means is that Corona isn’t {i}just{/i} a casino."
hide mk worried 
hide c worried 
hide breakroom
with dissolve 
pause 0.7
show casinoclipart with dissolve 
c "This city was built around it. Quite literally."
c "It’s not just some tourist attraction, or a fancy five-star hotel... Corona’s is everything that makes Sonora a powerhouse of a society."
c "The hold it has on the economy, on the minds of the people, on the elites of this world… it’s on a whole other level. They're basically the government here. You {i}cannot{/i} mess with them without consequence."
hide casinoclipart with dissolve 
pause 0.7
show breakroom 
show c clothes hm at slightright
show mk clothes worried at slightleft
with dissolve
c "They’re untouchable. The only way into their inner circle is either being a damn good gambler or being stupid rich. And a little reminder, kid, you’re neither of those things."
mk "Mixing with Corona and getting too close is a bad idea, Angel."
a concern "…"
show c serious 
a "But… we’re Valentines. Surely, we have some immunity, right? I mean, we’re not high-class elites, but we do have protection from the S.P.D., don’t we?"
pause 1.5
c hm "Angel, if the Casino had to choose between facing the punishment of killing a Valentine, or protecting their own reputation… do you really think it’s a close call?"
a "…"
show c serious 
show mk stan 
a "Wh… why, then? Why did Mr. Valentine even give me a story like this in the first place?"
pause 2.0
mk worried "Honestly?"
mk "I think he expected you to fail."
pause 2.0
a sad "…"
c "…"
show mk stan 
c cocky "Hey, cheer up. Valentine’s a freak, anyway. You’re still practically a newbie at this. One failed assignment isn’t gonna stain your record. Maybe it’ll hurt your bonus, but, uh… what can you do, y’know…?"

"He chuckles, trying to lighten the mood a bit, but it only makes this whole situation seem more like what it truly is: a big joke.{w} And I’m the punchline."
show c stan
mk worried "Listen, Angel. Corona’s influence in this city is so grand, that even if you’re outside of its walls, you’re {i}still{/i} gambling. Still risking your livelihood by even thinking about getting involved with it."
mk "And as Valentines, we can’t take that risk."
mk "Because we aren’t just risking our own lives."
pause 1.0
show c surprised 
show mk concern 
a "Mom…"
show c serious 
show mk stan 
pause 2.0

c cocky "Well, that’s that, then! You just treat this like a vacation, too. Dick around, talk to people around the missing person’s inner circle, and tell Valentine he’s shit outta luck. You’re not messing with Corona."
show c stan
"He slaps his paw on my shoulder, forcing a smile."

c cocky "And if you get bored, we can play chess in the breakroom when the boss ain’t around. I might even let you win next time."
a cocky "Tch. You’re on."
show mk worried 
show c stan 
"He gives me a hard squeeze, then turns around and heads out the door, sharing a glance with Mika as he exits the room."
hide c stan with dissolve 
show mk worried at center with move 
pause 1.5
a sad "…"
mk "I know you want to help her, Angel. But sometimes, the smartest move in a game is to not play at all."
a bashful "…maybe you’re right."
show mk flattered 
a flattered "Thanks, Mika."
mk "I’ll leave you to it, then."
stop music fadeout 1.5
hide mk flattered with dissolve 
pause 1.5
a concern "…"

"Doubts fill my head, swirling around until it numbs the rest of my body."
"Am I maybe just not good enough to solve this? Is Mr. Valentine just pulling a really big, elaborate ‘fuck you’ right in my face?"
"What is he expecting me to do? And, more importantly…"
"What {i}am{/i} I going to do?"
pause 1.5
"I think back to Mr. Yoshida, his strained expression as he spoke about his missing niece. I think about all the other missing people who came before Megumi, and how people seem to be going missing more and more frequently lately."
"And I think of Mr. Valentine’s cold, knowing look, telling me exactly what I should do."
pause 2.0
"My job."
hide breakroom with dissolve 
show coutday with fade 
play music casino 
"Fear bubbles in my chest as I look up to see the grand building before me."
"For being so off-limits, the casino is incredibly inviting; people pour inside despite it being relatively early, and there seems to be no one guarding the actual entrance."
"I take small glances inside, the flickering of lights and the sounds of slot machines being audible even from all the way out here."
"It sounds… fun."

a surprised "…"
a flustered "{i}N-no way. There I go again, thinking stupid things. How can throwing money into a machine and hoping it matches three symbols in a row possibly be any fun at all?"

"That’s right. It’s just the allure of the casino. That’s what they’re designed to do."
pause 2.0
"I’m stalling. {w}Again."
"My heart’s hammering in my chest as I take yet another quick peek inside. I mean… there’s no {i}explicit{/i} rule a Valentine can’t just {i}enter{/i} a casino, right? Surely, Mr. Valentine would’ve stopped me had that been the case."

a stan "…"
a frown "…"

"No. I can’t let my own fears and desires get in the way of my work. I’m a Valentine, not some amateur freelancer. This is what I was made to do."

a "{i}That’s right. Unfeeling, calculated, and efficient. Get the job done."
a "{i}Your livelihood isn’t the only thing on the line…"

"I brush back my hair in a slow, soothing way… and take a step forward, entering the casino."
hide coutday with dissolve 
show clobby with fade 
"The lobby itself is a beautiful, spacious area, with a fountain at its center, filling the room with the sound of rushing water."
"Prestigious looking people banter quietly around it, and further along this room is an entryway to where I’m positive the casino is. To my right, a hall leads towards the registration desk, and even further seems to be a restaurant."
"I can only guess that even deeper inside the building is the actual hotel lobby, where I’m sure leads to the many rooms available in this resort."
"Access is most likely only granted with a room keycard, and I wouldn’t be surprised if even the elevators won’t function if you don’t have one on you."
"This place truly has it all…"
"I walk aimlessly around the fountain, feigning interest… well, maybe not feigning it. I am quite interested, but not so much in the architecture of the place, as beautiful as it may be. There’s something else that caught my attention."
"This is the very last room Megumi was last seen in. I’m positive of it."
"The patterns on the floor match exactly… but, how? Corona’s is in the middle of the city. Surely, some other camera must have picked up her trail…?"
"All the more reason to question the staff. And speaking of…"
a body2 uniform thinking "Hm…"

"I walk up to the fountain, staring down at my distorted reflection in the ripples of the water. I do my best to appear unassuming, with my hands behind my back, looking at nothing in particular."
"In reality, I’m gathering a ton of information."
"In the entryway to the casino, just shy of my peripheral vision, stand two large men on either side. A polar bear to the right, a bull to the left. Stereotypical bouncers, but I suppose they can’t afford to have anything less than the biggest and strongest in a place like this."
"I close my eyes, yawning without a sound as I try to pick up on anything they might be saying, the urge to flick my ears to their direction as strong as it ever is. Like an itch I’m not allowed to scratch."
"I resist, of course… but unfortunately for me, the two men don’t make a sound."

a body2 frown2 "{i}This isn’t good. I’m not getting anything useful just standing here, and it’s not like I can just go up and talk to them…"
a body2 hm2 "{i}Well, it’s not the end of the world. I at least know what they look like. If I can talk to Ethan and ask him to get me information on every bull and polar bear in the city…"
a body concern "{i}But what good would that do for my story? Agh, that’s so needlessly complicated…! Why can’t I just go inside?!"

"I guess technically I could… but I’m terrified of the consequences. I’d rather play it safe… like I always do."
"The casino itself might be off limits… but, maybe I could gather information at the registration? Even just going up to the hotel to snoop around would be wonderful."
"I’m just about to head towards the registration desk when something coming from the casino entryway catches my eye. Or rather-"
stop music fadeout 1.0
anon "Oh my… a Valentine in my casino? To what do I owe the pleasure?"
show l coat suit stan with dissolve 
"…someone."
play music lionjazz 
"The man before me is none other than Leonidas Grey, the current owner of Corona's Casino. To say he’s rich and powerful would be downplaying his status – he’s one of the richest people in the entire country, probably top ten in the world."
"So, to see him in broad daylight, unprompted and with no security behind him is…"
"The large lion walks straight up to me, speaking in a sultry, sophisticated way that makes my skin crawl. My pulse quickens, and that feeling of fear comes right back, but I swallow it down, {i}hard."
"No one can see that I’m afraid. An emotion means death in this world."
"I stand up straighter, putting one hand on my chest, the other behind my back. I bow, keeping my eyes locked on his, making sure he can’t read anything that might be written on my face."

a stan "Excuse my intrusion, sir. Angel Valentine, of the Valentine Report. The pleasure is all mine."
show l ponder 
"He smiles, a low purr rumbling in the back of his throat as he does.{w} I don’t smile back."

l "What a rare sight. The last time we had a Valentine enter these premises… oh, far too long."
a frown "Forgive my audacity, sir. I was simply…"
show l cocky 
"I freeze. I can’t think of a single excuse, and the fear of what this man might do to me is getting to my head."

a concern "I… was simply waiting for a client who requested we meet-"
l stan "I have no interest in fictional stories, Valentine. You of all people must understand that, as a seeker of truth."
"He purrs when he speaks, that English accent of his making every word that comes out of his mouth sound like something important."
pause 2.0
a  "…"
l ponder "As a matter of fact… I believe you have some business with me, do you not?"
a surprised "Business? No, I-"
l surprised  "No? There isn’t anything that you’d like to talk about with me?"
l peek "Is the reason you’re here… none of my concern?"
pause 1.5
 
"The gross, icky feeling of being wrapped around someone else’s finger seeps into me, his eyes drilling into mine, not even blinking once."
"It’s the same feeling I had with Mr. Yoshida, Mr. Valentine… and now, Mr. Grey. That’s my place in this city: nothing more than a pawn in the bigger game of chess these men play with each other."
show l stan 
a concern "…"
a "I do have some business with you, sir."
l ponder "That’s what I thought. Come then, Valentine."
hide l ponder with dissolve 
"He turns and heads deeper into the building, not checking to see if I follow him; he knows I will. With a racing pulse, I lift my chin up and walk a few feet behind him, silently wondering if I’ll make it out of here alive."
hide clobby with dissolve 
show cstairs with fade 
"Walking straight past the reception desk, we enter the main lobby of the building: a beautiful, vast room with large staircases leading up to the rooms of the many elites who will no doubt enjoy their time here."

a yeesh "{i}And spend a ton of cash in the process."

"I’m in awe at such a luxurious place. Even in my wildest dreams, I don’t dream something this big."
"Mr. Grey keeps his stride as we walk up the steps, and to my surprise, strikes up a friendly conversation with me."

l "Is this your first time inside?"
a flustered "Yes, sir."
l "Marvelous, isn’t it? Its brilliance doesn’t get any easier to get used to, I’ve come to experience."
a stan "…"

"That’s right… If I remember correctly, Mr. Grey isn’t actually a descendant of the original owners of this place. The details of how he came to be are muddled, and kept under wraps. Even the Valentine Report doesn’t have any files on it."
"All the more reason to be guarded. This man must be as dangerous as he is enigmatic."
hide cstairs with dissolve 
show coffice with fade 
"We reach a hallway that leads down an elevator, and with the push of a button, it opens for him instantly."

l "After you."

"We both get inside of it. He presses his fingers on some sort of fingerprint scanner, making the elevator shoot up with surprising speed."
"I fiddle with my bangs, taking in my surroundings. A high-tech elevator going at max speed, a camera on the upper right corner with a glowing red dot, mirrors on every wall. It’s an assault on the senses, to say the least."
"Finally, we reach an undefined number of floors up, and the doors open again. Mr. Grey gestures for me to walk out first, and I think to myself how if I’m going to be killed here, it’s nice he’s being a gentleman about it."
"After another short walk down a hallway, we reach a door he opens with zero hesitation, leading to what I can only assume is his office."
stop music fadeout 1.0
show coffice 
show l coat suit stan 
with dissolve 
l "Have a seat, Valentine. Would you like a drink?"

"I subtly look around as I do what I’m told, sitting down as he pours himself a glass of what is most likely whiskey."

a "No, thank you."
show l -coat suit stan with dissolve 
"He drapes his coat on his large chair and sits down in front of me with a sigh, leaning back on his chair in a cool, collected manner. He looks at me… {i}really{/i} looks at me, eyeing me up and down and taking everything in.{w} It makes me feel naked."
pause 2.0

l ponder "Before we discuss anything, I’d like to make one simple condition."
show l stan 
a concern "And… that is?"
pause 2.0
l serious  "No lies."
pause 1.5
l stan "You’ve come here for the truth, yes? Then, I’ll give it to you. I only ask for the same treatment in return."
l surprised "Do we have a deal, Valentine?"
pause 1.5
show l stan 
a "Yes, sir."
pause 1.5
l peek "Good.{w} I hope you mean it. I’m quite good at calling someone’s bluff."
a hm "{i}I’m sure you are…"
l stan "Very well, Valentine. Please, do tell what business it is you have with me."
pause 1.5
show l ponder 
"I swallow hard. Do I really just… lay it out honestly to him? It’s what he asked for, but…"
show l stan 
pause 1.0
"Something tells me he won’t appreciate anything but the cold, hard truth."

a concern "…"
a frown "{i}Fine. Have it your way."
show l stan 
a bashful "You won’t mind if I record this, would you, Mr. Grey?"
l ponder "Certainly not. By all means."
show l stan 
"I lay my recorder on his desk, pressing the button to start it up, and lean back on my seat, mirroring his gaze."
play music noir 
a stan "Ms. Megumi Yoshida has been missing for the past three months. She was last seen here, in your casino. Several reports indicate that she isn’t the only missing person in the last twelve months that was last seen in this location."
show l serious 
a frown "Every other press has been silent; the police have also made little attempts to actually search for these individuals… which is why their families have come to us: The Valentine Report."
a "Do you have any explanations for this… Mr. Grey?"
pause 2.0
show l ponder with qdis 
"He grins, a somewhat satisfied look on his face. Whatever I did right, it must have pleased him.{w} Not that I could care in the slightest."

l surprised "This is all very true, Valentine. People have been going missing for quite some time now in Sonora. The number seems to pile up every day."
l shocked "As for explanations…{w} I’m afraid I have none."
pause 1.5
a concern "Pardon?"
l "It’s true. I’m as dumbfounded as you are, love. I have no involvement in any of these disappearances, and my staff has been closely monitored to ensure no one is up to anything nefarious behind my back."
l serious "It’s a pity and a shame what happened to those people… but unfortunately for you, Valentine, my hands are clean."
a frown "…"

"Bullshit. There’s no way one of the most powerful men on this earth doesn’t know what’s going on at every given moment."
"He’s lying to me. He has to be…"

l hm "Tell me, Valentine… why would I stain my own reputation, and my casino’s reputation for that matter, by committing such an atrocity right here in this very building? What would the people say about me? What must they be saying now?"
l serious "I have no desire to enact violence. No need to resort to crimes to exact justice. I am just as you see me: a businessman."
l shocked "Ms. Yoshida did frequent our casino, but she did so of her own volition. She never owed us any money, as Corona never loans to anyone."
l ponder "Now what reason would I possibly have to harm a young woman who gives me business?"
pause 2.0
show l stan 
a concern "…"

"As much as I hate to admit it, he might have a point. Megumi wasn’t exactly indebted to the casino… and having so many disappearances all center Corona’s... someone like Mr. Grey couldn’t possibly be dumb enough to overlook that."

a "So, then… if not you, it must be someone from your staff. Someone with access to the video footage of the casino? Someone trying to harm your reputation?"
l ponder "Rest assured, these are all scenarios I’ve accounted for. My staff is under my watchful eye. None of them are involved. The full, unedited tape was willfully given to the police department. And as for someone trying to harm my image…"
l serious "Perhaps that may be the case. But it is no one I personally know, or anyone under me."
pause 1.5
show l shocked 
a frown "Why should I just take your word for it?"
pause 2.0
l ponder "Oh, Valentine… did we not have an agreement? My word is good."
l peek "And I think, deep down, you know that."
stop music fadeout 1.0 
l "Don’t you, Angel?"
pause 2.0
"My stomach drops."
a scared "H… How do you…?"
l "You see, I’ve done my homework."
show l ponder 
"He grabs a folder that had been sitting on his desk, flipping it open as a cold feeling trickles down my spine."
play music darkjazz
l peek "Mr. Angel Valentine. Unlike many of your peers, you began training to become a Valentine at a remarkably young age, and graduated with flying colors. At just twenty-three, you now have a high-profile case in your hands at the investigation unit of the company."
l surprised "Most Valentines don’t even get to be in the ‘Journalist’ unit, much less receive important cases such as these… one has to wonder, how did you do it?"
a nngh "…"
l peek "Hm… perhaps because you’ve had to work twice as hard for it? I mean, if your debt is anything to base my assumptions on."
l shocked "50,000 dollars, Angel. How does a teenager garner that much debt?"
pause 2.0
show l serious 
a "That… doesn’t concern you, Mr. Grey."
l ponder "Oh? Perhaps you’re right."
l peek "It doesn’t concern me… this is between you and your mother, isn’t it?"
a scared "…!"
l hm "This must be {i}her{/i} debt… how cruel. Pushing it onto her thirteen-year-old son, giving him no choice but to work it off for her. Tell me, Angel… when do you estimate you’ll pay this off?"
a nngh "Please…"
l shocked "If my calculations are correct - and rest assured, they are - you’ve paid off less than ten percent of your total debt. Have you done the math, love?"
l serious "It’ll take more than forty years for your debt to be finalized."
a scared "…"
l ponder "Of course, I’m not counting bonuses. That must shave off a few months or two in the equation, correct? Now, why don’t we-?"
show coffice at shake 
show l shocked 
stop music 
a scared "Please, stop!!"
pause 2.5
a "Please… why are you doing this...?"
show l serious 
pause 2.0
l "My apologies, Angel. I did not mean to upset you."
l ponder "You see… I just find you…{w} fascinating."
pause 1.0
a concern "…what?"
play music darkjazz 
l stan "Indeed. Someone who wasn’t given a choice as to what their life may look like, how their story will play out. It’s exceptionally cruel… so much potential, so much intelligence… but has anyone ever asked you…"
l peek "What it is that {i}you{/i} want to do with your life, Angel? When you fall asleep at night, do you allow yourself to dream? Or is the very notion utterly ridiculous?"
pause 2.0
show l stan 
"I just stare at him, that cold feeling still permeating throughout my body, flowing through my bloodstream right up to my fingertips."
"Just who is this man…?"
pause 2.0

l ponder "It fascinates me…{w} so I’d like to play a game with you."
pause 2.0
show l stan 
a "A… game?"
l "Precisely. As you might already know, this casino wasn’t mine to begin with, and I have no familial ties to its original owners."
l ponder "To make a very long story short… I won it. In a gamble."
a concern "…"
l "It was a surprisingly ordinary game of poker… but oh, how wonderful it was. It still stays in my memory as one of the most thrilling experiences of my life."
l surprised "Baring it all on the line, your entire life… for the chance of success. {i}That{/i} is what I believe divides the strong from the weak."
l ponder "How much are we willing to risk for the greatest return…?"
show l stan 
"He opens a drawer on his desk, and slowly, carefully, places a gold coin in the middle of the surface, the weight of it making a deep sounding {i}clink{/i} against the smooth wood. It has a crown engraved on one side, a jester's hat on the other."

l ponder "It’s a simple coin flip. A fifty-fifty chance."
l stan "If you win…{w} I’ll give you my casino."
pause 2.5
a scared "…"
show l shocked 
a "That’s… it…?"

"He lifts his brows in genuine amusement."

l surprised "Oh? Would you like something more?"
a concern "N-No no! I mean… Just like that?! What… Why would you do that?!"
l cocky "Why? Well…"
l ponder "Because if you lose…"
l peek "I want you to work as my personal assistant.{w} For the rest of your days."
l ponder "All of the knowledge that the Valentine Academy has taught you, all of your experiences in the agency… someone like you, working in {i}my{/i} casino…"
l peek "Better still, under my watchful gaze… {w}and under my complete mercy..."
l grin "Oh, I’d wager much more than my casino for a chance to have that."
pause 2.0
show l shocked 
a scared "You’re… insane… That’s just crazy! Why would you make such a gamble?!"
pause 2.0
l surprised "Isn’t it fair? In the world of gambling, it doesn’t matter what your status is, who you are, what you’ve done… all that matters is what you put on the line, and who will emerge victorious."
l ponder "We decide our fates. We choose to put our livelihoods on the line. What greater act of rebellion against the world exists? To decide to risk your life, and leave it up to fate?"
l grin "I truly believe… that the risk makes the man. How can you live in a world where you’re afraid of its natural state – of loss? Of change?"
a concern "…"
l ponder "So, tell me, Angel… right here, right now, you and I are equals. We can both lose our livelihoods in the blink of an eye… or, we can gain something truly remarkable… and truly lifechanging."
l grin "You can be free… and I’ll have the most fascinating thing my eyes have ever laid upon, right on the palm of my paw."
l "The choice is now fully yours."
pause 3.0
a scared "…"

"I stare at the coin, one simple gold coin that probably isn’t worth much… holding so much power inside of it, so much potential."
"When have I ever been given the chance to decide on… anything, really? Mr. Grey is right. My life was carefully laid out for me from the moment I was forced to join the Valentine Agency."
"But now… I’ve been given a choice. A ‘What if?’ scenario."
"What if…{w} I accept?"
"I could win. The odds aren’t that bad… I could own Corona, pay off my debt in an instant, do whatever I wanted for the rest of my life…!"
"Or… I could lose. I could live the rest of my life by this lunatic’s side, doing God knows what with him, probably still trying to pay off my debt until I’m sixty…"
"With no hope in sight."
"Is that really a risk… I’m capable of taking?{w} Allowed to take?"

pause 3.0
show l shocked with qdis 
stop music fadeout 2.0
a sad "No."
pause 1.8
l serious "No…"
show l disappointed 
"Mr. Grey lets out a long sigh, deflating against his sturdy chair, the glimmer that was once in his eyes fizzling out in a heartbeat."

l "Of course, the answer is no."
l serious "As always, those who are afraid to lose will never play any kind of game."
a concern "I’m sorry… but I’m not just gambling my own life… I have someone who depends on me…"
a frown "And Valentines don’t gamble."
pause 2.0
l disappointed "I suppose you’re right. You have a life you simply can’t afford to lose, it seems."
l serious "Very well."

"He grabs the coin and haphazardly throws it back in his cabinet, leaning back in his chair."

l "Then I believe you no longer have any business with me."
l disappointed "Please, see yourself out of the building."
show l serious 
pause 2.0
l angry "Immediately."
a scared "I-I… yes, sir…"

"Holding back my emotions, I quickly stand up and grab my things as I give him one last bow before exiting the room, a shiver running down my spine. I feel his cold eyes watch me the whole way out the door until I shut it firmly behind me."
hide coffice
hide l angry
with dissolve 
show coutday with fade 
"By the time I’m out of the building, my breathing has gotten heavy, and hot tears threaten to leak out of my eyes as I stare at the spinning floor beneath my feet. ‘Humiliated’ doesn’t even begin to cover how I feel."
"He knew {i}everything{/i} about me, and I was powerless to it. He tried to play me, tried to make me one of his pawns…{w} didn’t he?"
"Yes, he did. There’s no doubt. That cheeky look in his eyes, that faux kindness… it was all a lie. Offering me the casino? How ridiculous…!"
a nngh "…"
play music ringtone 
"I feel like I’m about to throw up on the side of the road when my phone begins to ring."
pause 1.5
"I take a deep breath, brush my hair out of my eyes, and answer it, doing my best to sound calm and collected."
stop music 
a concern "Hello?"
e "Hey, Angie. We still on for lunch?"
pause 2.0
a nngh "Uh… yeah, sure."
e "…you okay?"
pause 1.5
a concern "Yeah… yeah, I’m…"
pause 2.0
a bashful "Corona’s ended up being a bust. I’m just disappointed."
e "Aw. Yeah, I get it. Don’t beat yourself up about it. Let’s go to Shogey’s, maybe you’ll cheer up."
a hm "Shogey’s? The sports bar?"
e "Yeah. I like their wings. Plus… they have beer."
a surprised "…"
a stan "I’ll be there."
hide coutday with dissolve 
show shogeys with fade 
play music ambience 
"Fifteen minutes later, I’m sitting at the bar in the brightly lit room, hearing men talk loudly as they stare at whatever sports game is on the screen on the TV while I wait for Ethan to show up."
"I order a beer, and the waiter asks me if Babylon is okay. I tell him no – Babylon is the expensive kind – that a Tonio would be good."
"If I could, I would have ordered a Babylon. I remember the first time I tried one – on my twenty-first birthday at some dive bar near Ethan’s apartment. He had bought me both, as a birthday present, and asked me if I could taste the difference."
"At the time, they both tasted equally as bad. Now that I’ve acquired a bit of a taste for them, however, I can tell that Babylon is the superior brand. But, alas, it’s about the price of two and a half Tonios, so it’s unfortunately not worth the extra money."
"The bartender comes back with two beers, a Babylon and a Tonio. He slides my drink in front of me, and the other to the guy to my left, who I somehow failed to notice was even there. He takes it, downing about half the bottle in one big gulp."
"Envy boils inside me as I watch him from the corner of my eye. How does someone as disheveled looking as him have the money to afford expensive beers like that? Has he had to work as hard as I do? Will he ever have to?"
"I think back to my conversation with Mr. Grey. How stupid it is to think that he and I could ever be equals. Gambling isn’t going to fix anything. He’s just an insane man who happened to get lucky."
pause 2.0

a worried "{i}Well… isn’t that the whole point? Getting lucky?"
a "{i}What if I could have gotten lucky, too?"
stop music fadeout 3.0
pause 2.0

"I shake my head. When have the odds {i}ever{/i} been in my favor? That coin would have sealed my fate into his hands, no question about it."
"I seethe internally as I’m about to bring the bottle to my lips, when the stranger next to me slides his bottle to my side. I look over at him completely now, raising an eyebrow."
show s body2 uniform2 stan2 with dissolve 
anon "Oh, sorry… You seemed to be eyeing my drink. I thought maybe you wanted to have some."
a hm "…"
show s body uniform stan with hdis 
play music thewolf 
"This… man… speaks in a low, almost hushed voice, a serious look on his face that I can’t tell whether it's because of me, or if that’s just how he always looks."
"He has a bit of an accent, as if English isn’t his first language, but I can’t quite discern where it’s from. The ‘disheveled’ look I assessed earlier may not have been completely true; he seems more rugged, like he’s not trying hard to look good."
"He doesn’t have to, though. He’s naturally handsome, with dark fur and piercing eyes to match. He’s unlike anyone I’ve ever seen before, at least in person. He could fit right into a movie with that face."
"I laugh off his statement, shaking my head."

a bashful "N-nah, sorry… I’m good with mine. Thanks."
show s smile 
"He nods, offering me a sheepish smile and grabbing his bottle to clink it against mine."

anon "{i}Salud, pues."

"I stare at him as he practically finishes the bottle in one gulp. So, he’s a Spanish speaker. From where in the world, I couldn’t tell off his accent alone. The last time I met someone who spoke Spanish was... back in the Academy."
show s hm 
anon "You waiting for someone, {i}chele?"
a flattered "Uh…{w} yes?"
anon "You don’t sound so sure."
a bashful "I’m sure. I just don’t know what {i}chele{/i} means… it’s nothing bad, is it?"
show s grin 
"He laughs a full, hearty laugh, leaning his body a bit closer to mine. My instincts tell me to back away. {w}I don’t, though."
show s body2 uniform2 cocky2 with qdis 
anon "{i}Chele{/i} just means you have light-colored fur. It’s not offensive."
show s body uniform smile with qdis 
a surprised "Oh. Well… how do I know you’re telling the truth?"
anon "…"
show s amused 
anon "You don’t. You’re just gonna have to take my word for it."

"He practically whispers this, looking me right in the eyes as he does."

a cocky "…"
show s smile 
a "Well, just in case you {i}are{/i} calling me something bad, I’d rather you call me by my name."
a smile "I’m Angel. I don’t think I’ve ever seen you around Sonora."
s "Nice to meet you, {i}Ángel{/i}. I’m Sebas."
a surprised "Sebas? I've never heard that name before."
s cocky "It’s short for {i}Sebastián{/i}, if you must know. I just like it better this way."

"His accent comes out strong here, and I realize he must have trouble pronouncing his r’s, practically rolling them when he tries to say them. He says my name differently in his accent, {i}Ahn-hel.{/i} It sounds… nice."
"He also pronounces his own name completely different than you would in English, his vowels and consonants sounding almost… harsher? {i}Seh-bas-tyan{/i}, with more emphasis in the last syllable."
show s body2 uniform2 cocky2 with qdis 
s "So, {i}Ángel{/i}… is this mystery person coming any time soon, or should I keep you company?"
show s body uniform cocky with qdis 
a smile "He’s being held up at his job. But I wouldn’t mind your company until he gets here."
s amused "Is that right…?"
show s stan 
"He finishes his drink, licking his muzzle slowly as he stares down the counter."

s hm "I’m surprised to see someone like you here at this hour."
a hm "Someone like me?"
s "You are a Valentine, yeah? I hear it’s quite the demanding job."
pause 1.5
show s stan 
a bashful "That’s right. Never a dull moment… I’m just stopping by for lunch."
s smile "I see. It must be interesting though, being a journalist. You get to talk to so many different people, go to different places."
show s stan 
a flattered "Hah. No, not really. The Valentine Report only covers stories inside of Sonora, and talking to people isn’t exactly a fun part of the job. Most here don’t really like Valentines."
s lookaway "So I’ve come to notice."
pause 1.5
show s stan 
a surprised "Where are you from, actually?"
pause 1.5
s smile "Michigan."
pause 1.5
a concern "Oh."
show s body2 uniform2 cocky2 with qdis 
s "What? Could it be... you wanted to know where I'm {i}really{/i} from?"

"My cheeks grow hot. Now he's gonna think I'm some racist."

a flustered "N-No no, I was just-!"
show s body uniform cocky with qdis 
s "Heh. {i}Tranquilo.{/i} I'm messing with you."
s smile "I'm Colombian. But I do live in Michigan."
a "I see... good to know."
s amused "I take it you don't see many foreigners around here?"
a bashful "Well… there are lots of people from all around the world living here, actually. I’ve just never had a proper conversation with anyone who speaks Spanish."
s smile "Maybe I can teach you a thing or two… when you’re not so busy."
pause 1.0
a blush "I’d like that."
show s amused 
a smile "So what brings you to Sonora, anyway?"
pause 2.0
show s amused at center:
 yalign 0.1
 ease 0.8 zoom 2.0
"He leans in even closer, as if he’s about to tell me a secret. I get closer too, so close I can smell the beer on his breath. It makes my face burn red."

s "I’m here on business... But, that’s not the main reason I came to this city."
s cocky "To tell you the truth, {i}chelito…{/i}{w} I came here to gamble."
pause 2.0
show s smile 
a surprised "Did you, now?"
s amused "That’s right. I was wondering, actually… if you happened to know of any good places for that."
pause 1.5
show s amused at center:
 yalign 0.1
 ease 0.4 zoom 1.0
"I lean back in my own space, sighing."
show s stan 
a hm "Unfortunately not. Valentines can’t gamble."
s hm "’Can’t’ or ‘don’t’?"
a hm "That’s… the same thing."
s stan "I don’t think it is."
pause 2.0
a worried "In any case… the only place I know of is Corona’s, and let’s just say, I don’t recommend it. I’m actually writing a story about the missing person case that happened there not too long ago."
s lookaway "I’ve heard about that, too."

"His casual demeanor falters somewhat, a darkness clouding his already pitch-black eyes."

s hm "Well, doesn’t matter. There’s plenty of other places to go, I’m sure."
s smile "In fact, I’ve heard talk around the town that there’s an underground ring somewhere in Sonora. Maybe I’ll check that out instead."
a hm "Underground? Where did you hear this?"
show s surprised 
"He tilts his now empty bottle side to side, toying with it as he thinks."

s "Where I heard this…? I can’t remember anymore. I get around a lot. But I did remember where it was. Some bar called The Albatross."
a concern "…"
show s stan 
"That’s… the dive bar near Ethan’s apartment."

a body2 thinking "I see…"
pause 2.0
s smile "You know, {i}chele{/i}, I think you should check it out. Those kinds of people are always in the know-how, and if you gamble with them, they might tell you a thing or two. Could help you out with your story."
show s stan 
a body cocky "Hah. Fat chance. Even if I wanted to gamble, which I don’t… I don’t even have the money to do it."
s hm "Who said anything about money? You have something much more valuable."
a hm "And that is…?"
show s stan 
pause 2.0
s "Information."
show s body2 uniform2 stan2 with qdis 
s "Sure, you might have to pay your first time around, but… unlike a casino, money isn’t the only thing you can put on the table in these places."
s hm2 "Properties, possessions… and yeah, even something as abstract as information. It’s all fair game, as long as both parties agree. And trust me, these people have a lot of information to share as well."
show s body uniform smile with qdis 
s "You’d be surprised how interconnected this world is. Someone knows a guy who knows a guy, who knows a guy…"
s cocky "And pretty soon, you know every guy. And the person with the most knowledge has the most power."
s amused "And isn’t that what you’re after, {i}Ángel{/i}?"
pause 2.5
a concern "…"

"Does he mean information…{w} or power?"

a "I, um…"
show s surprised 
e "Angel."
stop music fadeout 3.0
show s stan at slightleft with move
show e uniform stan at slightright with dissolve 
"I flinch, quickly turning around to see Ethan standing right behind me, with a look that tells me I’ve done something wrong."

a bashful "Ethan… there you are. What took you so long?"
e hm "Got held up at work. Who’s your friend?"
show s smile 
"He nods towards Sebas, who, despite being put on the spot, doesn’t seemed phased by Ethan’s pointedness in the slightest."

a "Um… Ethan, this is-"
show s body2 uniform2 cocky2 with qdis 
s "I’m just a stranger making conversation. But unfortunately, I’ve got places to be now."
show e stan 
show s body uniform amused with qdis 
"He gets up, opening his wallet to leave a bill on the bar, and very smoothly leans close to me as he’s turning to leave, speaking in a hushed voice that I’m sure Ethan couldn’t hear - maybe intentionally so."

s smile "I’ll see you around, {i}Ángel{/i}."
hide s smile with dissolve 
"I shudder, resisting the urge to turn and watch him leave. Ethan slides into the stool that Sebas was on, giving me a puzzled look."
show e hm at center with move 
e "Do you know that guy?"
pause 2.0
a surprised "Never met him before."
e "Yeah, well let’s hope we don’t run into him again. He gives me the creeps."
a bashful "Yeah… me too."

"Or so I say. And, although he does kind of give me the creeps, too… I secretly hope that it won’t be the last time I run into him."
play music ambience 
e uh "Stop talking to strangers, too. You're gonna get yourself into trouble."
a eyeroll "Yes, Dad."
e sigh "Ugh. Whatever. I need a drink."
show e hm 
"He waves over the bartender and orders - what else - a Tonio. I prop my chin on my hand, resting my elbows on the bar’s countertop as I watch him take three big, manly gulps of his beer."

a worried "Rough day?"
show e sigh 
"Ethan sighs as he sets the glass down, licking his muzzle clean."

e hm "Sort of. The police station is a bit of a mess right now. I don’t want to get too into it, though. I don’t even fully know what’s going on."
a "Hm… that does sound tiring…"
e "Yeah… though, I’ve never seen it this… hectic."
show e surprised 
a surprised "Wasn’t it like that when you were younger?"
e "You mean when my dad was in office?"
a cocky "Kind of, yeah. Or when you first started off. You know… {i}way{/i} back then."
e hm "Haha. Well, no. Not when I was starting off."
e surprised "But my dad would work late nights. Mainly because he worked the graveyard shift. I just thought that was how it always was, though. I guess you don’t really catch onto things when you’re a kid."
a surprised "Hm."
e frown "Enough about me, though. What about you? What did {i}Mr. Valentine{/i} want?"

"Ethan says his name like it has a taste to it, and not a very good one at that. I just smile, rolling my eyes."
show e hm 
a cocky "Oh, you know, just to partake in his favorite pastime in the whole wide world… tormenting me for fun. I had to go on a fetch quest for donuts that he didn’t end up eating."
e uh "Seriously? That guy’s a lunatic."
a bashful "Hah, yeah… but whatever."
e flattered "Yeah. What can you do, am I right?"

"I hum like I agree with him… but, in my head, I can’t help but think about my conversation with Mr. Grey, as much as I’d like to pretend our whole interaction was just some nightmarish dream."
show e surprised 
"Despite what I said, Mr. Grey {i}did{/i} give me an option. Just the very thought is crazy to me, and I still haven’t been able to fully process it."
"I had an {i}option.{/i} I had an out, albeit an extremely risky out, to this life that I’m trapped in, for the first time ever. So, when I hear Ethan say the words ‘What can you do?’… I realize that there {i}is{/i} something I could’ve done."
pause 2.0
"Maybe something I {i}should’ve{/i} done…"

e worried "In any case, what happened in Corona’s?"

"Ethan’s voice snaps me out of my worrying thoughts, only for his sentence to bring another layer of anxiety to them. No way in hell am I telling him what happened in there."
show e hm 
a flustered "Huh? Oh, um… it was just… useless."
e "Seriously? How come?"
a flattered "Well… I did try and talk to the staff, but…"
e "But?"
show e surprised 
a bashful "But nothing worthwhile was said."
pause 2.0
e worried "Aw. I see."
show e smile 
"He seems somewhat let down by this, but mostly relieved, taking much smaller sips of his beer as he looks at nothing in particular. Did he really wanna know about Corona’s?"
"More importantly, apart from my very strange interaction with Mr. Grey, did I really not learn anything useful today? He claims he has nothing to do with the disappearances, and his staff are all under a watchful eye."
"Doesn’t that put me back at square one?"
"Unless…"
"My conversation with Sebas replays in my head… but, was he telling me the truth? Or just planting seeds in my mind?"
"Either way, I can find out if I play my cards right."
show e surprised 
a surprised "Well… there was {i}one{/i} thing I found out about."

"Ethan perks up again, listening attentively."
show e stan 
a hm "I was talking to a staff member-"
e hm "Which one?"
a surprised "Uh… I don’t know, they were just walking by in uniform. Maybe a receptionist?"
show e stan 
"He nods, urging me to go on."
"He bought it. Nice."
show e surprised 
a frown "Anyway, they told me something about their boss keeping them under strict surveillance, and that they doubt it was anyone from the staff. But… they also told me to ask around a certain underground ring."
a hm "The Albatross seems to have some gambling going on underneath the bar. Have you… heard about that?"
show e stan 
pause 1.5

"Ethan doesn’t look too surprised by this, which just confirms my suspicions before he even opens his mouth again."

e sigh "There have been reports about underground rings forming in the city in the past couple of months. The Albatross {i}is{/i} a suspect… but we have nothing concrete yet."
show e stan 
a hm "Why haven’t you guys investigated it? If it’s something the S.P.D. suspect is happening."
e hm "It’s not that simple. There are ways of going about these things. You think they’ll just let a cop in the ring, no questions asked?"
e frown "It’s underground for a reason, Angie. It’s supposed to be a secret, and even if there are rumors going around, without solid proof, we can’t do anything."
e hm "Besides… private gambling isn’t {i}technically{/i} illegal in Sonora. There are just certain rules you have to follow. If it’s just a couple of guys playing poker, we can’t really shut that down."
e uh "But if they start sending out invitations, well… then it becomes a problem."
a concern "…"
show e stan 
a "But then… what would be the issue? If anyone can just gamble with whoever they want, why does it matter if there are rings?"
pause 1.5
e "Because there’s no regulation. Unlike casinos, the house can accept anything as payment, not just money, and that becomes a problem. People lose their homes, their possessions… some people gamble their family members away."
e frown "That’s why, when you’re out of physical money, but still think you can turn your luck around somehow…"
a surprised "You go to a ring."
e sigh "Exactly."
show e stan 
"So, Sebas was telling the truth after all.{w} What else was he right about?"
show e hm 
a body2 thinking "{i}I guess this is my only real lead right now… that doesn’t give me many options. I might have to end up going to The Albatross… How would I even go about doing it?"
a frown2 "{i}Maybe a disguise? I don’t have many clothes, though…"

e frown "Don’t even think about it."
a body surprised "Huh?"
e "I know what you’re thinking. You’re not going there."
a frown "What? Why not?"
e "If people have gone missing right on the doorsteps of the most famous casino in the city, imagine what would happen to you at some dingy dive bar."
a "I’m not going to get killed for just walking into a bar. This is part of my job, you know."
e "No, your job is to write a story on the disappearance of that girl, not going around shady pubs and entering gambling rings."
a concern "That’s… sometimes part of it."
e uh "Don’t start right now. I don’t need to hear how you think you have everything under control, and you don’t care what happens to you."
a worried "I do care what happens to me. But if I don’t at least try-"
e angry "Why don’t you try listening to someone who clearly knows more about this than you and just do what you’re supposed to do for once?"
pause 2.0

a concern "…"

"My cheeks flush, at first in shame, but it quickly morphs into something different. Something stronger."
show e surprised 
a angry "So, what? I’m just some idiot who doesn’t know what they’re doing?"
pause 1.0
e uh "That’s not what I meant. You just..."
pause 2.0
show e hm 
a "That's exactly what you meant."
e uh "Well, can you blame me? You never take my advice."
a "Your 'advice' is to just shut up and do as I'm told."
e hm "If that'll keep you safe, then just do it. Better to bite your tongue than the dust."
show e surprised 
a dejected "Yeah, because I'm too stupid to know better, so you have to tell me what to do so I can stay safe? I think I get it now."
show e frown 
"I scoff, getting up to head towards the bathroom when Ethan grabs my arm, starting to protest."

e "Hey, calm down. I didn’t mean it like that. You {i}know{/i} I didn’t mean it like that."
e sigh "Just sit back down, and we’ll{nw}"
show e surprised 
show shogeys at shake 
stop music fadeout 1.0
a nngh "Stop {i}fucking{/i} telling me what to do, Ethan!"
pause 2.0
"I yank my arm away, something snapping in my mind that makes me start seeing red."

a concern "What is wrong with you? Who do you take me for? Why do you feel the need to watch over me like I’m some idiot who can’t take care of himself?"
a angry "I’m not your child, or {i}whatever{/i} you think I am that gives you the authority to keep telling me what I can or can’t do! I’m so fucking sick of it!"
show e concern 
"All the pent-up frustrations from today stumble out of me all at once, and I couldn’t care less in this moment if I’m making a scene, if I hurt Ethan’s feelings. {w}I just want to go home."

a sad "You really think I don’t have enough of that already?"
a "You’re the one person I thought I could get away from all of this, and just be myself around… I guess I can’t even do that."

"I slam a crumpled-up bill on the counter of the bar, giving Ethan one last look of disdain before turning around and exiting the bar."
hide e concern 
hide shogeys
with dissolve
show angelapt with fade 
"Home."
"Or, at least, the only place in the city that comes to close to it."
play music soft 
"It feels like forever since I’ve last step foot in my own apartment, even though it’s only been about a day or two. Life in Sonora can feel endless in that way."
"It wouldn’t matter much, anyway. This space isn’t particularly pretty or cozy – that’s why I spend so much time over at Ethan’s – but it’s the one place in the city where I can be completely, fully alone… which can be both a good and bad thing."
"I feel my entire body slump from exhaustion as I close the door behind me, and I start to slowly undress from head to toe, trudging towards the bathroom as I peel off each article of clothing from my fur."
"The feeling of wanting to burst into tears overtakes my sense, but, just as always, I push it down. Crying wins me nothing. It’s just a waste of time."
hide angelapt with dissolve 
show angeltub with dissolve 
"I turn on the faucet to my bathtub, setting my bare ass on the edge of its porcelain body as I watch the warm water fill up.{w} I think of nothing.{w} I feel nothing. "
"I can’t. I don’t allow myself to. The moment I let my reasoning slip, I know I’ll fall into a sadness so deep, not even I could pull myself out of. If I allow myself to daydream of better times, of a softer, simple life… it would drive me to the brink of madness."
"Because it’s impossible. Because I know I’ll sob my eyes out, stomp and throw a tantrum like a child, scream out ferociously how it’s not fair, it’s not fair, not fair…!"
"And when I’ve finally settled down… nothing will have changed. I am still a Valentine. I am still in Sonora. I am still all on my own, with no one to come home to, no chance of living a normal life."
"So…{w} I don’t cry. I don’t feel. I simply exist in the life that was laid out for me."
hide angeltub with dissolve
show 1-tub1 with fade 
"The water is warm, hot even. It stings as I slip inside, making my muscles tense up when I submerge myself completely. Eventually, though, my body adjusts to the temperature, and my sense of touch goes numb from the heat."
"But I can’t relax. The rage I feel for the way Ethan spoke to me starts to spread to the way Mr. Gray looked at me, like I was a toy he really wanted to play with. Then it goes to Mr. Valentine, how he, too, toys with my head any chance he gets."
"The cycle continues and repeats, until I’m not sure whether the heat I feel is from the bath water or the rage flushing against my cheeks."
pause 2.0
show 1-tub2 with dissolve
hide 1-tub1 
"I grab my phone sitting on the sink, which I got into a habit of carrying everywhere nowadays. I never know when Mr. Valentine will call me for some other stupid, menial task."
"I wonder to myself, is there someone who could talk me out of feeling this way? My mind immediately goes to Ethan. It was always him, in times like these. He would come over, or I would go to his apartment, and he’d show me some old movie I would never really be interested in."
"And yet, somehow, it made me feel better. To have someone in my life who wanted to share their time with me, not under any transaction, but just because they liked me. It made me feel… normal."
"But I don’t want to think about Ethan right now."
pause 1.5
"Then, that leaves only one other person…"
hide 1-tub2 with dissolve
show angeltub with fade 
"With a shaky hand, I reach for my phone and dial the number I know by heart, pressing it up to my ear. I always get nervous when I call her, as if I’m intruding in her life, but I remind myself to not be ridiculous"
"She’s my mother. Moms want to hear from their kids, don’t they?"
pause 1.0
"The phone rings. Once, then twice, three times…"

mom "{i}Hello?"
a -uniform surprised "Mom?"

"My voice comes out pleading, and tears fill my eyes as I hear her voice on the other end of the line. It’s amazing how quickly it soothes me."

mom "{i}Angel?"
a bashful "Mom, hi… yeah, it’s Angel. How are you?"
a flattered "I-I’m sorry if I’m interrupting something, or if you're busy, I just… I wanted to talk to you."
pause 1.3
mom "{i}Oh. Well, alright then… how are things going for you, Angel?"
a worried "…things are…"
pause 1.5
a sad "…"
a bashful "Things are fine. I’m just a little tired lately."
mom "I understand. I’m sorry, honey… Don’t get bummed out about it, okay? You’re doing a good job, and I’m very grateful for everything you do for me."
a concern "…"

"How many times have I heard her say those words to me? They always used to fill me with hope, always made my heart feel warm and proud. So… why do these words feel hollow to me now?"

a flattered "I know, Mom. I was just thinking that maybe… I could come visit soon? I got a new story, and if everything goes well, I think I’ll get a bonus, which would be enough to…"
pause 1.5
mom "Oh honey… I don’t know. Are you sure you can afford it? Everything is so expensive in Sonora."

"She speaks in that soft, slow manner she always does with me, ever since I was little. Today, for some reason, it only annoys me."

a bashful "It’s fine, Mom. I have a bit saved up already. This would just be the last push I need to make it come true. Besides, I think I need a little break, hehe…"
pause 2.0
mom "Oh, I know honey. You work very hard. But…"
mom "Things are just… not very good here on my end, Angel. I got a new job, so I won’t be able to take days off whenever it is that you come to visit. It’s just not good timing, hun."
pause 2.0
a scared "…"
a "Oh… Okay…"
a bashful "No, yeah, that’s fine, um…{w} that’s okay!{w} You just never mentioned a new job, so… I mean, of course you didn’t, haha!"
a "When was the last time we called? Last month? Or, the one before that? It’s been a while."
mom "Yeah… yeah, it has. I’m sorry, sweetie…"
a flattered "It’s okay! I know you’re busy… um…"

"I’m trying to keep my composure, trying to not cry as I feel my one beacon of hope slowly die out in front of. I tilt my head up, looking at my monochrome popcorn ceiling, my breathing ragged and heavy as I try to blink away the tears."

a bashful "I’ll just… save that money. For next year, when you’re more acclimated to your job."
mom "Okay sweetie. Whatever it is you decide."
pause 2.5
"I wait for her to tell me more, to try and reassure me we’ll be reunited again soon. Static is all that comes from the other end of the line."
pause 1.0
a sad "I… I love you…"
pause 2.5
mom "I love you too, Angel."
pause 2.0
a "…"
a "Bye…"
mom "Goodbye, honey."
stop music fadeout 1.5
pause 1.5

"She hangs up the call, and I dig my claws into my arm, willing myself not to do it. Don’t cry. Even if my own mother – the person who I’ve been fighting for my whole life – doesn’t want to take time to see me…{w} just don’t cry."
hide angeltub with dissolve 
play music piano 
"But it’s no use. I’m not made of stone, as much as I wish I was, and after seeking solace in the only family I have to turn to and being met with nothing but indifference…{w} I break down."
"I sob. I cry and scream in my tiny, colorless bathroom, my wails echoing against the walls."

a1 "It’s not fair…"

"The words I didn’t dare even utter now come out in pained cries as my teardrops plop loudly into the water. I was right, though; it fixes nothing. I am still a Valentine, no matter how hard I scream… but it feels good, somehow. To let everything I had inside come out."

"By the time I finish crying, my fur is soaked and matted, my bones aching from sitting in the tub for too long. I get up, my throat sore and my eyes red and burning. I meticulously dry myself in front of my mirror, staring hard into my reflection."
"It’s just the me that I’ve always seen, if not a little dazed and distressed. I look angry, sad, and deranged… which I guess I am. But I hate to see myself this way. So weak, so pathetic."
"I won’t even be able to be used as a pawn like this. No one wants to play with such a fragile toy."
pause 1.5
a1 "…"

"But no. I’m nowhere near broken. I’m exactly as I was yesterday, and the day before. Nothing in my life has changed."
"Nothing… except for the dark realization that, in the end, I am truly and completely on my own in in this city."
pause 1.5
"I was never just fighting for my mother… there’s one thing that mattered far more to me than her, as selfish as it is to admit. And that’s my freedom."

"I drop my towel on the floor and walk out of my bathroom, naked, cold, and alone… but now filled with something stronger than just pure determination."
pause 2.0
"After all, I still have a job to do."
stop music fadeout 2.0
show divebar with dissolve 
play music familiar 
"The Albatross is a stuffy, dingy place. The smell of smoke lingers in the air, and the regulars talk loudly amongst themselves, drowning out the sound of the jukebox with their laughter. It’s cheap and dirty, but somehow finds a way to be cozy."
"Basically, it’s for people like me."

a uniform hm "{i}So how is there an underground ring here?"

"It doesn’t make sense. I don’t see anyone suspicious, or people walking into the same room. In fact, I don’t see very many rooms in this place at all, minus the kitchen in the back, where they make the soggiest nachos known to mankind."
"I think they dip them in water or something. Anyway…"
"I slip a peanut into my mouth, scanning the room, listening in on anything out of the ordinary… but I’m coming up short. Are they being extra careful because I’m here?"
"I ended up coming in my uniform, but I’m technically off the clock right now. I guess that wouldn’t matter to anyone, though. Valentines aren’t to be trusted…"
"I sigh. I may have let the idea of getting more information get to my head. Maybe Ethan was right. Maybe I bit off more than I can-"

anon "{i}Chelito~"
show s body2 uniform2 cocky2 with dissolve 
"I feel a hot whisper against my ear and a large hand grab my waist, so sudden that it catches me off guard, shuddering a full body chill."

a flustered "S-Sebas…"
s "{i}Dichoso los ojos.{/i} I didn’t expect to actually see you here tonight."
show s body uniform smile with qdis 
"He sits down on the stool next to me, and I take the opportunity to compose myself. How did I not notice him walk in? He didn’t even make a sound."

a cocky "Well, I’m full of surprises. Seems like you are, too."
pause 1.5
s amused "You could say that."
s cocky "You want a drink? You look like you could use one."
a hm "Why do you say that?"
s amused "You just seem... tense. Some alcohol will help with that, I'm sure."
a bashful "Hah. You might be right, but I think I'll pass on the drink."
s cocky "Oh? Well, if there's something else that could help you ease up, let me know. I'm full of ideas."

"I roll my eyes, but a smile is still on my face. This guy’s clearly full of shit."

a cocky "{i}But even if you’re hot, I won’t let my guard down for someone like you."
show s surprised 
a flattered "I’m okay."
s "Are you, now? What a shame."
show s smile 
"He orders a drink, and I sneak glances at him while he’s distracted with the bartender."
"Yeah, this guy’s eye-candy for sure. His arms are huge, his hair soft and flowy when he moves… but those eyes are what really capture me."
"Tired, and with dark circles under them, but with an intrigue and allure that I can’t help but want to stare into. What secrets lie behind them, I wonder…?"
show s cocky 
"He suddenly turns to me, and I quickly glance away, pretending to be very immersed in the pattern of the wooden countertop."

s amused "So, {i}Ángel{/i}… tell me. Are you here because of me?"
a surprised "What…?"
s "Because I told you about {i}that?"

"He’s speaking in code now?"

a bashful "…maybe."
show s smile 
"Sebas smiles."

s "Well, good thing I’m here then. You would’ve been lost without me."
a hm "Oh? I think I was doing just fine."
s cocky "Yeah? How were you gonna get in?"
a surprised "…"
a flustered "That’s… a work in progress."
s flirty "Do you even know where you’re supposed to enter from?"
a "…"
a "The… back… door…"
s amused "{i}Ajá.{/i} It’s fine to admit it, you know. You can ask for help."
show s surprised 
a frown "I don’t {i}need{/i} help."
pause 1.5
show s stan 
"He shrugs, grabbing a peanut and popping it in his maw like a pill."

s smile "Whatever you say, {i}chelito."
pause 2.0
show s amused 
a hm "If, say, I {i}did{/i} need help… what would you tell me?"
pause 1.5
s flirty "Well… first, I’d bring you a bit closer…"
show s flirty at center:
 yalign 0.1
 ease 0.8 zoom 2.0
"He grabs the edge of my stool and effortlessly pulls it right next to his, bringing us shoulder to shoulder."

s "…to prevent any listening ears."

"I can smell the peanut on his breath, his muzzle closing in on my ear again. I blush, completely unaccustomed to this level of closeness with another guy that isn’t Ethan."
"Not even he puts his face this close to mine…"

s amused "And I’d tell you to order a Death in the Gulf Stream… and tap your fingers-"

"He taps his claw on the countertop thrice as he enunciates his next words."

s "Just.{w} Like.{w} This."
pause 1.8
show s smile at center:
 yalign 0.1
 ease 0.4 zoom 1.0
"I pull away to look at him."
show s surprised 
a concern "How do you know all of this?"
pause 1.5
s cocky "Do you think journalists are the only ones with connections?"
show s smile 
"He downs his drink – a rum and coke, I think – in three big gulps and sighs, slipping out of his stool to stand behind me."

s "And speaking of, I’m actually here on business myself, so I’ll have to cut our conversation a little short tonight."
show s amused 
"He slips something into my back pocket, his hands lingering there for a moment too long, and I whip around to frown at him."

s "Just my personal number. I wanna hear all about your escapades tonight."
a hm "…"
s smile "I’ll see you around… {i}Ángel{/i}."
hide s smile with dissolve 
a concern "…"
a "{i}What a freak. Stupidly hot… but a freak nonetheless."

"I know exactly what he’s doing. Flirting with me, closing the distance between us (literally) to make me open up to him. I bet he just wants information out of me, too."
"Sebas… Something is off about that man. So very, very off, and yet…"
"I don’t think I’ll be able to resist him, even if I tried."

a body2 hm2 "{i}…well, whatever. He did give me some pretty useful information… if it turns out to be true, that is."
"But nerves start to rattle me again. There’s no going back after this, no feigning ignorance; If I’m caught inside a hidden gambling ring, there’s no saving me from the consequences that may come."
"My instincts tell me to just go home – play it safe, do as I’m told… but the anger and refusal that comes from thinking that way overpowers my fears."
"I don’t want to be a pawn anymore."
stop music fadeout 3.0 
a body frown "Excuse me…!"

"I call the bartender over, my heart pounding in my ears. He nonchalantly stands in front of me, a bored look on his face."
pause 2.0
a concern "…"
a "Gimmie a Death in the Gulf Stream."

"{i}Tap. Tap. Tap."

ba "…"
pause 1.5
ba "We don’t have that in stock."
pause 2.5
a surprised "O… Oh…"

"My ears burn as I look down, my face hot in raw embarrassment. Was I really played for a fool by Sebas? When I see that motherfucker again, I swear, I’ll-"

ba "But there’s some in the supply closet. In the bathroom."
pause 1.0
a "Huh?"

"The bartender jerks his head towards the bathroom, that same bored look on his face."

ba "Check in there."
pause 2.0
ba "Now."
a flustered "Eh? Uh! Right…! Thank you…?"

"I hop off my stool and hurry over to the bathroom, my head spinning in different directions as I open the door."
hide divebar with dissolve 
show barbathroom with fade 
play music darkjazz
a yeesh "Ugh…"

"It smells like piss and cigarettes. Do guys not aim for the urinal when they pee?"
"It’s quiet, other than the hum of a ventilation fan somewhere in the room. On the other end of the room is the supply closet door, and I slowly approach it, as if I’m some protagonist in those old horror movies Ethan loves so much."
"I place a sweaty paw on the handle, and taking a deep breath, I turn it-"
pause 2.0
"It’s locked."
pause 2.0
"I turn around, getting more agitated. What, is there a key? Or is everyone in the world pulling some elaborate prank on me?"
"This is getting so-!"
stop music fadeout 1.0
hide barbathroom
pause 0.5

"The door suddenly swings open behind me, and before I have time to react, a pair of large hands grab onto me and pull me to the other side."

"I’m thrown onto the ground, disoriented by the sudden change of lighting, and when I open my eyes…"
show ring with fade 
"I see someplace that doesn’t look like a gambling ring to me."
"I expected a rundown, rustic place that would mirror the bar outside. The room I’m in now looks sleek, modern, brand new, even. It’s…{w} kind of beautiful."
play music dissonance 
"But I don’t have much time to admire my surroundings. Someone that seems almost twice my size steps in front of me, and I look up to see what I can only assume to be a pro wrestler with how well built they are."
"He sneers down at me, obviously trying to intimidate me. I steel my nerves, doing my best to not let it show in my face that he’s unfortunately doing a good job of it."

guard "Well, lookie what we caught here…"

"Someone else steps into my view, a woman this time, but surprisingly, she looks just as strong as the alligator."

guard2 "A Valentine? What’s he doing here?"
guard "Maybe he’s gone rogue. Or he’s just plain ol’ stupid."

"I frown at him, and that makes his grin grow wider."

guard "Or…"

"He kneels down and grabs me by the arm again, lifting me to my knees with a grip so tight, I’m scared it’ll bruise."

a nngh "H-hey! Let me go!"

guard "Or maybe, he’s sticking his little nose where it doesn’t belong."
a scared "…!"
anon "Come on now, Darwin… is that really any way to treat a guest?"
stop music fadeout 3.0
"’Darwin’ and I both turn our heads to look up at my savior, and my eyes widen the moment I see who it is."
show m clothes1 stan with dissolve 
play music tigerjazz 
"Matteo Milan... superstar actor and Sonora's golden boy."
"He's a celebrity in every sense of the word. Movies, TV shows, magazines... hell, I think he has his own fragrance line."
"From what I can remember, his father owns one of the largest banks in the country, and even his mother is in the entertainment industry...{w}so basically, he's a nepo baby."
"But I've seen some of his movies, and even I have to admit, he is quite talented. So..."
"What the hell is he doing in a gambling ring on the shittiest side of Sonora?"

m cocky "But I’ll admit, a Valentine does me make even me feel a bit uneasy."

"He kneels down to look at me, with piercing mismatched colored eyes that make me wonder if they’re even real. I can smell his cologne from how close he is, and I silently wonder if it's his own brand."

m serious "Why don’t you tell me why you’re really here?"
a surprised "…"
pause 1.5
a frown "Why does anyone come down here?"
a angry "…I’m here to gamble."
pause 2.5
show m stan 
"Matteo smiles;{w} I answered correctly, it seems."

m sweet "I bet you are."
show m stan 
"He stands up, addressing Darwin now."

m serious "Let him go."

"Darwin hesitates for a moment, then does as he’s told with a grunt. I guess even the strongest yield to the richest."
"Matteo waves a hand at both of his guards, and they wordlessly slip away, manning the door and looking inside with stoic expressions. He offers me his paw, and after a beat, I take it, letting him pull me to my feet."

m apologetic "Sorry about that. We can never be too careful down here, and you’re not exactly a friendly face."
show m stan 
"There’s an odd kindness to him, a smile on his face that I can’t quite tell if it’s fake or not. For the sake of my own safety, I’ll assume the worst... but even I have to admit, I'm a little starstruck."
"I'm not exactly a 'fan', but to see a celebrity so up close and looking right at me... it does things to my heart that I can't quite control. It helps he's very easy on the eyes, too."

a bashful "I-It’s fine. I guess I can’t blame you for that."
m sweet "I’m glad we’re on the same page, then."
m stan "I’m Matteo. Welcome to my little… establishment."
show m surprised 
a flattered "I know who you are..."
m "Oh? I'm surprised a Valentine knows about pop culture."
show m stan 
a bashful "Kind of hard to miss when your face is on billboards."
m apologetic "Well, you have a point there."
m stan "Is this your first time gambling?"

"Saying ‘yes’ might make me look too naïve… but saying ‘no’ means I won’t get any explanations about how to play."
"Well, whatever. I’d rather know the rules of whatever game we play in exchange for looking like I’m a dumb amateur."

a flattered "Yeah, it is. Would you mind walking me through it?"
m sweet "It’d be an honor."
m cocky "What’s your pleasure? Cards? Slots? Roulette?"

"I definitely don’t want to play a game that leaves {i}everything{/i} up to luck. I need to have some kind of control."
show m hm 
a surprised "Do you guys have poker?"
m cocky "Do we have poker? Do kitchens have forks?"
a bashful "Right. Stupid question."
show m stan 
"He leads me towards a table, and to my surprise, sits directly in front of me. Someone who doesn’t seem to be a guard approaches us, standing to our left."

a hm "What’s this?"
m sweet "We have a different style of poker around here. Our own little creation, to make us stand out. You’ll actually be playing against me."
show m stan 
a "What? You guys don’t have the regular kind?"
m cocky "If you wanted to play regular poker, you should’ve gone to a casino, Valentine."
a concern "…"
m sweet "I’ll simply be acting as the house for this game. If you don’t like it, you’re welcome to walk out at any time."
show m stan 
pause 1.5
a eyeroll "{i}Ugh. Talk about avant-garde bullshit."
a hm "Fine. I’ll play. What’re the rules?"
stop music fadeout 2.0
m sweet "The rules are simple."
hide m sweet 
hide ring 
with dissolve 
show redbg with fade 
play music casino 
m "We'll be using a standard 52 deck of cards, plus both joker cards, for a total of 54."
show 1-cs with dissolve 
m "The deck gets split in two, and our dealer places both halves on either side of our card shuffler here."
hide 1-cs with dissolve 
show 1-hands with dissolve 
m "Then, we both get 4 cards each, instead of the standard 5. No exchanges can be made once the cards are dealt."
m "The hands are all the same, minus one card, so there's a greater chance you'll get a good hand. However..."
m "That's where the jokers come in."
hide 1-hands with dissolve 
pause 0.5
show 1-bwjoker with dissolve 
m "The gray joker card is also a 'wild card', but not in the same way. Instead, a random card will be drawn from the deck, and that'll be your joker's value."
m "It leaves your hand up to fate. You might not want this card, Valentine."
show 1-cjoker with dissolve
pause 0.5
m "The colored joker is the good one. It's a wild card, and can be used to make any hand a little better. It'll represent any suit or rank once we move on to the showdown phase."
m "So, a three of a kind can become a four of a kind. That can be the difference between a win and a loss... so you're gonna want this joker."
hide 1-cjoker
hide 1-bwjoker
hide redbg
with dissolve 
pause 0.7
show ring
show m body clothes1 hm 
with dissolve 
m "We each pay a blind to start the game, one small and one big. Since you're new, I'll start off with the big blind and let you play first. So, if you fold, you lose the least amount."
m stan "Considering this is your first time gambling... let's start with 15 chips. Small blind is one, big blind, two."
a hm "How much is each chip worth?"
m sweet "Let's not worry about that right now. This'll be a practice round. If you win, you keep whatever you make. If you lose, I won't charge you a penny. If you like the game, we'll keep playing."
m stan "How's that sound?"
a frown "..."

"It doesn't sound {i}too{/i} bad, I guess. Although I may not know much about gambling, this game doesn't seem too unfair to me. A little more 'luck-of-the-draw' than I was hoping for, but I can make it work."
"I have to make it work."
show m amused 
a stan "Sounds good to me."

pause 1.5
m sweet "Perfect. Let's start then, shall we?"
show m stan at center:
 yalign 0.1
 ease 0.8 zoom 1.5
"My heart is pounding in my ears as I watch our dealer, a tall, quiet capybara, rips open a fresh pack of cards and splits the deck in half, slipping them into the machine as if he's done it a million times before."
show m sweet 
"Matteo smiles warmly at me, as if sensing my nerves, but I don't return it. Any sign of weakness, and he'll latch onto it until it becomes the death of me. I won't let him do that."
show m stan 
"Four cards are passed out to each of us, as well as three stacks of five chips. Matteo grabs two and throws them into the middle with a satisfying clinking sound, and he looks at me, quietly telling me to do the same."
"I grab one from my stack and slide it into our pile, hoping he doesn’t see just how shaky my hands are."
show m serious 
a flustered "{i}Am I really doing this? Think about how much trouble I could get myself into if I get found out. I could spend the rest of my life as a Valentine, or worse… in prison."
a sad "{i}But… is my situation right now… really any better?"
pause 1.0

"Mr. Grey’s voice echoes in the back of my mind."
l "{i}If my calculations are correct - and rest assured, they are - you’ve paid off less than ten percent of your total debt. Have you done the math, love? It’ll take more than forty years for your debt to be finalized."
a "…"
a "{i}That’s basically my entire life. At this rate, whether I do something bad or not doesn’t really matter anymore."
a frown "{i}Because…"
a angry "{i}I want to start living... {w}right now!"
show m stan 
"I grab my cards and look at them, Matteo following suit.{w} The game has begun."

"A pair of sixes, a four and a jack. No joker."
a hm "{i}This… is a pretty shitty hand."
a frown "{i}But the odds of Matteo having an equally shitty hand is pretty high, too. Considering we can’t even change our hands, the most we can hope for is pairs, or straights if we’re lucky enough."
a yeesh "{i}That’s where the joker would come into play… if I HAD one. Anyways…"
a hm "{i}Seems like I should fold. The only way I’d win is if he has a total pig."
show m sweet 
"Matteo looks up at me, a coy smile on his face. That’s right… a big part of poker is bluffing, isn’t it? As long as your opponent {i}thinks{/i} you have a good hand, then you can win, even with a pig."
show m stan 
"But it’s a risk… if they match you, you can lose, big time."
"I guess that’s the whole point of gambling, in the end…"
pause 1.5
a frown "…"
a "{i}I’m done with taking the safe route. If I can’t take a risk on a practice game of poker, with nothing to lose… then I’m not cut out to be in Sonora."
a angry "{i}’The risk makes the man’, huh, Mr. Grey? I’ll show you…"

"Our dealer places one card from the deck face down, then spreads his hands palms-up to us. I guess that means the betting phase starts now."

m cocky "Your move, Valentine."
a frown "…"
pause 1.5
show m surprised 
"I place two chips in the center of our pile, putting up a confident front."

a stan "Two chips."
pause 1.5
m amused "Ballsy. I like it."
m wink "Then, I’ll raise you by one chip."
show m sweet 
"He throws in three chips of his own, smiling that same kind smile. My eye twitches."
"So he has a good hand? Is that it? Or is he bluffing? God, I can’t tell at all…"
show m stan 
a frown "{i}Fuck it. It’s a practice round. I can afford to lose a chip or two."
a surprised "I’ll match your bet."
m cocky "We call that a ‘call’, Valentine."
show m stan 
a flustered "Uh- r-right… I call."

"I slide another chip to the center pile, making 6 chips in total."

dealer "You may now reveal your cards."
m sweet "You wanna do the honors?"
a concern "…"
show m stan 
"With a pounding heart, I flip my cards on the table, showing them off."

a surprised "A pair of sixes."
pause 1.5
m apologetic "Agh, darn."

"Matteo flips his, showing…"

m "Queen high-card. A pig."
a "…"
m wink "Congrats, Valentine. You won~"
a "I…"
show m sweet 
a blush "{i}I did?"
a excited "{i}H-Hah! I did! I won!!!"

"It’s impossible to hide my happiness, a giddy smile starting to creep into my face as my shaky hands fold together. I did it… I really did it!"
show m stan 
"That wasn’t so bad…! Scary, sure, but it was almost… fun…"
a flattered "…"
m amused "So… did ya like it?"
m cocky "Would you… like to keep playing?"
pause 2.0
show m stan 
a confident "Let’s do it."
m "…"
m amused "I knew you’d say that."
show m stan 
"The dealer starts shuffling the deck again, and I look over to Matteo."
show m surprised 
a hm "Wait. How much will the chips be worth now?"
m sweet "Hm? Oh, that. Well… let’s say, for this round… 50 dollars each. That sound good to you?"
pause 1.5

"I bite my lip. 50 dollars is pretty generous, but even that much is a lot for me. That’s almost a week’s worth of food, if I stretch it right. Throwing that away in a gamble would be…"
show m cocky 
"I shake my head. No, I can’t chicken out, not now that I’ve already gone all the way! Besides, I’ll make it back twofold if I win this one."

a bashful "Sounds good then."
m sweet "Perfect."
hide m sweet 
hide ring 
with dissolve 
pause 0.8
show ring
show m clothes1 surprised at center:
 yalign 0.1
 zoom 1.5
 
with dissolve 
a confident "A pair of nines."
m apologetic "Another pig on my end. Damn. You’re gonna run me out of business, Valentine."
a silly "I guess I’m a natural~"
show m stan 
a blush "{i}Another win… this is exhilarating!"
a bashful "{i}I shouldn’t get carried away… but, still…! I’m doing so well! I made 250 bucks from this game alone! If I could stay on a winning streak…"
a blush "{i}My debt could be paid off sooner than I thought!"
m sweet "Another game?"
a confident "You’re on."
show m stan 
"I grab my cards and immediately try not to let it show on my face…"
"…That I got the colored joker."
show m sweet 
a grin "{i}Yes!! Instant win! I just have to bluff my way into making him bet a lot."

"A three-of-a-kind isn’t bad at all. It’s higher than a double pair, right?"
show m stan 
"I push two chips into the center, trying to play it nonchalant."

a smile "Two chips."
m cocky "You’re becoming a seasoned gambler, aye, Valentine? Well, I can’t stay behind anymore."
m stan "I’ll raise you one chip."

"I smile. This {i}is{/i} fun."
show m amused 
a cocky "Let’s see how high you’re willing to go, Milan. I’ll raise you by one myself."
pause 1.5
m sweet "I’m pretty confident in my hand. I’ll raise you by two."
a surprised "…"
show m stan 
a concern "{i}There’s no way his hand is better than mine… right? Yeah, no way. What are the odds he gets a flush, or a straight?"
a frown "{i}He’s bluffing… I know he is. I just have to out-bluff him, and I’ll win the whole pot."
a stan "I raise your bet by one."
pause 2.0
stop music fadeout 2.5
m sweet "I’m all in."

"Matteo pushes all of his chips into the pile, a bead of sweat starting to form on my forehead as I watch him lean back confidently in his chair."
show m cocky 
play music dissonance 
a scared "{i}Jesus… I… I can’t fold now. I’d lose, what, two-hundred? Three-hundred dollars? But if I match him, that’ll be six-hundred dollars…! Matteo can certainly afford to lose that, but can I?"
a concern "{i}In any case, the only way to not lose any money now would be to check him… and hope I win."
a frown "…"
a angry "{i}No. I WILL win. I alone have the colored joker. That makes my hand better than his automatically, doesn’t it?"
a "{i}No more stepping down. I’m doing this now!"
show m amused 
a frown "I’m all in, too!"
show m sweet 
"I push my chips to the center before I can regret it, my adrenaline spiking to levels I’ve never felt before. Matteo seems way too casual about this… but, maybe there’s a hint of nerves in his eyes?"
show m stan 
dealer "You may now show your cards."
pause 2.5
show m amused 
a surprised "…!"
a "M-mine’s a three-of-a-kind! That means I win, right!"
m cocky "Now, hold on… didn’t you notice?"
m sweet "I have a joker card of my own."
"I blink. He’s right… he has the gray joker. B-but there’s no way…"
m cocky "Thomas?"
show m stan 
"Our dealer – Thomas – draws a card from the deck, and it feels like he flips it in slow motion to reveal…"
show m amused 
a scared "!!!"

"My face turns to ice.{w} He drew a six."

m sweet "Well, look at my luck! A flush on gray joker! I don’t think that’s {i}ever{/i} happened to me before."

"I shudder, feeling like I’m about to be sick. {i}Six-hundred dollars on a poker game…"
show m stan 
"That’s almost half a month’s paycheck… what am I gonna tell Mom? What am I- "

m cocky "Oh, shoot. We forgot to establish what the chips were worth this round, didn’t we?"
pause 2.0
a "H… huh?"
a "N-no, we didn’t. You said 50 dollars…"
m sweet "I said that last round, Valentine. Try and keep up, will ya?"
m cocky "So, let’s see… how about…"
m amused "A thousand dollars for each chip. That sounds good, right, Thomas?"
a nngh "What?!"
show m surprised 
show ring at shake 
"I stand up, slamming my hand on the table."

a pissed "Don’t fuck with me! You can’t just put a price like that! Who do you think you are?!"
show m serious 
pause 1.5
m "I think the better question is… who do you think {i}you{/i} are?"

"He stands up to meet my position, and those jewel-colored eyes turn icy in an instant, as if a switch was flipped in his head."

m angry "This is my ring, Valentine. You think you have some authority here?"
a scared "…"
show m serious 
a "B-but we… we gambled, fair and square…"
pause 1.0
m sweet "Yeah, sorry. Fair’s not really my thing."
show m serious 
a pissed "You…! You can’t do this! You can’t-!"
m angry "And who the fuck's gonna stop me?"
pause 2.0
m "Tell me, Valentine. What’re {i}you{/i} gonna do about it?"
m cocky "Gonna tell the cops? Go right ahead. Tell them what you did."
a nngh "…"

"I collapse on my chair, head hung low facing the table, blinking tears onto its surface as Matteo chuckles above me."

a sob "{i}Why…?"
hide m cocky
hide ring with dissolve 
show 1-matt
show 1-ang
with dissolve 
tr_text "Well, then. That’s… how much? Oh, right…"
tr_text2 "Twelve-thousand dollars. You have the money, don’t you?"
tr_text3 "Aw, don’t look so distraught.\nSorry to clip your wings, Valentine."
tr_text "But you really should’ve known better~"

a_text"{i}Why…{w} was I so stupid?!"
stop music fadeout 1.5
hide 1-matt
hide 1-ang 
anon "Sorry to interrupt your game, but… I couldn’t help myself from coming over."
show ring with dissolve 
"A low, familiar voice makes my ears flick, and looking up through my tear-soaked eyes, I see…"
show s body2 uniform2 cocky2 with dissolve 
s "{i}¿Qué te pasó, angelito?{/i} I thought you said you had this under control?"

"I blink several times to clear my vision and see him properly, dumbfounded by his sudden appearance. What does he want…?"
show s hm2
play music darkjazz 
m "Can I help you?"
show s body uniform stan at slightright with move 
show m clothes1 angry at slightleft 
"An annoyed Matteo does a once-over at Sebas, who just stands to my side, paws in his pockets, slightly hunched over without a care in the world."

s hm "This is my friend here. I’m guessing he lost to you?"
m hm "He did. What’s it to you?"
show s body2 uniform2 cocky2 with qdis 
show m serious 
s "I just hate seeing cute boys cry like that. Don’t you?"
show s hm2 
m angry "I honestly couldn’t care less. Darwin!"
show s body uniform frown with qdis 
"Darwin starts marching over to us, and a whine escapes my throat, but Sebas stands his ground."
show m hm 
s cocky "I’m not looking for any trouble. Actually, I just wanted to gamble with you, too."
m "…"

"Darwin just about puts his hands on Sebas when Matteo stops him, putting his own paw up in a ‘halt’ gesture."
pause 2.0
show s smile 
m angry "What are you on about?"
show m surprised                                                                                                  
s amused "Is the saying ‘double or nothing’ a thing here?"
m "…"
show s smile 
m cocky "You wanna gamble for double his debt, huh?"
s "That’s right. If you’d let me."
pause 2.5
show s stan 
m arrogant"Hah!"
m "Hahahaha!!"
m angry "Who do you think you are?"
s "You can call me Sebas."
show m surprised 
"He takes out his wallet and pulls out a shiny black card from inside, making everyone at the table gasp – except for me, who just sits there like an idiot that doesn’t know what he’s looking at."

s smile "And I believe this should show you I’m serious?"
pause 2.0
show m hm 
"Matteo glances at the card, then at me, then Sebas… then the card again."
show s stan 
m cocky "Heh. I don’t know who the hell you are, but if you’re willing to go double or nothing for this Valentine, then by all means. Be my guest."
m angry "But I’ve got my conditions. I want fifty thousand. I don’t care how you split it between the two of you."
s "And If I win, you let Angel go, debt free."
m cocky "Fine. It’s a deal."
s smile "It’s settled, then."
show m hm 
show s surprised 
stop music fadeout 3.0
a nngh "Wait, wait, WAIT!"
hide m hm 
show s surprised at center, shake:
 ease 0.4 yalign 0.1 zoom 2.0
show ring at shake
"I stand up and grab Sebas by the collar, pulling him lower to my eye level."

a nngh  "Who the hell told you to make decisions for me?! You think I’m just going to let you rack up my debt if you lose?!"
s "…"
s stan "I won’t lose, {i}Ángel{/i}."
s "It’s okay to ask for help sometimes."
a scared "…!"
pause 1.5
a concern "Just who the hell are you?"
pause 1.5
s smile "I already told you. {w}A friend."
pause 2.0

"I stare into those onyx eyes that are looking right back into my soul as we have one last silent conversation through our gazes alone."

a concern "{i}How do I know I can trust you…?"
pause 1.5
s hm "{i}You don’t.{w} You're just gonna have to take my word for it."

"Yet another wager."
pause 2.0
show s surprised 
a worried "Okay…"

"I let go of him, and he stands up straight again, giving me a soft, assured smile."
show s surprised at slightright:
 yalign 0.1
 ease 0.5 zoom 1.0
show m clothes1 hm at slightleft with dissolve 
m "Are you two done? Can we get on with this?"
s smile "With pleasure."
hide m hm 
hide s smile 
hide ring
with dissolve 
play music dissonance
"Sebas takes my seat at the table, and I’m forced to stand next to Thomas, unable to see either of their cards. This works out better for both of us. I don’t think I’d be able to hide the emotions on my face if I saw Sebas’ cards."
"I swallow hard, both men in front of me showing me nothing on either of their expressions. The once warm and kind façade from Matteo’s smile is nowhere to be seen, now replaced with a cold, calculating glare."
"Sebas glances at me through the corner of his eyes as Matteo explains the rules to him. Am I supposed to help him out in any way? I’m so confused… and close to puking my guts out."
show ring
show m clothes1 hm at slightleft
show s body uniform stan at slightright
with dissolve 
m "You got all that?"
s "…"
m cocky "What? Getting cold feet?"
show m surprised 
s hm "No. I’m just curious why you use an automatic shuffler. Not even Corona’s uses one."

"I frown. So he {i}did{/i} go to Corona’s?"

m cocky "It’s just to ensure the shuffle is truly random. Nothing else to it."
s stan "Is that right?"
pause 2.0
show s body2 uniform2 cocky2 with qdis
show m surprised 
s "Would you care if we just let the dealer shuffle for us?"
pause 1.5
m hm "Why, exactly?"
show s body uniform smile with qdis 
s "To make it fair, of course."
m angry "Are you insinuating I’m cheating?"
s "No."
show s body2 uniform2 cocky2 with qdis
s "I’m… hm, what’s the word? ‘Stating’? Yes, I’m ‘stating’ that you’re cheating."
m "…"

"Matteo looks into Sebas’ eyes with silent fury etched into them, clenching his jaw so tight I’m scared for his teeth."
show s body uniform smile with qdis  
m "That’s a {i}bold{/i} claim, whatever-your-name-was."
s "It’s Sebas."
show s hm 
m "Whatever. I don’t have to sit here and take this slander from some punk who thinks he’s hot shit."
show m nervous 
s "Slander? I can prove it, if you’d like. I mean, even the fact that you’re getting so defensive about letting your dealer shuffle is telling in its own way."
show s body2 uniform2 cocky2 with qdis
s "But I’ll admit, it’s a {i}very{/i} elaborate cheat. I bet no one’s ever noticed it before, have they?"
a concern "What… do you mean?"
show s body uniform cocky with qdis 
"Sebas looks over to me, a smug grin on his face."
show m angry 
s "I can’t blame you for not noticing, {i}chele{/i}. Unless you know cards well, you probably would’ve never caught it. Hell, even I had a hard time keeping up."
s "And obviously, the culprit is the machine."
show 1-csgreen with dissolve 
s "It’s performing a perfect faro shuffle. The deck is split in half, and when they’re shuffled, each card gets interweaved through the other deck via the machine. That alone isn’t a cheat, though."
show 1-standeck with dissolve 
hide 1-csgreen 
s "The real trick comes from the deck itself. You weren’t shown the order before it was placed into the machine, right, Angel?"
a concern "No… but it was a brand-new deck. Aren’t they all the same order, anyway?"
s "Normally, yes. However, this one wasn’t."
s "It had a completely different order… a very specific one. Does the Joyal deck ring any bells, Matteo?"
m "…!?"
a hm "Joyal?"
show 1-joyaldeck with dissolve 
pause 0.5
hide 1-standeck 
s "It’s a specific pattern of a deck of cards used for different kinds of magic tricks. Matteo here must have them custom made, fresh in the pack."
s "In other words, the cards weren’t ever going to be randomized."
s "Whether it was an out or in faro shuffle, each of your hands were predetermined from the very beginning. He must have memorized the outcome of each hand and betted accordingly."
hide 1-joyaldeck with dissolve 
pause 0.5
show m glare 
show s body2 uniform2 hm2 with qdis
s "What I don’t understand are the jokers… two extra cards messes with the order of the Joyal deck. My guess… a specific button that pushes them out, maybe?"
m "…"
s cocky2 "It's so subtle. So many different moving parts in such a tiny machine... you must have had this custom built as well. Oh, what money can buy, aye?"
s "But, well… this is all speculation. You’re welcome to clear your name, Matteo. I’m open to be proven wrong."
show m angry 
show s body uniform cocky with qdis
s "But I’m right, aren’t I? You can’t {i}really{/i} play cards. You’re just some Hollywood Hills frat douche playing casino with Daddy's money and scamming those weaker than you to, what? Get his approval?"
pause 2.0
show m surprised 
stop music fadeout 0.5 
s angry "Why don’t you gamble like a real man instead of cheating like a pussy?"
play sound thump
show m angry at jumping
show ring at shake 
pause 2.0
show s stan 
play music stakes 
m "You motherfucker…! Just who the hell do you think you are?!"
s "My name’s Seb-"
show ring at shake 
m "I DON’T GIVE A FUCK!! If you think you know a SINGLE thing about me, you’re dead fucking wrong!!"
m arrogant "Yeah, I’ll admit it. I cheated. This is MY ring, and I can do whatever the FUCK I want! And if you think you’re gonna change that, then you’re an even bigger idiot than this Valentine!!"
show m angry 
a flustered "{i}Why am I catching strays…?"
pause 2.0
show m angry
s hm "You know, maybe you’re right, Matteo. I thought you’d be willing to gamble with me even without the cheat, but…"
show m surprised 
show s body2 uniform2 cocky2 with qdis
s "I guess I really am a fool to ever think you’d be capable of doing that."
m "…"
show s hm2 
show m glare 
"Matteo sinks back into his seat, almost in slow motion, staring daggers at Sebas as he quietly seethes for a moment."
pause 2.0
show s body uniform stan with qdis 
m cocky "You’ve got balls, Sebas, I’ll give you that. Spying on our game, calling me out in front of my staff, disrespecting me. You’re lucky I haven’t shot you square between the eyes."
m arrogant "But you know what? I respect it."
m "So I will play. And I’ll make sure to get every penny of those fifty-thousand dollars from that black card of yours when I win."
m angry "And if I ever see your stupid face again…{w} I’ll kill you right where you stand."
pause 2.0
s flirty "Now we’re talking."
m serious "Thomas. Go get a normal deck."
show s smile 
"Thomas nods, disappearing somewhere for a moment."

a concern "{i}Wait a minute… so I was being screwed over from the very beginning?"
a sad "{i}Maybe Ethan was right… I’m not cut out for this. If I couldn’t even tell I was being conned on my first ever gamble, what business do I have being here?"
a worried "{i}…I guess it’s too late to back out now."

"Thomas reappears with a deck of cards in his hands, opening the pack and spreading it through the table with the precision of a magician. Sure enough, the cards are in the order you’d expect, from ace to king."
"He then grabs them all up again, cuts the deck in two and gives them a shuffle, repeating this process about three more times before finally dealing out the cards, four for each, just like before."
hide s smile 
hide m serious 
with dissolve 
a "{i}With the bets already placed… that means there’s no bluffing this time. It’s a game of pure luck."
a "{i}How the hell is Sebas going to win like this??"

s "…"
m "…"
dealer "You… may reveal your cards at any time."
pause 2.0
s "I’m surprised you ended up agreeing to this in the end. I suppose the Milan’s do have a bit of honor left."
m "You gonna play, or what?"
pause 2.0
dealer "At the count of three, then, gentlemen… please reveal your cards."
dealer "One…"
dealer "Two…"
dealer "Three."
pause 1.5
a surprised "…!"
"They both have complete pigs... but Sebas has an Ace! He wins with the high card!"
s "{i}Comiste mierda, gomelo.{/i} Looks like I win."
show s body uniform cocky at slightright
show m clothes1 angry at slightleft 
with dissolve 
stop music fadeout 2.0
"I breathe out a heavy, shaky sigh of relief, chills running through my whole body. He really did win… from the hairs of his chin, but a win is a win."
"Matteo stares at the cards on the table, seething in a way I don’t think I’ve seen anyone do before, his paws clenched so tight that his claws must be digging into his pads."
"Sebas, on the other hand, just stands up, as calm and collected as ever."
hide m angry with dissolve 
show s smile at center with move 

s "Well, I can’t say I didn’t enjoy this, but it’s getting quite late now. {i}Ángel, ¿nos vamos?{/i}"

"Instinctively, somehow, I know that means we should get the hell out of here. I nod, still shaken by the entire ordeal, as if I just woke up from a fever dream."
show s stan 
"Sebas places his large paw on my lower back and starts to lead me to the doorway, when we hear Matteo slam the table, his chair sliding backwards."
show s stan at slightright with move 
show m clothes1 glare at slightleft with dissolve 
m "Don’t think for a second this is over, Valentine! Your pimp may have saved you this time, but you’re not safe anymore."
show s frown 
m angry "You're deep in my world now, {i}Angel{/i}. And I won't let you forget it."
a concern "…"
s stan "Come on. Let’s go."
hide s stan with dissolve 
"Sebas nudges me to start walking again, and the last thing I see as we exit the room is Matteo’s eyes glaring deep into mine…"
hide m angry 
hide ring
with dissolve 
"The bar is mostly empty once we walk out, and Sebas leads me towards a different exit of the bar, the back door. It leads to a dark alleyway full of dumpsters, but the cold midnight breeze carries the smell somewhere else."
show alleyway 
show s body uniform stan
with dissolve 
play music city 
s "Stay here for a second."
a hm "Why?"
s hm "I’m going to check if the coast is clear."
a "Is that really necessary?"
s "If you don’t want people seeing a Valentine come out of a bar that’s rumored to be a gambling ring this late, then yes, I think so."
a surprised "…"
show s smile 
a pout "Touché."
hide s smile with dissolve 
pause 1.5
a stan "…"

"I blink, my eyelids heavy but my mind feeling wide awake. Did all of that really just happen?"
"I was almost fifty-thousand dollars deeper in debt… That’s my {i}entire{/i} debt right now to the Valentine Agency. I really {i}would{/i} have spent my whole life paying that off, and then some."
"How could I be so stupid…? I was conned, then rescued, and by some miracle walked away like nothing ever happened. But something did happen, and Matteo’s parting words echoes in my mind."
"I’ve bitten the fruit.{w} No way back to Eden now."
show s body uniform stan with dissolve 
s "Okay, it’s good. Come on."
hide alleyway 
hide s stan 
with dissolve
show streetsnight
show s body uniform stan
with dissolve 
"I hug myself as we walk onto the sidewalk, the chilly air only deepening my nerves. I feel like the world’s ending, for some reason. Like I’m still at that table…"
show s body2 uniform2 cocky2 with qdis 
s "What a rush, ‘ey, {i}chelito?"
stop music fadeout 1.0
a concern "…"
show s body2 hm2 
play music noir 
a "You owe me {i}a lot{/i} of explanations."
a "What were you doing down there? Why were you spying on our game? Why did you help me?"
pause 0.8
show s body2 stan2 
a angry "Who are you…?"
show s body uniform stan with qdis 
pause 1.5
s "…"
s smile "You know what? I’m starving."
s "There’s a diner open twenty-four hours not too far from here. Wanna check it out?"
pause 1.0
"I really don’t. But something tells me I won’t get my answers otherwise…"
pause 1.0
a hm "I could eat."
stop music fadeout 1.0
hide streetsnight 
hide s smile 
with dissolve 
pause 0.6
show dinernight
show s body uniform stan 
with dissolve 
play music ambience 
"A short, quiet walk later, Sebas and I are seated face-to-face inside a booth of a cheap diner, the restaurant completely empty aside from us. Sebas spins a straw in one hand over and over again, in an almost hypnotizing motion."
"An older woman takes our order. Sebas asks if they’re still serving food, and the lady replies no (obviously). So he orders a slice of pie instead.{w} I just get a water."
"She walks away, probably wondering to herself what the hell a Valentine and some Hispanic guy are doing here in the middle of the night. I can’t say I blame her. I’m wondering the same thing."
pause 2.0

s smile "Ever been here before?"
a hm "Can’t say I have. You?"
s "Once or twice."
show s stan 
a "I thought you were a tourist."
s hm "I never said that."
a frown "You implied it."
s cocky "I imply a lot of things."
a hm "…"
pause 1.1
"Whatever the fuck {i}that{/i} means."
show s smile 
pause 2.0
show s surprised 
a frown "How did you know you’d win?"
s "Hm?"
a "The poker game. How’d you win?"
show s stan 
pause 2.0
show s body2 uniform2 cocky2 with qdis
s "Oh, that?{w} I just got lucky."
pause 1.8
a concern "What?"
s "I had no idea what was going to happen there. I figured he’d challenge me to a regular game of poker, not that four-card bullshit. But, it worked out for me in the end."
show s body uniform cocky with qdis 
s "A little anticlimactic, but hey. That’s just how gambling is. Highs and lows."
a scared "…"
show s surprised 
a "You risked fifty-thousand dollars on a game you weren’t even sure you’d win? How would you have paid it off if you lost?!"
show s amused 
"Sebas just keeps on twirling the straw, an amused smile on his face as he stares at the table."

s "I have my ways. As for the risk…"
s smile "If you don’t risk, you’re guaranteed to fail. If you do risk, there’s at least a chance you’ll win. One percent is better than zero, no?"
pause 2.0
a concern "That’s... an insane mentality to have."
s flirty "Hah. Maybe. But you have to be a little crazy to gamble in the first place."
show s smile 
"The waitress comes back and sets Sebas’ pie in front of him, and he gives her a kind smile. To my surprise, she returns it, despite her grumpy demeanor."
"I watch as he shovels a large forkful of lukewarm apple pie down his maw, thinking back to our meeting at Shogey’s, then The Albatross, then in Matteo’s ring…"
pause 1.5
show s surprised 
stop music fadeout 2.0 
a stan "What are you after?"
pause 1.5
s "How do you mean?"
play music darkjazz 
a frown "You asked me for a place to gamble even though you knew about The Albatross and Corona’s. You approached me at the bar to tell me how to get inside, and then proceeded to follow me in without my knowledge."
a angry "And to top it all off, spied on my poker game and saved me from the con. All of that… for what?"
a "What are you after, ‘Sebas’? Is that even your real name?"
show s stan 
pause 2.0
s "Is ‘Angel’ yours?"
pause 2.0
a dejected "…"
s lookaway "What I’m after…"
show s stan 
"He shoves another bite of pie into his mouth, looking right back at me."

s hm "I wouldn’t say I’m ‘after’ anything. But I do have a dream."
pause 1.5
a concern "A dream?"
s smile "Yes. Don’t you?"
a surprised "…"
a bashful "You’re the second person to ask me that today…"
show s stan 
pause 2.0
a dejected "No. I don’t have a dream."
a "I’m a Valentine. We don’t get to dream."
s "Everyone is allowed to dream. Your thoughts are the one thing that are completely your own."
show s body2 uniform2 hm2 with qdis
s "I believe you have a dream, somewhere inside you. You must be too scared to admit what it is."
show s body uniform stan with qdis 
s "Because then… you’ll want to fight for that dream."
a concern  "…"
a hm "Well… what’s your dream?"
pause 1.5
s lookaway "My dream…"

"He looks out the window to the deserted streets of Sonora… or, maybe at his own reflection against the glass. I’m not sure. But his eyes keep that razor sharp focus they always seem to have."
pause 2.0
stop music fadeout 2.5
s stan "My dream…{w} is to destroy Corona’s Casino."
pause 3.0
show s smile 
"And then he takes another bite, as if he didn’t just say that."
hide dinernight 
hide s smile 
with dissolve 
pause 0.7
show streetsnight with fade 
play music noir 
"We spend the rest of our time there in silence. I offer to pay Sebas for the pie, as a thank you for saving me, but he simply shoos me away. Something about being a gentleman."
"We walk outside again, and Sebas stays by my side as we wait for a cab to pass by. I’m exhausted, my brain feels foggy, and my nerves are at high alert. I feel like my entire body is buzzing with anxiety."
"I sneak a glance at the wolf next to me, wondering when the hell I got caught in his web. There’s more, so much more I want to talk about, to ask, to wring out of him… but I know I can’t right now."
show s body uniform stan with dissolve 
"A cab finally stops in front of us, and Sebas opens the back door for me. I’m about to slip inside the taxi when he and I lock eyes… {w}and my heart skips a beat."
show s surprised 
"Sebas… those eyes seem to hold a familar sadness behind them. Why do I feel like I've seen them before?{w} What secrets lie beyond that smile?"
pause 1.7
"And why do I want to find out?"
pause 1.7
show s stan 
a worried "Sebas…?"
s smile "Yes, {i}chele?"
pause 2.0
show s surprised 
a concern "Your dream…{w} I want to help make it a reality."
pause 2.0
s "…"
show s amused 
"The words slip out of my mouth before I can stop them, and as I’m left wondering why I even said that, Sebas just smiles at me."

s flirty "Yeah? Well… I’ll be counting on you then, {i}chele."
a stan "…"
hide streetsnight
hide s flirty 
with dissolve
pause 0.7 
"As the driver takes me home, Corona’s peeks through the cluster of buildings in this dark city, making its presence known at every possible second of my existence."
"Mr. Gray must be in there now, sitting in his big, fancy desk, doing whatever it is that billionaires do in their free time. Is he thinking of me, the way I am thinking of him now?"
"The offer to change my life seemed so ludicrous at the time. Now I wonder… if I should have taken it after all?"
pause 2.0
"I guess it doesn’t matter anymore."
pause 1.8
stop music fadeout 3.0
"After all... {w}this game has only just begun."
pause 3.0
"{i}To Be Continued…"
pause 2.0
return 