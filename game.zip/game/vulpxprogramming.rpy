
init python:
    config.developer = True

image vulpxprograming = Transform("images/translate/vulpxprograming.png", xysize=(2560, 1440))
