﻿# CHARACTERS #
define a = Character("Angel", color="#FFFFFF", image="a")
define a1 = Character("Angel", color="#FFFFFF")
define e = Character("Ethan", color="#EDBC32", image="e")
define s = Character("Sebas", color="#9E9191", image="s")
define m = Character("Matteo", color="#48B023", image="m")
define v = Character("Mr. Valentine", color="#9E1E1E", image="v")
define mk = Character("Mika", color="#64DAED", image="mk")
define c = Character("Cameron", color="#F74DAB", image="c")
define l = Character("Leonidas Grey", color="8C1EC9", image="l")
define y = Character("Mr. Yoshida", color="248F48", image="y")
define anon = Character("???", color="A1A1A1")
define dealer = Character("Dealer", color="A1A1A1")
define guard = Character("Guard", color="A1A1A1") 
define guard2 = Character("Other Guard", color="A1A1A1") 
define mom = Character("Mom", color="D47B13")
define ba = Character("Bartender", color="248F48")

##ANGEL LAYERED SPRITES##
layeredimage side a:
  
  group body:
     attribute body default:
      "images/Angel sprites/a_body.png"  
     attribute body2:
      "images/Angel sprites/a_body2.png"  
  group clothes:    
    attribute uniform:
      "images/Angel sprites/a_uniform.png"

  group expressions:
    attribute stan:
      "images/Angel sprites/a_stan.png"
    attribute thinking:
      "images/Angel sprites/a_thinking.png"
    attribute smile:
      "images/Angel sprites/a_smile.png"
    attribute bashful:
      "images/Angel sprites/a_bashful.png"
    attribute frown:
      "images/Angel sprites/a_frown.png"
    attribute concern:
      "images/Angel sprites/a_concern.png"
    attribute worried:
      "images/Angel sprites/a_worried.png"
    attribute surprised:
      "images/Angel sprites/a_surprised.png"
    attribute flustered:
      "images/Angel sprites/a_flustered.png"
    attribute angry:
      "images/Angel sprites/a_angry.png"
    attribute hm:
      "images/Angel sprites/a_hm.png"
    attribute pout:
      "images/Angel sprites/a_pout.png"
    attribute hmph:
      "images/Angel sprites/a_hmph.png"
    attribute bored:
      "images/Angel sprites/a_bored.png"
    attribute superhmph:
      "images/Angel sprites/a_superhmph.png"
    attribute excited:
      "images/Angel sprites/a_excited.png"
    attribute eyeroll:
      "images/Angel sprites/a_eyeroll.png"
    attribute flattered:
      "images/Angel sprites/a_flattered.png"
    attribute cocky:
      "images/Angel sprites/a_cocky.png"
    attribute silly:
      "images/Angel sprites/a_silly.png"
    attribute dejected:
      "images/Angel sprites/a_dejected.png"
    attribute sad:
      "images/Angel sprites/a_sad.png"
    attribute flirty:
      "images/Angel sprites/a_flirty.png"
    attribute blush:
      "images/Angel sprites/a_blush.png"
    attribute yeesh:
      "images/Angel sprites/a_yeesh.png"
    attribute scared:
      "images/Angel sprites/a_scared.png"
    attribute nngh:
      "images/Angel sprites/a_nngh.png"
    attribute sob:
      "images/Angel sprites/a_sob.png"
    attribute frown2:
      "images/Angel sprites/a_frown2.png"
    attribute hm2:
      "images/Angel sprites/a_hm2.png"
    attribute confident:
      "images/Angel sprites/a_confident.png"
    attribute grin:
      "images/Angel sprites/a_grin.png"
    attribute pissed:
      "images/Angel sprites/a_pissed.png"

##SEBAS LAYERED SPRITES##
layeredimage s:

  group body:
    attribute body default:
      "images/Sebas sprites/s_body.png"
    attribute body2:
      "images/Sebas sprites/s_body2.png"

  group clothes:
    attribute uniform:
      "images/Sebas sprites/s_uniform.png"
    attribute uniform2:
      "images/Sebas sprites/s_uniform2.png"

  group expressions:
    attribute stan:
      "images/Sebas sprites/s_stan.png"
    attribute stan2:
      "images/Sebas sprites/s_stan2.png"
    attribute hm:
      "images/Sebas sprites/s_hm.png"
    attribute hm2:
      "images/Sebas sprites/s_hm2.png"
    attribute smile:
      "images/Sebas sprites/s_smile.png"
    attribute grin:
      "images/Sebas sprites/s_grin.png"
    attribute cocky:
      "images/Sebas sprites/s_cocky.png"
    attribute cocky2:
      "images/Sebas sprites/s_cocky2.png"
    attribute amused:
      "images/Sebas sprites/s_amused.png"
    attribute lookaway:
      "images/Sebas sprites/s_lookaway.png"
    attribute surprised:
      "images/Sebas sprites/s_surprised.png"
    attribute flirty:
      "images/Sebas sprites/s_flirty.png"
    attribute frown:
      "images/Sebas sprites/s_frown.png"
    attribute angry:
      "images/Sebas sprites/s_angry.png"

##ETHAN LAYERED SPRITES##
layeredimage e:

  always:
      "images/Ethan sprites/e_body.png"

  group clothes:
    attribute uniform:
      "images/Ethan sprites/e_uniform.png"
    attribute pjs:
      "images/Ethan sprites/e_pjs.png"

  group expressions:
    attribute stan:
      "images/Ethan sprites/e_stan.png"
    attribute smile:
      "images/Ethan sprites/e_smile.png"
    attribute frown:
      "images/Ethan sprites/e_frown.png"
    attribute hm:
      "images/Ethan sprites/e_hm.png"
    attribute cocky:
      "images/Ethan sprites/e_cocky.png"
    attribute surprised:
      "images/Ethan sprites/e_surprised.png"
    attribute uh:
      "images/Ethan sprites/e_uh.png"
    attribute pout:
      "images/Ethan sprites/e_pout.png"
    attribute flattered:
      "images/Ethan sprites/e_flattered.png"
    attribute worried:
      "images/Ethan sprites/e_worried.png"
    attribute sigh:
      "images/Ethan sprites/e_sigh.png"
    attribute angry:
      "images/Ethan sprites/e_angry.png"
    attribute concern:
      "images/Ethan sprites/e_concern.png"
    attribute blush:
      "images/Ethan sprites/e_blush.png"
    attribute flirty:
      "images/Ethan sprites/e_flirty.png"

##MATTEO LAYERED SPRITES##
layeredimage m:

  always:
      "images/Matteo sprites/m_body.png"

  group clothes:
    attribute clothes1:
      "images/Matteo sprites/m_clothes1.png"

  group expressions:
    attribute stan:
      "images/Matteo sprites/m_stan.png"
    attribute cocky:
      "images/Matteo sprites/m_cocky.png"
    attribute serious:
      "images/Matteo sprites/m_serious.png"
    attribute sweet:
      "images/Matteo sprites/m_sweet.png"
    attribute apologetic:
      "images/Matteo sprites/m_apologetic.png"
    attribute surprised:
      "images/Matteo sprites/m_surprised.png"
    attribute hm:
      "images/Matteo sprites/m_hm.png"
    attribute amused:
      "images/Matteo sprites/m_amused.png"
    attribute wink:
      "images/Matteo sprites/m_wink.png"
    attribute peek:
      "images/Matteo sprites/m_peek.png"
    attribute angry:
      "images/Matteo sprites/m_angry.png"
    attribute arrogant:
      "images/Matteo sprites/m_arrogant.png"
    attribute nervous:
      "images/Matteo sprites/m_nervous.png"
    attribute glare:
      "images/Matteo sprites/m_glare.png"

##LEONIDAS GREY LAYERED SPRITES##
layeredimage l:

  always:
      "images/Grey sprites/l_body.png"

  group clothes:
    attribute suit:
      "images/Grey sprites/l_suit.png"

  group ontop:
    attribute coat:
      "images/Grey sprites/l_coat.png"

  group expressions:
    attribute stan:
      "images/Grey sprites/l_stan.png"
    attribute serious:
      "images/Grey sprites/l_serious.png"
    attribute cocky:
      "images/Grey sprites/l_cocky.png"
    attribute smirk:
      "images/Grey sprites/l_smirk.png"
    attribute ponder:
      "images/Grey sprites/l_ponder.png"
    attribute surprised:
      "images/Grey sprites/l_surprised.png"
    attribute hm:
      "images/Grey sprites/l_hm.png"
    attribute disappointed:
      "images/Grey sprites/l_disappointed.png"
    attribute shocked:
      "images/Grey sprites/l_shocked.png"
    attribute peek:
      "images/Grey sprites/l_peek.png"
    attribute grin:
      "images/Grey sprites/l_grin.png"    
    attribute angry:
      "images/Grey sprites/l_angry.png" 

##MR. VALENTINE LAYERED SPRITES##
layeredimage v:

  always:
      "images/Valentine sprites/v_body.png"

  group clothes:
    attribute clothes:
      "images/Valentine sprites/v_clothes.png"

  group expressions:
    attribute stan:
      "images/Valentine sprites/v_stan.png"
    attribute surprised:
      "images/Valentine sprites/v_surprised.png"      
    attribute glare:
      "images/Valentine sprites/v_glare.png"
    attribute hm:
      "images/Valentine sprites/v_hm.png"
    attribute frown:
      "images/Valentine sprites/v_frown.png"

##MIKA LAYERED SPRITES##
layeredimage mk:

  always:
      "images/Mika sprites/mk_body.png"

  group clothes:
    attribute clothes:
      "images/Mika sprites/mk_clothes.png"

  group expressions:
    attribute stan:
      "images/Mika sprites/mk_stan.png"
    attribute surprised:
      "images/Mika sprites/mk_surprised.png"
    attribute hm:
      "images/Mika sprites/mk_hm.png"
    attribute worried:
      "images/Mika sprites/mk_worried.png"    
    attribute flattered:
      "images/Mika sprites/mk_flattered.png"  
    attribute concern:
      "images/Mika sprites/mk_concern.png"  

##CAMERON LAYERED SPRITES##
layeredimage c:

  always:
      "images/Cameron sprites/c_body.png"

  group clothes:
    attribute clothes:
      "images/Cameron sprites/c_clothes.png"

  group expressions:
    attribute stan:
      "images/Cameron sprites/c_stan.png"
    attribute serious:
      "images/Cameron sprites/c_serious.png"
    attribute grin:
      "images/Cameron sprites/c_grin.png"
    attribute uh:
      "images/Cameron sprites/c_uh.png"
    attribute hm:
      "images/Cameron sprites/c_hm.png"
    attribute disappointed:
      "images/Cameron sprites/c_disappointed.png"
    attribute surprised:
      "images/Cameron sprites/c_surprised.png"
    attribute pout:
      "images/Cameron sprites/c_pout.png"
    attribute flirty:
      "images/Cameron sprites/c_flirty.png"
    attribute worried:
      "images/Cameron sprites/c_worried.png"
    attribute cocky:
      "images/Cameron sprites/c_cocky.png"

##MR. YOSHIDA LAYERED SPRITES##
layeredimage y:

  always:
      "images/Yoshida sprites/y_body.png"

  group clothes:
    attribute clothes:
      "images/Yoshida sprites/y_clothes.png"

  group expressions:
    attribute stan:
      "images/Yoshida sprites/y_stan.png"
    attribute sweet:
      "images/Yoshida sprites/y_sweet.png"
    attribute smile:
      "images/Yoshida sprites/y_smile.png"
    attribute frown:
      "images/Yoshida sprites/y_frown.png"
    attribute hm:
      "images/Yoshida sprites/y_hm.png"
    attribute cocky:
      "images/Yoshida sprites/y_cocky.png"
    attribute surprised:
      "images/Yoshida sprites/y_surprised.png"
    attribute ponder:
      "images/Yoshida sprites/y_ponder.png"

# TRANSFORMS #
transform jumping:
    linear 0.05 yoffset -20
    linear 0.05 yoffset 0

transform slightright:
    xalign 0.75
    yalign 1.0

transform rightish:
    xalign 0.60
    yalign 1.0

transform slightleft:
    xalign 0.25
    yalign 1.0
 
transform leftish:
    xalign 0.35
    yalign 1.0
    
transform jitter(rate=0.090):
    linear rate xoffset 2 yoffset -6
    linear rate xoffset -2.8 yoffset -2
    linear rate xoffset 2.8 yoffset -2
    linear rate xoffset -2 yoffset -6
    linear rate xoffset +0 yoffset +0
    repeat

transform shake:
    linear 0.2 xoffset -20 
    linear 0.2 xoffset 0 

init:

    $ slower_dissolve = Dissolve(5.0)
    $ farleft = Position(xpos=0.12, xanchor='center')
    $ farright = Position(xpos=0.9, xanchor='center')


define qdis = Dissolve (0.1)
define hdis = Dissolve (0.5)
define sdis = Dissolve (2.0)

default persistent.menu_bg = "default"

image animated_menu_bg = ConditionSwitch(
    "persistent.menu_bg == 'default'", "gui/main_menu_default.png",
    "True", "gui/main_menu_variant.png",
    predict_all=True
)

define tr_text = Character(None, 
    what_style="centered_text",
    what_xalign=0.1,           
    what_yalign=-2.4,            
    what_text_align=0.0,
    window_background=None
)

define tr_text2 = Character(None, 
    what_style="centered_text", 
    what_xalign=0.05,            
    what_yalign=-2.4,            
    what_text_align=0.0,
    window_background=None
)

define tr_text3 = Character(None, 
    what_style="centered_text", 
    what_xalign=0.15,            
    what_yalign=-3.0,            
    what_text_align=0.0,
    window_background=None
)

define a_text = Character(None, 
    what_style="centered_text", 
    what_xalign=0.7,            
    what_yalign=0.2,           
    what_text_align=0.5,
    window_background=None
)
label start:
  scene vulpxprograming with dissolve
  "Hi! I'm Vulpx, the person who translated this novel. I hope you enjoy the experience."
  "If you want to know more about my work, you can follow me on {a=https://x.com/VulpxVenandi25}{color=#00acee}Twitter{/color}{/a} or visit my {a=https://vulpxvenandi25.github.io/}{color=#004030}Website{/color}{/a}."
  "You can also support me with a donation at my {a=https://ko-fi.com/vulpxvenandi25}{color=#FF5E5B}Ko-fi{/color}{/a}."
  "And without further ado, I leave you with this novel called \"[config.name]\"."
  scene black
jump act1 
